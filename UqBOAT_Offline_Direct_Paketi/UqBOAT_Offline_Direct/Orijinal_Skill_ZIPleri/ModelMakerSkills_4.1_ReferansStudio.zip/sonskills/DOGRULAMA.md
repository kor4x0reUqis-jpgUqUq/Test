# Doğrulama ve açık sınırlar — 4.1.0

Tarih: **2026-10-24**. Bu dosya beceri paketinin kanıt kapsamını anlatır; gerçek bir haritanın birebir tamamlandığına dair onay değildir.

## Yapılan kontroller

| Kontrol | Sonuç | Ne kanıtlar / kanıtlamaz |
|---|---|---|
| Resmî Luau0.743 derleyicisi + Python parse | 34 dosya kontrolü PASS | Syntax; Studio yürütmesi değil |
| Saf matematik + aynı adapter kaynaklarının test-double ortamı | **45 PASS / 0 FAIL** | World/local, ölçek, SAT/ray, projection/renk/tile, state gate, gerçek kod akışının mock yüz audit/rollback/kamera davranışı |
| Bağımsız Python mesh kontrolü | PASS | 72 vertex/140 triangle; her kenar2 zıt yön; Euler2, nondegenerate, pozitif volume. Tam self-intersection/collider/görsel onay değil |
| Kaynak06 yaklaşık kamera fit | **REJECTED** | Yaklaşık anotasyon/3B tahminler sıkı uyum vermedi; toleransı aşma/sınıra dayanma gizlenmedi. Başarılı kaynak kalibrasyonu diye kullanılmaz |
| Bilinen pozlu sentetik kamera fit | Sayısal PASS | Hesaplayıcının sentetik veride doğruluğu; gerçek kaynak ölçüsü değil |
| 35 kullanılan API sembolü ve ilgili enumlar | Güncel API dump'ta mevcut | İsim/tür/güvenlik metadatası; gerçek izin/çalışma değil |
| 80 vaka, 16 kaynak provenansı, family-disjoint bölmeler | Paket validator'ı denetler | Şema/yol/hash/bölme; insan etiket kalitesi veya AI başarı skoru değil |
| Orijinal skill/park/liman arşiv hash'leri | Eşleşti | Bu görevde eski teslimler değiştirilmedi |

Ayrıntılı makine kayıtları `validation/` altındadır. Derleyici binary'leri pakete gömülmedi; resmi release URL'si syntax raporundadır.

## Özellikle test edilen yeni hatalar

- Source Model ID'sini image sanma, type/access/fetch hatasında engel.
- İlk adayı/kuponu otomatik onaylamama; fetch≠görsel.
- Kupon değişirse veya scale/contrast/URI/yön/katman bozulursa kurulum engeli.
- Required-studs görevinde dokusuz main build yapılamaması.
- Kurulumdan önce/sonra maskeyi değiştirerek yüz eksikliğini gizleyememe.
- Tam mini iskele/depo builder'ının gerçek SAT temas/kapı ışını ve bütün yüzleri — **mock** ortamında.
- Yabancı aynı isimli modeli silmeme; own replacement açık onay ve önceki sahneyi backup; başarısızlıkta rollback.
- Default kupon/kurulumda kamera write0; optionalcapture başarı/hata yollarında restore; nil subject atamama; kamera değişiminde yenisini ezmeme.
- Sayısal geçişi final referans/görsel kabulüne otomatik dönüştürmeme.

Test doubles, gerçek Roblox davranışının tamamını taklit etmez. `tests/MockStudio.luau` içindeki image numarası tamamen hayali fixture'dır; ağ veya gerçek asset değildir. Bu ID hiçbir Studio örneğinin gerçek doku kaynağı olarak dağıtılmaz.

## Yapılmayanlar — durumları değiştirilmedi

- **Gerçek Roblox Studio'da bu yeni kurulumların çalıştırılması: NOT_RUN.**
- Model9454666962'ye canlı erişim; gerçek image URI/fetch/motif/izin: **NOT_RUN**. URI alanı null.
- İnsan tarafından gerçek doku kuponu onayı ve gerçek sahne uygulaması: **NOT_RUN**.
- Referansla dokulu görsel kabul, tekne/UV/collider/avatar/editor/save-reopen: **NOT_RUN**.
- FPS/bellek/cihaz/kalite/yayın testi: **NOT_MEASURED**; sayılar null.
- AI ağırlık eğitimi, zayıf/başka AI'larla davranış benchmark'ı: **YAPILMADI**.

Kullanıcının mevcut liman Studio görüntüsü, o önceki dosyanın kendi ekranında görünmesine dair kanıttır; bu yeni skill örneklerinin ajan tarafından Studio'da yürütüldüğü anlamına gelmez. Kullanıcının 'diğer her şey iyi' ifadesi genel yerleşim/sonuç için olumlu; dört hata kapsam dışı tutulur.

## Yeniden kontrol

Paket bütünlüğünü **değiştirmeden**:

```sh
python tools/verify_package.py
```

Resmî Luau binary'si varsa:

```sh
luau tests/run_all.luau
luau-compile examples/01_Depolu_Iskele_CommandBar.luau
```

Kaynaklar değişirse önce `build_installers.py`, sonra `validate_all.py --luau-dir ... --api-dump ...`; veri değişirse `build_training.py`. En son `build_index.py` ve `build_manifest.py`. Bu adımlar doğrulama dosyalarını yeniden yazar; manifest de tekrar üretilmelidir.

**Dürüst kabul:** Yeni skill paketi hazırlanmış ve çevrimdışı denetlenmiştir. Hiçbir yeni örnek “Studio'da testli, gerçek dokusu onaylı, birebir, her cihazda optimize” diye etiketlenmemiştir.

## 4.1 ek doğrulaması
Dört olumlu alt örneğin807kaynakPart verisi, yeni builderın actual mock sonucuyla konum/dönüş/boyut/renk/materyal/maske/collision düzeyinde karşılaştırıldı. Yeni kurulumlarda gerçek doku akışı ve kamera write0 aynı test-double kapsamında denetlendi. Source crop/çıktı aynı kamera değildir; tam görsel gold denmedi. Medya dosya kimlikleri overview ile ayrıca kontrol edildi.
