# Çözümlü hesaplar ve kod bağlantısı

Bu sayılar, belirtilen sözleşme için denetlenebilir örnektir. Kaynağın görünmeyen gerçek ölçüleri veya Studio testi diye sunulmaz.

## 1. Local → world biniş
Origin(-39,0,19), yaw−5°, local(-12,6.65,7.36) → **(-51.5958026437,6.65,25.2861240650)**.

```lua
local modelWorld=CFrame.new(-39,0,19)*CFrame.Angles(0,math.rad(-5),0)
local boardingWorld=modelWorld:PointToWorldSpace(Vector3.new(-12,6.65,7.36))
print(boardingWorld)
```

Yerel soketi döndürmek yerine tahmini world koordinatı yazmak, tekne dönünce biniş ucunu dışarı düşürebilir. Değmek yetmez: borda açıklığı/geçiş de denenir.

## 2. Tek root ölçeği
O(10,3,−5), yaw90°, local(2,4,6), scale2 → **(22,11,−9)**.

```lua
local root=CFrame.new(10,3,-5)*CFrame.Angles(0,math.rad(90),0)
local localPosition=Vector3.new(2,4,6)
local scale=2
local world=root*CFrame.new(localPosition*scale)
-- Rotation açısı90° olarak kalır; position ve size ölçeklenir.
```

## 3. Floor/header clear height
Header alt16, iç taban üst.8 → clear15.2. Dış kapı/duvar yüksekliği16 ile clear16 aynı değil. En32; iki ön panel8.4 → rawgap15.2; ribler.25 içeri girerse clear14.7.

## 4. Kazık boşluğu
207 genişlikte .34w−.33w=2.07 merkez farkı; yarı en toplamı1.50 → **.57 gerçek boşluk**. Testte epsilonu.6 yaparak PASS satın alma. Kazığı kirişin kendi merkez/soketinden üret.

## 5. Doku tile / motif
Bir gerçek image tile'ında4 motif; istenen motif aralığı1.25stud → **tileU=5stud**. Görseldeki motif sayısı önce kuponda görülür. Ana parçayı2kat büyütmek world-pitch-constant politikada tile boyutunu da2kat büyütmez.

## 6. Ekran hatası
Δ1(.02,0),w1; Δ2(0,.01),w3 → sqrt((.0004+.0003)/4)=**.0132287566 normalize RMS**. Kaynak belirsizliğine göre yorumla; tek başına silhouette/renk/geometri onayı değil.

## 7. Renk
sRGB.5 → linear.2140411405. İki kat ışık → linear.4280822810 → sRGB **0.6858361191**, yaklaşık **175**/255. Aynı ışıkta gözlenen renk, taban albedo değildir.

## 8. Kaynak06 pose fit: bir reddetme örneği
Yaklaşık2D ankrajlar + eski yeniden kurulum3D tahminleri, bu kayıtta normalize RMS **0.081324** verdi; ilan edilmiş .025 ölçüm toleransını aşar. Durum **REJECTED**. Parametre sınırına dayanma ayrıca kontrol edilir. Bu sayı iyi eşleşme diye sunulmaz; anotasyon/ölçüm/geometri varsayımı tekrar incelenmelidir. Kaynak kamera kalibre edildi veya birebirlik sağlandı denmez.

Ayrı sentetik kontrol, bilinen kamera nokta verisiyle yaklaşık **1.23e-13 RMS** elde etti. Bu sadece hesaplayıcının sentetik problemde doğru çalışabildiğinin testidir, kaynak06'nın ölçülerinin kanıtı değil. İki kayıt validation/camera_fit_*.json içindedir. Hiçbir kamera Studio'ya uygulanmadı.

## 9. Gerçek açık üstlü kabuk
6 istasyon, outer/inner profil, side/keel/gunwale/endwall. **72 vertex / 140 üçgen / 210 kenar**; her kenar2 zıt yön; signed volume **529.579080 stud³**; Euler2. İç dik ışın üstte kapak bulmaz, altta gerçek tabanı bulur.

Veri `hull_numeric.json` / `.obj`; teknik çizim `training/images/synthetic_hull.svg`; native laboratuvar `02_Tekne_Matematik_Lab_CommandBar.luau`. Bu kaynak teknelerin düzeltilmiş kopyası veya görsel gold değildir.

## 10. Motor ilişkisi
Part0World*C0*Transform*C1⁻¹. Menteşe root-local(2,0,0), wing-local(−4,0,0). Sıfır Transform'da Wing merkezi root'a göre x6 olur; 18° ImportPose'da wing merkezi pivot etrafında döner. İlk pozu gerçekten uygula. Kaynak klipler `03_Editable_Rig_Clips_CommandBar.luau` içinde; yayın ID'si uydurulmaz.
