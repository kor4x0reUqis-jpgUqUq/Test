"""Read-only stdlib integrity/contract/dataset validator, NOT an engine/AI benchmark.
Run after build_manifest.py. No Studio, image fetch or human visual acceptance is implied.
"""
from pathlib import Path
import json,hashlib,re,csv,collections,argparse,math
ROOT=Path(__file__).resolve().parent.parent

def load(path):return json.loads((ROOT/path).read_text(encoding='utf8'))
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def rows(path):return [json.loads(line) for line in (ROOT/path).read_text().splitlines() if line.strip()]
def validate_schema(value,schema,path='case'):
    typ=schema.get('type')
    if typ:
        ok={'object':isinstance(value,dict),'array':isinstance(value,list),'string':isinstance(value,str),'boolean':isinstance(value,bool),'number':isinstance(value,(int,float)) and not isinstance(value,bool),'integer':isinstance(value,int) and not isinstance(value,bool),'null':value is None}.get(typ,False)
        assert ok,f'{path}: wrong type {typ}'
    if 'const' in schema:assert value==schema['const'],f'{path}: const mismatch'
    if 'enum' in schema:assert value in schema['enum'],f'{path}: enum mismatch'
    if isinstance(value,str) and 'minLength' in schema:assert len(value)>=schema['minLength'],f'{path}: short text'
    if isinstance(value,dict):
        for key in schema.get('required',[]):assert key in value,f'{path}: missing {key}'
        properties=schema.get('properties',{})
        if schema.get('additionalProperties') is False:assert set(value)<=set(properties),f'{path}: unexpected key'
        for key,item in value.items():
            if key in properties:validate_schema(item,properties[key],path+'.'+key)
    if isinstance(value,list) and 'items' in schema:
        for i,item in enumerate(value):validate_schema(item,schema['items'],f'{path}[{i}]')

def verify(allow_no_manifest=False):
    checks=[]
    def passed(name,details):checks.append({'test':name,'status':'PASS','details':details})
    required=['SKILL.md','README.md','DOGRULAMA.md','CHANGELOG.md','VERSION.json','HIZLI_BASLANGIC.md','training/README.md','training/cases.jsonl','training/source_index.json','training/palette_liman.json','training/annotations_liman06.json','training/evaluation_rubric.json','schemas/training_case.schema.json','tools/StudioKit.luau','tools/Acceptance.luau','tools/CameraGuard.luau','tools/Math3.luau','tests/run_all.luau','examples/01_Depolu_Iskele_CommandBar.luau','examples/02_Tekne_Matematik_Lab_CommandBar.luau','examples/03_Editable_Rig_Clips_CommandBar.luau','examples/Hesaplar.md','catalogs/vfx_katalogu.json','catalogs/vfx_katalogu.csv','catalogs/assestvfxx.txt']
    for name in required:assert (ROOT/name).is_file(),f'Missing {name}'
    assert (ROOT/'SKILL.md').read_text().startswith('---\nname: sonskills\n')
    passed('structure_and_skill_entry',len(required))
    # Active references only: history is explicitly inactive and not the full old package.
    active=[p for p in ROOT.rglob('*.md') if 'history' not in p.relative_to(ROOT).parts]
    pattern=r'`((?:references|templates|tools|examples|training|validation|catalogs|schemas)/[^`\n]+\.(?:md|jsonl|json|luau|py|csv|png|jpg|svg|obj))`'
    count=0
    for p in active:
        for ref in re.findall(pattern,p.read_text()):
            if '*' in ref:continue
            assert (ROOT/ref).is_file(),f'Broken active reference {p.relative_to(ROOT)} -> {ref}';count+=1
    passed('active_reference_paths',count)
    pref=load('references/preferences.json')
    assert pref['studs']['source_model_id']==9454666962 and pref['studs']['expected_asset_type_id']==10
    assert pref['studs']['resolved_image_uri'] is None and pref['studs']['source_is_direct_image'] is False
    assert pref['camera']['default_writes'] is False and pref['primary_delivery']=='STANDALONE_STUDIO_EDIT_COMMAND_BAR_CODE'
    assert not pref['style']['hidden_part_or_code_budget'] and pref['animation']['editable_rig_and_keyframes_required_when_requested']
    passed('current_user_contract',{'model_source':9454666962,'installer_primary':True,'camera_default_readonly':True})
    catalogue=load('catalogs/vfx_katalogu.json')
    with (ROOT/'catalogs/vfx_katalogu.csv').open() as f:assert list(csv.DictReader(f))==catalogue
    assert len(catalogue)==389 and len({x['id'] for x in catalogue})==263
    passed('complete_vfx_catalogue',{'records':389,'unique':263})
    cases=rows('training/cases.jsonl');assert len(cases)==len({x['id'] for x in cases})
    schema=load('schemas/training_case.schema.json')
    families={};image_refs=0
    for item in cases:
        validate_schema(item,schema)
        family=item['family_id'];split=item['split'];families.setdefault(family,split);assert families[family]==split,'Scene-family leakage'
        for image in item['input']['images']:assert (ROOT/'training'/image).is_file(),image;image_refs+=1
        if item['target'].get('code_example'):assert (ROOT/item['target']['code_example']).is_file()
        assert item['provenance']['current_map_repaired'] is False
        if item['label'].startswith('KNOWN_NEGATIVE'):assert not item['provenance']['human_reviewed_target']
    assert sum(x['family_id']=='harbor' and x['split']!='train' for x in cases)==0
    for split in ['train','eval','test']:
        part=rows(f'training/{split}.jsonl');sft=rows(f'training/sft_{split}.jsonl')
        assert part==[x for x in cases if x['split']==split]
        assert [x['id'] for x in sft]==[x['id'] for x in part]
        for x in sft:assert [m['role'] for m in x['messages']]==['system','user','assistant']
    summary=load('training/dataset_summary.json');assert summary['cases']==len(cases) and summary['weights_trained'] is False and summary['model_behavior_benchmark_run'] is False
    assert summary['by_split']==dict(collections.Counter(x['split'] for x in cases))
    passed('dataset_schema_paths_family_splits',{'cases':len(cases),'families':len(families),'split':summary['by_split'],'image_references':image_refs})
    index=load('training/source_index.json');assert len(index)==16
    for source in index:
        p=ROOT/'training'/source['package_image'];assert digest(p)==source['package_sha256'],str(p)
        assert len(source['original_sha256'])==64 and source['pixel_albedo_ground_truth'] is False
        if source['transformation']=='EXACT_BYTES':assert source['original_sha256']==source['package_sha256']
    passed('image_provenance_derivative_hashes',len(index))
    installers=load('validation/installer_sources.json')
    for name,metadata in installers.items():
        p=ROOT/'examples'/name;source=p.read_text()
        assert digest(p)==metadata['sha256'] and metadata['standalone'] is True
        assert not re.search(r'\brequire\s*\(',source),'Standalone example has hidden module dependency'
        assert not re.search(r'\bloadstring\s*\(',source),'Unsafe external code loading'
    main=(ROOT/'examples/01_Depolu_Iskele_CommandBar.luau').read_text()
    for region in ['tools/Math3.luau','tools/Acceptance.luau','tools/CameraGuard.luau','tools/StudioKit.luau','examples/Depo_Iskele_Builder.luau']:
        marker='-- BEGIN INLINE '+region+'\n';assert marker in main
        body=main.split(marker,1)[1].split('-- END INLINE '+region,1)[0]
        assert (ROOT/region).read_text() in body,'Stale inlined module '+region
    core=(ROOT/'tools/StudioKit.luau').read_text()
    assert not re.search(r'(?:workspace\.CurrentCamera|camera)\.(?:CFrame|CameraType|Focus|FieldOfView|CameraSubject)\s*=',core),'Default adapter writes camera'
    for text in ['GetProductInfoAsync','root.Parent==nil','LuaSourceContainer','TextureContent=Content.fromUri','assertSurfaceManifest','BeginInstall','AuditInstalled']:
        assert text in core,text
    passed('standalone_installer_and_source_safety',len(installers))
    positive=load('training/positive_pairs/index.json');assert len(positive)==4
    assert sum(x['parts'] for x in positive)==807
    records=load('validation/positive_installer_sources.json');assert len(records)==4
    for item,meta in zip(positive,records):
        folder=ROOT/item['directory'];spec=json.loads((folder/'source_subset.json').read_text());measure=json.loads((folder/'measurements.json').read_text())
        assert len(spec['parts'])==item['parts'] and len({x['n'] for x in spec['parts']})==item['parts']
        assert spec['scope']=='PARTIAL_POSITIVE_GEOMETRY_LAYOUT_NOT_TEXTURE_CAMERA_BOAT_OR_GLOBAL_GOLD'
        assert measure['source_part_count']==item['parts']
        evidence=json.loads((folder/'image_evidence.json').read_text())
        for key,file in [('reference','reference_crop.jpg'),('observed_user_output','user_output_crop.jpg')]:
            assert digest(folder/file)==evidence[key]['file_sha256']
            assert evidence[key]['pixel_alignment_with_other_view'] is False
        code=(ROOT/meta['file']).read_text();assert digest(ROOT/meta['file'])==meta['sha256']
        assert not re.search(r'\brequire\s*\(',code) and not re.search(r'\bloadstring\s*\(',code)
        assert meta['standalone'] is True and meta['real_studio']=='NOT_RUN'
    refs=load('training/reference_views.json');assert len(refs['views'])==9
    assert 'vinç' in refs['views'][0]['description'] and 'duvar' in refs['views'][4]['description']
    passed('scoped_positive_reference_code_output_pairs',{'pairs':4,'source_parts':807,'standalone_extra':4,'not_full_gold':True})
    regression=load('validation/regression_results.json');assert regression['fail']==0 and regression['pass']>=45 and regression['scope']=='OFFLINE_MATH_AND_TEST_DOUBLE_NOT_STUDIO'
    syntax=load('validation/syntax_results.json');assert syntax['fail']==0 and syntax['studio_execution']=='NOT_RUN'
    statuses=load('validation/evidence_status.json')
    for key in ['real_studio_execution','live_source_asset_access','real_image_visual_coupon','reference_visual_acceptance','fps_device_measurement']:
        assert statuses[key] in ['NOT_RUN','NOT_MEASURED'],(key,statuses[key])
    passed('honest_distinct_test_scopes',{'offline':regression['pass'],'studio':'NOT_RUN','fps':'NOT_MEASURED'})
    manifest=ROOT/'SHA256.json'
    if manifest.exists():
        records=load('SHA256.json')
        for name,record in records.items():
            p=ROOT/name;assert p.is_file() and p.stat().st_size==record['bytes'] and digest(p)==record['sha256'],'Changed/missing '+name
        actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='SHA256.json' and '__pycache__' not in p.parts}
        assert actual==set(records),'Manifest omitted/untracked files: '+str(actual.symmetric_difference(records))
        passed('sha256_complete_manifest',len(records))
    else:assert allow_no_manifest,'Missing SHA256 manifest'
    return {'scope':'PACKAGE_DATA_INTEGRITY_AND_CONTRACT_NOT_STUDIO_NOT_AI_BENCHMARK','pass':len(checks),'fail':0,'checks':checks,'limits':['No real Studio execution','No real texture/permission/visual or FPS verification','No AI weights trained or model benchmark run']}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--allow-no-manifest',action='store_true');args=p.parse_args()
    result=verify(args.allow_no_manifest);print(json.dumps(result,indent=2,ensure_ascii=False))
