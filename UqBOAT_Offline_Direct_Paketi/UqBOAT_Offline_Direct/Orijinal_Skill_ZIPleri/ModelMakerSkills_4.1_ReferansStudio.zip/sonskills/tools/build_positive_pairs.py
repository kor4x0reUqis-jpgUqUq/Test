"""v4.1 positive reference->geometry->code->observed-output pairs.
Rebuild from committed subsets/crops without any old project folder. Optional first
extraction reads the retained original harbor ZIP; installers never depend on it.
Known boat/texture/camera/delivery failures are never labeled full-model gold.
"""
from pathlib import Path
import json,hashlib,math,argparse,zipfile,io
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'training/positive_pairs'
DEFINITIONS=[
 {'id':'PP01','slug':'red_gantry_container','title':'Ana vinç ve asılı açık konteyner','groups':[32,33],'origin':[-24,5.6,-44],'ref':1,'ref_roi':[.16,.04,.98,.94],'output_roi':[.275,.20,.548,.63],'lesson':'Aynı taşıyıcı çerçevede dört kolon, bom, kabin, üst A, spreader ve dört halatın doğru taraf/temas ilişkisi. Ana geometriye hizmet eden detay; rastgele nesne tekrarı değil.'},
 {'id':'PP02','slug':'yellow_crane_payload','title':'Sarı kafes vinç ve sandık askısı','groups':[34,35],'origin':[62,5.6,-29],'ref':2,'ref_roi':[.36,.12,.72,.72],'output_roi':[.51,.34,.63,.61],'lesson':'Kolon/platform/kabin/ankraj/bom ve kanca-sandık zinciri tek koordinat sözleşmesinde. Sadece aynı Y seviyesinde olmak gerçek bağlantı değildir.'},
 {'id':'PP03','slug':'warehouse_interior','title':'Açık kapılı depo, görünen iç ve çatı yükleri','groups':[36],'origin':[78,5.6,-53],'ref':2,'ref_roi':[.60,.39,.84,.75],'output_roi':[.505,.455,.640,.665],'lesson':'32x22x29 kütlede gerçek ön kapı, iç taban/arka yüz, oluk, çatı ve yükler. Görünmeyen duvarları tek proxy veya siyah kapı Decal ile geçiştirmeme.'},
 {'id':'PP04','slug':'blue_roof_hut','title':'Mavi çatılı kulübe ve gerçek çatı bağlantıları','groups':[45],'origin':[-86,5.6,74],'ref':6,'ref_roi':[.26,.55,.62,1.0],'output_roi':[.36,.73,.56,.99],'lesson':'İki eğimli çatı, duvar/kapı/pencere, kalkan kapakları ve baca gerçek geometriyle bağlanır. Daha net görünen bu alt nesne seçildi; örtülü köprü görüntüsünden sahte görsel gold üretilmedi.'},
]

def sha(raw):return hashlib.sha256(raw).hexdigest()
def bbox(parts):
 lo=[math.inf]*3;hi=[-math.inf]*3
 for p in parts:
  for i in range(3):
   extent=sum(abs(p['r'][i*3+j])*p['s'][j]/2 for j in range(3));lo[i]=min(lo[i],p['p'][i]-extent);hi[i]=max(hi[i],p['p'][i]+extent)
 return {'min':lo,'max':hi,'size':[hi[i]-lo[i] for i in range(3)]}
def first(ps,prefix):
 return next(p for p in ps if p['n'].startswith(prefix))
def norm3(v):return math.sqrt(sum(x*x for x in v))
def contact(a,b,tol=1e-5):
 aa=[[a['r'][i*3+j] for i in range(3)] for j in range(3)];bb=[[b['r'][i*3+j] for i in range(3)] for j in range(3)]
 cross=lambda a,b:[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
 dot=lambda a,b:sum(x*y for x,y in zip(a,b));delta=[b['p'][i]-a['p'][i] for i in range(3)]
 for raw in aa+bb+[cross(x,y) for x in aa for y in bb]:
  n=norm3(raw)
  if n<1e-10:continue
  axis=[x/n for x in raw];ra=sum(abs(dot(axis,x))*a['s'][j]/2 for j,x in enumerate(aa));rb=sum(abs(dot(axis,x))*b['s'][j]/2 for j,x in enumerate(bb))
  if abs(dot(delta,axis))>ra+rb+tol:return False
 return True

def meaningful_contacts(key,ps):
 out=[]
 def add(a,b):
  assert contact(a,b),('Source contact does not hold',key,a['n'],b['n']);out.append({'a':a['n'],'b':b['n'],'tolerance':1e-5,'kind':'REAL_BLOCK_OBB_CONTACT_NOT_VISUAL_ACCEPTANCE'})
 find=lambda p:first(ps,p)
 if key=='PP01':
  legs=[p for p in ps if p['n'].startswith('AnaVinc_Dikme')];feet=[p for p in ps if p['n'].startswith('AnaVinc_Ayak_Tabani')]
  heads=[p for p in ps if p['n'].startswith('Vinc_Derinlik_Kusagi') and p['p'][1]>90];boom=find('AnaVinc_Ana_Kopru')
  for leg in legs:
   foot=min(feet,key=lambda f:sum((leg['p'][i]-f['p'][i])**2 for i in [0,2]));add(leg,foot)
   head=min(heads,key=lambda h:abs(leg['p'][0]-h['p'][0]));add(leg,head)
  for h in heads:add(h,boom)
  add(find('Kabin_Doseme'),boom);sp=find('Sari_Kaldirma_Cercevesi');add(sp,find('Konteyner_Tavan'))
  bars=[p for p in ps if p['n'].startswith('Kaldirma_Ust_Enine_Kiris')]
  for wire in [p for p in ps if p['n'].startswith('Aski_Halati')]:add(wire,sp);add(wire,min(bars,key=lambda h:abs(wire['p'][0]-h['p'][0])))
  for b in bars:add(b,boom)
 elif key=='PP02':
  platform=find('Sari_Vinc_Ust_Platform');boom=find('Sari_Vinc_Yatay_Bom')
  for p in [p for p in ps if p['n'].startswith('Sari_Vinc_Ana_Dikme')]:add(p,platform)
  add(find('Kabin_Cati'),find('Bom_Tasiyici_Ankraj'));add(find('Bom_Tasiyici_Ankraj'),boom)
  add(find('Sari_Vinc_Karsi_Agirlik'),find('Karsi_Agirlik_Tasiyicisi'));add(find('Karsi_Agirlik_Tasiyicisi'),platform)
  add(find('Kanca_Cift_Halat'),find('Kanca_Ust_Arabasi'));add(find('Kanca_Ust_Arabasi'),boom);add(find('Kanca_Cift_Halat'),find('Kanca_Takozu'))
  for p in [p for p in ps if p['n'].startswith('Sandik_Aski_Zinciri')]:add(p,find('Kanca_Takozu'));add(p,find('Sandik_Kapak'))
 elif key=='PP03':
  floor=find('Depo_Doseme');sides=[p for p in ps if p['n'].startswith('Depo_Yan_Duvar')];back=find('Depo_Arka_Duvar')
  for side in sides:add(floor,side);add(back,side)
  add(floor,back)
 elif key=='PP04':
  roofs=[p for p in ps if p['n'].startswith('Kulube_Egimli_Cati')];assert len(roofs)==2;add(roofs[0],roofs[1])
  chimney=find('Kulube_Baca');hit=[p for p in roofs if contact(chimney,p)];assert hit;add(chimney,hit[0])
  for g in [p for p in ps if p['n'].startswith('Kulube_Kapali_Kalkan_Duvari')]:
   hits=[p for p in roofs if contact(g,p)];assert hits;add(g,hits[0])

 return out

def crop(raw,roi,path):
 im=Image.open(io.BytesIO(raw)).convert('RGB');box=[round(roi[0]*im.width),round(roi[1]*im.height),round(roi[2]*im.width),round(roi[3]*im.height)]
 im=im.crop(box);im.thumbnail((800,800));im.save(path,quality=90,optimize=True,subsampling=0)
 return {'roi_normalized':roi,'source_sha256':sha(raw),'file_sha256':sha(path.read_bytes()),'pixel_alignment_with_other_view':False,'occlusion_or_neighbor_context_possible':True}

def initialize(archive,user_image):
 BASE.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(archive) as z:
  raw=z.read('LimanHaritasi/Sahne_Verisi.json');data=json.loads(raw)
  index=[]
  for item in DEFINITIONS:
   folder=BASE/item['slug'];folder.mkdir(parents=True,exist_ok=True)
   parts=[p for p in data['parts'] if p['g'] in item['groups']];assert all(p['shape']=='Block' for p in parts)
   spec={**item,'source_scene_ir_sha256':sha(raw),'original_ir_archive_member':'LimanHaritasi/Sahne_Verisi.json','source_is_original_game_geometry':False,'source_is_delivered_reconstruction':True,'parts':parts,'bounding_box_world':bbox(parts),'scope':'PARTIAL_POSITIVE_GEOMETRY_LAYOUT_NOT_TEXTURE_CAMERA_BOAT_OR_GLOBAL_GOLD','external_scene_support_not_included':True,'new_installer_studio_execution':'NOT_RUN','contacts':meaningful_contacts(item['id'],parts),'approval_basis':'User said other parts as requested except studs, code delivery, camera and boats. These pairs preserve only the accepted component/layout lesson.'}
   (folder/'source_subset.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
   reference=z.read(f'LimanHaritasi/Referanslar/Liman_{item["ref"]:02d}.png')
   evidence={'reference':crop(reference,item['ref_roi'],folder/'reference_crop.jpg'),'observed_user_output':crop(Path(user_image).read_bytes(),item['output_roi'],folder/'user_output_crop.jpg'),'no_new_render_generated':True,'source_reference_camera_not_same_as_output_camera':True,'cannot_certify_unseen_individual_details':True}
   (folder/'image_evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
   index.append({k:item[k] for k in ['id','slug','title','lesson']}|{'family_id':'harbor','split':'train','directory':str(folder.relative_to(ROOT)),'parts':len(parts),'contact_checks':len(spec['contacts'])})
 (BASE/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2))

def number(x):return format(float(x),'.10g')
def arr(v):return '{'+','.join(number(x) for x in v)+'}'
def q(s):return json.dumps(s,ensure_ascii=False)
def build():
 index=json.loads((BASE/'index.json').read_text());source_records=[]
 for item in index:
  folder=ROOT/item['directory'];spec=json.loads((folder/'source_subset.json').read_text());origin=spec['origin'];lines=[]
  lines.append('-- Exact delivered reconstruction subset, PARTIAL POSITIVE ONLY. Not source-game dimensions or full-model gold.\n-- Native camera/doku/code defects are not inherited; new wrapper is texture-gated and default camera read-only.\nreturn function(ctx)\n local E=ctx.Env or {Vector3=Vector3,CFrame=CFrame,Color3=Color3,Enum=Enum}\n local pivot=ctx:Part({name="PositivePairOrigin",cframe=E.CFrame.new(),size=E.Vector3.new(.1,.1,.1),color=E.Color3.new(0,0,0),role="PIVOT",mask=0,alpha=1,collide=false,query=false,exclusionReason="Invisible positive-pair origin"})\n ctx.Model.PrimaryPart=pivot\n local data={')
  for p in spec['parts']:
   cf=[p['p'][i]-origin[i] for i in range(3)]+p['r'];role='WOOD' if p['g'] in [12,13,14,15,35] or p['n'].startswith('Sandik') else 'MAIN'
   reason='Delivered source explicit nonstuds surface policy: '+p['m'] if p['f']==0 else ''
   lines.append('  {name='+q(p['n'])+',cf='+arr(cf)+',size='+arr(p['s'])+',rgb='+arr(p['c'])+',mask='+str(p['f'])+',role='+q(role)+',alpha='+number(p['a'])+',material='+q(p['m'])+',collide='+str(p['k']).lower()+',reason='+q(reason)+'},')
  lines.append(' }\n for _,p in ipairs(data) do\n  ctx:Part({name=p.name,cframe=E.CFrame.new(table.unpack(p.cf)),size=E.Vector3.new(table.unpack(p.size)),color=E.Color3.fromRGB(table.unpack(p.rgb)),mask=p.mask,role=p.role,alpha=p.alpha,material=E.Enum.Material[p.material],collide=p.collide,exclusionReason=p.reason})\n end')
  for c in spec['contacts']:lines.append(' ctx:Contact('+q(c['a'])+','+q(c['b'])+','+number(c['tolerance'])+')')
  lines.append(' ctx.Model:SetAttribute("TrainingScope","PARTIAL_POSITIVE_COMPONENT_NOT_FULL_REFERENCE_GOLD")\n ctx.Model:SetAttribute("SourceOrigin",'+q(','.join(number(x) for x in origin))+')\nend\n')
  builder=folder/'Builder.luau';builder.write_text('\n'.join(lines))
  rows=[{'name':p['n'],'original_world':p['p'],'rebased_local':[p['p'][i]-origin[i] for i in range(3)],'original_rotation':p['r']} for p in spec['parts'][:4]]
  summary={'case_id':item['id'],'source_part_count':len(spec['parts']),'installed_part_count_including_pivot':len(spec['parts'])+1,'source_world_origin':origin,'root_transform_in_example':[0,8,0],'rule':'local=originalWorld-origin; installedWorld=rootWorld*local; rotation retained. These are reconstruction, not measured source-game dimensions.','worked_samples':rows,'expected_texture_faces_when_required':sum(p['f'].bit_count() for p in spec['parts']),'contacts':len(spec['contacts']),'acceptance_scope':spec['scope']}
  (folder/'measurements.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
  instructions=f'''# {item['title']} — eşleşmiş olumlu alt örnek\n\n**Kapsam:** Kullanıcının beğendiği genel geometri/yerleşim yaklaşımından gerçek alt küme. Tam model gold değil; doku/kamera/kod/tekne hata kapsamları dışarıda. Yeni kurulumun Studio testi NOT_RUN.\n\n## Eşleşme\n- reference_crop.jpg: kaynak kare {spec['ref']:02d}, crop/provenans image_evidence.json içinde.\n- user_output_crop.jpg: kullanıcının mevcut Studio görüntüsünden crop; yeni render değil. Aynı kamera/piksel hizası değil; bazı ayrıntılar örtülü.\n- source_subset.json: teslim edilmiş IR'nin {len(spec['parts'])} Part'lık gerçek alt kümesi; tüm poz/boyut/dönüş/renk/maske.\n- measurements.json: origin, rebase örnekleri, yüz ve temas sayısı.\n- Builder.luau: bu veriden gerçekten üretilmiş tam native build.\n- Installer_CommandBar.luau: bütün kütüphaneleri inline eden standalone kurulum.\n\n## Nasıl öğrenilir?\n{item['lesson']}\n\nOrigin={origin}. Her noktada local=world−origin; rotasyon korunur. Örnek wrapper root=(0,8,0) ile componenti incelemeye taşır; kamera taşımaz. Kaynak oyunun ölçüleri kesin elde edildi demek değildir. {len(spec['contacts'])} gerçek kutu temas kısıtı kodda; {summary['expected_texture_faces_when_required']} planlı yüz gerçek image/kupon/uygulama olmadan tamamlandı sayılmaz.\n\nKomponent çevresindeki liman zemini/ana iskele/tank bu bağımsız derse dahil değildir. Dış sahne bağlantıları tam harita kabulünde ayrıca gerekir.\n'''
  (folder/'README.md').write_text(instructions)
  # Standalone wrapper: same real core implementation, no prior scene/module dependency.
  script='-- SONSKILLS 4.1 standalone positive COMPONENT exercise, not a full map or fully accepted gold.\nassert(_G.MM41'+item['id']+'==nil,"Positive case already registered")\n'
  for rel,var in [('tools/Math3.luau','M'),('tools/Acceptance.luau','A'),('tools/CameraGuard.luau','C'),('tools/StudioKit.luau','Factory'),(str(builder.relative_to(ROOT)),'Builder')]:
   script+='\n-- BEGIN INLINE '+rel+'\nlocal '+var+'=(function()\n'+(ROOT/rel).read_text()+'\nend)()\n-- END INLINE '+rel+'\n'
  script+='\n_G.MM41'+item['id']+'=Factory(M,A,C).new({name="MM41_'+item['id']+'",ownerKey="MM41_POSITIVE_'+item['id']+'",requiresStuds=true,sourceModelId=9454666962,scale=1,worldCFrame=CFrame.new(0,8,0),builder=Builder})\n'
  script+='print("'+item['id']+' ready; Resolve -> real candidate Coupon -> explicit Approve -> Install -> AuditInstalled. No active camera changes; no untextured final main build.")\n'
  install=folder/'Installer_CommandBar.luau';install.write_text(script)
  source_records.append({'case_id':item['id'],'file':str(install.relative_to(ROOT)),'bytes':install.stat().st_size,'sha256':sha(install.read_bytes()),'builder_sha256':sha(builder.read_bytes()),'standalone':True,'real_studio':'NOT_RUN'})
 # Independent expectation fixture keeps original world data (not builder's rebased values).
 expected=['-- TEST ONLY original delivered reconstruction coordinates, not original game measurements.','return {']
 for item in index:
  spec=json.loads((ROOT/item['directory']/'source_subset.json').read_text())
  expected.append(' {id='+q(item['id'])+',origin='+arr(spec['origin'])+',parts={')
  for p in spec['parts']:
   expected.append('  {n='+q(p['n'])+',p='+arr(p['p'])+',r='+arr(p['r'])+',s='+arr(p['s'])+',c='+arr(p['c'])+',f='+str(p['f'])+',a='+number(p['a'])+',m='+q(p['m'])+',k='+str(p['k']).lower()+'},')
  expected.append(' }},')
 expected.append('}')
 (ROOT/'tests/positive_expected.luau').write_text('\n'.join(expected)+'\n')
 (ROOT/'validation/positive_installer_sources.json').write_text(json.dumps(source_records,indent=2))
 print('Positive pairs',len(index),'source parts',sum(i['parts'] for i in index),'standalone source bytes',sum(x['bytes'] for x in source_records))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--harbor-archive',type=Path);p.add_argument('--user-image',type=Path);args=p.parse_args()
 if args.harbor_archive:assert args.user_image,'Raw user image required only for initial extraction';initialize(args.harbor_archive,args.user_image)
 build()
