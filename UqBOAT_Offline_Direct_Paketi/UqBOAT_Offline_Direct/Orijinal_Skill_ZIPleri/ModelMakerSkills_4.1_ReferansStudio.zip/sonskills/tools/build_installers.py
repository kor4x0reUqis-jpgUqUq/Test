"""Assemble genuinely standalone EDIT Command Bar source files. No remote require.
Shared source is inlined, not assumed to already exist in a Studio place.
"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent.parent

def inline(path,name):
    source=(ROOT/path).read_text()
    return f'\n-- BEGIN INLINE {path}\nlocal {name} = (function()\n{source}\nend)()\n-- END INLINE {path}\n'

head='''-- SONSKILLS 4.1 / STUDIO EDIT COMMAND BAR / COMPLETE STANDALONE SOURCE
-- Training example; NOT a new full harbor reconstruction or Studio-tested gold model.
-- Paste this ENTIRE file. No .rbx file, ModuleScript or filesystem required.
-- Do not execute historical or downloaded foreign scripts.
'''
main=head+'assert(_G.MM4Ders==nil,"MM4Ders already registered; use its commands or explicitly remove its coupon/session before repasting")\n'
for path,name in [('tools/Math3.luau','Math3'),('tools/Acceptance.luau','Acceptance'),('tools/CameraGuard.luau','CameraGuard'),('tools/StudioKit.luau','StudioKitFactory'),('examples/Depo_Iskele_Builder.luau','BuildWarehouse')]:main+=inline(path,name)
main+='''
local StudioKit=StudioKitFactory(Math3,Acceptance,CameraGuard)
_G.MM4Ders=StudioKit.new({name="MM4_Depolu_Iskele_Dersi",ownerKey="SONSKILLS_V4_WAREHOUSE_DEMO",requiresStuds=true,sourceModelId=9454666962,scale=1,worldCFrame=CFrame.new(0,8,0),builder=BuildWarehouse})
print("MM4Ders registered. Active camera unchanged. Main geometry is NOT installed without the required texture.")
print("1 _G.MM4Ders:Resolve()")
print("2 Select an actual candidate and create Coupon(index, profile). Trial tileU/V is NOT proven motif pitch.")
print('3 Only after real visual inspection: _G.MM4Ders:Approve("KUPONU_GORSEL_OLARAK_ONAYLIYORUM")')
print('4 _G.MM4Ders:Install("ONAYLI_KURULUMU_BASLAT")')
print("5 local r=_G.MM4Ders:AuditInstalled(); print(r.pass,r.actual,r.expected)")
print("6 _G.MM4Ders:RemoveCoupon() -- camera was never moved")
'''
(ROOT/'examples/01_Depolu_Iskele_CommandBar.luau').write_text(main)
hull=head+'assert(_G.MM4HullLab==nil,"Hull lab already registered")\n'+inline('tools/Math3.luau','Math3')+inline('examples/Tekne_MeshLab_Core.luau','HullLabFactory')
hull+='''
_G.MM4HullLab=HullLabFactory(Math3)
print('Synthetic UNTEXTURED geometry lab only. Not a required-studs task fallback or a corrected source boat.')
print('_G.MM4HullLab:Build("YALNIZ_SENTETIK_GEOMETRI_LABORATUVARI")')
print('EditableMesh capability/budget may block. To remove owned lab: _G.MM4HullLab:Remove()')
'''
(ROOT/'examples/02_Tekne_Matematik_Lab_CommandBar.luau').write_text(hull)
rig=head+'assert(_G.MM4RigLab==nil,"Rig lab already registered")\n'+inline('examples/Rig_ClipLab_Core.luau','RigLabFactory')
rig+='''
_G.MM4RigLab=RigLabFactory()
print('Synthetic EDITABLE CLIP structure lab, not a finished creature or published animation.')
print('_G.MM4RigLab:Build("YALNIZ_DUZENLENEBILIR_KLIP_LABORATUVARI")')
print('Source clips require actual Animation Editor/rig verification. Camera is not modified.')
'''
(ROOT/'examples/03_Editable_Rig_Clips_CommandBar.luau').write_text(rig)
records={}
for p in sorted((ROOT/'examples').glob('*CommandBar.luau')):
 records[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'standalone':True,'studio_execution':'NOT_RUN','foreign_require':False}
(ROOT/'validation/installer_sources.json').write_text(json.dumps(records,indent=2))
print('Three standalone installers assembled:',[(k,v['bytes']) for k,v in records.items()])
