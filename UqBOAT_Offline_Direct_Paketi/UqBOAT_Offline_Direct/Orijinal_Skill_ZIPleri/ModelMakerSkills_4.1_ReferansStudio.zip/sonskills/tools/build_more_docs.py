"""Supplementary authored skill docs; no model mutation."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DOCS={
'references/09_tekne_dersi.md':'''# Tekne dersi: 17 PASS ile yine hatalı tekne nasıl çıkar?

## Gerçek geri bildirim
Kullanıcı limanın genel sonucunu istediği gibi buldu; **teknelerde hata** bildirdi ve yakın plan verdi (`training/images/liman_studio_02.png`). Belirli tek bir kusurun sebebini kullanıcı açıklamadı. Ekran görüntüsünden 'kesin yalnız bu satır' teşhisi uydurma. Mevcut tekne kodu bu skill görevi kapsamında onarılmadı.

Önceki offline kontrol, kapalı Native karina parçalarının birbirine temasını ve biniş tahtasının kutulara değmesini ölçtü. Bu, düzgün pruva silüeti, gerçek borda akışı, doğru güverte genişliği, geçilebilir biniş veya bütün halatların uç bağlantısı demek değildi.

## Beş bağımsız tekne kapısı
1. **Planform:** uzunluk/beam oranı, stern/bow ayrımı, kesit genişlik eğrisi, pruva daralması ve kaynak kameradaki çizgi.
2. **Kesit/hacim:** kapalı karina altı, gerçek duvar kalınlığı, iç taban, borda/gunwale; denizden görünen yüzlerden arka plan sızmaması.
3. **Üst açıklık/kamara:** açık güverte gerçek boşluk; karanlık düzlemle sahte delik değil. Kamara tabanı/hull teması, pencere çerçeveleri, kapı önünü kesen şerit.
4. **Bağlantı:** biniş ucu tekne local soketinden türemeli; borda kesintisi/iniş basamağı işlevsel; halatın her iki ucu gerçek baba/direk/kanca üzerinde.
5. **Görsel kritik plan:** baş-kıç, yandan profil, üst plan ve su seviyesinden alt/borda yakın planı. Boat tarafını iskeleyle örten geniş açı tek başına kabul değildir.

## Kötü çözüm kalıpları
- Sabit uzunluklu gövde kutularının merkez aralıkları büyür → arada boşluk kalır.
- Gapsiz kutu zinciri → yine yanlış basamaklı/prizmatik pruva; temas PASS silüeti onaylamaz.
- Tek dev dikdörtgen güverte daralan bow'un dışına taşar.
- Beyaz kuşak/kaplama bir açıklığı görsel olarak örter; gerçek hacim eksik kalır.
- Mooring local yerine tahmini world → döndürülen teknede uç bordadan kaçar.
- Biniş tahtası değiyor ama önünde kapalı borda var → fizik/geçiş FAIL.
- Sonsuza giden/off-frame halat için yalnız başlangıç yüksekliği kontrol edilir.

## Çözümlü sayısal laboratuvar
`Math3.hullMesh`: her istasyonda outer/inner kesit; dış/inner side ve keel; baş/kıç end wall; gunwale rim. Duvarının tamamı kapalı bir sınırdır, iç hacme üstten erişim açıktır. Topoloji testi: her kenar2 yüz ve zıt yön; nondegenerate yüzler; volume>0; Euler2; içeri dik ışın tavan/lid bulmaz ama gerçek tabanı bulur.

`examples/02_Tekne_Matematik_Lab_CommandBar.luau` bunu EditableMesh→CreateMeshPartAsync ile gösterebilir. **Sentetik geometridir, kaynak teknelerin düzeltilmiş/görsel onaylı kopyası değildir.** Untextured geometri deneyi için açık ayrı token ister; blok/studs asıl görevin yerine kullanılamaz. Mesh UV/studs, çarpışma, Studio izinleri, save/reopen ve görsel form ayrı kapıdır. EditableMesh bellek/kabiliyet engelinde kutu proxy'ye sessiz dönüş yok.
''',
'references/10_gorsel_kabul.md':'''# Çok açılı kabul ve erken önizleme

## İlk kanıtı geciktirme
Gerçek geometri ilk okunur hale geldiğinde kalıcı `Onizleme.png` yaz ve aç. Cache, ileride oluşturulacak dosya, taslak plan veya AI hedef resmi teslim önizlemesi değildir. Uzun render/test zinciri varsa sonunu bekletmeden taslak damgasıyla ilk sonucu göster.

## Bakış matrisi
- Genel kaynak eşleme: landmark/ölçek/örtülme.
- Ön/arka/iki yan/üst/alt: boş bırakılan kısımlar ve form sürekliliği.
- Kritik yakın plan: tekne karina/borda/biniş; kapı ve depo içi; halat üst/alt uçları; vinç kabin/merdiven; rig eklemi/kanat kökü.
- Texturesız ve VFX'siz: form saklanıyor mu?
- Gerçek onaylı studs ile: bütün gerekli yönler, motif pitch, alfa/renk/faz, yakın/uzak dikiş.
- Poz/animasyon istenmişse ImportPose ve her klibin hazırlık/eylem/toparlanma anı.

## Aynı veri ve poz
Son sahne/kurulum kaydıyla preview hash'ini eşleştir. Eski renderı yeni kaynak finali diye sunma. Kamera kaydedilmiş pose verisiyle üretilebilir; aktif kullanıcı kamerasını kilitlemek zorunda değildir. Dış renderer görüntüsünü 'Studio screenshot'ı yapma. PBR/Glass/Atmosphere/Neon ve gökyüzü farklarını belirt.

Kaynakla karşılaştırırken yalnız bütün-piksel MAE kullanma: sky, UI, ışık, saydamlık skoru çarpıtabilir. Önce normalize ağırlıklı landmark hatası + silüet/negatif boşluk + komşuluk/örtülme ilişkisi; sonra renk/materyal. Eşiği ölçüm güveninden seç. Gizli alanları 'aynı' diye onaylama.

## Testler ayrı
Syntax PASS, sayısal placement PASS, topology PASS, asset type/access/fetch, insan kupon, gerçek uygulama, Studio API/open, reference visual, avatar physics, FPS: ayrı durumlar. 17 kontrol geçen limanın tekne kusuru bu ayrımın gerçek örneğidir.

Kullanıcı yalnız alt kapsamı onayladıysa onu kapsamlı tut: 'diğer her şey iyi, tekneler hatalı' → layout/general positive; boats negative; doku/kamera/teslim fail. Bütün sahneyi golden örnek yapma.
''',
'references/11_gorev_ve_stil.md':'''# Görev/kapsam/stil yönlendiricisi

## Son açık talep üstün
Varsayılan blok/studs stili, kullanıcı yeni gerçekçi/no-studs/mesh isterse dayatılmaz. İptal edilmiş ormanın tercihi sonraki limana taşınmaz. Referansın blok/studs karakterini natural materyalle sessizce değiştirme. 'No Blender' → native Studio yöntemleri/kurulum kodu; Studio erişimin yoksa dürüst engel, dosyayı kod yerine gizlice koyma değil.

## Aşırı detay
Büyük/orta/küçük ölçekte anlamlı hacim. Baş/gövde/alt/arka/eklem/kanat/kuyruk veya bina içi/çatı/bodrum/merdiven her görevde envantere yazılır. Kritik bölge blockout iken final değildir. Ana gövdeyi tek kutu, tüp veya daireye dizilmiş panel staves ile geçiştirme. Silindir teker/mekanik gibi yerel işlev, bütün gövdeyi tüpe çevirme izni değildir. Kaynak blok stilini doğru geometriyle koru.

Detay görevde kaynak/işlev/silüet/anatomiye hizmet etsin. Aynı mikro bloğu bin kez rastgele çoğaltmak 'sınır yok' talebini karşılamaz. Kaynak limitinde kullanıcıyla parti kapsamını azalt; sonraki nesneleri gizlice sadeleştirme.

## Ek iş ekleme
Statik harita → sürüş, hasar, NPC, teleport, vinç hareketi, balık animasyonu otomatik eklenmez. Yalnız tekne → ada/akvaryum üretme. VFX/animasyon istendiyse gerçek işçilikle yap, istenmediyse zorla ekleme.

## Model yöntemini seç
Native Block/Wedge: stil/köşeli form; boşluklar gerçek bölünmüş hacimlerle.
CSG: gerçekten oyuk/boole gerekiyorsa, sayıyı azaltma sihri değil.
Mesh/loft: gerçek kesit/organik/karina yüzeyine ihtiyaç varsa; izin, UV, winding, closed ends ve collider ayrı.
Import gerekiyorsa: gerçek dosya/ölçek/up-axis/4 kalibrasyon landmark'ı. Hayali MeshId veya ithalatın test edilmeden başarı garantisi yok.

Skill-only görevde çalışmış haritayı değiştirme. Buradaki laboratuvarlar yeni tam harita/yaratık teslimi değil; öğrenme örnekleridir.
''',
'references/12_rig_vfx_csg.md':'''# Gerçek rig, klip, VFX ve kontrollü CSG

## Rig matematiği
`childWorld = parentWorld * C0 * Transform * C1:Inverse()`.
Pivotu gerçek eklem soketine koy; Part merkezi kolay diye omuz pivotu sayılmaz. Her sürülen parça tek Motor6D/Bone zincirine, her dekor tek taşıyıcıya bağlı olsun. Ölçeği geometri, C0/C1 ve Attachment translation'ında tutarlı uygula; rotasyonları ölçekleme.

İlk import görünüşü gerçekten uygulanmış ImportPose olmalı. Gelecekte Idle başlayacak olması T-pose'u şimdiden düzeltti demek değildir.

## Klip kalitesi ve teslim
Düzenlenebilir KeyframeSequence/Keyframe/Pose + uygun Motor6D/Bone ağı + anlamsal isim/marker manifesti. Aynı sinüsün adını Walk/Fly diye değiştirip eylem üretme. Hazırlık→eylem→takip→toparlanma; ayak basışı/ağırlık/denge; türün hareketine uygun storyboard.

Dört ayaklıda erişim clamp'li IK ve pole; kuşta omuz→dış kanat gecikmesi ve zar sınırları; balıkta gövdeden kaudale yanal genlik; uçakta gerçek menteşe kontrol yüzeyi; serpente zincir eğriliği. Runtime dekor gösterisi kaynak kliplerin yerine geçmez.

`examples/03_Editable_Rig_Clips_CommandBar.luau`: açık sentetik laboratuvar isteğiyle iki parçalı menteşe, gerçek motor, uygulanmış import pozu, WingFold/WingDownstroke/WingHold kaynak klipleri üretir. Tam yaratık anatomisi veya published animation değildir. Animation Editor'da açılması/oynatılması bekleyen ayrı testtir. Hiçbir AnimationId uydurulmaz.

## VFX
389 kategori kaydı/263 ID `catalogs/` içinde tam korunur. VFX istendiyse bu havuz önceliklidir; her ID'yi yığma. Etiket/type/source/access/license/render ayrı kontrol. SoundId ile ParticleEmitter.Texture, Beam ile volumetric ışığı karıştırma. Blank Beam çizgi/ribbon olabilir ama gerçek hacimsel ışık kanıtı değildir. Neon materyal kendi başına çevreyi aydınlatan Light değildir.

Marker→bölge→bileşen eşleşmesi: ayak tozu temas marker'ı, nefes windup/burst/recover, egzoz motor/fly. İstenmedikçe VFX'e hasar/AI/oynanış ekleme. Rate/Emit, Beam/Trail/lights ve mesafe/kalite kapıları ayrı; eski particle lifetime'ını hesaba kat. Public/free asset metadata lisans belgesi değildir.

## CSG
`tools/GuvenliCSG.luau` primitive-only statik sınırlı helper'dır. GeometryService sonuç **dizisini** işler; her sonucu ayrı doğrular/parent eder. Motor/Constraint/Attachment kaynakları için kör union yapmaz. Yeni sonucu doğrulamadan kaynağı yok etmez; deletion sadece açık owned tag ile. Engine-returned transformu her parçada main.CFrame'e zorlamaz. SplitApart ve mesh girdisinin sonuç türüne etkisi güncel docs'tan kontrol edilir.

Blender Boolean sonucu native UnionOperation değildir. CSG API çağrısı gerçekleşmediyse 'gerçek union' sayısı yazma. Mesh/PBR gerekiyorsa normal convention/UV/izin ve gerçek importer testi ayrı; eski aktarım varsayımını güncel dosya desteği diye genelleme.
''',
'references/13_performans_ve_detay.md':'''# Ölçüm, ayrıntı ve dürüst performans

Part adedi, Texture, decal, union/mesh, transparency/overdraw, ışık, joint, Pose, emitter/beam/trail ve collider maliyeti ayrı sayılır. Texture katmanı da gerçek Instance ve render yüküdür. Limanda planlanan 34.710 yüz FPS ölçümü değildir.

Kullanıcı sınır koymadıysa keyfi Part/kod üst sınırı üretme. Yield/batch UI'yi rahatlatır; truncation değildir. Son öğeleri giderek daha düşük detayla bitirme. 'Aşırı detay' anlamlı form/yapı/iç/odak işçiliğidir, rastgele repetition değil.

Hero/Game varyantı ancak kullanıcı kapsamına uygunsa, aynı silüet/ölçek/rig ilişkisini koruyarak ve farkları açık kaydederek yapılır. Occluded yüz politikası rol/niyetle belgelenir; görünür yanları sırf bütçe için sessizce studs'suz bırakma.

Gerçek FPS ölçüm satırı: cihaz, GPU/CPU, çözünürlük, grafik kalitesi, kamera/rota, eşzamanlı adet, warmup, örnek süresi, median/p95 frame time, bellek ve test tarihi. Bunlar yoksa sayısal FPS hücreleri **null/NOT_MEASURED**. Bir headless OpenGL render süresi Roblox mobil FPS'si değildir.

'Herkes için optimize', 'sıfır hata', 'game-ready', 'satılabilir' koşulsuz etiket değildir. Yayın/izin/ticari hak testi ayrı. Gerçek kaynak limitinde kapsamı açık böl; kaliteden sessiz vazgeçme.
''',
'references/14_liman_vakasi.md':'''# Liman: pozitif alt kapsam ve dört negatif ders

## Kaynaklar
Kullanıcının 9 kaynak karesi + 2 Studio geri bildirimi. Eğitim paketinde kompakt türevler ve özgün SHA256/boyut kayıtları vardır; tam çözünürlüklü orijinaller değişmeden asıl oturum arşivinde durur. JPEG türevini orijinal piksel/albedo ölçümü sanma. `training/source_index.json` provenansı açıklar.

### Görüş eşleme
01 arka-üst ana vinç/uzun bom/konteyner; 02 sağ pazar/depo/sarı vinç; 03 zemin yükleme/ana vinç/merdiven; 04 akvaryum dışı; 05 akvaryum iç duvarı; 06 genel ön-sol; 07 tekneler önden; 08 büyük gemi kumanda/baca; 09 meydan ve karşı yöndeki bağlantılar.

## Başarıyı nasıl korumalı?
Kullanıcı 'onun harici her şey tam istenilen şekilde' dedi. **Yerleşim ve genel harita yaklaşımı** olumlu örnek; doku, ana teslim biçimi, kamera ve tekneler istisnadır. Tamamını tek gold resim etiketiyle kullanma.

9 görüntüden sabit ilişkiler: kırmızı vinç merkez/arka; büyük yük gemisi arkada; tekne çiftinin renk ve merkez havuz ilişkisi; mavi depo/sarı vinç sağ; mavi çatılı kulübe ön-sol; sağ yanda mavi/beyaz tezgâh; ahşap geçişler ve dış akvaryum. Ref6'da kısa görünen bom, arka Ref1'te uzun görünür; farklı perspective yüzünden ilk görünüşe göre kolu kısaltma.

## Gerçek sayısal örnekler (kaynak ölçüsü değil yeniden kurulum parametresi)
Stud; +Y up / +X right / +Z front. İskele top5.6; su0.6; kum−17. Ana kule merkezi(−24,5.6,−44), tepe(−24,134.5,−44). Aksine göre mirrorX=2(−24)−x.
- Eski uzun kol center−11 → **−37**.
- Eski operatör x−45 → **−3**.
- Eski asılı konteyner x17 → **−65**.
Böylece bütün ilgili öğe aynı aynalama sözleşmesiyle karşı tarafa alınır; sadece bir objenin X'ini rastgele değiştirme.

Depo32×22×29, merkezx78/z−53; kapı/perde boşluğu ve kaynak içi tamamlandı. Bunlar özgün oyun verisinden kesin alınmış boyutlar değil. Mini iskele/depo ders kodu, bu olumlu alt yaklaşımı gösterir; tüm mapin yeni teslimi değildir.

## Eski offline yakalananlar
Kazık/kiriş x kaçması; world biniş ucu; üstte kiriş Z genişliği dışında biten halatlar; izole köprü sahanlığı; görünür coplanar asfalt/ahşap; kapıdan geçen kırmızı kabin şeridi. Gerçek geometri değişti; tolerans büyütülmedi.

## Offline'ın yakalayamadıkları
Gerçek studs hiç dağıtılmamıştı; kurulum kodu ana dosya değildi; kamera Scriptable bırakıldı; tekneler kullanıcı yakın planında başarısızdı. 17 PASS bunları geçersiz kılamaz.

4.0 bunun için **install-code required / required-texture-before-main-build / camera-read-only / critical-boat-visual** kapıları ekler. Sadece kuralları yazmaz: standalone örnek, canlı maske audit'i, immutable yüz sözleşmesi ve hata yolunda kamera/commit regression testleri içerir.
''',
'references/15_gecmis_dersler.md':'''# Geçmişten doğrulanmış dersler — bağlamı koru

## Park
Kullanıcı genel parkı iyi buldu; yollar/banklar kaynak yerleşiminden kaydı, bazı studs yönleri eksikti. Syntax/adet/ortonormal testleri bunları yakalamadı. Ders: ilk kamera/landmark, ilişkisel yerleşim, açık yüz maskesi. `training/images/park_feedback.jpg` genel beğeni + yerleşim hatası olarak etiketlenir.

## İptal edilmiş orman
No-studs gerçekçilik/mesh isteği o göreve aitti. Son geometri kapısında10PASS/1FAIL; dal kapağı/weld sorunu çözülemedi. Render yalnız cache'te kaldığı için kullanıcı göremedi. Daha sonra kalıcı draft açıldı, kullanıcı onayıyla kaynak/cache silindi. Bu sahne bitmiş/gold değildir. Geri kalan draft görseli etiketli negatif kanıttır.

Dersler: gerçek kapak/topoloji; aynı float koordinatı var diye weld başarılı saymama; texture/VFX ile boşluğu gizlememe; ilk gerçek preview kalıcı dosya + kullanıcıya açma; Studio render/export/import/FPS testlerini offline Blender/XML'e karıştırmama. Bu yeni skill görevi ormanı geri üretmez.

## Ghidorah/F16 ve eski seri
Orijinal paketin olumsuz görsel otopsileri korunur. Tek büyük kutu göğüs, direk boyun, çubuk uzuv, fan şerit zar, yanlış teker/eklem ve T-pose; fazla Part adı/kaplama ile kurtarılamaz. Source rig/IK yaklaşımından yararlı kısım çıkarılır ama eski output gold yapılmaz.

`history/v3/` belge ve kaynakları tarihsel tutar; eski default ID veya görev emirleri 4.0'a hükmetmez. İnceleme kaynakları yalnız data, dış script olarak parent/require/execute edilmez.
''',
'references/16_api_guncellik.md':'''# Güncel API / provenans — 2026-10-24

Resmî doküman URL, sayfanın last_updated alanı ve indirilen içerik hash'i `references/resmi_kaynaklar.json` dosyasında. Kullanılan semboller ve enumlar `validation/api_symbols.json` ile karşılaştırılır. Doküman/isim varlığı, gerçek Studio yürütmesi veya izin başarısı değildir.

- **Camera:** Scriptable default camera scripts tarafından güncellenmez; default kurulumda kullanma. Subject=nil atanamaz. CurrentCamera swap'ı, Workspace'e doğrudan bağlı diğer kameraları yok edebilir; poz verisi/Folder kullan.
- **Texture/Decal/Content:** tekrar boyutu StudsPerTileU/V. Content.fromUri ve Content.Uri güncel. Örnek serializable TextureContent kullanır; ColorMapContent'in save bayrağını okumadan eşdeğer persistence iddiası yok.
- **MarketplaceService:** örnekte güncel GetProductInfoAsync ile AssetTypeId kontrolü. Model10, image1, decal13 enumları API dump'tan denetlenir.
- **DataModel.GetObjects:** Command Bar/plugin güvenlik bağlamı. Kaynağı unparented tutup yabancı kodu sil; serbest metadata bütün hesaplarda erişim/lisans garantisi değildir.
- **ContentProvider:** PreloadAsync / AssetFetchStatus fetch kanıtıdır, görüntünün doğru studs motifi olduğunun veya sahibin izin verdiğinin kanıtı değil.
- **GeometryService:** Union/Subtract/Intersect sonuç dizisi, unparented sonuçlar, engine-returned transform, constraint-preservation koşulları.
- **AssetService/EditableMesh:** CreateEditableMesh nil dönebilir; CreateMeshPartAsync Content kabul eder; normal/triangle/UV yöntemleri ayrı. Bellek/capability ve görsel/collider/save-reopen kabulü ayrıca gerekir. Object Content replication kısıtını göz ardı etme.
- **Lighting:** güncel LightingStyle/PrioritizeLightingQuality mevcut; deprecated Technology varsayımıyla otomatik başarı bekleme. Gölgeler/bloom kalite ve cihaza bağlıdır.

Her yeni çalışma için ilgili resmi API'yi tekrar denetle. Yeni adı kullanmak tek başına doğru model/renk/doku yapmaz. Eski uyumlu özellik ile eski asset ID'yi karıştırma; ID yalnız kullanıcı tercihiyle değişir.
''',
'README.md':'''# ModelMakerSkills / SONSKILLS 4.1.0

**Referansa sadakat + çözümlü matematik + gerçek Studio kurulum kodu + etiketli eğitim seti.**

Bu paket kullanıcının **“evet tam da bu, devam”** onayıyla hazırlanmış yeni skill sürümüdür. Orijinal `ModelMakerSkills.zip`, liman ve park teslimleri değiştirilmez. Mevcut liman/tekneler bu görevde onarılmadı; kusurlu çıktılar gold hedef yapılmadı.

## Başla
1. Skill destekleyen AI'ya bu ZIP içindeki `sonskills` klasörünü/skill'i ekle; **`SKILL.md`** giriş noktasıdır. Bu sohbet dosya teslimi kendiliğinden bütün AI platformlarına kurulum/kalıcı eğitim yapmaz.
2. Yeni görevde güncel kullanıcı sözleşmesini ve ilgili referans rehberini oku.
3. Örnek/karşıörnekler için `training/README.md`, `training/cases.jsonl`; ana mantık için `examples/Hesaplar.md`.
4. Çalıştırılabilir tam örnek: **`examples/01_Depolu_Iskele_CommandBar.luau`**. Dış .rbx dosyası veya ModuleScript istemez; kendi build kodu ve araçları inline'dır.

## Dört somut değişiklik
- İstenen kurulum kodu **ana teslim**; model dosyası onun yerine geçmez.
- Gerekli studs görseli doğrulanıp kupon açık onaylanmadan **ana kurulum engellenir**. Onaylı görsel gerçek yüzlere uygulanır ve audit edilir.
- Kupon/kurulum aktif kamerayı **değiştirmez**. İsteğe bağlı geçici inceleme başarı/hata yollarında geri yüklenir.
- Tekne silüeti/kabuk/borda/biniş/halat yakın planı ayrı kabul; offline PASS bütün formu onaylamaz.

## Studio örneğini çalıştır
`examples/01_Depolu_Iskele_CommandBar.luau` içeriğinin tamamını Studio **EDIT → Command Bar**'a yapıştır. Play/Run kapalı olmalı. Sonra:

```lua
_G.MM4Ders:Resolve()
```

Gerçek Model9454666962 içinden Image(1) adayları listelenir. Birinci aday otomatik seçilmez. İnceleyeceğin gerçek sıra numarasıyla, **deneme** profilini ver:

```lua
_G.MM4Ders:Coupon(1, {tileU=1, tileV=1, transparency=0.35,
    woodMinTransparency=0.48, thinMinTransparency=0.78, phaseMode="LOCAL_ZERO"})
```

`1` örnektir; motif/tile oranını gerçekten görerek seç. Kupon 5 blok/30 yüzdür; kamera taşınmaz. İstersen kuponu Explorer'da kendin seçip F ile odaklan. Bütün yönleri, eğimi, renkleri ve yakın/uzak görünüşü inceledikten sonra:

```lua
_G.MM4Ders:Approve("KUPONU_GORSEL_OLARAK_ONAYLIYORUM")
_G.MM4Ders:Install("ONAYLI_KURULUMU_BASLAT")
local r = _G.MM4Ders:AuditInstalled()
print(r.pass, r.actual, r.expected)
_G.MM4Ders:RemoveCoupon()
```

Aynı **kendi** sahneni staging audit sonrası açık değiştirmek için Install'ın ikinci argümanı `true`; eski sonuç `ServerStorage/MM4_Backups` altında korunur. Yabancı aynı isimli model silinmez. Asset/fetch/kupon engelinde tamamlanmış dokusuz model kurulmaz. Kaynak9454666962 **Model'dir**, doğrudan image değildir. Gerçek URI burada önceden uydurulmadı.

**Örnek kapsamı:** depolu iskele alt sahnesi. Tam limanın yeni birebir teslimi değildir. `02_Tekne_Matematik_Lab_CommandBar.luau` ve `03_Editable_Rig_Clips_CommandBar.luau` ayrıca açık token isteyen sentetik laboratuvarlardır; default studs/model görevini bypass etmek için kullanılamaz.

## Paket içeriği
- `SKILL.md` + 17 odak referans rehberi + makine okunabilir tercihler.
- Standalone kurulum örnekleri; portable Math3, gerçek Studio adapter, acceptance state machine ve CameraGuard.
- Native açık üstlü kapalı duvarlı hull hesabı, gerçek editable rig/klip laboratuvarı; bunlar kaynak tekne görsel kabulü değildir.
- `training/`: gerçek kaynak türevleri + scoped kullanıcı geri bildirimi + çözümlü/sentetik ve karşıörnek vakaları; family-disjoint train/eval/test ve isteğe bağlı SFT dışa aktarımı. Bu veriyle bir ağırlık eğitimi yapılmadı.
- Tam VFX katalogu:389 kayıt/263 ID ve özgün metin; hak/tür/erişim yine bekleyen gerçek kontrol.
- `history/v3/`: eski kuralların kısıtlı tarihsel kopyası; aktif talimat değildir.
- `validation/`: derleyici/matematik/mock/dataset/integrity sonuçları; Studio/asset/render/FPS durumları ayrı.

## Doğrulama

```sh
python tools/verify_package.py
luau tests/run_all.luau
```

Python paket kontrolü stdlib ile yapılır. Kamera fit örneği isteğe bağlı NumPy/SciPy; eğitim verisi yeniden üretme/görsel türevler için Pillow kullanır. Bunlar Studio kurulum kodunun bağımlılığı değildir.

**Dürüst sınır:** Gerçek Roblox Studio bu ortamda yürütülmedi. Resmî Luau derleyicisi, sayısal testler ve test doubles gerçek Studio, asset hakkı, insan görsel kuponu, editor/collider veya FPS kanıtı değildir. Ayrıntı `DOGRULAMA.md`.
''',
'CHANGELOG.md':'''# 4.1.0 — 2026-10-24

## Kırıcı/öncelikli
- Son kullanıcı Model9454666962 tercihi aktif oldu; eski945466696 varsayılanı yalnız tarihsel alanda.
- Studio kurulum kodu ana çıktı; .rbx dosyası yerine geçmez.
- Required-studs kurulumunda gerçek image/fetch/insan kuponu olmadan main build engeli.
- Default kamera yazması kaldırılmış güvenli yeni örnek; opt-in capture restore/camera-swap koruması.
- Tekne kritik yakın planı bağımsız; 17 offline PASS + kullanıcı tekne FAIL vakası scoped veri.

## Eklendi
- Matematik: local/world, tek ölçek, dönüş, SAT, ışın, perspektif, weighted residual/scale, sRGB ve motif/tile hesabı.
- Kapalı sınır ve gerçek açık üstlü sentetik hull; directed-edge/manifold/no-lid/floor testleri.
- Tam inline Command Bar örneği; staged install, ownership, actual yüz audit ve manifest değiştirme koruması.
- Model çözümlemesinde yabancı kod unparented temizliği, Image tür kontrolü, kupon değiştirme/eksik yüz blokları.
- Hata sırasında owned replacement rollback, eski düzenlenebilir model backup.
- Yapılandırılmış vaka/karşıörnek eğitim veri seti, source hashes, düşük boyutlu gerçek referans türevleri; family-disjoint bölme ve SFT export.
- 389 VFX kaydı/263 ID korunması; orijinal arşiv değişmezlik kontrolü.

## Değişmedi
Anlamlı yüksek detay, silüet/anatomi/bölgesel bütünlük, görünen içler, gerçek editable rig/keyframe, semantik hareket/VFX, gizli bütçe olmaması, sahte API/ID/kanıt/garanti olmaması.

Mevcut liman/park/orijinal skill üzerinde değişiklik yapılmadı. Yeni skill, model onarımına eşitlenmedi.
'''
}
DOCS['README.md']+='\n## 4.1 eşleşmiş olumlu örnekler\nDört başarılı alt bölge için training/positive_pairs/README.md: referans/gerçek kullanıcı çıktısı,807 kaynak Part, ölçü/rebase hesabı ve4 ek standalone kurulum. Toplam7 standalone örnek; tam görsel gold veya Studio/FPS kanıtı değil.\n'
DOCS['CHANGELOG.md']="# 4.1.0 — olumlu eşleştirme ve güvenli kaynak takibi\n\n- 4 gerçek başarılı alt bölge: referans crop + gerçek kullanıcı çıktısı + tam807Part alt kümesi + origin/ölçü hesabı + Builder + standalone Installer.\n- 76→80 vaka;57→61train,13eval/6test korunur. Bütün liman vakaları aynı ailede.\n- 3 temel+4 eşleşmiş=7 bağımsız Command Bar örneği. Kamera/texture-gated kurulum yeni örneklerde de korunur.\n- Kaynak görüntü dosya adları etiketli overview ile doğrulandı;4.0'daki01/05 ve04/07 semantik eşleme/link hataları düzeltildi. Orijinal görsel baytları ve önceki teslim ZIP'leri değiştirilmedi.\n- Örtülü köprü karesini görsel gold'a zorlamak yerine net kulübe seçildi. Eksik doku/kamera/tekne başarı olarak öğretilmedi.\n- YeniSource parity/mock testleri; canlı Studio/asset/FPS hâlâ NOT_RUN. AI ağırlığı eğitimi değildir.\n\n## Önceki4.0 temeli\n"+DOCS['CHANGELOG.md']
for name,text in DOCS.items():
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf8')
print('Supplement docs:',len(DOCS))
