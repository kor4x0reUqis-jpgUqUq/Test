"""Run reproducible syntax/math/test-double/API-symbol checks. NEVER labels Studio PASS.
Requires official luau and luau-compile binaries (--luau-dir), not bundled in the skill.
Run before build_manifest.py if regenerating validation files.
"""
from pathlib import Path
import json,subprocess,hashlib,ast,shutil,argparse,re,urllib.request
ROOT=Path(__file__).resolve().parent.parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(binary_dir,api_dump):
    compiler=Path(binary_dir)/'luau-compile';runtime=Path(binary_dir)/'luau'
    assert compiler.is_file() and runtime.is_file(),'Official Luau binaries required; do not fake checks'
    report=[]
    for p in sorted(ROOT.rglob('*.luau')):
        if 'history' in p.relative_to(ROOT).parts:continue
        result=subprocess.run([str(compiler),str(p)],capture_output=True,text=True)
        report.append({'file':str(p.relative_to(ROOT)),'source_sha256':sha(p),'status':'PASS' if result.returncode==0 else 'FAIL','error':result.stderr if result.returncode else None})
    py=[]
    for p in sorted((ROOT/'tools').glob('*.py')):
        ast.parse(p.read_text());py.append({'file':str(p.relative_to(ROOT)),'status':'PASS','sha256':sha(p)})
    syntax={'scope':'OFFICIAL_LUAU_SYNTAX_AND_PYTHON_PARSE_NOT_STUDIO','luau_release_used':'0.743','official_release_url':'https://github.com/luau-lang/luau/releases/download/0.743/luau-ubuntu.zip','pass':sum(x['status']=='PASS' for x in report)+len(py),'fail':sum(x['status']=='FAIL' for x in report),'luau_files':report,'python_files':py,'studio_execution':'NOT_RUN'}
    (ROOT/'validation/syntax_results.json').write_text(json.dumps(syntax,indent=2));assert syntax['fail']==0,'Syntax failure'
    result=subprocess.run([str(runtime),str(ROOT/'tests/run_all.luau')],capture_output=True,text=True)
    log=result.stdout+result.stderr;(ROOT/'validation/regressions.log').write_text(log)
    passes=re.findall(r'^PASS (.+)$',log,re.M);failures=re.findall(r'^FAIL (.+)$',log,re.M)
    regression={'scope':'OFFLINE_MATH_AND_TEST_DOUBLE_NOT_STUDIO','pass':len(passes),'fail':len(failures),'tests':passes,'failures':failures,'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in list((ROOT/'tools').glob('*.luau'))+list((ROOT/'tests').glob('*.luau'))},'limits':['Mock fixtures contain fictional IDs, no network or image render','No real Studio permissions/API execution','No actual texture visual or FPS acceptance']}
    (ROOT/'validation/regression_results.json').write_text(json.dumps(regression,indent=2));assert result.returncode==0 and not failures,'Regression failure'
    data=json.loads(Path(api_dump).read_text());classes={c['Name']:c for c in data['Classes']};enums={e['Name']:{i['Name']:i['Value'] for i in e['Items']} for e in data['Enums']}
    symbols={'DataModel':['GetObjects'],'MarketplaceService':['GetProductInfoAsync'],'ContentProvider':['PreloadAsync'],'RunService':['IsStudio','IsRunning'],'ChangeHistoryService':['SetWaypoint'],'HttpService':['GenerateGUID'],'AssetService':['CreateEditableMesh','CreateMeshPartAsync'],'EditableMesh':['AddVertex','AddTriangle','AddNormal','SetFaceNormals'],'GeometryService':['UnionAsync','SubtractAsync','IntersectAsync'],'Camera':['CameraType','CameraSubject','CFrame','Focus','FieldOfView'],'Decal':['TextureContent','ColorMapContent','Texture','Color3','Transparency'],'Texture':['StudsPerTileU','StudsPerTileV','OffsetStudsU','OffsetStudsV'],'KeyframeSequence':['Loop'],'Keyframe':['Time'],'Pose':['CFrame','Weight'],'Motor6D':['Transform']}
    found=[]
    for cls,names in symbols.items():
        for name in names:
            c=classes[cls];member=None
            while c:
                member=next((x for x in c['Members'] if x['Name']==name),None)
                if member:break
                c=classes.get(c.get('Superclass'))
            assert member,(cls,name)
            found.append({'symbol':cls+'.'+name,'member_type':member['MemberType'],'security':member.get('Security'),'tags':member.get('Tags',[]),'status':'PRESENT_IN_API_DUMP_NOT_RUNTIME_PROOF'})
    assert enums['AssetType']['Model']==10 and enums['AssetType']['Image']==1 and enums['AssetType']['Decal']==13
    assert enums['NormalId']=={'Right':0,'Top':1,'Back':2,'Left':3,'Bottom':4,'Front':5}
    assert 'Precise' in enums['RenderFidelity']
    api={'fetched_local_date':'2026-10-24','source':'https://raw.githubusercontent.com/MaximumADHD/Roblox-Client-Tracker/roblox/API-Dump.json','snapshot_sha256':sha(Path(api_dump)),'symbols':found,'relevant_enums':{k:enums[k] for k in ['NormalId','CameraType','PartType','RenderFidelity','AssetFetchStatus']},'asset_type_ids':{'Model':10,'Image':1,'Decal':13},'engine_execution':'NOT_RUN'}
    (ROOT/'validation/api_symbols.json').write_text(json.dumps(api,indent=2))
    status={'skill_version':'4.1.0','date':'2026-10-24','syntax':'PASS','pure_math_and_mock_adapter':'PASS','api_symbol_documentation':'PRESENT_NOT_RUNTIME_TEST','dataset_structure':'VERIFY_PACKAGE','real_studio_execution':'NOT_RUN','live_source_asset_access':'NOT_RUN','resolved_real_image_uri':None,'real_image_visual_coupon':'NOT_RUN','actual_real_texture_application':'NOT_RUN','reference_visual_acceptance':'NOT_RUN','real_physics_avatar_editor':'NOT_RUN','fps_device_measurement':'NOT_MEASURED','fps_numeric':None,'ai_weights_trained':False,'ai_model_benchmark_run':False,'current_maps_modified':False,'reference06_camera_fit':'REJECTED_NOT_A_GOOD_CALIBRATION_EXAMPLE','synthetic_numeric_fit':'PASS_NOT_REAL_REFERENCE_PROOF'}
    (ROOT/'validation/evidence_status.json').write_text(json.dumps(status,indent=2))
    proof={'original_skill_archive_sha256':'25c1289167e2e851d5bc5746bc56e9c0bb5ead4959bef24e3038c7437f248b20','previous_park_archive_sha256':'a6383e0ac87225d41d956a05f3ae256eae21ef42a1c4bd66798c98e0ec3cfaff','previous_harbor_archive_sha256':'248a840a6d3e535fa21a43755ba7a1dd864afc48c81317589b7ecde4e31b7c4b','originals_modified':False,'verification_if_files_present':{}}
    session=ROOT.parent.parent
    for name,key in [('ModelMakerSkills.zip','original_skill_archive_sha256'),('ReferansPark_Harita.zip','previous_park_archive_sha256'),('LimanHaritasi_Studio.zip','previous_harbor_archive_sha256')]:
        p=session/name
        if p.exists():assert sha(p)==proof[key],name;proof['verification_if_files_present'][name]='HASH_MATCH'
    (ROOT/'validation/protected_originals.json').write_text(json.dumps(proof,indent=2))
    print('SYNTAX',syntax['pass'],'PASS; REGRESSIONS',regression['pass'],'PASS;',len(found),'API symbols. REAL STUDIO NOT_RUN.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--luau-dir',type=Path,required=True);parser.add_argument('--api-dump',type=Path,required=True);args=parser.parse_args();main(args.luau_dir,args.api_dump)
