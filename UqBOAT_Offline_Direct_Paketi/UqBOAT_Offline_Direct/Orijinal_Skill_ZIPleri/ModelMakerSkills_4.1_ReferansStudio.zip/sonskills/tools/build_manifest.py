"""Complete SHA256 manifest; intentionally excludes only itself and Python cache dirs."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
manifest={}
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name!='SHA256.json' and '__pycache__' not in p.parts:
        manifest[str(p.relative_to(ROOT))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(ROOT/'SHA256.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
print('Manifest files',len(manifest))
