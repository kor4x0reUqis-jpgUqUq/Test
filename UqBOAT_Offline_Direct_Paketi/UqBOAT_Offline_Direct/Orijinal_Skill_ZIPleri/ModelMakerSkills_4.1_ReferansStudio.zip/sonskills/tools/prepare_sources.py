"""Optional source-image preparation from the original session archive.
No model files are modified. Package includes compact derivatives + original hashes,
not duplicate full-resolution copies. Re-preparation needs --session-root originals.
"""
from pathlib import Path
import argparse,hashlib,json,zipfile,io,base64,math
from PIL import Image,ImageDraw
import statistics
ROOT=Path(__file__).resolve().parent.parent

def sha(b):return hashlib.sha256(b).hexdigest()
def main(session):
    images=ROOT/'training/images';images.mkdir(parents=True,exist_ok=True);records=[]
    def add(id,raw,origin,outname,kind,label,maxdim=1024,exact=False):
        im=Image.open(io.BytesIO(raw)).convert('RGB');original_size=list(im.size);path=images/outname
        if exact:path.write_bytes(raw)
        else:
            im.thumbnail((maxdim,maxdim));im.save(path,quality=86,optimize=True,subsampling=0)
        final=Image.open(path)
        records.append({'source_id':id,'origin':origin,'family_id':kind,'label':label,'original_sha256':sha(raw),'original_bytes':len(raw),'original_dimensions':original_size,'package_image':'images/'+outname,'package_sha256':sha(path.read_bytes()),'package_dimensions':list(final.size),'transformation':'EXACT_BYTES' if exact else 'JPEG_DERIVATIVE_RESIZE_PRESERVE_ASPECT_QUALITY86','pixel_albedo_ground_truth':False})
    refs=session/'Referanslar'
    for i in range(1,10):add(f'harbor_ref_{i:02d}',(refs/f'Liman_{i:02d}.png').read_bytes(),f'User original Liman_{i:02d}.png',f'liman_{i:02d}.jpg','harbor','USER_REFERENCE_NOT_A_MODEL_OUTPUT')
    add('harbor_user_studio_01',(refs/'Liman_Studio_Kullanici_01.png').read_bytes(),'User Studio feedback overview','liman_studio_01.jpg','harbor','SCOPED_LAYOUT_POSITIVE_FOUR_KNOWN_FAILURES')
    add('harbor_user_studio_02',(refs/'Liman_Studio_Kullanici_02.png').read_bytes(),'User Studio feedback boat closeup','liman_studio_02.png','harbor','KNOWN_NEGATIVE_BOAT_USER_REPORTED',exact=True)
    add('park_user_feedback',(refs/'Onceki_Harita_Studio_GeriBildirim.png').read_bytes(),'User park feedback','park_feedback.jpg','park','GENERAL_POSITIVE_LAYOUT_TEXTURE_ISSUES')
    add('forest_cancelled_draft',(session/'Orman_Taslak_Onizleme.png').read_bytes(),'Cancelled draft only, Blender NOT Studio, sources deleted by user','forest_cancelled.jpg','forest_cancelled','CANCELLED_NOT_GOLD')
    with zipfile.ZipFile(session/'ModelMakerSkills.zip') as z:
        for i in [1,2,3]:
            src=f'sonskills/examples/son_olumsuz_kanit/kanit-{i}.png'
            add(f'legacy_negative_{i:02d}',z.read(src),src,f'legacy_negative_{i:02d}.jpg','creature_legacy','ORIGINAL_NEGATIVE_AUTOPSY_NOT_GOLD')
    views={1: 'Arka-üst ana vinç/uzun bom/kabin/asılı konteyner ve depo/gemi', 2: 'Sağ pazar/depo/sarı vinç', 3: 'Zemin yükleme/ana vinç/gemi merdiveni', 4: 'Akvaryum dışı/yan duvar/bitki-balık kuşağı', 5: 'Akvaryum iç duvarı/yansıma şeritleri/deniz canlıları', 6: 'Genel ön-sol/kulübe/tekneler/vinç/depo', 7: 'Tekneler önden/havuz/iskele ve köprü bağlamı', 8: 'Büyük gemi kumanda/baca/arka-yan bakış', 9: 'Meydan/ana vinç ayağı/karşı yön bağlantılar'}
    for record in records:
        if record['source_id'].startswith('harbor_ref_'):record['semantic_view_description']=views[int(record['source_id'][-2:])]
    (ROOT/'training/source_index.json').write_text(json.dumps(records,indent=2,ensure_ascii=False))
    # Approximate annotations, not measured source geometry or calibrated camera ground truth.
    anchors=[
        ('crane_beacon',[.504,.015],[-24,134.5,-44],.8),
        ('operator_cab_center',[.519,.124],[-3,104.2,-44],.7),
        ('cargo_funnel_center',[.220,.178],[-77,51,-89],.7),
        ('cargo_pilothouse_window_center',[.246,.270],[-77,34,-84],.5),
        ('yellow_crane_cab_center',[.694,.273],[62,70.85,-29],.7),
        ('warehouse_door_center',[.611,.370],[78,14,-38.5],.65),
        ('blue_boat_cab_center',[.400,.469],[-36.011416,10.47,19.261467],.4),
        ('red_boat_cab_center',[.617,.450],[40.988584,10.47,21.738533],.4),
        ('hut_roof_center',[.415,.675],[-86,20.8,74],.25),
    ]
    ann={'source_id':'harbor_ref_06','source_width':1919,'source_height':1079,'image':'images/liman_06.jpg','pixel_coordinate_basis':'normalized original full image; no crop','world_basis':'legacy reconstruction estimates, NOT original map dimensions','review_status':'AGENT_APPROXIMATE_ANNOTATION_REQUIRES_HUMAN_REVIEW','initial_guess_eye_yaw_pitch_fovY':[-150,90,140,42,-12,70],'anchors':[{'id':n,'uv_approx':uv,'world_estimate':world,'weight':weight,'uv_uncertainty_radius':.02 if weight>=.5 else .04,'use_for_fit':True} for n,uv,world,weight in anchors]}
    ann['camera_constraints']={'eye_min':[-500,10,20],'eye_max':[-10,350,500],'fovY_min':35,'fovY_max':95,'basis':'HYPOTHESIS_PRIOR_FROM_SCENE_EXTENT_NOT_MEASURED_SOURCE_CAMERA'}
    ann['fit_rms_tolerance']=.025
    (ROOT/'training/annotations_liman06.json').write_text(json.dumps(ann,indent=2,ensure_ascii=False))
    im=Image.open(images/'liman_06.jpg').convert('RGB');draw=ImageDraw.Draw(im)
    for j,(name,uv,world,weight) in enumerate(anchors):
        x,y=uv[0]*im.width,uv[1]*im.height;draw.ellipse((x-5,y-5,x+5,y+5),fill=(255,217,83),outline=(15,20,30),width=2);draw.text((x+7,y-5),str(j+1),fill=(255,255,255),stroke_width=2,stroke_fill=(0,0,0))
    im.save(images/'liman06_annotated.jpg',quality=90,subsampling=0)
    # Actual original PNG samples; not JPEG measurements or proven albedo.
    original=Image.open(refs/'Liman_06.png').convert('RGB')
    patches={'wood_observed':[.763,.742,.785,.772],'red_observed':[.498,.261,.509,.327],'warehouse_blue_observed':[.577,.349,.589,.378],'warehouse_white_observed':[.584,.309,.619,.322]}
    stats={}
    for name,r in patches.items():
        box=(int(r[0]*original.width),int(r[1]*original.height),int(r[2]*original.width),int(r[3]*original.height));crop=original.crop(box);pixels=list(crop.get_flattened_data() if hasattr(crop,'get_flattened_data') else crop.getdata());channels=list(zip(*pixels))
        stats[name]={'normalized_patch':r,'original_pixel_box':list(box),'sample_count':len(pixels),'median_rgb':[statistics.median(c) for c in channels],'p10_rgb':[sorted(c)[int((len(c)-1)*.1)] for c in channels],'p90_rgb':[sorted(c)[int((len(c)-1)*.9)] for c in channels],'label':'OBSERVED_PIXELS_MIXED_STUDS_SHADOW_CAST_NOT_ALBEDO','semantic_patch_human_review':'PENDING'}
    palette={'program_palette_not_source_measured_albedo':{'wood':[167,113,65],'wood_dark':[106,70,43],'white':[223,233,233],'blue':[55,137,183],'red':[194,64,47],'yellow':[224,207,39],'teal':[19,143,135]},'sampled_original_source_sha256':sha((refs/'Liman_06.png').read_bytes()),'observed_patch_stats':stats,'warning':'Patches may include studs/shadow/cast. Human semantic review and neutral-light coupon needed. Lossy package derivatives must not be treated as the original sample.'}
    (ROOT/'training/palette_liman.json').write_text(json.dumps(palette,indent=2,ensure_ascii=False))
    print('Source records',len(records),'package image bytes',sum(p.stat().st_size for p in images.iterdir()))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--session-root',type=Path,required=True);args=p.parse_args();main(args.session_root)
