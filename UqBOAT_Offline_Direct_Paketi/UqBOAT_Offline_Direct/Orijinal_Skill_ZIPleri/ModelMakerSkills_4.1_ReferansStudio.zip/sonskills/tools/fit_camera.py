"""Offline camera-number fitting, never writes a Studio camera.
Dependencies for this optional lesson only: numpy, scipy.
3D points are reconstruction estimates; annotated 2D points are approximate.
A low residual is not proof of original dimensions, source pose or visual fidelity.
"""
from pathlib import Path
import argparse,json,math,hashlib
import numpy as np
from scipy.optimize import least_squares

def project(points,params,aspect):
    eye=np.array(params[:3]);yaw,pitch=np.radians(params[3:5]);fov=params[5]
    f=np.array([math.sin(yaw)*math.cos(pitch),math.sin(pitch),-math.cos(yaw)*math.cos(pitch)])
    right=np.cross(f,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,f)
    delta=points-eye;depth=delta@f;safe=np.maximum(depth,.01);t=math.tan(math.radians(fov)/2)
    uv=np.column_stack((.5+(delta@right)/(2*safe*t*aspect),.5-(delta@up)/(2*safe*t)))
    return uv,depth,f

def fit(data):
    a=[x for x in data['anchors'] if x.get('use_for_fit',True)]
    assert len(a)>=6,'Need at least six named, spatially distributed correspondences'
    points=np.array([x['world_estimate'] for x in a]);target=np.array([x['uv_approx'] for x in a]);weights=np.array([x['weight'] for x in a]);aspect=data['source_width']/data['source_height']
    def residual(p):
        uv,z,_=project(points,p,aspect);r=(uv-target)*np.sqrt(weights)[:,None]
        behind=np.maximum(.01-z,0)/20
        return np.r_[r.ravel(),behind]
    initial=data['initial_guess_eye_yaw_pitch_fovY']
    prior=data.get('camera_constraints',{})
    low=prior.get('eye_min',[-np.inf]*3)+[-179.9,-89.0,prior.get('fovY_min',1.0)]
    high=prior.get('eye_max',[np.inf]*3)+[179.9,89.0,prior.get('fovY_max',120.0)]
    solution=least_squares(residual,initial,bounds=(low,high),loss='soft_l1',f_scale=.025,max_nfev=4000)
    uv,z,f=project(points,solution.x,aspect)
    delta=uv-target;rms=float(np.sqrt(np.sum(weights*np.sum(delta**2,axis=1))/sum(weights)))
    eye=solution.x[:3];look=eye+f*100
    tolerance=data.get('fit_rms_tolerance',.02)
    reasons=[]
    if rms>tolerance:reasons.append('RMS_EXCEEDS_DECLARED_MEASUREMENT_TOLERANCE')
    if np.any(z<=0):reasons.append('ANCHOR_BEHIND_CAMERA')
    boundary=any((math.isfinite(l) and abs(p-l)<1e-4) or (math.isfinite(h) and abs(p-h)<1e-4) for p,l,h in zip(solution.x,low,high))
    if boundary:reasons.append('PARAMETER_AT_BOUNDARY_POSSIBLE_DEGENERATE_FIT')
    if not solution.success:reasons.append('OPTIMIZER_DID_NOT_CONVERGE')
    return {'kind':'OFFLINE_NUMERIC_FIT_NOT_STUDIO_APPLIED','source_id':data['source_id'],'annotations_are_approximate':True,'world_points_are_reconstruction_estimates':True,'optimizer_success':bool(solution.success),'fit_quality':'REJECTED' if reasons else 'NUMERIC_FIT_ONLY_REVIEW_PENDING','rejection_reasons':reasons,'declared_RMS_tolerance':tolerance,'constraints_are_hypothesis_not_measurement':prior,'eye':eye.tolist(),'target_100_units_forward':look.tolist(),'fovY':float(solution.x[5]),'roll_assumed_degrees':0,'normalized_weighted_RMS':rms,'not_automatic_visual_acceptance':True,'residuals':[{'id':x['id'],'expected_uv':x['uv_approx'],'projected_uv':v.tolist(),'delta_uv':d.tolist(),'depth':float(depth)} for x,v,d,depth in zip(a,uv,delta,z)],'note':'Residual cannot distinguish all calibration, annotation and geometry errors. Do not alter landmarks or inflate tolerance to force PASS.'}
if __name__=='__main__':
    root=Path(__file__).resolve().parent.parent
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=root/'training/annotations_liman06.json');p.add_argument('--output',type=Path,default=root/'validation/camera_fit_example.json');args=p.parse_args()
    data=json.loads(args.input.read_text());result=fit(data);result['input_sha256']=hashlib.sha256(args.input.read_bytes()).hexdigest();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False));print(json.dumps(result,indent=2,ensure_ascii=False))
