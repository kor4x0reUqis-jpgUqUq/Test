"""Create labeled reference/negative/synthetic cases and family-disjoint SFT exports.
No weights are trained. Bad historical code is never a gold assistant target.
Image derivatives/provenance are prepared separately from original user sources.
"""
from pathlib import Path
import json,math,hashlib,collections
ROOT=Path(__file__).resolve().parent.parent
CASES=[]
FAMILY_SPLIT={'harbor':'train','math_synthetic':'train','asset_contract':'train','delivery_contract':'train','hull_synthetic':'train','camera_safety':'eval','park':'eval','forest_cancelled':'eval','creature_legacy':'test','rig_vfx':'test'}

def case(id,family,title,task,action,math_steps=None,checks=None,images=None,label='CORRECTIVE_EXERCISE',basis='AGENT_CURATED_NOT_HUMAN_GOLD',code=None):
    answer={'action':action,'worked_calculation':math_steps or [],'required_checks':checks or [],'evidence_rule':'Do not convert syntax/numeric/mock evidence to Studio, image, visual or FPS proof.'}
    if code:answer['code_example']=code
    item={'schema_version':'1.0','id':id,'family_id':family,'split':FAMILY_SPLIT[family],'title':title,'language':'tr','input':{'task':task,'images':images or [],'active_source_model_id':9454666962 if family in ('harbor','asset_contract') else None},'label':label,'provenance':{'basis':basis,'human_reviewed_target':False,'current_map_repaired':False},'target':answer}
    CASES.append(item)

# Harbor: one scene family only in train; all views/feedback remain in that family.
h='images/liman_06.jpg';user1='images/liman_studio_01.jpg';user2='images/liman_studio_02.png'
case('H01','harbor','Tema değil ilişki','9 karede liman var; aynı renk nesneleri rastgele koyarak bitir.',
     'Önce aynı object_id ile yerleşim, taşıma ve boşluk/rota graflarını kur. Depo-sarı vinç, arka gemi, merkez tekneler ve sağ tezgâh ilişkisinden başla; nesne adedi yeterli değil.',checks=['landmark/ratio across views','occlusion/order','connected paths'],images=[h,'images/liman_01.jpg'],label='SCOPED_POSITIVE_LAYOUT',basis='USER_APPROVED_GENERAL_LAYOUT_EXCEPT_FOUR_REPORTED_ISSUES')
case('H02','harbor','Vinç alt öğelerini aynı aynayla taşı','Kule x=-24. Kol merkezi-11, kabin-45, konteyner17. Ters görünüme göre uzun kol tarafı yanlış.',
     'Ortak referans ekseninde bütün ilişkili alt öğeleri aynala; rotasyon/bazı da sağ elli olarak yeniden kur. Sadece konteynerin işaretini değiştirme.',
     ['x_mirror=2*(-24)-x','beam center=-48-(-11)=-37','cab=-48-(-45)=-3','container=-48-17=-65'],['all views','cable attachments after mirror','det(R)=+1'],images=['images/liman_01.jpg',h])
case('H03','harbor','Sağ tezgâhı ön kenara koyma','Mavi/beyaz tezgâhın yeri genel temaya göre ön kenara seçildi.',
     'Kaynak02/06 ile sağ yan iskele-depo-sarı vinç ilişkisini doğrula. Düzeltilen yeniden kurulum parametresi (97,5.6,4) bir kaynak ölçüsü değil ama aynı ilişkisel hedefe dayanır. Ayakların gerçekten zemine oturduğunu ölç.',checks=['right quay relation','8 stall post contacts','source pose compare'],images=['images/liman_02.jpg',h])
case('H04','harbor','Eksik gerçek studs','Haritada0 Texture var; yalnız doku helperı ekli. Tamamlandı diyebilir miyim?',
     'Hayır. Kullanıcı bunu hata olarak bildirdi. Gerekli gerçek image çözümü/kupon/gerçek yüz uygulaması olmadan dokulu final diye kurma veya sunma. Engeli BLOCKED olarak koru; helper uygulanmış doku değildir.',checks=['Image(1) chain','human coupon','actual coverage','near/far source appearance'],images=[user1],label='KNOWN_NEGATIVE_MISSING_TEXTURE',basis='USER_REPORTED_FAILURE')
case('H05','harbor','Dosya yerine istenen kod','Kullanıcı kurulum kodu istiyor. .rbxlx verip README ekledim.',
     'Ana teslim tam standalone Studio EDIT kurulum kodu olmalı. Dosyayı ancak ek olarak ver. Doku modülü tek başına geometriyi kuran kod değildir.',checks=['self-contained code','correct execution context','no hidden file/module dependency'],images=[user1],label='KNOWN_NEGATIVE_DELIVERY',basis='USER_REPORTED_FAILURE')
case('H06','harbor','Kamera kilidi','Sahne açıldığında CameraType Scriptable kaldı; kullanıcı hareket ettiremiyor.',
     'Default kurulum/kupon aktif kameraya yazmamalı. Tek bir ekran görüntüsünden bütün kilit nedenlerini kesinleştirme; Type, scripts ve repeated writes kontrol et. Geçici capture açık opt-in ve restore gerektirir.',checks=['zero default camera writes','control in actual Studio','restore on exception'],images=[user1],label='KNOWN_NEGATIVE_CAMERA',basis='USER_REPORTED_FAILURE')
case('H07','harbor','17 PASS ama tekne hatalı','17 offline test geçti. Kullanıcı yakın planda teknelerde hata olduğunu söylüyor.',
     'Kullanıcı görsel kusurunu geçersiz sayma. Mevcut çıktıyı KNOWN_NEGATIVE/boat olarak etiketle. Pruva/karina/borda, güverte, biniş açıklığı ve iki halat ucu için kaynakla yakın plan kontrolü gerekir. Özgül sebep doğrulanmadan tek kesin teşhis verme.',checks=['source/boat closeups','silhouette and underside','boarding clear route','rope endpoint contacts'],images=[user2,'images/liman_07.jpg'],label='KNOWN_NEGATIVE_BOAT',basis='USER_REPORTED_FAILURE_NUMERIC_PASS_DID_NOT_CATCH')
case('H08','harbor','Kazık ve kiriş ekseni','w=207; kazık .34w, kiriş .33w. Yarı enler.85 ve.65. Her şey ortonormal.',
     'Merkezleri aynı kiriş soketinden türet; şu an gerçek boşluk var. Matris testi temas testinin yerine geçmez.',
     ['offset=(.34-.33)*207=2.07','allowed half-width sum=.85+.65=1.50','gap=.57 stud'],['actual OBB contact','keep physical epsilon small'])
y=math.radians(-5);px=-39+math.cos(y)*(-12)+math.sin(y)*7.36;pz=19-math.sin(y)*(-12)+math.cos(y)*7.36
case('H09','harbor','Tekne local biniş ucu','O=(-39,0,19), yaw=-5°, local A=(-12,6.65,7.36). World A?',
     'Ucu teknenin ortak dönüşümünden hesapla; ayrı tahmini world değeri verme. Bu yalnız konum hesabıdır, tüm tekne görsel onayı değildir.',
     [f'x=-39+cos(-5°)*(-12)+sin(-5°)*7.36={px:.12f}','y=6.65',f'z=19-sin(-5°)*(-12)+cos(-5°)*7.36={pz:.12f}'],['actual hull/deck endpoint','inverse transform roundtrip','boarding opening'],code='examples/Hesaplar.md')
case('H10','harbor','Halatın yalnız Y seviyesini kontrol etme','Bom z aralığı[-50.5,-37.5]; halat üstü z=-58; üst Y doğru.',
     'Y eşitliği bağlılık değildir. Z dışında biten halat için gerçekten boma bağlanan travers veya doğru soket gerekir. Spreader→halat→üst travers→bom zincirini hacim test et.',
     ['z=-58 is 7.5 studs outside nearer beam boundary -50.5'],['all4 upper/lower endpoints','traverse/boom actual contacts'])
case('H11','harbor','Köprü sahanlığı su üstünde izole','Kemer güzel ama iki küçük sahanlık ana iskeleye ulaşmıyor.',
     'Yaklaşım geçişlerini gerçek geometriyle bağla; Part seviyesinde rota grafını hesapla. Aynı Model adı altında olmak bağlantı değildir.',checks=['per-part connectivity','two landings','small documented plank seams only'])
case('H12','harbor','Coplanar asfalt ve ahşap','İki döşeme top5.6, alanları örtüşüyor; koyu texture ile gizleyelim.',
     'Pozitif alanlı aynı-düzlem bindirmesini kırp/böl. Malzeme/Neonla saklama. İç taşıyıcı örtüşmesi ile görünür üst yüz çakışması ayrı.',checks=['XZ overlap area at same topY','near/far z-fighting'],label='CORRECTIVE_GEOMETRY')
case('H13','harbor','Onayı bütün sahneye genişletme','Kullanıcı diğer her şey istendiği gibi; studs/kod/kamera/tekne yanlış dedi.',
     'General layout/style alt kapsamını olumlu koru. Dört hatayı ayrı negatif tut; tüm sahneyi GOLD veya tüm sahneyi FAIL etiketleme. Actual Studio screenshot, ajanın Studio çalıştırması demek değildir.',checks=['scoped labels','failure exceptions','evidence source'],images=[user1,user2],basis='EXPLICIT_USER_SCOPED_FEEDBACK',label='USER_SCOPED_APPROVAL_WITH_EXCEPTIONS')
case('H14','harbor','Kamera fit kaynak boyutu değildir','Yaklaşık2D noktalar ve eski yeniden kurulum3D tahminleriyle kamera fit düşük residual verdi.',
     'FIT_ESTIMATE etiketi kullan. Annotation, pose ve geometri hatası karışabilir. Kaynak ölçüsünü veya birebirliği doğrulandı sayma; held-out görünüş/negatif boşluk ve insan incelemesi ekle.',checks=['approximate annotations','known vs estimated 3D','held-out view'],images=[h],code='tools/fit_camera.py')

# Synthetic math: independently checkable outputs; not image measurements.
case('M01','math_synthetic','Tek ölçek ve dönüş','O=(10,3,-5), yaw90°, p=(2,4,6), s2.',
 'Translation ve boyutları2 ile çarp, açıyı veya rotasyon matrisini çarpma.', ['s*p=(4,8,12)','Ry90*(4,8,12)=(12,8,-4)','world=(22,11,-9)'],['inverse roundtrip','detR=1'],label='SYNTHETIC_NUMERIC_GOLD')
case('M02','math_synthetic','İkinci world offset','modelWorld zaten(10,0,0); partLocal(3,0,0). Kod iki kez modelWorld ekliyor.',
 'Tek root dönüşümü uygula; sonuç13,23 değil.', ['10+3=13','10+(10+3)=23 is double offset'],['one transform source'],label='SYNTHETIC_NUMERIC_GOLD')
case('M03','math_synthetic','Ayna determinantı','X mirror matrix diag(-1,1,1) CFrame rotation olur mu?',
 'Hayır; yön/normal ve asimetrik ayrıntılarla sağ elli baz yeniden kurulmalı.', ['det(diag(-1,1,1))=-1'],['orthonormal AND positive determinant'],label='SYNTHETIC_NUMERIC_GOLD')
case('M04','math_synthetic','Merkezden değil tabandan yerleşim','Zemin top5.6, sandık h5.5. CenterY?',
 'Gerçek alt yüzü hedefe oturt.', ['centerY=5.6+5.5/2=8.35','bottom=8.35-2.75=5.6'],['actual platform support'],label='SYNTHETIC_NUMERIC_GOLD')
case('M05','math_synthetic','Paralel kutular temas','A center0 size2; B centerx2 size2.',
 'Eşit yüzler temas eder; Bx2.01 olursa.01 boşluk vardır, epsilon1e-5 ile fail.', ['gap=2-(1+1)=0','newgap=2.01-2=.01'],['SAT instead of rotation-only'],label='SYNTHETIC_NUMERIC_GOLD')
case('M06','math_synthetic','Rota derzi vs metal temas','.025 stud tahta derzi var; metal sokette de .025 boşluk var.',
 'Rota komşuluğu için belgeli .0301 izin fiziksel metal temas değildir. Sokette gerçek temas toleransı ile fail tut.',checks=['separate tolerance semantics','no epsilon inflation'],label='SYNTHETIC_POLICY_GOLD')
case('M07','math_synthetic','Perspective depth','İki nesnenin dünya eni8; depths10 ve20; aynı focal.',
 'Yakındaki ekranda2kat büyük; fiziksel eni2kat sanma.', ['p1=f*8/10','p2=f*8/20','p1/p2=2'],['depth-aware scale'],label='SYNTHETIC_NUMERIC_GOLD')
case('M08','math_synthetic','Weighted scale','r=(3,5); k=(6,10); w=(1,2).',
 'Perspektiften arındırılmış bu ölçülerde least-squares tek ölçek2.', ['num=1*3*6+2*5*10=118','den=1*9+2*25=59','s=2'],['known anchors required'],label='SYNTHETIC_NUMERIC_GOLD')
case('M09','math_synthetic','Normalize ekran noktası','1919x1079 görüntüde x=959.5 y=539.5.',
 'Normalize(.5,.5); resize sonrası aynı, crop sonrası offset düzeltilmeli.', ['u=959.5/1919=.5','v=539.5/1079=.5'],['crop vs resize distinction'],label='SYNTHETIC_NUMERIC_GOLD')
case('M10','math_synthetic','Weighted RMS','İlk fark(.02,0), w1; ikinci(0,.01), w3.',
 'Normalize RMS sqrt(.0007/4), tek pixel-MAE değil.', ['sum=.0004+3*.0001=.0007','RMS=0.0132287565553'],['uncertainty-aware threshold'],label='SYNTHETIC_NUMERIC_GOLD')
case('M11','math_synthetic','Kamera arkasındaki nokta','Camera eye(0,0,10), forward-Z; nokta(0,0,11).',
 'Depth-1; ekran landmarkı olarak projekte etme, BEHIND_CAMERA etiketle.', ['depth=10-11=-1'],['positive depth'],label='SYNTHETIC_NUMERIC_GOLD')
case('M12','math_synthetic','sRGB yarım kanal','sRGB .5 linear .5 midir?',
 'Hayır, gamma dönüşümü uygula.', ['((.5+.055)/1.055)^2.4=.214041140482'],['sRGB/linear labeling'],label='SYNTHETIC_NUMERIC_GOLD')
case('M13','math_synthetic','Işığı iki kez uygulama','Linear .21404114 enerji2kat aydınlatıldı.',
 'Görünüşlinear .42808228; sRGB yaklaşık.685836. Gözlenen değeri yeniden albedo diye seçme.', ['linear=.428082280964','sRGB=1.055*linear^(1/2.4)-.055≈.685836','8bit≈175'],['neutral/material vs observed pixel'],label='SYNTHETIC_NUMERIC_GOLD')
case('M14','math_synthetic','Basit cam alfa örneği','Linear surface(.6,.6,.6), glass(.05,.15,.8), opacity.25.',
 'Basit alfa karışımı(.4625,.4875,.65); gerçek Roblox Glass tam simülasyonu diye sunma.', ['C=.75*surface+.25*glass'],['shader approximation disclosure'],label='SYNTHETIC_NUMERIC_GOLD')
case('M15','math_synthetic','Yatay kapı ölçüsü','32 genişlik; ön iki panel8.4; ribler.25 içeri giriyor.',
 'Ham gap15.2; her iki tarafta.25 daralırsa gerçek clear14.7.', ['32-2*8.4=15.2','15.2-2*.25=14.7'],['clear opening includes trim'],label='SYNTHETIC_NUMERIC_GOLD')
case('M16','math_synthetic','Dikey kapı ölçüsü','Header altı16; iç floor top.8.',
 'Clearheight15.2,16 değil.', ['16-.8=15.2'],['frame/floor ray tests'],label='SYNTHETIC_NUMERIC_GOLD')
case('M17','math_synthetic','Soket ölçeği','Local socket(2,3,4), scale.5; rot yaw30°.',
 'Socket translation(1,1.5,2); rot30° kalır. Attachment/Motor offsets de aynı sözleşmede.', ['p_scaled=(1,1.5,2)'],['joints and geometry same scale'],label='SYNTHETIC_NUMERIC_GOLD')
case('M18','math_synthetic','Normal yönleri','Dünya ön tarafım+Z; Native Texture.Front hangisi?',
 'NativeFront yerel-Z, Back yerel+Z. Bütün gerekli yüzleri açık maskelemek, kameranın önüyle karıştırmaktan kurtarır.', ['Right1+Top2+Back4+Left8+Bottom16+Front32=63'],['6 local directions'],label='SYNTHETIC_NUMERIC_GOLD')
case('M19','math_synthetic','Coplanar alan','A x[-5,5],z[-2,2]; B x[4,8],z[-1,1], aynı top.',
 'Pozitif overlap1*2=2 stud²; görünür yüz kırpılmalı.', ['overlapX=5-4=1','overlapZ=1-(-1)=2','area=2'],['same-height positive area'],label='SYNTHETIC_NUMERIC_GOLD')
case('M20','math_synthetic','Sıfır/parallel lookAt','Eye target ile aynı ya da forward up ile parallel.',
 'Sıfır yönü reddet; parallel up için deterministik alternatif baz seç; NaN CFrame kurma.',checks=['unit zero assert','fallback up','det+1'],label='SYNTHETIC_POLICY_GOLD')

assets=[
 ('A01','Model image değildir','9454666962 sayısını doğrudan TextureContent yap.', 'Model10 kapsayıcısını çöz; gerçek Image1 URI olmadan main install BLOCKED.', ['assetTypeId==1','sourceID!=imageID']),
 ('A02','İlk aday otomatik onay değil','Modelden tek Texture çıktı, kuponu atla.', 'Tek aday olsa da gerçek motif/atlas/kontrast insan kuponu gerekir; otomatik onay yok.', ['candidate explicit','human ack']),
 ('A03','Fetch görünüş değil','PreloadAsync success; studs doğru.', 'Yalnız fetch geçti. Yanlış atlas da başarıyla indirilebilir; görsel inceleme ayrı.', ['fetch status','visual coupon']),
 ('A04','Tile motif sayısı','Tile4 motif içeriyor; hedef1.25stud aralık.', 'Bütün tileU5stud olmalı; tile1.25 motif spacing.3125 üretir.', ['tileU=4*1.25=5','near/far spacing']),
 ('A05','Güvenli Model inceleme','Kaynak ModuleScriptini require ederek texture yolunu al.', 'Yabancı kod parent/require/execute edilmez. Unparented veri taraması, LuaSourceContainer silme ve finally cleanup.', ['foreign scripts destroyed','no source parenting']),
 ('A06','Eksik yan yüz','Sadece Top/Bottom texture var; toplam yüksek.', 'Ana katıların ön/arka/sağ/sol yüzlerini de maske/görünüş denetimine kat; sayıyı kalite sanma.', ['per-direction matrix','immutable surface policy']),
 ('A07','Maske değiştirerek testi kandırma','EksikRight yüzü maskeden kaldırdım, auditPASS.', 'Kurulumdaki immutable yüz sözleşmesiyle live maskeyi karşılaştır; değiştiyse yeni onay/test gerekir.', ['baseline policy vs current','duplicate layer test']),
 ('A08','Local phase dünya sürekliliği değil','OffsetStuds0 tüm döndürülmüş parçalarda global grid garantiler.', 'Hayır. Yerel U/V yönü parçayla döner. Dünya fazı için yüz bazını/başlangıç ve işareti kuponla kalibre et.', ['seam inspection','phase policy explicit']),
 ('A09','İzin ile lisansı ayır','Model free/public ve fetchsuccess; yeniden satış hakkı var.', 'Metadata/fetch erişim göstergesidir, lisans/ticari yayın hakkı kanıtı değil. Hak durumunu UNKNOWN tut.', ['type/access/rights separate']),
 ('A10','Yeni Content API','TextureContent ve ColorMapContent aynısavebayrağı mı?', 'Dokümanı denetle; örnek serializable TextureContent kullanır. ColorMapContent adının güncel olması save/reopen testinin yerine geçmez.', ['API field metadata','saved roundtrip pending'])]
for id,title,task,action,checks in assets:case(id,'asset_contract',title,task,action,checks=checks)

cameras=[
 ('C01','Default kupon kamera taşımaz','Kuponu yararlı olsun diye aktif kamerayı otomatik üstten taşı.', 'Kuponu oluştur/yerini bildir; F ile odaklama kullanıcı eylemi. Default CFrame/Type/Focus/FOV/Subject write0.'),
 ('C02','Hata yolunda restore','Screenshotcallback hata verdi; kameraScriptablekaldı.', 'Snapshot+try/finally; başarı ve exception yolunda bütün değiştirilen alanları geri yükle.'),
 ('C03','Subject nil yanlışı','Eski Subjectnil; restore sırasında nil atıyorum.', 'CameraSubjectnil atanamaz; snapshotnilse setetme. DefaultCustom/humanoid atayıp kullanıcının modunu ezme.'),
 ('C04','Kamera swap koruması','Capture sırasında kullanıcı yeni CurrentCamera seçti.', 'Yeni kamerayı ezme veya eski nesneyi zorlaCurrentCamera yapma. Restoreengelini açık raporla.'),
 ('C05','Sürekli frame yazma','Bir görünüşü korumak için her RenderStepped CFrame ata.', 'İstenen kamera kontrolü yoksa bu kilittir. İnceleme pozları veri olarak kalır; opt-in bounded callback dışında binding yok.'),
 ('C06','Kamera preview ayrı veri','YedekCameraWorkspacealtınakoyup CurrentCamera swap yaptım.', 'DirectWorkspacekamera nesneleri swapta yok olabilir. Folder/Model veya saltCFrame verisi kullan; defaultinstaller swap yapmasın.')]
for id,title,task,action in cameras:case(id,'camera_safety',title,task,action,checks=['default zero writes','optional restoration','actual Studio control NOT_RUN'],basis='OFFICIAL_DOC_AND_MOCK_REGRESSION')

geo=[
 ('G01','Kapalı primitive kapalıModel değil','6kapalı kutu var, teknegövdesi tamam.', 'Kutuların temas/yüzey zinciri, kesit geçişi ve dış silüeti ayrıca gerekir; kapalılık yeterli değil.'),
 ('G02','Açık üst ve kapalı duvar','Tekne üstü açık olsun diye alt/arka yüzleri de sildim.', 'Outer+inner wall/keel+gunwale+endwall kapalı sınır oluşturur; yalnız iç hacme üstten açıklık intentional.'),
 ('G03','Kenar yönü','Her meshkenarında2yüz var ama winding aynı.', 'Yüz sayısı yetmez; ortak kenar iki zıt yönde dolaşılmalı. Normal/signedvolume ayrıca kontrol.'),
 ('G04','Sahte kapı','Koyu dikdörtgenDecal kapı gibi.', 'Gerçek boşluk, iç taban/yan/arka/tavan ve çok örnekli ışın testi gerekir.'),
 ('G05','Borda binişi engelliyor','Biniş tahtasıbordaya değdi, avatargeçer.', 'Değmekgeçilebilirlikdeğildir. Borda açıklığı/iniş basamağı/korkuluk geçişi ve actualavatar testi ayrı.'),
 ('G06','AABBmesh yüzeyi değildir','EditableMeshAABBsi iskeleyle kesişiyor, halat bağlı.', 'Mesh gerçeksurface/soket/ray kontrolü gerekir. OBB exactBlockaçıktestidir, mesh yüzeyi değil.'),
 ('G07','CSG sonuç dizisi','SubtractAsync tekparça döner diye ilkini aldım.', 'Bütün sonuç dizisini işle; unparented sonuçları validate/parent et; kaynakları başarıdan sonra ownedtagile sil.'),
 ('G08','Detay ile formu gizleme','Gövde kutuama2000studs/parçaekledim.', 'Büyük/orta form, oran ve geçiş kapısı geçmeden mikro detay çoğaltma. Parça sayısı kalite puanı değildir.')]
for id,title,task,action in geo:case(id,'hull_synthetic',title,task,action,checks=['surface topology','critical closeup','scope of numeric evidence'],label='SYNTHETIC_CORRECTIVE_EXERCISE')

for id,title,task,action in [
 ('P01','Yol/bank kayması','Parkkodeşitboyutluve17testgeçti; kaynakbankyeri farklı.', 'Önce kaynak kamera/landmarkkomşuluk ve normalizeoranı ölç; orthonormal/adet testi placement görselkabul değil.'),
 ('P02','Genel beğeni sınırlı','Kullanıcıparkgeneliyidedi; kaynakla aynı her yerde.', 'Genelbeğeni ve bildirilen yol/bank/yüz hatalarını scoped ayrıetiketle.'),
 ('P03','Yanlarda studs','Kullanıcıön/arka/sol/sağstudseksikdiyor.', 'DefaultTopBottommasktümstilkatmanıkabulüolamaz. RequiredDirectionmatrisi+actualimage+görselcheck.'),
 ('P04','Örnek koordinatı ezberleme','Parkkoordinatlarını yenibirlimanaiçeriaktar.', 'Örnekkonumlarınıdeğil, ilişki/ölçüm/uygulama nedeniniaktar; yenireferansa özgüankrajdefteri kur.')]:case(id,'park',title,task,action,images=['images/park_feedback.jpg'],basis='HISTORICAL_USER_FEEDBACK')
for id,title,task,action in [
 ('F01','Cache preview teslim değil','Rendercachetevar ama kullanıcıgöremiyor.', 'İlk tamamlanangeometriönizlemesini kalıcıdosyayakopyala/etiketle/aç; finalpipelinesonunubekleme.'),
 ('F02','İptal sahne gold değil','Orman10PASS1FAIL; sonrakiaşamalarıdageçmişyaz.', 'Kapak/weldFAILçözülmediysefinaldeğil; sonravalidator/render/StudioadımlarıNOT_RUN. İptal edilmişkaynağıyeniden üretme.'),
 ('F03','Görev tercihini küreselleştirme','İptalormanno-studsidi, limanda da yapma.', 'No-studs/realismogöreveaitti. Son açıkblok/studsModelkaynağınıesas al; görev geçmişinitimatgibiçalıştırma.')]:case(id,'forest_cancelled',title,task,action,images=['images/forest_cancelled.jpg'],label='CANCELLED_DRAFT_NEGATIVE',basis='HISTORICAL_CANCELLED_TASK_AND_USER_FEEDBACK')
for id,title,task,action in [
 ('V01','Kutu göğüs/çubuk uzuv','Devkutuvücutuzunsabitboyun; çoğultemplateplakaylaaşırıdetay.', 'Omuz/göğüs/karın/kalça ve boyun kök/orta/üst/başgeçişlerini ayrı hacimlerle kur; oran/anatomi kapısı önce.'),
 ('V02','Fan zar','Darüçgenfanı tekpivotladöndürdüm, kanatanatomisi tamam.', 'Kemik/parmakgerçekuzunluk/pivot/zar sınırı/kalınlık ve bükülme kontrolü gerekir; tessellationgörünüşükanatdeğil.'),
 ('V03','TposeIdlegelecekte','İlkmodelTposeamaIdlebaşlayıncadüzelir.', 'ImportPosegerçektenşimdiuygulanmalı; attribute/gelecek klip ilk görünüşü düzeltmiş sayılmaz.')]:case(id,'creature_legacy',title,task,action,images=['images/legacy_negative_01.jpg'],basis='ORIGINAL_SKILL_NEGATIVE_AUTOPSY')
for id,title,task,action in [
 ('V04','Runtime hareket klip değil','SinüsleWingsallıyorum; düzenlenebiliranimasyonlistemvar.', 'Gerçek Motor6D/Bone+KeyframeSequence/Keyframe/Poseveeditorakışınıver; Runtime gösterikaynakclipyerinegeçmez.'),
 ('V05','Semantik hareket','Bütünhayvanlaraaynı3klibyazıpadınıWalk/Fly/Biteyaptım.', 'Türegöreprepare/force/recoverveimzapozları; marker/bölge/rig/manifest isimlerini tutarlı yap.'),
 ('V06','VFXtür/hak karışması','KatalogdatümIDlerParticleTexturelisanslıdır.', '389kayıt263ID havuzunukoru ama metadatatype/access/rights/renderayrıdoğrula; Sound/Beam/Particle rollerini karıştırma.')]:case(id,'rig_vfx',title,task,action,checks=['editable source clips','no invented animation/asset IDs','only when requested'])
for id,title,task,action in [
 ('D01','Standalone kaynak','Kurulumkodu öncekigizliModuleScriptgerektiriyor.', 'Kütüphane/builddata inline veya açık paketli doğru executioncontextile ver; tekassetbaşkakoleksiyongizlibağımlılığıolmasın.'),
 ('D02','Bilinen eksikle tamam deme','Assetengedlendiamaimagetile yerinegeneratedstudsilebitir.', 'Kullanıcı onaysızikameyapma; BLOCKED_ASSETvegerçekdeneme/hata/aksiyon kaydı. Ana kod/paket teslimi modelin görsel tamamlığına eşitlenmez.'),
 ('D03','Bütçeyle sessiz kesme','100nesneistendi, ilk20detaylısonrasıbasitproxy.', 'GizliPart/kodbütçesi koyma. Kaynaksınırında parti kapsamını açık azalt ve onayla; kaliteyi sessiz düşürme.'),
 ('D04','Rapor kapıları ayrı','Syntaxvemockgeçti; StudioFPS60yaz.', 'GerçekStudio/asset/render/fizik/FPSgözlemi yoksa NOT_RUN/NOT_MEASURED, sayısalFPSnull.'),
 ('D05','İlgisizmekanik ekleme','Statikharitayagirinceforkliftsürüş/teleportekle.', 'İstenmedikçe gameplay/animasyon/VFXekleme. Görevkapsamı veteslimbiçiminikoru.')]:case(id,'delivery_contract',title,task,action,checks=['scope contract','explicit delivery','no false evidence'])

# v4.1: paired successful geometry/layout subsets, still the same harbor train family.
positive_index=json.loads((ROOT/'training/positive_pairs/index.json').read_text())
for pair in positive_index:
 folder=ROOT/pair['directory'];measure=json.loads((folder/'measurements.json').read_text());sample=measure['worked_samples'][0]
 case(pair['id'],'harbor',pair['title'],
      'Kullanıcının beğendiği bu alt bölgenin referansını, gerçek geometri verisini ve çıktı görüntüsünü birlikte incele; yeni görevde aynı ilişkiyi hesapla, kör koordinat kopyalama.',
      pair['lesson']+' Geometri/yerleşim kabulü kapsamlıdır: eksik doku, kilit kamera, eski dosya-odaklı teslim ve hatalı tekneler gold değildir. Yeni standalone wrapper actual texture ve serbest kamera kapılarını uygular; gerçek Studio testi NOT_RUN.',
      ['origin='+str(measure['source_world_origin']),
       'sample originalWorld='+str(sample['original_world']),
       'local=originalWorld-origin='+str(sample['rebased_local']),
       'Rotation and dimensions retained; rootWorld=(0,8,0) only for teaching placement.',
       'required surface faces='+str(measure['expected_texture_faces_when_required'])],
      ['exact source-subset parity','actual material/direction/texture audit','source reference/output are not same camera','default camera write0','external map supports separately'],
      [str((folder/'reference_crop.jpg').relative_to(ROOT/'training')),str((folder/'user_output_crop.jpg').relative_to(ROOT/'training'))],
      label='USER_SCOPED_POSITIVE_GEOMETRY_LAYOUT',basis='SCOPED_USER_FEEDBACK_AND_EXACT_DELIVERED_SCENE_SUBSET_NOT_FULL_GOLD',
      code=str((folder/'Installer_CommandBar.luau').relative_to(ROOT)))

# Reviewed editorial expansions: preserve clear Turkish targets (not typo imitation).
CLEAN={
'P01':('Park kodunda boyutlar ve sayısal testler geçiyor ama bankın yeri kaynakta farklı.', 'Önce kaynak kamerası, landmark komşuluğu ve normalize oranı ölç. Ortonormal matris/adet testi, yerleşimin görsel kabulü değildir.'),
'P02':('Kullanıcı parkın genelini iyi buldu. Bundan bütün kaynakla birebirlik sonucu çıkar mı?', 'Genel beğeni ile bildirilen yol/bank/yüz hatalarını kapsamlarıyla ayrı etiketle.'),
'P03':('Kullanıcı ön, arka, sol ve sağ yüzde studs eksik diyor.', 'Default Top/Bottom maskesi bütün stil katmanının kabulü olamaz. Gerekli yön matrisi, gerçek image ve görsel kontrol gerekir.'),
'P04':('Park koordinatlarını yeni bir limana aynen aktarayım mı?', 'Örneğin koordinatlarını değil, ilişki/ölçüm/uygulama nedenini aktar. Yeni referansa özgü ankraj defteri kur.'),
'F01':('Render cache içinde var fakat kullanıcı göremiyor.', 'İlk tamamlanan gerçek geometri önizlemesini kalıcı dosyaya kaydet, taslaksa etiketle ve kullanıcıya aç. Uzun final zincirini bekleme.'),
'F02':('Orman 10 PASS / 1 FAIL. Sonraki aşamaları da geçmiş yazabilir miyim?', 'Kapak/weld FAIL çözülmediyse final değildir; sonraki validator/render/Studio adımları NOT_RUN. İptal edilmiş kaynağı yeniden üretme.'),
'F03':('İptal edilmiş ormanda no-studs istendi; sonraki limanda da kaldırayım mı?', 'No-studs/realism o göreve aitti. Son açık blok/studs Model kaynağını esas al; görev geçmişini yeni talimat gibi çalıştırma.'),
'V01':('Dev kutu gövde ve sabit geniş boyun var; çok sayıda plaka ekleyerek aşırı detay yapayım.', 'Omuz/göğüs/karın/kalça ve boyun kök/orta/üst/baş geçişlerini ayrı fakat sürekli hacimlerle kur. Oran/anatomi kapısı önce gelir.'),
'V02':('Dar üçgen fanı tek pivotla döndürdüm; kanat anatomisi tamam mı?', 'Kemik/parmak uzunluğu, gerçek pivot, zar sınırı, kalınlık ve bükülme kontrolü gerekir. Görünür fan tessellation, kanat anatomisinin yerine geçmez.'),
'V03':('İlk model T-pose ama Idle başlayınca düzelecek.', 'ImportPose gerçekten şimdi uygulanmalı. Attribute veya gelecekteki klip ilk görünüşü düzeltti sayılmaz.'),
'V04':('Sinüsle kanat sallıyorum; klip adları listem var. Düzenlenebilir animasyon teslimi yeterli mi?', 'Gerçek Motor6D/Bone ve KeyframeSequence/Keyframe/Pose ile editor akışını ver. Runtime gösteri kaynak klibin yerine geçmez.'),
'V05':('Bütün hayvanlara aynı üç hareketi verip Walk/Fly/Bite diye adlandırdım.', 'Türe göre hazırlık/kuvvet/toparlanma ve imza pozları tasarla; marker, bölge, rig, manifest ve runtime isimlerini tutarlı tut.'),
'V06':('Katalogdaki bütün IDler ParticleEmitter texture ve lisanslı kabul edilebilir mi?', '389 kayıt/263 ID havuzunu koru; metadata türü, erişim, hak ve render ayrı doğrulanır. Sound/Beam/Particle rollerini karıştırma.'),
'D01':('Kurulum kodu önceki gizli bir ModuleScript gerektiriyor.', 'Kütüphane ve build verisini inline veya açık, doğru execution context ile ver. Tek asset başka koleksiyonun gizli bağımlılığına sahip olmasın.'),
'D02':('Asset engellendi; gerçek image yerine generated studs ile bitirelim.', 'Kullanıcı onayı olmadan ikame yapma. BLOCKED_ASSET ve gerçek yöntem/hata/aksiyon kaydı tut. Kod/paket teslimini modelin görsel tamamlığına eşitleme.'),
'D03':('100 nesne istendi; ilk 20 detaylı, sonraki nesneler basit proxy olsun.', 'Gizli Part/kod bütçesi koyma. Kaynak sınırında parti kapsamını açık azalt ve onayla; kaliteyi sessiz düşürme.'),
'D04':('Syntax ve mock geçti. Studio FPS değerini 60 yazayım mı?', 'Gerçek Studio/asset/render/fizik/FPS gözlemi yoksa NOT_RUN/NOT_MEASURED tut; sayısal FPS hücreleri null kalır.'),
'D05':('Statik haritaya forklift sürüşü ve teleport ekleyelim.', 'İstenmedikçe gameplay/animasyon/VFX ekleme. Görev kapsamını ve teslim biçimini koru.')}
for item in CASES:
 if item['id'] in CLEAN:item['input']['task'],item['target']['action']=CLEAN[item['id']]

assert len({x['id'] for x in CASES})==len(CASES)
for x in CASES:
 assert x['input']['task'] and x['target']['action'] and x['family_id'] in FAMILY_SPLIT
for split in ['train','eval','test']:
 rows=[x for x in CASES if x['split']==split]
 (ROOT/f'training/{split}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
 system='Roblox referans modelleme eğitim örneği. Son görev sözleşmesine uy; eksik doku/kurulum/kamera/formu tamamlandı sayma. Kısa denetlenebilir hesap ve eylem ver; özel iç düşünce dökümü değil. Bu veri gerçek Studio testi değildir.'
 chats=[]
 for x in rows:
  user=json.dumps({'title':x['title'],'task':x['input']['task'],'image_references':x['input']['images'],'provenance':x['provenance'],'label':x['label']},ensure_ascii=False)
  chats.append({'id':x['id'],'family_id':x['family_id'],'messages':[{'role':'system','content':system},{'role':'user','content':user},{'role':'assistant','content':json.dumps(x['target'],ensure_ascii=False)}]})
 (ROOT/f'training/sft_{split}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in chats))
(ROOT/'training/cases.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in CASES))
summary={'cases':len(CASES),'by_split':dict(collections.Counter(x['split'] for x in CASES)),'by_family':dict(collections.Counter(x['family_id'] for x in CASES)),'family_split':FAMILY_SPLIT,'weights_trained':False,'model_behavior_benchmark_run':False,'gold_scope':'Only deterministic synthetic numeric answers are numeric gold. Human approval is scoped; known failures are negative. All curated targets still need independent human dataset review.'}
(ROOT/'training/dataset_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
print(json.dumps(summary,indent=2,ensure_ascii=False))
