# Teslim raporu şablonu

## Ana çıktı
- Studio EDIT kurulum kodu dosyası / hash:
- Tam standalone build: EVET/HAYIR (varsayma)
- Ek model dosyası varsa: ana kodun yerine geçmez.
- Kısa çalıştırma adımları:

## Gerçek çıktı kanıtı
- Kalıcı Onizleme.png ve kaynak hash'i (model görevinde):
- Görüntü motoru: Studio / dış renderer / taslak; doğru etiketi seç.
- Kaynak kamera/landmark, ölçek ve kritik yakın plan durumu:

## Gerçek doku
- Model ID → çözümlenmiş image URI → type/access/fetch:
- İnsan kuponu, motif sayısı/tile/pitch/kontrast/faz:
- Beklenen/gerçek yönler; gerekçeli istisnalar:

## Ayrı kapılar
Syntax / sayısal / mock / Studio / asset / kupon / gerçek uygulama / referans / kamera / avatar / animasyon / FPS: her biri PASS/FAIL/BLOCKED/NOT_RUN/NOT_APPLICABLE.

## Kalan engeller ve kullanıcı kapsamlı kabulü
Gerçek hata, gereken aksiyon, onaylanmış alt kapsam ve açık başarısızlıklar. Kritik engel varsa final/birebir tamamlandı deme.
