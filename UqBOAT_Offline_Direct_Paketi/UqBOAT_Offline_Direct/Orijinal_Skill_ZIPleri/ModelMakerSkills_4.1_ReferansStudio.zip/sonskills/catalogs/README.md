# Kullanıcının VFX havuzu

389 kayıt / 263 benzersiz ID, orijinal JSON/CSV ve assestvfxx.txt baytları korunur. Duplicate ID farklı kategorilerde olabilir; sessiz dedup/truncation yok. Bunlar hak, tür, erişim veya render onayı değildir. Yalnız VFX istenirse uygun bileşen/marker rolüyle kullan; diğer göreve zorla efekt/gameplay ekleme.
