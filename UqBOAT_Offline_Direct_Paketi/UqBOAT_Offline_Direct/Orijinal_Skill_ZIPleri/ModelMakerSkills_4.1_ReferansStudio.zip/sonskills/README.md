# ModelMakerSkills / SONSKILLS 4.1.0

**Referansa sadakat + çözümlü matematik + gerçek Studio kurulum kodu + etiketli eğitim seti.**

Bu paket kullanıcının **“evet tam da bu, devam”** onayıyla hazırlanmış yeni skill sürümüdür. Orijinal `ModelMakerSkills.zip`, liman ve park teslimleri değiştirilmez. Mevcut liman/tekneler bu görevde onarılmadı; kusurlu çıktılar gold hedef yapılmadı.

## Başla
1. Skill destekleyen AI'ya bu ZIP içindeki `sonskills` klasörünü/skill'i ekle; **`SKILL.md`** giriş noktasıdır. Bu sohbet dosya teslimi kendiliğinden bütün AI platformlarına kurulum/kalıcı eğitim yapmaz.
2. Yeni görevde güncel kullanıcı sözleşmesini ve ilgili referans rehberini oku.
3. Örnek/karşıörnekler için `training/README.md`, `training/cases.jsonl`; ana mantık için `examples/Hesaplar.md`.
4. Çalıştırılabilir tam örnek: **`examples/01_Depolu_Iskele_CommandBar.luau`**. Dış .rbx dosyası veya ModuleScript istemez; kendi build kodu ve araçları inline'dır.

## Dört somut değişiklik
- İstenen kurulum kodu **ana teslim**; model dosyası onun yerine geçmez.
- Gerekli studs görseli doğrulanıp kupon açık onaylanmadan **ana kurulum engellenir**. Onaylı görsel gerçek yüzlere uygulanır ve audit edilir.
- Kupon/kurulum aktif kamerayı **değiştirmez**. İsteğe bağlı geçici inceleme başarı/hata yollarında geri yüklenir.
- Tekne silüeti/kabuk/borda/biniş/halat yakın planı ayrı kabul; offline PASS bütün formu onaylamaz.

## Studio örneğini çalıştır
`examples/01_Depolu_Iskele_CommandBar.luau` içeriğinin tamamını Studio **EDIT → Command Bar**'a yapıştır. Play/Run kapalı olmalı. Sonra:

```lua
_G.MM4Ders:Resolve()
```

Gerçek Model9454666962 içinden Image(1) adayları listelenir. Birinci aday otomatik seçilmez. İnceleyeceğin gerçek sıra numarasıyla, **deneme** profilini ver:

```lua
_G.MM4Ders:Coupon(1, {tileU=1, tileV=1, transparency=0.35,
    woodMinTransparency=0.48, thinMinTransparency=0.78, phaseMode="LOCAL_ZERO"})
```

`1` örnektir; motif/tile oranını gerçekten görerek seç. Kupon 5 blok/30 yüzdür; kamera taşınmaz. İstersen kuponu Explorer'da kendin seçip F ile odaklan. Bütün yönleri, eğimi, renkleri ve yakın/uzak görünüşü inceledikten sonra:

```lua
_G.MM4Ders:Approve("KUPONU_GORSEL_OLARAK_ONAYLIYORUM")
_G.MM4Ders:Install("ONAYLI_KURULUMU_BASLAT")
local r = _G.MM4Ders:AuditInstalled()
print(r.pass, r.actual, r.expected)
_G.MM4Ders:RemoveCoupon()
```

Aynı **kendi** sahneni staging audit sonrası açık değiştirmek için Install'ın ikinci argümanı `true`; eski sonuç `ServerStorage/MM4_Backups` altında korunur. Yabancı aynı isimli model silinmez. Asset/fetch/kupon engelinde tamamlanmış dokusuz model kurulmaz. Kaynak9454666962 **Model'dir**, doğrudan image değildir. Gerçek URI burada önceden uydurulmadı.

**Örnek kapsamı:** depolu iskele alt sahnesi. Tam limanın yeni birebir teslimi değildir. `02_Tekne_Matematik_Lab_CommandBar.luau` ve `03_Editable_Rig_Clips_CommandBar.luau` ayrıca açık token isteyen sentetik laboratuvarlardır; default studs/model görevini bypass etmek için kullanılamaz.

## Paket içeriği
- `SKILL.md` + 17 odak referans rehberi + makine okunabilir tercihler.
- Standalone kurulum örnekleri; portable Math3, gerçek Studio adapter, acceptance state machine ve CameraGuard.
- Native açık üstlü kapalı duvarlı hull hesabı, gerçek editable rig/klip laboratuvarı; bunlar kaynak tekne görsel kabulü değildir.
- `training/`: gerçek kaynak türevleri + scoped kullanıcı geri bildirimi + çözümlü/sentetik ve karşıörnek vakaları; family-disjoint train/eval/test ve isteğe bağlı SFT dışa aktarımı. Bu veriyle bir ağırlık eğitimi yapılmadı.
- Tam VFX katalogu:389 kayıt/263 ID ve özgün metin; hak/tür/erişim yine bekleyen gerçek kontrol.
- `history/v3/`: eski kuralların kısıtlı tarihsel kopyası; aktif talimat değildir.
- `validation/`: derleyici/matematik/mock/dataset/integrity sonuçları; Studio/asset/render/FPS durumları ayrı.

## Doğrulama

```sh
python tools/verify_package.py
luau tests/run_all.luau
```

Python paket kontrolü stdlib ile yapılır. Kamera fit örneği isteğe bağlı NumPy/SciPy; eğitim verisi yeniden üretme/görsel türevler için Pillow kullanır. Bunlar Studio kurulum kodunun bağımlılığı değildir.

**Dürüst sınır:** Gerçek Roblox Studio bu ortamda yürütülmedi. Resmî Luau derleyicisi, sayısal testler ve test doubles gerçek Studio, asset hakkı, insan görsel kuponu, editor/collider veya FPS kanıtı değildir. Ayrıntı `DOGRULAMA.md`.

## 4.1 eklemesi
Dört başarılı alt bölge için `training/positive_pairs/README.md`: gerçek referans/çıktı cropu, ölçü/rebase hesabı, orijinal807Part alt kümesi ve tam build/standalone kodu. Yeni7standalone örneğin4ü bu eşleşmelerdir. Kabul sadece geometri/yerleşim kapsamındadır; gerçek doku/Studio/FPS tamamlandı denmez.
