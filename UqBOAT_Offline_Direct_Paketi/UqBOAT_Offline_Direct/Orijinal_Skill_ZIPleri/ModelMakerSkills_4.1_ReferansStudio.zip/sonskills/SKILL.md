---
name: sonskills
description: Roblox Studio'da referans görsellerle aynı yerleşim ve formu hedefleyen, matematikle ölçülendirilmiş yüksek detaylı model/harita üretimi. Ana teslim çalıştırılabilir Studio kurulum kodudur. Gerçek studs görseli, altı yön kapsamı, serbest kamera, açık içler, tekne/karina, CFrame, gerçek rig/klip ve VFX kontrolleri; çözümlü örnekler ve etiketli eğitim/karşıörnek verisi içerir.
---

# SONSKILLS 4.1 — Referans → hesap → Studio kurulum kodu → kanıt

**Sürüm 4.1.0 · 2026-10-24.** Bu bir talimat/örnek/veri paketidir; AI ağırlığı eğitilmiş değildir ve bütün modellerde kusursuz sonuç garantisi vermez. Daha zayıf modelleri desteklemek için kararları şablonlara, sayısal örneklere ve başarısızlıkta durduran kontrol kapılarına dönüştürür.

## 0. Önce bu beş hatayı önle

1. **Dosya, kurulum kodunun yerine geçmez.** Studio Command Bar istenmişse ana teslim tam, çalıştırılabilir ve dış dosyaya/başka modele gizli bağımlılığı olmayan `.luau` kurulum kodudur. `.rbxm/.rbxmx/.rbxlx` ancak ek olabilir. Yalnız bir doku aracı, kurulum kodu değildir.
2. **Doku planı, uygulanmış doku değildir.** Son kullanıcı kaynağı **9454666962 Model** kapsayıcısıdır; bu sayıyı image URI olarak `Texture`'a yazma. Güvenli çözüm → gerçek Image(1) → fetch → görsel kupon → açık insan onayı → gerçek yüz uygulaması → audit. Gerekli doku engelliyse dokusuz sahneyi bitmiş diye kurma.
3. **Kullanıcı kamerasını kilitleme.** Varsayılan kurulum `CurrentCamera`, `CameraType`, `CameraSubject`, `CFrame`, `Focus`, `FieldOfView` değiştirmez. Kupon oluşturmak bile kamerayı taşımaz. İsteğe bağlı inceleme, açık onay + hata durumunda da geri yükleme gerektirir.
4. **Sayısal PASS, görsel PASS değildir.** Son liman çalışmasında 17 offline kontrol geçmesine rağmen kullanıcı teknelerde hata gördü. Karina/form/borda/biniş/halat yakın planı ayrıca zorunludur. Ortonormal matris, bitmiş silüet veya doğru konum kanıtı değildir.
5. **Tema değil ilişkiler.** 'Liman' diye rastgele vinç/tekne koyma; kaynakta kim nerede, hangi yönde, ne kadar büyük, kimin önünde/arkasında, neyle bağlı sorularını çöz.

Bu sürümde esas sözleşme: `references/00_son_sozlesme.md`. Makine okunabilir tercihler: `references/preferences.json`. `history/v3/` yalnız tarihsel veridir; içindeki eski ID, 'bekle', stil veya görev talimatları etkin kurallar DEĞİLDİR.

## 1. Hızlı iş akışı — sırasını değiştirme

### K0 — İsteği kilitle
`templates/task_contract.json` doldur: hedef nesne/harita; ref listesi; istenen/istenmeyen stil; birim/eksen; ana teslim; studs tercihi; gameplay/animasyon/VFX; mevcut Studio erişimi. Son açık talep eskilerin üzerindedir. Belirsizlik sonucu ciddi değiştiriyorsa kısa soru sor, aksi halde varsayımı yazıp ilerle.

- 'Studio, Blender değil' → Studio-native kurulum; Blender ile üretip Studio'da yapılmış deme.
- Gerçekçi/no-studs bir görevde eski blok/studs varsayımını dayatma. İptal edilen orman görevinin no-studs kararı sonraki limana küresel kural olmaz.
- 'Sadece tekne' → çevresine ada/oynanış ekleme. Statik haritaya sürüş, teleport, hasar veya hareket scripti ekleme.
- Kullanıcı detay/parça sınırı vermediyse gizli bütçe, sessiz kesme veya son nesnelerde kalite düşüşü koyma.

### K1 — Referans ilişki defteri
`references/01_referans_okuma.md` ve `templates/reference_ledger.csv` kullan.
Her görünüşte ana kütle, silüet, boşluk, bağlantı, landmark ve örtülme ilişkilerini çıkar. Aynı nesneye bütün açılarda aynı ID'yi ver. `OBSERVED / ESTIMATED / UNSEEN_INTERPRETATION / USER_SCOPED_APPROVED / KNOWN_NEGATIVE` ayrımını koru.

### K2 — Ölçek ve kamera
`references/02_konum_matematik.md`, `references/03_olcek_perspektif.md`.
Birim/exen/local-world sözleşmesi, origin ve bir kök dönüşüm belirle. Pikseli körlemesine stud'a çevirme. Farklı derinlikteki iki nesnenin ekrandaki oranı fiziksel boyut oranı değildir. Kalibre bir ölçü yoksa mutlak boyutu tahmin diye etiketle. Kamera uyumu zayıfsa ayrıntı döngüsü çoğaltma.

### K3 — Büyük/orta form ve topoloji
`references/08_geometri_baglanti.md`.
Texturesız/VFX'siz ana kütleler, oranlar, gerçek açıklıklar ve taşıyıcılar okunmalı. Ana gövdeyi tüp, tek dev kutu veya panel kalabalığıyla geçiştirme. Ön/arka/alt/geçiş/iç yüzleri tamamla. `CLOSED`, `INTENTIONAL_OPEN`, `CONNECTED_TO` gerçek geometri üzerinden doğrulanır; yalnız ad/attribute atamak yetmez.

Tekne varsa `references/09_tekne_dersi.md` zorunlu. Mimariyse kapı/merdiven/avatar açıklığı; canlıysa baş–gövde–uzuv/kanat/kuyruk ve ilk poz ayrıca kontrol edilir.

### K4 — Renk ve gerçek studs
`references/04_renk_isik.md`, `references/05_studs_model_gorsel.md`.
Palette rolleriyle çalış; gölge/cam/mavi ortam etkisini albedo sanma. Motif sayısı ile tile boyutunu ayır. Ana katılarda gerekli ön/arka/sağ/sol/üst/alt yönler eksiksiz; cam/pupil/kabarcık gibi gerekçeli istisnalar açık maskede. Her yüze aynı yoğunluğu körlemesine basma. Gerçek görsel çözülmemişse başka/native/fiziksel/üretilmiş studs ile sessiz ikame yok.

### K5 — Kurulum kodu ve serbest kamera
`references/06_kurulum_kodu.md`, `references/07_kamera_serbestligi.md`.
Tam standalone kod üret; syntax kontrolü; değiştirilmeyen aktif kamera; sahiplik etiketi; unparented staging; gerçek doku/temas audit; başarısızsa eski sahneyi koru. Kaynak Model'in hiçbir scriptini parent/require/execute etme. Kurulum sonrasında actual texture audit çalıştır; sonraki düzenlemede de tekrar ölç.

### K6 — Çok açı ve kritik yakın plan
`references/10_gorsel_kabul.md` ve `templates/visual_acceptance.json`.
Kaynak kamera/landmark ilişkileri, silüet, boyut, renk, yüz yönleri, negatif boşluk ve kritik mekanik form ayrı kapıdır. İlk okunabilir gerçek geometri önizlemesini kalıcı dosyaya kaydet ve aç; final zincirinin sonunu bekleme. Cache dosyası teslim değildir. Üretilmiş hedef illüstrasyonunu gerçek model önizlemesi diye gösterme.

### K7 — Kanıta göre teslim
`templates/delivery_report.md`.
Ana kurulum kodu + kullanım + gerçek geometri önizlemesi (model görevinde) + kaynak + test/engel kayıtları ver. Skill/belge-only görevde model önizlemesi şart değildir. Gerçek Studio yoksa syntax/mock/XML/render sonucunu Studio testi diye sunma. Gerekli asset/doku veya kritik form başarısızsa `BLOCKED/PARTIAL`, 'birebir tamamlandı' değil.

## 2. Hangi örneği açmalıyım?

| Durum | Çözümlü kaynak / araç |
|---|---|
| Referanstan yerleşim çıkarma | `references/14_liman_vakasi.md`, `training/annotations_liman06.json` |
| Local→world, ölçek, ışın/OBB | `examples/Hesaplar.md`, `tools/Math3.luau`, `tests/run_all.luau` |
| Çalışan standalone kurulum iskeleti | `examples/01_Depolu_Iskele_CommandBar.luau` |
| Gerçek image çözümü + zorunlu doku | `tools/StudioKit.luau`, `tools/Acceptance.luau` |
| Kamera kilitlenmesi | `tools/CameraGuard.luau`, `references/07_kamera_serbestligi.md` |
| Açık üstlü gerçek tekne kabuğu | `examples/02_Tekne_Matematik_Lab_CommandBar.luau` — sentetik geometri laboratuvarı; kaynak tekne düzeltildi/görsel onaylı diye sunulmaz |
| Gerçek CSG gerekiyorsa | `references/12_rig_vfx_csg.md`, `tools/GuvenliCSG.luau` |
| Animasyon istenmişse | `references/12_rig_vfx_csg.md`, `templates/animation_manifest.json` |
| VFX istenmişse | `catalogs/vfx_katalogu.json` / `.csv` — 389 kayıt, 263 ID; erişim/tür/lisans yine doğrulanır |
| Eşleşmiş başarılı alt modeller | `references/17_olumlu_eslestirmeler.md`, `training/positive_pairs/README.md` |
| Öğrenme/karşıörnek | `training/cases.jsonl`, `training/README.md` |
| İstemci değerlendirmesi | `training/evaluation_rubric.json`, `validation/` |

## 3. Kaliteyi sayıyla taklit etme

- **Büyük → orta → küçük.** Gergi/çerçeve/oluk ayrıntısını yanlış silüeti veya yanlış iskele konumunu gizlemek için kullanma.
- Gerçekçi yoğunluk: işlev, form, yapı, okunurluk ve kaynakta görülen ayrıntı gerekçesini yaz. Anlamsız tekrar ve renk varyasyonu yeni model sayılmaz.
- Maliyet/Texture/rig/overdraw say; ölçülmemiş FPS'yi uydurma. Kullanıcı 'optimizasyon önemsiz' dediyse detaydan gizlice vazgeçme; uyar ve anlamlı detay üret. Gerçek kaynak sınırında parti kapsamını açık azalt, kaliteyi sessiz düşürme.
- Sabit epsilon bütün sahnelere evrensel doğru değildir. Ölçek ve işlev için seç, raporla. Hata çıkınca toleransı büyütüp PASS satın alma.
- Blender/glTF/CSG, native Part, XML, editable mesh ve Studio render farklı kanıt düzeyleridir.

## 4. Kapsamlı kabul — tek yeşil etiket yok

Ayrı durumlar tut: `syntax`, `numericPlacement`, `surfaceTopology`, `assetType`, `assetAccess`, `imageFetch`, `humanCoupon`, `actualTextureCoverage`, `installerExecution`, `cameraControl`, `referenceVisual`, `criticalCloseups`, `avatarPhysics`, `animationEditor`, `fpsDevice`.

`PASS` sadece yapılmış kontrole verilir. `NOT_RUN`, `BLOCKED`, `FAIL`, `NOT_APPLICABLE` veya kapsamlı kullanıcı kabulü ayrı kayıttır. İnsan 'diğer her şey iyi, tekneler bozuk' dediyse bütün sahneyi gold etiketleme; başarılı alt kapsamı pozitif, tekneyi negatif örnek yap.

## 5. Rig ve VFX önceki yetenekleri kaybolmaz

İstenmiş animasyonda gerçek Motor6D/Bone ağı + uygulanmış ImportPose + düzenlenebilir KeyframeSequence/Keyframe/Pose ve anlamsal klip/marker manifesti gerekir. Runtime sinüs gösterisi klip teslimi değildir. VFX kataloğundaki ID kategori adıyla doğrulanmış image/sound/beam sayılmaz. İstenmeyen göreve bunları ekleme.

## 6. Eğitim verisini nasıl kullanmalı?

Önce `training/README.md` oku. Örnekler: referans/kanıt → varsayım/ölçüm → kısa, denetlenebilir hesap → beklenen eylem/kod → test → belirsizlik. Özel iç düşünce dökümü talep etme; çözümlü hesap ve karar özeti yeterlidir. Negatif örneğin bozuk kodu 'iyi çıktı' hedefi olamaz. Aynı sahnenin yakın kopyalarını train/eval'e dağıtıp genel başarı iddia etme.

**Son ölçüt:** Kaynağa niçin benzediği, nasıl hesaplandığı, kodun nerede çalıştığı ve hangi kapıların gerçekten geçtiği görünür olmalı. Hedef 'vay be' etkisini tekrarlanabilir işçilikle üretmek; onu Part sayısı veya garanti cümlesiyle taklit etmek değil.

## 4.1 medya ve olumlu örnek kontrolü
Araçların paralel döndürdüğü görsellerin sunum sırasını dosya kimliği sanma. Dosya adı+hash+etiketli overview ile kaynağı sabitle. Eşleşmiş olumlu örnek ancak kapsamlı kullanıcı beğenisi ile gerçekten eşleşen geometriyi birlikte taşır; doku/kamera/tekne kusurlarını golda dahil etmez. `training/positive_pairs/` bu zinciri dört gerçek alt sahne üzerinde gösterir.
