# Renk seçimi: piksel, albedo ve ışık ayrı şeyler

## Rollerle palet
Temel gövde / gölge tonu / kenar-çerçeve / odak rengi / işlevsel uyarı / cam-su / göz-pupil rolleri oluştur. Rastgele renk varyasyonu yüzey/anatomi işçiliği değildir. `training/palette_liman.json` eski kod paletini **PROGRAM_PALETTE**, gerçek görüntü patch istatistiğini **OBSERVED_PIXELS** diye ayrı saklar.

Liman kodundaki örnekler: ahşap (167,113,65), koyu ahşap (106,70,43), beyaz (223,233,233), mavi (55,137,183), sarı (224,207,39), kırmızı (194,64,47). Bunlar kaynak oyundan doğrulanmış albedo ölçümü değildir. Kullanıcının genel yaklaşım onayı, her RGB'nin evrensel gold olduğu anlamına gelmez.

## Örnekleme
1. UI/avatar/seçim konturu/pupil/VFX/glare maskesini dışla.
2. Aynı malzemeden gölgeli/aydınlık ve yakın/uzak birkaç patch al.
3. Medyan ve yüzde 10/90 aralığını sakla; tek parlak pikseli bütün malzeme yapma.
4. Dokunun koyu studs motifini ve camın mavi cast'ini taban renk sanma.
5. Neutral ışık swatch'ı + gerçek kaynak ışığında karşılaştır. Işık/atmosfer/cam değişimini ayrı kaydet.

## Doğru renk hesabı
sRGB kanal c (0..1): c≤.04045 ise c/12.92; değilse `((c+.055)/1.055)^2.4` → linear.
**sRGB .5 → linear .21404114**, .5 değil. 8-bit 128'i doğrudan lineer enerji sanma.

Sentetik aydınlatma örneği: linear .21404114'in 2 katı .42808228; sRGB'ye dönüş yaklaşık .686 → 8-bit yaklaşık175. Gözlenen175'i taban albedo yaparsan aynı ışık ikinci kez uygulanır. Bu basit örnek gerçek Roblox gölgelendiricisinin tam simülasyonu değildir.

Saydam düz alfa örneği (tüm değerler linear): yüzey (.6,.6,.6), cam (.05,.15,.8), opacity .25 → görünüş **(.4625,.4875,.65)**. Gerçek Glass; yansıma/kırılma/tonemap nedeniyle bundan daha karmaşıktır. Görünüşü değiştiren bu katmanları 'objenin kendi rengi' diye kopyalama.

## Kupon
Kırmızı/beyaz/ahşap/sarı/30° eğimli mavi örnekleri aynı gerçek image ile incele. Ahşaba uygulanan minimum alfa kupondaki ahşaba da uygulanır. Böylece kupon farklı, final farklı kontrastla şaşırtmaz. Renkli kaynak görsel motifse Color3 beyazın onu renksizleştirmediğini unutma; uygunluk insan tarafından görülür.
