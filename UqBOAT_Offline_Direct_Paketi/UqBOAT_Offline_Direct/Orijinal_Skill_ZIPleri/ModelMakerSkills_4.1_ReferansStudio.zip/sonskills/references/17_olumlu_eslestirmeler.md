# Olumlu eşleştirmeler: kuralı gerçek geometriyle öğret

4.0 hata/karar derslerinde güçlüydü; fakat yalnız olumsuz örneklerden iyi bir modelin nasıl kurulduğu yeterince görülmüyordu. 4.1 bunun için **dört gerçek alt-model eşleştirmesi** ekler.

## İçerik

`training/positive_pairs/index.json`:
- **PP01:** ana kırmızı vinç + asılı açık konteyner — 268 Part.
- **PP02:** sarı kafes vinç + sandık askısı — 167 Part.
- **PP03:** açık kapılı mavi depo, iç ve çatı yükleri — 325 Part.
- **PP04:** mavi çatılı kulübe, gerçek çatı/kalkan/baca bağlantıları — 47 Part.

Toplam807 kaynak Part. Bu sayı bir kalite/performans puanı veya limit değildir; veri/kod eşliğini ölçmek içindir.

## Her örneğin tam zinciri

1. Kullanıcının kaynak görselinden gerçek crop + kimlik/hash.
2. Kullanıcının kendi Studio görüntüsünden gerçek çıktı cropu; AI illüstrasyonu veya yeni render değil.
3. Kullanıcının beğendiği genel geometri/yerleşim kapsamı; istisnalar açık.
4. Teslim edilen sahne IR'sinden birebir Part verisi: dünya konumu, boyut, dönüş matrisi, renk, materyal, maske, collision.
5. **origin/rebase hesabı:** local=sourceWorld−origin. Rotasyon değişmez. Ders wrapper'ı rootWorld=(0,8,0) ile bağımsız komponenti kurar; kamera taşımaz.
6. Aynı veriden tam Builder ve bütün kütüphaneleri inline eden standalone Command Bar kurulumu.
7. Orijinal dünya değerleriyle bağımsız test beklentisi; native adapter'ın test-double çalışmasında tekrar hesaplanan konum/boyut/renk/materyal/maske ve doku/serbest kamera denetimi.

Kurulum yeni source/doku onay akışına uyar; eski dokusuz sonuçla eksik doku/camera kusurunu yeniden üretmez.

## Kabul sınırı

Bu bir **PARTIAL_POSITIVE_GEOMETRY_LAYOUT** setidir. Kullanıcı 'diğer her şey istediğim gibi, doku/kod/kamera/tekne sorunlu' dedi. Doku, eski kurulum teslimi, eski kamera ve tekneler gold değildir. Bazı detaylar crop'ta örtülü/küçüktür; tek tek görünmeyen detaylar ayrıca onaylandı denmez. Kaynak ve çıktı aynı kamerada değildir; pixel-perfect eğitim etiketi yoktur.

Köprü bu mevcut kullanıcı karesinde bitki/tekneyle örtülüyordu. Onu yapay bir görsel gold'a zorlamak yerine net görünen kulübe seçildi. Köprü bağlantı matematiği diğer geometri derslerinde durur.

## Aktarma

Örnekteki koordinatları her yeni modele kopyalama. Aynı çözümü öğren:
- Vinçte uzun kol/kabin/spreader tarafını ortak eksenle kur;
- Halat uçlarını gerçekten taşıyıcıya bağla;
- Depoda kapı boşluğunu ve görünen içi tamamla;
- Kulübede çatı eğimi/baca/gable kapanışını ölç;
- Birim, local-world ve renk/rol politikasını tek kaynaktan türet.

## Medya eşliği

Paralel araç dönüşlerindeki görüntü sırası, dosya adı değildir. 4.1'de `training/reference_overview.jpg` gerçek dosya adlarını üstünde gösterir; `reference_views.json` düzeltmeleri saklar. Özellikle kaynak01 arka-üst vinç,04 akvaryum dışı,05 iç duvar,07 tekne önüdür. İyi eğitim için önce doğru görüntü doğru case ile eşleşmelidir.
