# Liman: pozitif alt kapsam ve dört negatif ders

## Kaynaklar
Kullanıcının 9 kaynak karesi + 2 Studio geri bildirimi. Eğitim paketinde kompakt türevler ve özgün SHA256/boyut kayıtları vardır; tam çözünürlüklü orijinaller değişmeden asıl oturum arşivinde durur. JPEG türevini orijinal piksel/albedo ölçümü sanma. `training/source_index.json` provenansı açıklar.

### Görüş eşleme
01 arka-üst ana vinç/uzun bom/konteyner; 02 sağ pazar/depo/sarı vinç; 03 zemin yükleme/ana vinç/merdiven; 04 akvaryum dışı; 05 akvaryum iç duvarı; 06 genel ön-sol; 07 tekneler önden; 08 büyük gemi kumanda/baca; 09 meydan ve karşı yöndeki bağlantılar.

## Başarıyı nasıl korumalı?
Kullanıcı 'onun harici her şey tam istenilen şekilde' dedi. **Yerleşim ve genel harita yaklaşımı** olumlu örnek; doku, ana teslim biçimi, kamera ve tekneler istisnadır. Tamamını tek gold resim etiketiyle kullanma.

9 görüntüden sabit ilişkiler: kırmızı vinç merkez/arka; büyük yük gemisi arkada; tekne çiftinin renk ve merkez havuz ilişkisi; mavi depo/sarı vinç sağ; mavi çatılı kulübe ön-sol; sağ yanda mavi/beyaz tezgâh; ahşap geçişler ve dış akvaryum. Ref6'da kısa görünen bom, arka Ref1'te uzun görünür; farklı perspective yüzünden ilk görünüşe göre kolu kısaltma.

## Gerçek sayısal örnekler (kaynak ölçüsü değil yeniden kurulum parametresi)
Stud; +Y up / +X right / +Z front. İskele top5.6; su0.6; kum−17. Ana kule merkezi(−24,5.6,−44), tepe(−24,134.5,−44). Aksine göre mirrorX=2(−24)−x.
- Eski uzun kol center−11 → **−37**.
- Eski operatör x−45 → **−3**.
- Eski asılı konteyner x17 → **−65**.
Böylece bütün ilgili öğe aynı aynalama sözleşmesiyle karşı tarafa alınır; sadece bir objenin X'ini rastgele değiştirme.

Depo32×22×29, merkezx78/z−53; kapı/perde boşluğu ve kaynak içi tamamlandı. Bunlar özgün oyun verisinden kesin alınmış boyutlar değil. Mini iskele/depo ders kodu, bu olumlu alt yaklaşımı gösterir; tüm mapin yeni teslimi değildir.

## Eski offline yakalananlar
Kazık/kiriş x kaçması; world biniş ucu; üstte kiriş Z genişliği dışında biten halatlar; izole köprü sahanlığı; görünür coplanar asfalt/ahşap; kapıdan geçen kırmızı kabin şeridi. Gerçek geometri değişti; tolerans büyütülmedi.

## Offline'ın yakalayamadıkları
Gerçek studs hiç dağıtılmamıştı; kurulum kodu ana dosya değildi; kamera Scriptable bırakıldı; tekneler kullanıcı yakın planında başarısızdı. 17 PASS bunları geçersiz kılamaz.

4.0 bunun için **install-code required / required-texture-before-main-build / camera-read-only / critical-boat-visual** kapıları ekler. Sadece kuralları yazmaz: standalone örnek, canlı maske audit'i, immutable yüz sözleşmesi ve hata yolunda kamera/commit regression testleri içerir.
