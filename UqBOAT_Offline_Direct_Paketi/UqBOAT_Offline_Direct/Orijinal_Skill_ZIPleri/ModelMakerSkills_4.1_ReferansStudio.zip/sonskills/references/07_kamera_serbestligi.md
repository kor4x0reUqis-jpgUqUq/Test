# Kamera sözleşmesi — kullanıcı kontrolünü koru

Kullanıcı mevcut limanda kameranın kilitlendiğini bildirdi. Eski exporterde CameraType token6 (Scriptable) kullanılması bir kod riskidir; tek ekran görüntüsünden bütün olası nedenleri kesin teşhis etmiş sayılmaz.

## Varsayılan
Kurulum, kupon, test, kaynak çözümleme ve tekrar kurulum aktif kameraya **yazmaz**. `workspace.CurrentCamera` değiştirilmez; aynı poz her frame tekrar atanmaz; RenderStepped/BindToRenderStep ile kamerayı kullanıcıya karşı sürme. Frame capture için model dosyasının default kamerasını Scriptable bırakma.

Kuponu oluştur ve adı/yerini bildir. Kullanıcı isterse Explorer'da seçip F ile kendi eylemiyle odaklar. İnceleme pozlarını CFrame/veri olarak sakla; aktif kameraya otomatik dayatma.

## Açık opt-in
`tools/CameraGuard.luau` callback boyunca geçici poz verir:
1. Camera nesnesi, Type, Subject, CFrame, Focus, FOV snapshot.
2. Açık token `KAMERA_POZUNU_GECICI_KULLAN`.
3. Sınırlı callback; sürekli kontrol bağlantısı yok.
4. Hata olsa da finally benzeri geri yükleme.
5. Bu arada kullanıcı CurrentCamera değiştirdiyse yeni kamerayı ezme; açık restorasyon uyarısı ver.

2026-10-24 Camera dokümanı: **CameraSubject=nil atanamaz**, eski değere döner. Snapshot nilse körlemesine nil restore etme. Default 'Custom' atayıp geçmek de doğru reset değildir; kullanıcının önceden seçtiği tür/subject korunur.

CurrentCamera değiştirildiğinde Workspace'e doğrudan bağlı diğer kameralar silinebilir. Gerekli yedek poz kameraları Folder/Model'de tut; mümkünse nesne yerine yalnız CFrame veri kullan. Kamera swap'ını ana kurulum için hiç gerektirme.

## Test
Default install/kupon boyunca sıfır kamera write; hata ve başarı yolunda snapshot eşliği; nil subject; optional callback failure; kamera nesnesi değişimi; yeniden çalıştırma. Bunların mock testi ile gerçek Studio'da mouse/keyboard kontrolünün serbest kalması ayrı kapıdır.
