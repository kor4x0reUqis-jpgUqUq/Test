# Gerçek hacim, kapanış, destek ve örtüşme

## Üç durum
- `CLOSED`: zorunlu dış/arka/alt yüzleri gerçekten kapalı.
- `INTENTIONAL_OPEN`: kapı/konteyner/ağız/açık üst; sınırı, kalınlığı, iç tabanı/yanı/arkası mevcut.
- `CONNECTED_TO`: hangi gerçek temas yüzeyi/soket üzerinden bağlı olduğu açık.

Attribute yazmak geometri üretmez. Native Block/Cylinder/Ball'ın kapalı primitive olması, bunların oluşturduğu Model'in tamamının kapalı ya da kaynak silüetle aynı olduğunu kanıtlamaz.

## Bağlantı kontrolü
Örnek: büyük vinç ayakları bomun Z derinliği dışında olabilir. Kolon→baş travers→bom yolu gerçekten varsa bağlantı doğrudur; testte var olmayan doğrudan kolon/bom temasını dayatma. Tersi de geçerli: halat ucu doğru Y seviyesinde ama bomun Z genişliği dışında havada bitiyorsa bağlı değildir. Üst travers veya doğru soket gerekir; 'uç yüksekliği doğru' yetmez.

İskele tahta→kiriş→kazık→taban yolu; köprü→iki sahanlık→ana iskele; tekne biniş tahtası→iskele ve borda/deck gerçek uçları. Rota grafında tek Model altındaki kopuk iki parçayı tek düğüm yapıp yanlış bağlılık üretme; kritik test Part seviyesinde olmalı.

## Coplanar yüz
Aynı topY'de asfalt ve ahşap alanları pozitif XZ alanda çakışırsa z-fighting riski. Birini sırf farklı renk/texture/neonla örtme. Plan bölgelerini kırp/böl ya da gerçek kot farkı ve yapısal gerekçe oluştur. İç birleşimde kontrollü örtüşme, görünür yüzlerde coplanar bindirmeden farklıdır.

## Açıklıklar ve içler
Kapı ray örnekleri birden fazla en/yükseklikte; arka yüz ışını; iç taban/tavan/yan duvar. Kapıdan geçen dekor şeridi, kontrolsüz roof slab veya merdiven boşluğundan geçen alt kiriş faildir. Iskele yarığı, yapısal açıklık ve kasıtlı dar tahta derzi ayrı etiketlenir.

## Mesh/CSG
Kapalı mesh: pozitif boyut yeterli değil; kenar komşuluğu=2, ters yönlü kenar eşliği, nondegenerate üçgen, tutarlı normal/winding, sıfır olmayan signed volume, gerekirse self-intersection ve minimum kalınlık gerekir. Bunlar silhouette/reference match değildir.

Yeni Math3 hull örneği duvarının bütün sınırını kapatırken ortasını üstten açık tutar. Matematik testinin geçtiği sentetik modeldir; eski kaynak teknenin düzeltilmiş/görsel onaylı hali değildir. Eski iptal edilmiş ormanda bir kapak/weld sorunu çözülememişti; 'aynı koordinatlar var' diye gerçek kapalı mesh varsayılmaz.

Her şey için tek tolerans kullanma; gerçek hata çıkınca toleransla saklama. Fizik/avatar/CSG collision fidelity motor içinde ayrıca denenir.
