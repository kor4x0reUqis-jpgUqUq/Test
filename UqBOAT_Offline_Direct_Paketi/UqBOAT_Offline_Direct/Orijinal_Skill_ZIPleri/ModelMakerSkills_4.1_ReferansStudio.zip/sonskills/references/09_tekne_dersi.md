# Tekne dersi: 17 PASS ile yine hatalı tekne nasıl çıkar?

## Gerçek geri bildirim
Kullanıcı limanın genel sonucunu istediği gibi buldu; **teknelerde hata** bildirdi ve yakın plan verdi (`training/images/liman_studio_02.png`). Belirli tek bir kusurun sebebini kullanıcı açıklamadı. Ekran görüntüsünden 'kesin yalnız bu satır' teşhisi uydurma. Mevcut tekne kodu bu skill görevi kapsamında onarılmadı.

Önceki offline kontrol, kapalı Native karina parçalarının birbirine temasını ve biniş tahtasının kutulara değmesini ölçtü. Bu, düzgün pruva silüeti, gerçek borda akışı, doğru güverte genişliği, geçilebilir biniş veya bütün halatların uç bağlantısı demek değildi.

## Beş bağımsız tekne kapısı
1. **Planform:** uzunluk/beam oranı, stern/bow ayrımı, kesit genişlik eğrisi, pruva daralması ve kaynak kameradaki çizgi.
2. **Kesit/hacim:** kapalı karina altı, gerçek duvar kalınlığı, iç taban, borda/gunwale; denizden görünen yüzlerden arka plan sızmaması.
3. **Üst açıklık/kamara:** açık güverte gerçek boşluk; karanlık düzlemle sahte delik değil. Kamara tabanı/hull teması, pencere çerçeveleri, kapı önünü kesen şerit.
4. **Bağlantı:** biniş ucu tekne local soketinden türemeli; borda kesintisi/iniş basamağı işlevsel; halatın her iki ucu gerçek baba/direk/kanca üzerinde.
5. **Görsel kritik plan:** baş-kıç, yandan profil, üst plan ve su seviyesinden alt/borda yakın planı. Boat tarafını iskeleyle örten geniş açı tek başına kabul değildir.

## Kötü çözüm kalıpları
- Sabit uzunluklu gövde kutularının merkez aralıkları büyür → arada boşluk kalır.
- Gapsiz kutu zinciri → yine yanlış basamaklı/prizmatik pruva; temas PASS silüeti onaylamaz.
- Tek dev dikdörtgen güverte daralan bow'un dışına taşar.
- Beyaz kuşak/kaplama bir açıklığı görsel olarak örter; gerçek hacim eksik kalır.
- Mooring local yerine tahmini world → döndürülen teknede uç bordadan kaçar.
- Biniş tahtası değiyor ama önünde kapalı borda var → fizik/geçiş FAIL.
- Sonsuza giden/off-frame halat için yalnız başlangıç yüksekliği kontrol edilir.

## Çözümlü sayısal laboratuvar
`Math3.hullMesh`: her istasyonda outer/inner kesit; dış/inner side ve keel; baş/kıç end wall; gunwale rim. Duvarının tamamı kapalı bir sınırdır, iç hacme üstten erişim açıktır. Topoloji testi: her kenar2 yüz ve zıt yön; nondegenerate yüzler; volume>0; Euler2; içeri dik ışın tavan/lid bulmaz ama gerçek tabanı bulur.

`examples/02_Tekne_Matematik_Lab_CommandBar.luau` bunu EditableMesh→CreateMeshPartAsync ile gösterebilir. **Sentetik geometridir, kaynak teknelerin düzeltilmiş/görsel onaylı kopyası değildir.** Untextured geometri deneyi için açık ayrı token ister; blok/studs asıl görevin yerine kullanılamaz. Mesh UV/studs, çarpışma, Studio izinleri, save/reopen ve görsel form ayrı kapıdır. EditableMesh bellek/kabiliyet engelinde kutu proxy'ye sessiz dönüş yok.
