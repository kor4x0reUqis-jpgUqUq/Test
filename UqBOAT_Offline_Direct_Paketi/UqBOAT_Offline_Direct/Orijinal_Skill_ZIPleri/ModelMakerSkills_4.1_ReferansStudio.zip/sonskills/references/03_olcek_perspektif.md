# Boyut/oran ve perspektif

## Aynı piksel ≠ aynı stud
İdeal pinhole modelinde `p_px = f_px * physical_size / depth`. Aynı 8-stud nesne 10 birim derinlikte, 20 derinliktekinden **2 kat büyük** görünür. İki farklı derinliğin piksel oranından fiziksel boyut oranı çıkarma.

Mutlak ölçü için en az bir güvenilir dünya ankrajı gerekir. Avatarın gerçek rig/ölçek ayarı bilinmiyorsa sabit boyu ölçülmüş kalibratör gibi kullanma. Kaynak ölçüsü yoksa relative ölçü + seçilen tahmini ölçek bildir.

## Çok ölçüden tek ölçek
Göreli ölçüler r_i, bilinen dünya ölçüleri k_i, güven ağırlıkları w_i:
`s = Σ(w_i r_i k_i) / Σ(w_i r_i²)`.
Örnek r=(3,5), k=(6,10), w=(1,2) → s=(18+100)/(9+50)=**2**.
Bu, perspektif düzeltilmiş/aynı düzlemde tanımlı ölçüler içindir; ham farklı-derinlik piksel oranlarına sihirli çözüm değildir.

## Kamera projeksiyonu
r=unit(cross(forward,up)); u=cross(r,forward); back=−forward.
Kamera yerel q=Rᵀ(p−eye), depth=−q_z>0.
`u_screen=.5+q_x/(2*depth*tan(fovY/2)*aspect)`
`v_screen=.5−q_y/(2*depth*tan(fovY/2))`.
Viewport kırpması, FOV modu ve roll biliniyorsa dahil et. Teknik ortografik üst görünüş, Native perspektif kamerayla aynı kare değildir.

`tools/fit_camera.py` elle yaklaşık landmark'lar ve tahmini 3B noktalarla pose/FOV uyumu yapar. Çıktı 'fit sonucu'dur; kesin ölçü veya birebirlik belgesi değildir. Düşük residual, işaret noktaları yanlış tanımlandıysa yanıltabilir. Kamera serbestliği kuralını bozmaz: araç sayı hesaplar, Studio kamerasını değiştirmez.

## Hata eşiği
Ağırlıklı normalize RMS: `sqrt(Σw((du)²+(dv)²)/Σw)`.
Eşiği hedef çözünürlük ve ölçüm belirsizliğine göre seç. Bütün modeller için tek '2 piksel geçti' sihri yok. Silüet/örtülme/komşuluk da kontrol edilir. Pose uymuyorsa önce kamera/ölçüm hatasını ayır; yanlış dünya yerleşimini kamerayla gizleme.

## Bu paketteki gerçek fit kaydı
Kaynak06 için yaklaşık anotasyon + tahmini eski dünya noktaları sıkı eşleşme üretmedi: `validation/camera_fit_example.json` **REJECTED** durumundadır. FOV/poz sınırına dayanma ve ölçüm toleransını aşma açıklanır. Bu iyi kalibrasyon örneği değildir. Ayrı sentetik bilinen-kamera kontrolü, hesaplayıcının kendi doğruluğunu test eder; kaynak ölçülerini doğrulamaz.
