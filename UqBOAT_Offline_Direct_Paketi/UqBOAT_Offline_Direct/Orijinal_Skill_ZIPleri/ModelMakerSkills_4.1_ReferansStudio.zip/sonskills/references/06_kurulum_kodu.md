# Ana teslim: Studio kurulum kodu

## Zorunlu teslim
İstenen EDIT Command Bar ise `Kurulum_CommandBar.luau` tam içerikli ana dosyadır. Gizli Python üreticisi, başka workspace klasörü, önceki ModuleScript veya özel .rbx dosyası olmadan çalışacak kaynak içerir. Güvenli gerçek asset sorgusu bunun dışındadır; izin gereksinimi açık yazılır. Yalnız README, model dosyası veya doku aracı yeterli değildir.

`examples/01_Depolu_Iskele_CommandBar.luau`: Math3 + Acceptance + CameraGuard + StudioKit + gerçek build fonksiyonu **inline** edilmiştir. Bu bir depolu iskele alt sahnesi dersidir; bütün limanın yeni birebir teslimi değildir. Varsayılan doku zorunludur.

## Akış
Paste → Resolve → aday seç/kupon → insan onayı → Install → gerçek yüz audit → referans/kritik yakın plan/Studio fizik/FPS kabulü. Onay gerektiren aşamalar tek tuş otomatik 'evet' değildir. Paste'te kayıtsız kamera taşınmaz ve dokusuz final model kurulmaz.

## Güvenli işlem
- Sahne sahibi/namespaceleri etiketli; yabancı kullanıcı modelini silme.
- Yeni sonuç unparented staging'de tamamlanır.
- İstenen geometri gerçekten oluşturulur; merkezi konum/boyut ve açılıklar test edilir.
- Uygulama sayısını planlanan maske ve URI/ölçek/kontrast/phase ile karşılaştır.
- Önceki kendi modelini değiştirmek bile açık `replaceOwned=true` ister; eski sonuç ServerStorage/MM4_Backups altında korunur.
- Builder/audit/commit başarısızsa yeni stage silinir, eski sahne geri tutulur. İnceleme hatasını gizleyip yarım sonucu commit etme.
- UI yield parça/yüz bütçesi değildir. Gizli bir adet sınırında üretimi kesme.

## Yeniden çalıştırma
Aynı isimde kendi sahnen varsa ya denetle ya açık değiştir. Aynı modelin üstüne ikinci kopyayı sessizce yığma. Başka sahiplikte aynı isim varsa fail. Source/build hash, version ve style kararı kayıtlı olsun.

## Kanıt
Syntax PASS kodun Studio'da çalıştığı anlamına gelmez. Mock adapter testi asseti indirmez, Studio API'sini işletmez, görüntü render etmez. README, NOT_RUN kapılarını açıkça korur. Kurulum tamamlandı mesajı bile referans birebirliği/başarılı FPS demek değildir.
