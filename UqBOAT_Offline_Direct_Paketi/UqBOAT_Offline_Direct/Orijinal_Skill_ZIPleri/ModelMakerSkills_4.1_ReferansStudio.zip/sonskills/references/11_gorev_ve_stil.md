# Görev/kapsam/stil yönlendiricisi

## Son açık talep üstün
Varsayılan blok/studs stili, kullanıcı yeni gerçekçi/no-studs/mesh isterse dayatılmaz. İptal edilmiş ormanın tercihi sonraki limana taşınmaz. Referansın blok/studs karakterini natural materyalle sessizce değiştirme. 'No Blender' → native Studio yöntemleri/kurulum kodu; Studio erişimin yoksa dürüst engel, dosyayı kod yerine gizlice koyma değil.

## Aşırı detay
Büyük/orta/küçük ölçekte anlamlı hacim. Baş/gövde/alt/arka/eklem/kanat/kuyruk veya bina içi/çatı/bodrum/merdiven her görevde envantere yazılır. Kritik bölge blockout iken final değildir. Ana gövdeyi tek kutu, tüp veya daireye dizilmiş panel staves ile geçiştirme. Silindir teker/mekanik gibi yerel işlev, bütün gövdeyi tüpe çevirme izni değildir. Kaynak blok stilini doğru geometriyle koru.

Detay görevde kaynak/işlev/silüet/anatomiye hizmet etsin. Aynı mikro bloğu bin kez rastgele çoğaltmak 'sınır yok' talebini karşılamaz. Kaynak limitinde kullanıcıyla parti kapsamını azalt; sonraki nesneleri gizlice sadeleştirme.

## Ek iş ekleme
Statik harita → sürüş, hasar, NPC, teleport, vinç hareketi, balık animasyonu otomatik eklenmez. Yalnız tekne → ada/akvaryum üretme. VFX/animasyon istendiyse gerçek işçilikle yap, istenmediyse zorla ekleme.

## Model yöntemini seç
Native Block/Wedge: stil/köşeli form; boşluklar gerçek bölünmüş hacimlerle.
CSG: gerçekten oyuk/boole gerekiyorsa, sayıyı azaltma sihri değil.
Mesh/loft: gerçek kesit/organik/karina yüzeyine ihtiyaç varsa; izin, UV, winding, closed ends ve collider ayrı.
Import gerekiyorsa: gerçek dosya/ölçek/up-axis/4 kalibrasyon landmark'ı. Hayali MeshId veya ithalatın test edilmeden başarı garantisi yok.

Skill-only görevde çalışmış haritayı değiştirme. Buradaki laboratuvarlar yeni tam harita/yaratık teslimi değil; öğrenme örnekleridir.
