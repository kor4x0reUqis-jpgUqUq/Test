# Konum, dönüş ve gerçek temas — çözümlü protokol

Birim stud; +Y yukarı, +X sağ, +Z bu örnekte ön iskele. Roblox yerel `LookVector` **−Z** yönüdür. 'Ön' sözcüğünü dünya +Z ile Native NormalId.Front arasında karıştırma.

## 1. Tek dönüşüm kaynağı
`p_world = O + R (s p_local)`; `p_local = Rᵀ(p_world−O)/s`.
`partWorldCF = modelWorldCF * CFrame.new(localPosition*s) * localRotation`.
Boyutu da `s` ile çarp. Radyan/degree karıştırma. Rotasyon matrisini veya açıyı ölçekleme. World offsetini iki defa ekleme.

`R_y(θ) = [[cosθ,0,sinθ],[0,1,0],[−sinθ,0,cosθ]]`.

**Liman dersi:** mavi tekne O=(−39,0,19), yaw=−5°, yerel biniş A=(−12,6.65,7.36).
- x=−39+cos(−5°)(−12)+sin(−5°)(7.36)=**−51.5958026437**
- y=**6.65**
- z=19−sin(−5°)(−12)+cos(−5°)(7.36)=**25.2861240650**
Tahmini world (−51,6.65,27) aynı yer değildir. CFrame ortonormal olsa bile uç borda dışında kalabilir. Bu hesap yalnız konum örneği; kaynak teknedeki bütün görsel hataların giderildiği anlamına gelmez.

## 2. Ölçek örneği
O=(10,3,−5), yaw=90°, p=(2,4,6), s=2 → Rp_s=(12,8,−4) → **world=(22,11,−9)**. R aynı kalır, det(R)=1. Ayna diag(−1,1,1) det=−1'dir; geçerli sağ elli rotasyon gibi CFrame'e verilmez.

## 3. Yüzeye oturtma
Merkez yerine gerçek min/max yüzünü kullan: `bottom = centerY−height/2`; hedef taban topY ise `centerY=topY+height/2`.
Yatay bloklarda boşluk `gap = upper.bottom−lower.top`.
- gap>tolerans: gerçek boşluk.
- gap≈0: temas.
- gap<0: örtüşme; görünür coplanar/z-fighting veya aşırı gömülme ayrıca kontrol edilir.

Eski kazık x=±0.34w, kiriş x=±0.33w idi. w=207 için merkez kaçması **2.07** stud. Kazık yarı eni .85 + kiriş yarı eni .65 =1.50; arada **0.57** stud boşluk kalır. İki matrisi de ortonormal bulmak bunu yakalamaz. Kazığı aynı kiriş soketinden türet.

## 4. Genel 3B temas
Döndürülmüş kutularda AABB yalnız geniş-faz filtresidir. OBB/SAT eksenleri: 3 A ekseni + 3 B ekseni + 9 çapraz eksen. Her birim n için:
`gap_n=|dot(Bc−Ac,n)|−Σ|dot(n,Ai)|Ah_i−Σ|dot(n,Bj)|Bh_j`.
Her eksende gap≤tolerans ise hacimler temas/örtüşme adaydır. En büyük gap ve toleransı raporla. Mesh/Wedge/Cylinder'in AABB/OBB'sini gerçek yüzeyi diye sunma.

Tahta derzi için rota komşuluğu toleransı ile metal soketin gerçek temas toleransını ayır. Aradaki 0.025 stud bilinçli derzi 'solid temas' diye etiketleme.

## 5. Açıklık
Kapı düzleminden içeri birden fazla x/y noktasında segment gönder. İnce şerit veya kapak boşluğu kesiyorsa fail. İç taban, yan/arka yüz ve tavan da mevcut olmalı. Koyu Decal veya ön yüzü silinmiş tek kutu gerçek iç mekân değildir.

`tools/Math3.luau`: world/local, SAT, segmentOBB, segmentTriangle, projection, scale, renk dönüşümü ve kapalı açık-üstlü kabuk verisi. `tests/run_all.luau` hesapları çalıştırır; Studio motoru değildir.
