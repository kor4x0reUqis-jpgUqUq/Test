# 9454666962: Model → gerçek görsel → gerçekten uygulanmış yüz

**Aktif kaynak: 9454666962, beklenen Model(10). Çözümlenmiş image URI bu pakette henüz yoktur.** Canlı erişim, gerçek görüntü ve lisans doğrulandı diye işaretlenmez. 945466696 eski görev tercihi olarak history'de durur; aktif kaynağı sayı benzerliğiyle değiştirme.

## Güvenli zincir
1. `GetProductInfoAsync` ile canlı tür kontrolü.
2. `GetObjects` yalnız Studio EDIT Command Bar/plugin bağlamında. Root'lar unparented kalır.
3. Tüm yabancı LuaSourceContainer'ları sil; hiçbir foreign Script/ModuleScript parent/require/execute edilmez. İster başarılı ister hatalı olsun bütün kaynak instance'ları sonunda yok et.
4. Texture/Decal/MeshPart/SurfaceAppearance gibi adayların URI verisini incele. Güncel Content `Uri` veya uyumlu string alanları salt veri olarak oku.
5. Image(1) değilse doğrudan Texture'a yazma. Decal kapsayıcısını veri olarak çöz; döngüleri visited kümesiyle kes. Model sayısını image diye kabul etme.
6. Birinci adayı otomatik seçme. Kullanıcı/inceleyen açık aday indeksi seçer.
7. Fetch ayrı, motif görüntüsü ayrı. `PreloadAsync` başarılı olsa da atlas/başka doku olabilir.
8. Kuponun bütün yönlerini ve eğimli yüzünü insan görür; açık onaydan sonra gerçek kurulum/uygulama yapılır.

Yeni `tools/StudioKit.luau`, doku zorunlu modda onaysız ana sahneyi kurmaz. Eski 'dokusuz harita + sonra istersen aracı çalıştır' başarısızlığını tamamlanmış teslim diye tekrarlama.

## Ölçek
`StudsPerTileU/V` bütün görüntü tile'ının fiziksel boyutudur. Tile içinde U yönünde 4 motif, hedef aralık1.25stud ise **tileU=5**, 1.25 değil. Gerçek motif sayısı görülmeden bir tile=bir stud varsayma. Geometry scale ile motif pitch politikası bağımsızdır; örnek adapter world pitch sabit tutar.

## Yerel yön ve maske
Right +X bit1; Top +Y bit2; Back +Z bit4; Left −X bit8; Bottom −Y bit16; Front −Z bit32. Native adlar yereldir; kameraya göre 'ön' değildir.

Ana Block yüzleri gerektiğinde63; cam/su/pupil/kabarcık/ince halat/emisyon gibi istisna0 + **gerekçe**. Sadece Top/Bottom yapıp yanları unutma. Gerekli bir yönü maskeden kaldırıp audit'i yeşile çevirme; kurulumdaki sözleşmeyle karşılaştır.

Örnek adapter Block-only'dir. Mesh/Wedge/CSG/curved body üzerinde '6 Texture = bütün gerçek yüzey' sonucunu varsayma; gerçek UV/yüzey planı ve görünür yüz testi gerekir.

## Güncel özellik seçimi
2026-10-24 dokümanında Texture, Decal'den Content alanlarını devralır. Örnek, serializable **TextureContent=Content.fromUri(uri)** kullanır. ColorMapContent de güncel API'dir ancak ilgili dokümanda can_save=false görüldüğünden yalnız ismine bakıp save/reopen kanıtı varsayılmaz. Eski string Texture hâlâ belgelenir; API özelliği seçimi ile farklı görsel kaynağına izinsiz geçiş aynı şey değildir.

## Faz/kontrast
Örnek LOCAL_ZERO'yu açık kaydeder; dünya UV sürekliliği iddia etmez. Döndürülmüş parçalarla aynı görüntünün yönü de döner. Bitişik yüzlerde motif dikişini ayrıca kontrol et. World-aligned faz gerekiyorsa yüz-U/V bazını, işaret ve köşe başlangıcını kuponla kalibre et; `OffsetStuds` işaretini tahminle final yapma.

Her role aynı kontrastı körlemesine basma. Rol/ince yüz alfası kuponda ve audit'te aynıdır. Tam alfa1 ile gerekli studsu görünmez yapıp 'uygulandı' deme.

**Engel:** kaynağa erişilemiyorsa `BLOCKED_ASSET`, kupon görülmediyse `PENDING_VISUAL_ACK`. Native SurfaceType.Studs, fiziksel çıkıntı, uydurma URI veya üretilmiş görsel yedek değildir. Ancak yeni açık kullanıcı onayı bir alternatif oluşturabilir. Public/free metadata, kullanım/yayın hakkı belgesi değildir.
