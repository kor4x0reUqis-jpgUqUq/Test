# Çok açılı kabul ve erken önizleme

## İlk kanıtı geciktirme
Gerçek geometri ilk okunur hale geldiğinde kalıcı `Onizleme.png` yaz ve aç. Cache, ileride oluşturulacak dosya, taslak plan veya AI hedef resmi teslim önizlemesi değildir. Uzun render/test zinciri varsa sonunu bekletmeden taslak damgasıyla ilk sonucu göster.

## Bakış matrisi
- Genel kaynak eşleme: landmark/ölçek/örtülme.
- Ön/arka/iki yan/üst/alt: boş bırakılan kısımlar ve form sürekliliği.
- Kritik yakın plan: tekne karina/borda/biniş; kapı ve depo içi; halat üst/alt uçları; vinç kabin/merdiven; rig eklemi/kanat kökü.
- Texturesız ve VFX'siz: form saklanıyor mu?
- Gerçek onaylı studs ile: bütün gerekli yönler, motif pitch, alfa/renk/faz, yakın/uzak dikiş.
- Poz/animasyon istenmişse ImportPose ve her klibin hazırlık/eylem/toparlanma anı.

## Aynı veri ve poz
Son sahne/kurulum kaydıyla preview hash'ini eşleştir. Eski renderı yeni kaynak finali diye sunma. Kamera kaydedilmiş pose verisiyle üretilebilir; aktif kullanıcı kamerasını kilitlemek zorunda değildir. Dış renderer görüntüsünü 'Studio screenshot'ı yapma. PBR/Glass/Atmosphere/Neon ve gökyüzü farklarını belirt.

Kaynakla karşılaştırırken yalnız bütün-piksel MAE kullanma: sky, UI, ışık, saydamlık skoru çarpıtabilir. Önce normalize ağırlıklı landmark hatası + silüet/negatif boşluk + komşuluk/örtülme ilişkisi; sonra renk/materyal. Eşiği ölçüm güveninden seç. Gizli alanları 'aynı' diye onaylama.

## Testler ayrı
Syntax PASS, sayısal placement PASS, topology PASS, asset type/access/fetch, insan kupon, gerçek uygulama, Studio API/open, reference visual, avatar physics, FPS: ayrı durumlar. 17 kontrol geçen limanın tekne kusuru bu ayrımın gerçek örneğidir.

Kullanıcı yalnız alt kapsamı onayladıysa onu kapsamlı tut: 'diğer her şey iyi, tekneler hatalı' → layout/general positive; boats negative; doku/kamera/teslim fail. Bütün sahneyi golden örnek yapma.
