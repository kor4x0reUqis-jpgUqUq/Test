# Gerçek rig, klip, VFX ve kontrollü CSG

## Rig matematiği
`childWorld = parentWorld * C0 * Transform * C1:Inverse()`.
Pivotu gerçek eklem soketine koy; Part merkezi kolay diye omuz pivotu sayılmaz. Her sürülen parça tek Motor6D/Bone zincirine, her dekor tek taşıyıcıya bağlı olsun. Ölçeği geometri, C0/C1 ve Attachment translation'ında tutarlı uygula; rotasyonları ölçekleme.

İlk import görünüşü gerçekten uygulanmış ImportPose olmalı. Gelecekte Idle başlayacak olması T-pose'u şimdiden düzeltti demek değildir.

## Klip kalitesi ve teslim
Düzenlenebilir KeyframeSequence/Keyframe/Pose + uygun Motor6D/Bone ağı + anlamsal isim/marker manifesti. Aynı sinüsün adını Walk/Fly diye değiştirip eylem üretme. Hazırlık→eylem→takip→toparlanma; ayak basışı/ağırlık/denge; türün hareketine uygun storyboard.

Dört ayaklıda erişim clamp'li IK ve pole; kuşta omuz→dış kanat gecikmesi ve zar sınırları; balıkta gövdeden kaudale yanal genlik; uçakta gerçek menteşe kontrol yüzeyi; serpente zincir eğriliği. Runtime dekor gösterisi kaynak kliplerin yerine geçmez.

`examples/03_Editable_Rig_Clips_CommandBar.luau`: açık sentetik laboratuvar isteğiyle iki parçalı menteşe, gerçek motor, uygulanmış import pozu, WingFold/WingDownstroke/WingHold kaynak klipleri üretir. Tam yaratık anatomisi veya published animation değildir. Animation Editor'da açılması/oynatılması bekleyen ayrı testtir. Hiçbir AnimationId uydurulmaz.

## VFX
389 kategori kaydı/263 ID `catalogs/` içinde tam korunur. VFX istendiyse bu havuz önceliklidir; her ID'yi yığma. Etiket/type/source/access/license/render ayrı kontrol. SoundId ile ParticleEmitter.Texture, Beam ile volumetric ışığı karıştırma. Blank Beam çizgi/ribbon olabilir ama gerçek hacimsel ışık kanıtı değildir. Neon materyal kendi başına çevreyi aydınlatan Light değildir.

Marker→bölge→bileşen eşleşmesi: ayak tozu temas marker'ı, nefes windup/burst/recover, egzoz motor/fly. İstenmedikçe VFX'e hasar/AI/oynanış ekleme. Rate/Emit, Beam/Trail/lights ve mesafe/kalite kapıları ayrı; eski particle lifetime'ını hesaba kat. Public/free asset metadata lisans belgesi değildir.

## CSG
`tools/GuvenliCSG.luau` primitive-only statik sınırlı helper'dır. GeometryService sonuç **dizisini** işler; her sonucu ayrı doğrular/parent eder. Motor/Constraint/Attachment kaynakları için kör union yapmaz. Yeni sonucu doğrulamadan kaynağı yok etmez; deletion sadece açık owned tag ile. Engine-returned transformu her parçada main.CFrame'e zorlamaz. SplitApart ve mesh girdisinin sonuç türüne etkisi güncel docs'tan kontrol edilir.

Blender Boolean sonucu native UnionOperation değildir. CSG API çağrısı gerçekleşmediyse 'gerçek union' sayısı yazma. Mesh/PBR gerekiyorsa normal convention/UV/izin ve gerçek importer testi ayrı; eski aktarım varsayımını güncel dosya desteği diye genelleme.
