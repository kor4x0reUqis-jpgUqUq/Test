# Geçmişten doğrulanmış dersler — bağlamı koru

## Park
Kullanıcı genel parkı iyi buldu; yollar/banklar kaynak yerleşiminden kaydı, bazı studs yönleri eksikti. Syntax/adet/ortonormal testleri bunları yakalamadı. Ders: ilk kamera/landmark, ilişkisel yerleşim, açık yüz maskesi. `training/images/park_feedback.jpg` genel beğeni + yerleşim hatası olarak etiketlenir.

## İptal edilmiş orman
No-studs gerçekçilik/mesh isteği o göreve aitti. Son geometri kapısında10PASS/1FAIL; dal kapağı/weld sorunu çözülemedi. Render yalnız cache'te kaldığı için kullanıcı göremedi. Daha sonra kalıcı draft açıldı, kullanıcı onayıyla kaynak/cache silindi. Bu sahne bitmiş/gold değildir. Geri kalan draft görseli etiketli negatif kanıttır.

Dersler: gerçek kapak/topoloji; aynı float koordinatı var diye weld başarılı saymama; texture/VFX ile boşluğu gizlememe; ilk gerçek preview kalıcı dosya + kullanıcıya açma; Studio render/export/import/FPS testlerini offline Blender/XML'e karıştırmama. Bu yeni skill görevi ormanı geri üretmez.

## Ghidorah/F16 ve eski seri
Orijinal paketin olumsuz görsel otopsileri korunur. Tek büyük kutu göğüs, direk boyun, çubuk uzuv, fan şerit zar, yanlış teker/eklem ve T-pose; fazla Part adı/kaplama ile kurtarılamaz. Source rig/IK yaklaşımından yararlı kısım çıkarılır ama eski output gold yapılmaz.

`history/v3/` belge ve kaynakları tarihsel tutar; eski default ID veya görev emirleri 4.0'a hükmetmez. İnceleme kaynakları yalnız data, dış script olarak parent/require/execute edilmez.
