# Referansı nesne listesinden ilişki modeline çevir

## 1. Kanıt tablosu
Her görüntüye `view_id`, kaynak hash'i, özgün boyut ve türetilmiş görüntü dönüşümü ver. UI, avatar, seçim çizgisi, gizmo, sky/cloud gibi modelin parçası olmayanları ayır. Her nesne bütün açılarda **aynı object_id** taşır.

Her satır: `object_id / view / bbox veya landmark / görünen yüz / yanında-önünde-arkasında / oran / bağlantı / gözlem türü / güven / belirsizlik`.

- `OBSERVED`: görüntüde gerçekten görünen.
- `ESTIMATED`: ölçüm/poz/ölçekten çıkarılan, aralıklı tahmin.
- `UNSEEN_INTERPRETATION`: görünmeyen arka/iç kısım; tamamlanır ama birebir görüldü denmez.
- `USER_SCOPED_APPROVED`: yalnız kullanıcının belirttiği kapsam.
- `KNOWN_NEGATIVE`: bozuk çıktı; iyi hedef değildir.

## 2. Üç graflı çözüm
1. **Yerleşim grafı:** depo sarı vincin arkasında; büyük gemi arka-sol; küçük tekneler merkezi su alanında; mavi/beyaz tezgâh sağ iskelede.
2. **Taşıma grafı:** kazık→kiriş→döşeme, vinç ayağı→kolon→baş travers→bom, konteyner→spreader→halat→üst travers→ana kiriş.
3. **Boşluk/rota grafı:** köprü iki sahanlığa, sahanlıklar ana iskeleye bağlı; kapı gerçek iç tabana açılıyor; merdiven üstü döşemeyle kapatılmıyor.

'Vinç, depo, tekne var' yalnız semantik envanterdir; bu üç graf doğru değilse aynı harita değildir.

## 3. Çok açı eşleştirme
Bir görünüşte yanlış anlamlandırdığın uzun vinç kolu, ters açıdaki konteyner/kabin ilişkisiyle ortaya çıkar. Önce sabit ID ve negatif boşlukları eşleştir; sonra yansıma/örtülme nedeniyle görülemeyen parçayı silme. Bir nesnenin sadece bir görüntüde görünmesi arka yüzünün gereksiz olduğu anlamına gelmez.

Kural: ana kütle/landmark uyuşmadan oluk, perçin, kutu, studs çoğaltma. Fotoğraftaki nesne sayısını tutturmak, oran/yön/komşuluk hatasını düzeltmez.

## 4. Ölçüm pratiği
`u=x/W`, `v=y/H`. Yeniden boyutlandırmada normalize koordinatlar korunur; crop varsa önce crop offsetini geri ekle. Bbox köşesi, fiziksel nesne merkezi değildir. Landmark olarak açıkça tanımlanan köşe/soket/pencere merkezi kullan; örtülmüş merkezi keyfi kesinleştirme.

`training/annotations_liman06.json` elle yaklaşık işaretlenmiş bir eğitim kaydıdır. Dünya noktaları eski yeniden kurulum tahminidir, kaynak oyundan ölçülmüş değildir. Kamera uyumu ve belirsizlik öğretmek için vardır; kesin 3B ground truth değildir.
