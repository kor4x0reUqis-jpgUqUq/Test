# Güncel API / provenans — 2026-10-24

Resmî doküman URL, sayfanın last_updated alanı ve indirilen içerik hash'i `references/resmi_kaynaklar.json` dosyasında. Kullanılan semboller ve enumlar `validation/api_symbols.json` ile karşılaştırılır. Doküman/isim varlığı, gerçek Studio yürütmesi veya izin başarısı değildir.

- **Camera:** Scriptable default camera scripts tarafından güncellenmez; default kurulumda kullanma. Subject=nil atanamaz. CurrentCamera swap'ı, Workspace'e doğrudan bağlı diğer kameraları yok edebilir; poz verisi/Folder kullan.
- **Texture/Decal/Content:** tekrar boyutu StudsPerTileU/V. Content.fromUri ve Content.Uri güncel. Örnek serializable TextureContent kullanır; ColorMapContent'in save bayrağını okumadan eşdeğer persistence iddiası yok.
- **MarketplaceService:** örnekte güncel GetProductInfoAsync ile AssetTypeId kontrolü. Model10, image1, decal13 enumları API dump'tan denetlenir.
- **DataModel.GetObjects:** Command Bar/plugin güvenlik bağlamı. Kaynağı unparented tutup yabancı kodu sil; serbest metadata bütün hesaplarda erişim/lisans garantisi değildir.
- **ContentProvider:** PreloadAsync / AssetFetchStatus fetch kanıtıdır, görüntünün doğru studs motifi olduğunun veya sahibin izin verdiğinin kanıtı değil.
- **GeometryService:** Union/Subtract/Intersect sonuç dizisi, unparented sonuçlar, engine-returned transform, constraint-preservation koşulları.
- **AssetService/EditableMesh:** CreateEditableMesh nil dönebilir; CreateMeshPartAsync Content kabul eder; normal/triangle/UV yöntemleri ayrı. Bellek/capability ve görsel/collider/save-reopen kabulü ayrıca gerekir. Object Content replication kısıtını göz ardı etme.
- **Lighting:** güncel LightingStyle/PrioritizeLightingQuality mevcut; deprecated Technology varsayımıyla otomatik başarı bekleme. Gölgeler/bloom kalite ve cihaza bağlıdır.

Her yeni çalışma için ilgili resmi API'yi tekrar denetle. Yeni adı kullanmak tek başına doğru model/renk/doku yapmaz. Eski uyumlu özellik ile eski asset ID'yi karıştırma; ID yalnız kullanıcı tercihiyle değişir.
