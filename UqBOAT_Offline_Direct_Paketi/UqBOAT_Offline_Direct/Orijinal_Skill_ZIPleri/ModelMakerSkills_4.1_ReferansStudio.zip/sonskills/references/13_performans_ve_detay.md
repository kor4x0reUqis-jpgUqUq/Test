# Ölçüm, ayrıntı ve dürüst performans

Part adedi, Texture, decal, union/mesh, transparency/overdraw, ışık, joint, Pose, emitter/beam/trail ve collider maliyeti ayrı sayılır. Texture katmanı da gerçek Instance ve render yüküdür. Limanda planlanan 34.710 yüz FPS ölçümü değildir.

Kullanıcı sınır koymadıysa keyfi Part/kod üst sınırı üretme. Yield/batch UI'yi rahatlatır; truncation değildir. Son öğeleri giderek daha düşük detayla bitirme. 'Aşırı detay' anlamlı form/yapı/iç/odak işçiliğidir, rastgele repetition değil.

Hero/Game varyantı ancak kullanıcı kapsamına uygunsa, aynı silüet/ölçek/rig ilişkisini koruyarak ve farkları açık kaydederek yapılır. Occluded yüz politikası rol/niyetle belgelenir; görünür yanları sırf bütçe için sessizce studs'suz bırakma.

Gerçek FPS ölçüm satırı: cihaz, GPU/CPU, çözünürlük, grafik kalitesi, kamera/rota, eşzamanlı adet, warmup, örnek süresi, median/p95 frame time, bellek ve test tarihi. Bunlar yoksa sayısal FPS hücreleri **null/NOT_MEASURED**. Bir headless OpenGL render süresi Roblox mobil FPS'si değildir.

'Herkes için optimize', 'sıfır hata', 'game-ready', 'satılabilir' koşulsuz etiket değildir. Yayın/izin/ticari hak testi ayrı. Gerçek kaynak limitinde kapsamı açık böl; kaliteden sessiz vazgeçme.
