# Eşleşmiş olumlu alt-modeller — 4.1

Bu set, beğenilmiş liman yaklaşımını yalnız 'iyi yap' cümlesi olarak değil **görsel → ölçü → geometri → kod → gözlenen çıktı** zinciriyle öğretir.

| Case | Klasör | Kaynak Part | Odak |
|---|---|---:|---|
| PP01 | red_gantry_container | 268 | Ana vinç ve gerçek konteyner askı zinciri |
| PP02 | yellow_crane_payload | 167 | Kafes kolon/platform/kabin/ankraj/bom ve sandık |
| PP03 | warehouse_interior | 325 | Gerçek kapı açıklığı, iç, duvar ve çatı yükleri |
| PP04 | blue_roof_hut | 47 | Çatı eğimleri, kalkan kapakları ve baca teması |

Her klasörde:
- `reference_crop.jpg`, `user_output_crop.jpg`;
- `image_evidence.json` crop/hash/örtülme ve farklı-kamera kaydı;
- `source_subset.json`: gerçek teslim IR'sinin seçilmiş parça verisi;
- `measurements.json`: orijinal origin, örnek dönüşüm, boyut/yüz/temas sayısı;
- `Builder.luau`: tam native geometri kodu;
- `Installer_CommandBar.luau`: bağımlılıkları inline tam standalone örnek;
- `README.md`: neyi öğrenip neyi kesin varsaymamak gerektiği.

## Çalıştırma

İlgili Installer dosyasının tamamını Studio EDIT Command Bar'a yapıştır. Namespace case'e göre `_G.MM41PP01`, `_G.MM41PP02`, `_G.MM41PP03` veya `_G.MM41PP04` olur. Sonra ana README'deki aynı Resolve → gerçek aday/kupon → açık insan Approve → Install → AuditInstalled akışını kullan. Default kamera yazması yoktur; required-studs gerçek image onayı olmadan main kurulum yapılmaz.

## Gold değil, kapsamlı olumlu örnek

Kullanıcının genel geometri/yerleşim beğenisi esas; eski eksik studs/kod/kilit kamera/tekne hataları dışarıda. Source ölçüleri orijinal oyundan çıkarılmış kesin world veri değil; bizim teslim yeniden kurulumumuzdur. Yeni örnek kurulumların gerçek Studio çalışması/asset/FPS testi bu ortamda yapılmadı. Croplar aynı kamerada değildir; bazı detaylar örtülüdür. Bunlar bütün modeli görsel gold yapmaz.

807 Part'ın veri/kod eşliği, test doubles ile sınanır. Buradaki kurulumları kullanmak, mevcut tam haritanın onarılması veya kullanıcı adına dokunun gerçekten yüklenmesi değildir.

## Yeniden üretme

`python tools/build_positive_pairs.py` committed subset/crop verisinden Builder/Installer/ölçü/test beklentisini yeniden üretir; eski proje klasörü gerekmez. İsteğe bağlı ilk extraction yalnız orijinal harita ZIP'i + raw kullanıcı görüntüsü ister. Bu arşiv bağımlılığı **Studio Installer'ın bağımlılığı değildir**.

Bütün PP vakaları aynı `harbor/train` ailesindedir; aynı sahneyi eval/test'e dağıtıp değerlendirme sızıntısı üretilmez. AI ağırlığı eğitimi yapılmış değildir.
