# Ana vinç ve asılı açık konteyner — eşleşmiş olumlu alt örnek

**Kapsam:** Kullanıcının beğendiği genel geometri/yerleşim yaklaşımından gerçek alt küme. Tam model gold değil; doku/kamera/kod/tekne hata kapsamları dışarıda. Yeni kurulumun Studio testi NOT_RUN.

## Eşleşme
- reference_crop.jpg: kaynak kare 01, crop/provenans image_evidence.json içinde.
- user_output_crop.jpg: kullanıcının mevcut Studio görüntüsünden crop; yeni render değil. Aynı kamera/piksel hizası değil; bazı ayrıntılar örtülü.
- source_subset.json: teslim edilmiş IR'nin 268 Part'lık gerçek alt kümesi; tüm poz/boyut/dönüş/renk/maske.
- measurements.json: origin, rebase örnekleri, yüz ve temas sayısı.
- Builder.luau: bu veriden gerçekten üretilmiş tam native build.
- Installer_CommandBar.luau: bütün kütüphaneleri inline eden standalone kurulum.

## Nasıl öğrenilir?
Aynı taşıyıcı çerçevede dört kolon, bom, kabin, üst A, spreader ve dört halatın doğru taraf/temas ilişkisi. Ana geometriye hizmet eden detay; rastgele nesne tekrarı değil.

Origin=[-24, 5.6, -44]. Her noktada local=world−origin; rotasyon korunur. Örnek wrapper root=(0,8,0) ile componenti incelemeye taşır; kamera taşımaz. Kaynak oyunun ölçüleri kesin elde edildi demek değildir. 22 gerçek kutu temas kısıtı kodda; 1518 planlı yüz gerçek image/kupon/uygulama olmadan tamamlandı sayılmaz.

Komponent çevresindeki liman zemini/ana iskele/tank bu bağımsız derse dahil değildir. Dış sahne bağlantıları tam harita kabulünde ayrıca gerekir.
