# Sarı kafes vinç ve sandık askısı — eşleşmiş olumlu alt örnek

**Kapsam:** Kullanıcının beğendiği genel geometri/yerleşim yaklaşımından gerçek alt küme. Tam model gold değil; doku/kamera/kod/tekne hata kapsamları dışarıda. Yeni kurulumun Studio testi NOT_RUN.

## Eşleşme
- reference_crop.jpg: kaynak kare 02, crop/provenans image_evidence.json içinde.
- user_output_crop.jpg: kullanıcının mevcut Studio görüntüsünden crop; yeni render değil. Aynı kamera/piksel hizası değil; bazı ayrıntılar örtülü.
- source_subset.json: teslim edilmiş IR'nin 167 Part'lık gerçek alt kümesi; tüm poz/boyut/dönüş/renk/maske.
- measurements.json: origin, rebase örnekleri, yüz ve temas sayısı.
- Builder.luau: bu veriden gerçekten üretilmiş tam native build.
- Installer_CommandBar.luau: bütün kütüphaneleri inline eden standalone kurulum.

## Nasıl öğrenilir?
Kolon/platform/kabin/ankraj/bom ve kanca-sandık zinciri tek koordinat sözleşmesinde. Sadece aynı Y seviyesinde olmak gerçek bağlantı değildir.

Origin=[62, 5.6, -29]. Her noktada local=world−origin; rotasyon korunur. Örnek wrapper root=(0,8,0) ile componenti incelemeye taşır; kamera taşımaz. Kaynak oyunun ölçüleri kesin elde edildi demek değildir. 19 gerçek kutu temas kısıtı kodda; 894 planlı yüz gerçek image/kupon/uygulama olmadan tamamlandı sayılmaz.

Komponent çevresindeki liman zemini/ana iskele/tank bu bağımsız derse dahil değildir. Dış sahne bağlantıları tam harita kabulünde ayrıca gerekir.
