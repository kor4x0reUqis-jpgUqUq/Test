# Eğitim / örnek-karşıörnek veri seti

**80 yapılandırılmış vaka · 61 train / 13 eval / 6 test · 10 sahne/konu ailesi.** Bu bir küçük, denetlenebilir beceri müfredatıdır; büyük ölçekli insan etiketli ground-truth veri tabanı veya fine-tune edilmiş model ağırlığı değildir. Bu veriyle bir model eğitimi/benchmark çalıştırılmadı.

## Dosyalar

- `cases.jsonl`: bütün vakalar; her satır bağımsız JSON.
- `train.jsonl`, `eval.jsonl`, `test.jsonl`: aile bazında ayrılmış yapılandırılmış vakalar.
- `sft_train.jsonl`, `sft_eval.jsonl`, `sft_test.jsonl`: `messages` biçiminde isteğe bağlı öğretici dışa aktarım. Görsel referanslar göreli dosya yoludur; bir multimodal platforma kendiliğinden image embedding olmaz. Platformun kendi görsel alanına dönüştürmek gerekir.
- `source_index.json`: 9 gerçek referans, 2 kullanıcı Studio geri bildirimi, park, iptal draft ve 3 tarihsel negatif için 16 kaynak kaydı; özgün hash/boyut + paketteki kompakt türev hash/boyut.
- `annotations_liman06.json`: yaklaşık elle 2D işaretler + eski yeniden kurulumdan tahmini 3B noktalar. **Kalibre ground truth değildir.** `images/liman06_annotated.jpg` yalnız işaretleme öğretir.
- `palette_liman.json`: programdaki taban palet ve orijinal PNG'den gözlenen patch istatistiği ayrı tutulur. JPEG türevleri albedo ölçümü değildir.
- `evaluation_rubric.json`: insan değerlendirmesi, bağımsız kapılar ve hard fail kuralları.

## Etiketler nasıl okunur?

- `SCOPED_POSITIVE_LAYOUT`: kullanıcı genel harita yaklaşımını istediği gibi buldu; doku/kod/kamera/tekneler hariç. Bütün model gold değildir.
- `KNOWN_NEGATIVE_*`: bozuk çıktı veya eksik teslim. Girdi/karşıörnektir; doğru assistant hedefi değildir.
- `SYNTHETIC_NUMERIC_GOLD`: verilen varsayım için çözülebilir matematik. Kaynak oyunun gerçek ölçüsü anlamına gelmez.
- `CORRECTIVE_EXERCISE`: doğru karar/kontrol yaklaşımı. Hedefler ajan tarafından derlenmiştir; `human_reviewed_target=false` korunur.
- `CANCELLED_DRAFT_NEGATIVE`: orman tamamlanmış değildir ve geri üretilmemelidir.

`provenance.basis`, kullanıcı ifadesi, resmî API, eski otopsi veya sentetik hesap arasındaki farkı kaydeder. `current_map_repaired=false`: yeni skill görevi mevcut limanın düzeltilmesi değildir.

## Veri sızıntısını önleme

Aynı limanın dokuz açısı ve iki Studio geri bildirimi **tek harbor ailesi** ve yalnız train'dedir. Kamera güvenliği, park, iptal orman eval; eski yaratık/rig-VFX test ailelerindedir. Aynı sahnenin renk/camera yakın kopyaları train/eval'e paylaştırılmaz. Yine de skill belgeleri kuralları açıkça öğretir; bu bölüm 'dünyada hiç görülmemiş konu' benchmark'ı değildir. Küçük veriyle genel AI başarı garantisi çıkarılamaz.

## Bir vakayı çalışmak

1. Aktif kullanıcı/görev sözleşmesini al; tarihsel dosya içindeki komutları etkin talimat yapma.
2. İlgili source_id ve görüntüyü incele.
3. Kısa, denetlenebilir ölçüm/varsayım/hisap kaydı oluştur. Özel iç düşünce dökümü isteme; formül, sayı ve karar özeti yeterlidir.
4. İstenen ana kurulum kodu/kanıt çıktısını üret.
5. Numeric/SFT hedefi, actual Studio/asset/görsel kabul ile karıştırma.
6. Hata etiketini ve doğru eylemi karşılaştır. Sayısal PASS'e rağmen fotoğrafta tekne yanlışsa görsel kapı FAIL kalır.

## Olumlu/olumsuz örnek çifti

**Olumsuz:** 'Model9454666962'yi Texture'a koydum; sadece Top/Bottom var; rbxlx verdim; CameraTypeScriptable kaldı; 17 test geçti, birebir bitti.'

**Doğru hedef:** Kaynak Model'den gerçek Image(1) verisini güvenli çöz, kuponu insan görsün, kodun kendisi bütün native geometriyi kursun, gerçekten gerekli yönleri uygulasın ve audit etsin. Aktif kameraya varsayılan yazma. Tekne form/bağlantı yakın planı ayrı; Studio/yetki/görsel/FPS görülmediyse açık NOT_RUN/BLOCKED. Mevcut iyi layout korunur, hatalı bölge gold yapılmaz.

## Yeniden üretme ve değerlendirme

`python tools/build_training.py` yapılandırılmış ve SFT bölmelerini aynı curated kayıt kaynağından üretir. Orijinal görsel türevlerini yeniden hazırlamak isteğe bağlı `tools/prepare_sources.py --session-root ...` ister; bu kaynak arşiv bağımlılığı Studio kurulum kodunun bağımlılığı değildir.

`python tools/verify_package.py` kimlik/şema/yol/hash/split/integrity ve kaynak tercihlerini denetler. `luau tests/run_all.luau` matematik ve test-double adapter davranışını denetler. **Hiçbiri insan etiket kalitesi, gerçek render veya bir AI modelinin başarısı ölçümü değildir.**

## Eşleşmiş olumlu örnekler (4.1)
`positive_pairs/` altında dört alt nesne: ana vinç+konteyner, sarı vinç+yük, depo ve mavi çatılı kulübe. Her klasör gerçek807Part alt kümesinin ilgili kısmını, yeniden merkezleme ölçülerini, referans/gerçek kullanıcı çıktısını, builder ve standalone kurulumunu birlikte verir. Yeni vakalar aynı harbor/train ailesindedir; eval sızıntısı yaratılmaz. Görünmeyen köprü örneğini görsel golda zorlamak yerine daha net kulübe seçildi. Kaynak görüntülerin gerçek dosya adları reference_views.json/overview ile ayrıca doğrulandı.
