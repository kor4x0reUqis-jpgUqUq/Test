## 3.0.1: Önizlemeli model teslimi
Bu skill ile yeni model üretirken Onizleme.png, README, kaynak/model dosyaları ve test raporu paketlenir. Önizleme gerçek geometriye dayanır; Studio değilse açıkça etiketlenir.

# Güncel teslim: SONSKİLLS.zip
Yalnız skill güncellendi; mevcut model/animasyon kodu düzeltilmedi. Ana giriş SKILL.md. Eski adı geçen bölümler tarihsel bağlamdır; güncel asset tercihlerinde son kullanıcı sözleşmesi önceliklidir.

**Önemli:** studs ID **945466696**; önceki 9454666962 değil. Tür/erişim burada doğrulanmadı. VFX tam kullanıcı havuzu 389 kayıt / 263 ID; VFX istenen işlerde bu havuz esas. Animasyonlar gerçek düzenlenebilir keyframe klipleri. Silüet/anatomi onayı, bölgesel detay ve studs kupon testi zorunlu. Yeni olumsuz görseller examples/son_olumsuz_kanit altında.

Kullanım: ZIP'i skill destekleyen araca yükle veya açılmış sonskills klasörünü ekle. Normal sohbette SKILL.md ve başvurduğu dosyaları paylaş. Bu paket ağırlık eğitimi veya plugin değildir. Yeni kurallar daha iyi çıktıyı yönlendirir; otomatik görsel başarı garantisi vermez.

# SONSKİLLS v3.0

**BabaarYapar skill'inin geliştirilmiş sürümü.** Roblox Studio'da yüksek detaylı, blok ağırlıklı modeller için yeniden kullanılabilir AI talimatı ve teknik bilgi paketi.

## Kullanım
### Skill destekleyen AI araçlarında
ZIP'i aç; `sonskills` klasörünü aracın skill yükleme akışına ekle. Ana giriş `SKILL.md` dosyasıdır. Platformlar farklıdır; klasör yükleyince her ortamda otomatik etkinleşeceği garanti edilmez.

### Dosya eklenebilen normal sohbette
ZIP'i veya açılmış dosyaları ekleyip şunu yaz:

> Ekteki HarıkaModelleme skill'ini bu görev için kullan. Önce SKILL.md ve ilgili referansları oku. Kare/küp/dikdörtgen Part ağırlıklı tasarla; silüet ve oranı önce kur, sonra katmanlı yüksek detay, geometrik gradient ve seçilmiş studs texture uygula. Gerektiğinde CSG ile gerçek boşluk/oyuk üret ama maliyetini gerekçelendir. Aşırı detay isteğimi rastgele mikro parçalarla geçiştirme. İstenen animasyon/VFX'i ayrı tasarla, istenmeyen gameplay ekleme. Ölçülmeyen performansı veya yapılmayan Studio testini doğrulanmış gibi sunma. İstediğim model: …

AI ZIP okuyamıyorsa SKILL.md ve ihtiyaç duyulan references dosyalarını ayrı yükle. Yalnız “HarikaModelleme kullan” demek başka sohbetin dosyalara erişmesini sağlamaz. Bu bir eğitim ağırlığı dosyası veya Roblox plugin'i değildir; AI'ya başvuru/talimat sağlar.

## 2.1 düzeltmesi
Yalnız skill güncellendi; eski model paketi onarılmadı. 15 kullanıcı görüntüsü negatif kanıt olarak eklendi. T-pose olmayan gerçek ImportPose, yaratıcı ve semantik klipler, tam tekerler ve sınırsız detay önceliği zorunlu hale getirildi. VFX tam JSON + CSV dizini: 389 kayıt / 263 ID. Seri01 artık başarı şablonu değil, hata inceleme kaynağıdır.

## Yeni olanlar
- Tasarımı nasıl analiz edeceği ve kısa gerekçeli kararlar vereceği.
- “Aşırı detay / kod ve part sınırı yok” talebini kaliteye dönüştürme protokolü.
- Silindirik olmayan çok hacimli Block gövdeler; kapanış/soket/teker ve bölgesel bitmişlik sözleşmesi.
- Gerçek Part gradientleri, bant fazı ve seçici studs yüzleri.
- Modern GeometryService CSG rehberi, güvenli statik primitive helper ve kaynak koruma.
- İç mekân/merdiven/taşıyıcı boşlukları ve R6/R15 hedef ölçek düşüncesi.
- Çok boyutlu optimizasyon; High/Medium ile gerçek LOD/streaming farkı.
- Rig, offline IK/FK bake, yayınlanmış klip, marker ve VFX katmanları.
- Üretim klonlarını editör kaynaklarından ayırma.
- Kanıt düzeyli öğrenme günlüğü, karar ve teslim şablonları.

## Dosya yapısı
- `SKILL.md`: ana davranış ve üretim sözleşmesi.
- `references/`: karar sistemi, geometri, CSG, optimizasyon, iç mekân, rig/VFX, kabul ve dersler.
- `examples/inceleme_kaynaklari/`: gönderilen iki ejderha, T-Rex ve VFX listesi; özgün dosyalar.
- `examples/yeni_calismalar/`: lobi, tam iç mekân gemisi, 10 asset generator'ı ve production hazırlama kodu. Referans olarak oku; otomatik çalıştırma.
- `tools/`: parça tarifleri üreten geometri helper'ı, sınırlı güvenli CSG helper'ı, paket doğrulama aracı.
- `templates/`: brief, karar, öğrenme ve teslim kayıtları.
- `CHANGELOG.md`: sürüm farkları.
- `DOGRULAMA.md`: paketin gerçek kontrol kapsamı.

Örnek kodların bulunması CSG/Studio/performans başarısı sertifikası değildir. Geçmiş kodlar iyi tekniklerle birlikte sınırlamalar da içerir. CSG rehberi resmi dokümana dayanır; yeni CSG helper'ı burada Roblox motorunda çalıştırılmadı.

## Eski pakete göre kullanım
Bu sürüm ana rehber olarak önceki BabaarYapar'ın yerini alabilir. Eski stil/animasyon tercihleri korunur; eski görev anına özgü “modeli bekle” gibi talimatlar arşiv bağlamıdır, yeni görevleri durdurmaz.

## Sürekli güncelleme
Yeni örneği `templates/ogrenme_kaydi.md` ile analiz et; kullanıcının beğenisini kod gözlemi ve gerçek testlerden ayır. İlgili reference dosyasını güncelle, sürüm notu ekle, paketi tekrar ZIP'le. Başarısızlıkları da kaydet.

## Sınırlar ve haklar
AI'nın tam olarak aynı sonuçları veya aynı tarzda düşünmesini garanti etmez; açık çalışma kuralları sağlar. Üçüncü taraf asset/animasyon/marka haklarını veya her cihazda performansı onaylamaz. Kaynakta ID bulunması kullanım/satış hakkı değildir. Önceki model kodları kurulum örnekleridir; ZIP hazır ve Studio'da açılmış `.rbxm` modelleri değildir.
