## 3.0 — Yeni kullanıcı kanıtı
Ghidorah silüet/anatomi/detay/studs açısından başarısız bulundu. Parça/texture/Pose sayıları kalite kanıtı değildi. Son otopsi ve silüet kapıları önceliklidir. F16 runtime-only animasyon ve studs eksikliği de bu revizyonda kalıcı ders olarak işlendi. Model kodları değiştirilmedi.

> 2026-10-20 DÜZELTMESİ: Kullanıcının 15 Studio görüntüsü Seri01 için ciddi görsel eksikleri ortaya koydu. Önceki olumlu kod gözlemleri bitmiş kalite onayı değildir. `gorsel_hata_otopsisi.md` ve negatif görsel kanıtlar önceliklidir; önceki performans tercihleri kullanıcının açık aşırı detay talebini geçersiz kılamaz.

# Öğrenme günlüğü — v2.0

## Kanıt etiketleri
- **KULLANICI TERCİHİ:** kullanıcının açık beğenisi/isteği.
- **KOD GÖZLEMİ:** kaynakta gerçekten bulunan uygulama.
- **SAYISAL TEST:** engine dışı hesaplama/örnekleme.
- **DOKÜMAN:** kaynakla desteklenen API bilgisi.
- **STUDIO TESTİ:** ancak gerçek Studio çalıştırmasıyla işaretlenir.
- **ÇIKARIM:** doğrulama gerektiren tasarım yorumu.

Bu çalışmalarda gerçek Studio render/oynatma/cihaz testi yapılmadı. “Öğrenildi” demek örneğin kusursuz olduğu anlamına gelmez.

## 1. İlk ejderha ve ikinci ejderha
**Kullanıcı tercihi:** ilk ejderhanın animasyonu daha başarılı.
**Kod gözlemi:** ilkinde analitik bacak IK ve zengin kanat/kuyruk takip; ikincide image URI çözümleme, seçilmiş yüz texture'ları, eksenli bantlar ve zar gradienti.
**Ders:** en iyi parçaları mantık düzeyinde birleştir. Eski animasyonu yalnız kemik adları aynı diye farklı pivot düzenine kopyalama. Marker adları da farklıdır.

## 2. T-Rex
**Kod gözlemi:** yüz katmanları, göz kırpma, pupil kayması, dil/çene ve kuyruk hareketi; hazırlık–eylem–toparlanma. Fiziksel silindir studlar ve her frame anchored detay taşıma da mevcut.
**Ders:** yüz/anlatı yaklaşımını al; pahalı gösterim altyapısını üretim standardı yapma. Print içindeki “60FPS” ölçüm değildir.

## 3. Lobi kapsamından yalnız gemiye
**Kullanıcı tercihi:** daha sonra yalnız gemi, daha fazla iç detay, mekanik yok ve R6/R15 uyumu istendi.
**Ders:** önceki işin kapsamını yeni isteğe zorla taşıma. Model, etkileşim ve gameplay ayrı teslimlerdir. “İçi de var” demek mobilya eklemek değil, gerçek dolaşım ve boşluk planlamaktır.

## 4. Tam iç mekân gemisi
**Kod gözlemi:** üç ana yürüme katı ve üst güverte; gerçek kapılar; döşeme boşlukları; kesilen alt kirişler; sabit açık kapı kanatları; camlı gerçek pencere açıklıkları.
**Sayısal test:** 21.553 BasePart; merkez hattı/kapı zarf örneklemesinde dikdörtgen parçalara 0 temas. Triangle hull ve gerçek Humanoid testi dahil değil.
**Ders:** yapısal kirişler merdiveni kapatabilir; yalnız döşemeyi kesmek yeterli değildir. Çok yüksek detayın mobilde iyi çalıştığına dair sonuç çıkarma.

## 5. 10 ayrı asset
**Kod gözlemi:** tür başına ayrı gövde/rig; ortak yardımcılar; 31 bake klibi; query hitbox; klip/mesafe/kalite kapılı VFX; High/Medium ortak rig sözleşmesi.
**Sayısal test:** High toplam 2.811 BasePart / 2.204 Texture; Medium 2.201 / 524. 19.568 Pose. Sözdizimi, sayısal çerçeveler, tek sürücü motor, metadata ve loop baş/son pozları kontrol edildi.
**Ders:** her modeli 20 bin parçaya taşımadan ayırt edici form ve hareket kurulabilir. Bu sayımlar Studio görsel kalitesinin kanıtı değildir; kitin her modeli aynı kalite düzeyinde kabul edilmez.

## 6. F-16 referansı
**Kod gözlemi:** tek dikey kuyruk, kanat kökü uzantısı, chin intake, cam canopy, ayrı kontrol yüzeyleri, dış tank ve statik yükler.
**Ders:** araç kimliğini bir uçak etiketi değil bu oranlar ve parçalar kurar. Canopy fasetleri ve saydamlık kalitesi/maliyeti birlikte değerlendirilir. Harici tankları sağ/sol ofset olmadan merkezde üst üste üretmek gibi parametrik hataları erken kontrol et.

## 7. Animasyon kaynak verisini üretimden ayırma
**Kod gözlemi:** kaynak AnimSaves ile küçük ClipSpecs ayrımı; bütün yayınlanmış ID biçimleri doluysa kaynakları ServerStorage'a yedekleyen isteğe bağlı araç.
**Ders:** üretim klonuna gereksiz bake ağacını taşımamak önemli olabilir; runtime'ı metadata/ID ile uyumlu hale getirmeden klasör silme. ID biçimi gerçek oynatma/izin onayı değildir.

## 8. CSG eklemesi
**Doküman:** modern GeometryService sonuç dizisi ve SplitApart seçenekleri; resmi sayfadaki mesh/Beta koşulları.
**Durum:** bu pakete eklenen CSG rehberi ve helper yeni; önceki gemilerin CSG ile yapılmış/test edilmiş olduğu söylenmez.
**Ders:** yeni araştırılmış bilgi ile pratikte çalıştırılmış başarıyı ayrı tut.

## Güncelleme kuralı
Yeni örnekte kaynak, amaç, kullanıcı geri bildirimi, teknik, görsel gerekçe, maliyet, kanıt etiketi ve aktarılabilir kuralı kaydet. Bir olumsuz sonucu da kaydet; yalnız olumlu örnek seçme. Tekil projeye özgü ölçüyü evrensel minimum veya her cihaz için garanti yapma.
