> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

> EK ZORUNLU KAPILAR: bölgesel tamamlama, gövde stil yasağı, açık/kapanmış uç sözleşmesi, soket ve ölçek kontrolleri, tam teker, gerçek ImportPose, yaratıcı semantik klipler. `templates/gorsel_kabul.md` doldurulmadan sayısal testleri görsel başarı diye sunma.

# Kabul kontrolü ve teslim rubriği

Kutuları yalnız gerçekten kontrol edildiğinde işaretle. Statik inceleme, sayısal test ve Studio denemelerini ayrı raporla.

## Görsel tasarım
- [ ] Doku/VFX kapalıyken silüet ve ana tür kimliği okunuyor.
- [ ] Oranlar ön/yan/üst bakışta tutarlı.
- [ ] Ana/orta/mikro detay hiyerarşisi var; her yüz eşit gürültülü değil.
- [ ] Referanstaki imza özellikler korunmuş; görünmeyen taraflar yorum olarak açıklanmış.
- [ ] Gradient yönü ve kontrastı formu destekliyor.
- [ ] Texture ölçeği, yönü, fazı ve erişimi kontrol edildi.
- [ ] Kenar, recess, boşluk ve malzeme ayrımları ana ışıkta okunuyor.
- [ ] Saydamlık/Neon/bloom ayrıntıyı yutmuyor.

## Geometri ve CSG
- [ ] Boyutlar pozitif, konum/rotasyonlar sayısal olarak geçerli.
- [ ] Dejenere üçgen, gereksiz sliver ve z-fighting kontrol edildi.
- [ ] Gerçek boşluk ile siyah yüzey efekti karıştırılmıyor.
- [ ] CSG sonucu listesi doğrulandı; hata halinde kaynaklar korundu.
- [ ] CSG rig/renk/texture/collision etkileri test edildi.
- [ ] Kaynak ve yeni model başarıdan önce geri dönülmez biçimde silinmiyor.

## İç mekân
- [ ] Tüm katlar erişilebilir; döşeme ve kirişler merdiveni kapatmıyor.
- [ ] Landing korkuluk/kapı/mobilya ile bloke değil.
- [ ] Hedef avatarların gerçek boyutlarıyla rota denendi.
- [ ] Ölçek değişikliği açıklıkları bozmadı.

## Rig ve efektler
- [ ] Tek sürücü motor ve doğru taşıyıcı/weld düzeni.
- [ ] Pivot/rest/C0/C1 ve ölçek tutarlı.
- [ ] Loop ilk/son poz ve mümkünse hız kontrolü.
- [ ] Yer teması, ayak kayması, zar ve kapak ayrılması incelendi.
- [ ] Animasyonların yayın/izin/oynatma akışı denendi.
- [ ] Footstep/FXOn/FXOff/Burst gibi marker sözleşmesi tek ve tutarlı.
- [ ] Uzakta emitter, Beam/Trail ve track davranışı doğrulandı.

## Performans
- [ ] Geometri/root/rig/collider parçaları ayrılarak sayıldı.
- [ ] Texture, weld, motor, Pose, ışık ve aktif VFX yükü raporlandı.
- [ ] High–Medium farkı gerçek; sadece etiket değil.
- [ ] Mesafe kontrolü geometrik LOD diye tanıtılmıyor.
- [ ] Hedef görünür adet/oyuncu/cihazla profiler ölçümü yapıldı veya beklediği açıklandı.
- [ ] Üretim klonlarının gereksiz kaynak verileri ve bağımlılıkları değerlendirildi.

## Teslim doğruluğu
- [ ] Tam ve istenen biçimde dosya/kod verildi.
- [ ] Çalıştırma bağlamı, kurulum ve ana Config ayarları açık.
- [ ] Tekil asset temiz place'e bağımsız aktarılabiliyor veya bağımlılıkları listeli.
- [ ] Gameplay kapsamı model/animasyon/VFX'ten ayrı belirtilmiş.
- [ ] Planlanan, üretilen ve test edilen içerik ayrı.
- [ ] Harici görüntü/animasyon/marka hakları doğrulanmadıysa garanti yok.
- [ ] Test doubles, render veya gerçek cihaz testi diye sunulmuyor.

## Teslim özeti şablonu
**Teslim:** …
**Tasarım kararı:** …
**Üretilen içerik:** …
**Ölçülenler:** …
**Yapılan testler:** …
**Bekleyen test/izinler:** …
**Çalıştırma:** …

## Kaliteyi değerlendirme
Her başlığı 0–4 puanla: silüet/oran, yapı/bağlantı, yüzey/renk, odak/hikâye, hareket/işlev, maliyet/ölçüm, teslim/doğruluk. Puan bir dış sertifika veya otomatik ürün onayı değildir; eksikleri bulmak içindir. Ana form/işlev bozuksa yüksek mikro detay puanı bunu telafi etmez.
