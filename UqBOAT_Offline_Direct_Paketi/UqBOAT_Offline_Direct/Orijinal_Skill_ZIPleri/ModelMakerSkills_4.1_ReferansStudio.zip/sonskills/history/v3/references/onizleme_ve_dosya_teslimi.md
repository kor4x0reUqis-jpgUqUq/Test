# Önizleme ve dosya teslim sözleşmesi

Her yeni model tesliminde kullanıcıya tek düzenli paket ver:
- `Onizleme.png`: teslim edilen model geometrisinden üretilmiş, ana silüeti açıkça gösteren görünüş.
- `README.md`: doğru kurulum, klipleri editörde açma, VFX ve asset gereksinimleri.
- İstenen kaynak/model dosyaları ve düzenlenebilir klipler.
- `TEST_RAPORU.md`: gerçekten yapılan ve yapılmayan kontroller.

İhtiyaca göre ayrı `Onizleme_On.png`, `Onizleme_Arka.png`, `Onizleme_Yan.png` ve kritik yakın görünüşler ekle. Bunlar farklı kamera açılarıdır; tek kareye kolaj zorunluluğu yoktur. Arşivi kullanıcıya sun; önizleme dosyasının yerini belirt.

## Gerçeğe uygunluk
Öncelik gerçek Studio ekran görüntüsü/render'ıdır. Studio yoksa aynı teslim geometri verisinden yazılımsal render üretilebilir; görüntüde ve raporda **“Geometri önizlemesi — Roblox Studio render'ı değildir”** yaz. Referansı, eski sürümü veya AI ile çizilmiş temsili bir resmi son modelin önizlemesi diye sunma.

Önizleme modelin silüetini ve oranlarını saklayan bir açı kullanmamalı. Kaplama, cam, studs veya VFX bu renderer'da temsil edilmiyorsa görünüyormuş/doğrulanmış gibi anlatma. Yeni model sürümü değişince önizlemeyi de aynı geometriyle yeniden üret. VFX'siz geometri görünüşü ayrıca bulunmalı.

Güvenilir önizleme üretilemiyorsa dosyayı uydurma: eksik teslimi açıkça bildir ve gereken görüntüleme adımını belirt. Önizleme, çok açılı gerçek Studio/rig/asset kabulünün yerine geçmez. Yalnız derlenen veya sayısal kontrolden geçen modelin görsel olarak başarılı olduğunu iddia etme.
