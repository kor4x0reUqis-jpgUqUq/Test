> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

> Öncelik: `tamamlama_ve_konum_sozlesmesi.md`. Ana gövdede silindirik/eliptik tüp ve büyük boş kutu yaklaşımı yasaktır.

# Block geometri, yüzey ve gradient

## Block stilini neden koruyoruz?
Kare/küp/dikdörtgen parçaların kontrollü ölçeği, açıları ve katmanları ortak bir görsel dil kurar. İyi sonuç, her şeyi tek büyük küp yapmak da her boşluğu küçük küple doldurmak da değildir. Birincil kütleler sade, kenarlar/bağlantılar ise planlı olmalıdır.

## 1. Geometri yardımcıları
- **brick:** renk, materyal, çarpışma, taşıyıcı, ad ve ölçek kurallarının tek noktası.
- **beam(a,b):** orta nokta + lookAt; uzunluk `(b-a).Magnitude`; küçük ve ölçeğe bağlı overlap.
- **surfaceFrame:** yüzey normalini yerel Y yap; longitudinal yönü normal düzlemine izdüşür; çapraz çarpımla baz kur. Paralellikte fallback şarttır.
- **plate:** biraz büyük koyu recessed altlık + az yükseltilmiş ana yüzey. Kalınlık, kenar kontrastı ve küçük tonal farklar hacim verir.
- **Blok kabuk:** ayrı köşeli ana hacimlere bağlanan yüz panelleri; omuz, göğüs, karın, kalça ve uç geçişleri ayrı tasarlanır. Çevresel daire/elips plakalarıyla tüp gövde yapma. Her panelin normalini ve bağlantısını kontrol et.
- **loft:** istasyonlar `[z, centerY, radiusX, radiusY]`; ardışık çokgen çevre köşelerini quad/üçgenlerle birleştir. Parça sayısı, istasyon ve çevre bölüm sayısıyla birlikte büyür.
- **taper:** nokta zinciri boyunca daralan blok kesitleri; kök/orta/uç tonuyla boynuz, tırnak, gaga veya kuyruk.
- **triangle:** en uzun kenara göre sırala, normal/baz ve izdüşüm yüksekliğini bul; iki WedgePart üret. Sıfır alanı ve çok kısa kenarı atla.

`tools/GeometriAraclari.luau` bu hesaplamaların bir kısmını **parça tarifleri** olarak döndürür. Her modeli otomatik bitiren sihirli bir generator değildir; rig bağlama/üretim bağlamı çağırana aittir.

## 2. Yuvarlak formu bloklarla kurmak
- Tam bir dikdörtgen çekirdek üstüne elips plakaları koyarsan çaprazlardaki plakalar kutunun içinde kaybolabilir.
- Daha dar/yüksek ana çekirdek + daha geniş/alçak yan çekirdek, rounded block kesiti için daha iyi tabandır.
- Kesit plakalarını yaklaşık yüzeye oturt; aşırı overlap iç çakışma ve görsel yumru üretir.
- Çevre segment sayısını her yerde aynı tutma: büyük gövdede daha çok, küçük kuyruk ucunda daha az yeterli olabilir.
- Kesit sayısı artırma kararını silüet değişimi belirlesin; dümdüz uzun bölgede gereksiz istasyon açma.

## 3. Geometrik gradient
Bu örneklerde gradient 3B yüzeyin shader'ı değildir. Bir parçayı X/Y/Z ekseni boyunca farklı renkli gerçek bantlara ayırmaktır.

- Ton: `low:Lerp(high, smoothstep(t))`.
- Uç örnekleme: `t=(i-1)/(n-1)` uç renkleri tam kullanır.
- Merkez örnekleme: `t=(i-0.5)/n` bant ortalamasını temsil eder; uç renkleri tam kullanmaz.
- Büyük odak yüzey: gerekçeli 3–5 bant düşünülebilir. Küçük plaka: çoğu zaman 1–2 veya gradientsiz.
- Karanlık uç hangi kenarda olmalı? Kök/derinlik/malzeme yönü mü, stilize ışık mı? Rastgele seçme.
- Geometrik bandın sayısı weld, Texture ve gölge yüzeyi sayısını artırır. Motor sayısını artırması gerekmez; hepsi aynı taşıyıcıya weld olabilir.
- Bandın içte kalan kesişim yüzlerine Texture ekleme. Son yüzleri yalnız ilk/son bantta kullan.
- Bant arası çok küçük örtüşme ince boşluğu gizleyebilir, ancak fazla örtüşme z-fighting veya çizgi yapar. Sabit `0.003` her ölçeğe evrensel değildir.

### Üçgen gradient
Bir tepe noktasından karşı iki kenara Lerp ederek şeritler oluştur; her şeridi iki üçgene böl. İlk şeritte bir üçgen dejenere olabilir; bunu atla. Gövde rengini izleyen az sayıda şerit, her kanat panelinde çok ince dilimlerden daha okunaklı olabilir.

## 4. Studs texture
- Kaynak model ID'si ile gerçek Texture/Decal image URI'sini ayır.
- İçe alınan asset kodlarını çalıştırma; image verisi dışında bağımlılık taşımama yaklaşımını koru. Bu önlem tüm asset risklerini ortadan kaldırmaz.
- Manuel image override ve dokusuz üretim fallback'i sağla; çözülemeyeni “texture hazır” diye sunma.
- `StudsPerTileU/V` fiziksel tekrar boyutudur. Göreli yoğunluğu korumak için model ölçeğiyle birlikte yönet.
- `Texture.Color3` palete tint verir; aşırı koyu texture ana renkleri çamurlaştırabilir.
- Çok küçük yüzler ve kapalı iç yüzler yerine gerçekten okunacak yüzlere ekle.
- Bant ve komşu panellerde U/V fazı ve yüz yönü önemlidir. `OffsetStudsU/V` bulunması tek başına dikişsiz görünüm garantisi değildir; özellikle ters yüzlerde işaret test edilir.
- 2D studs ışıkta gerçek geometri gibi kabartı gölgesi veya silüet üretmez.

## 5. Renk/materyal kararı
- Ana renk ailesi + daha koyu yapı + daha açık kenar + az sayıda vurgu.
- Ana parçalar arasında varyasyon, her yüzün renkli konfetiye dönüşmesi değildir.
- Neon göz/ısı/enerji odaklarında işe yarar; tüm modeli kaplarsa formu siler.
- Neon kendi başına sahneyi aydınlatan PointLight değildir.
- Cam sadece gerçekten pencere/kanopi gereken yerde; üst üste çok sayıda saydam katman görüntü ve GPU maliyetini bozar.
- Plastic estetiği metal/ahşap hissini engellemez: renk, kesit, kenar ve plank/plaka ritmi anlatımın önemli kısmıdır.

## 6. Modüler tekrarın kalitesi
Aynı yardımcıyla farklı tür üretmek kabul edilir; aynı bitmiş gövdeye yeni isim/renk verip farklı model saymak değildir. Griffin/kartal/baykuşta gövde oranı, yüz/gaga, kanat açıklığı, tüy uzunluğu ve hareket temposu ayrı kararlar olmalıdır.
