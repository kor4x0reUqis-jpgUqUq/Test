> 3.0: VFX istenen tüm görevlerde varsayılan ve esas havuz kullanıcının yeniden eklediği assestvfxx.txt dosyasıdır. Başka ID ancak açık onayla. Havuzdaki ID gerçek Beam/Particle/Sound bileşenine bağlanır; listelemek veya native efekti sessizce yerine koymak yeterli değildir.

# Önceden verilen VFX ID’leri — kullanılabilir dizin

Tam liste: `vfx_katalogu.json` ve tablo olarak `vfx_katalogu.csv`: **389 kayıt, 263 benzersiz ID**. Tek ID birden fazla kategori/türde geçtiği için kayıtları tekilleştirip rollerini kaybetme. Özgün kaynak: `../examples/inceleme_kaynaklari/assestvfxx.txt`. Bunlar yeni üretilmiş ID değil; önceden verilen listenin korunmuş dizinidir.

## Kaynakta bulunan örnekler
|ID|Kaynak türü|Kaynak kategori örneği|
|---|---|---|
|6706234595|Particle|Buso / Diable Jambe / Hiken / Meteor|
|296874871|Particle|FireballJutsu|
|867619398|Particle|GiganticCrush / SSJ3 / Silva orbs2|
|1084955012|Particle|Silva orbs2|
|7524756305|Particle|Orange / Purple / Red / Teal|
|1463874772|Particle|BasicHit|
|1135136643|Beam|Buso|
|1771082037|Beam|Buso|
|258126401|Particle|Pheonix Punch / Slash|
|1084991215|Particle ve Beam|Ball / GigChain|

Bu kategori isimleri **kaynak etiketidir**, texture görünüşü teyidi değildir. Her ID için tam eşleşmeyi katalogdan oku.

## Kullanım sözleşmesi
1. İstenen eylem, emitter/beam/trail/sound rolü, bölge ve marker zamanını belirle.
2. Katalogda kategori + type filtrele, gerçek uri’yi al. Sound'u Texture'a bağlama. Model ID’sini resim diye kullanma.
3. Kaynak Particle genellikle ParticleEmitter.Texture adayıdır; Beam, Beam.Texture adayıdır. Erişim/tür uygunluğu Studio'da kontrol edilmeden kesin çalışır deme. Beam için Attachment0/1 ve yön/mesafe gerekir; ID tek başına efekt sistemi değildir.
4. Texture/Sound yüklenmesi, moderasyon/izin ve deneyime erişim koşulları ayrı doğrulanır. Başarısızsa sessizce farklı ID uydurma; hatayı ve efektsiz fallback'i bildir.
5. Klip marker’ıyla başlat/durdur; süre/Rate/Lifetime/Size/Transparency/Color ve temizleme politikasını eyleme göre ayarla. VFX boş geometriyi saklamaz.
6. Dağıtım/satış hakkı ID listesinde bulunduğu için kazanılmaz. Kullanım hakları ayrıca araştırılır.

Örnek filtre (Python): `rows = [r for r in catalog if r["type"] == "Beam"]`. Oyuna Python eklemek gerekmez; bu dizin inceleme örneğidir.
