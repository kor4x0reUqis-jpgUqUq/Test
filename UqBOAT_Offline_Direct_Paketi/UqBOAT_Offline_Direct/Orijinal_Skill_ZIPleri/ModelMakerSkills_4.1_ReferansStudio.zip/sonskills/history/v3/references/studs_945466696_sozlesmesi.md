# Studs sözleşmesi — güncel ID 945466696

**Güncel tercih:** `945466696` / `rbxassetid://945466696`. Bu ID kullanıcı tarafından bu revizyonda açıkça verildi. Eski `9454666962` kullanılmaz. Son rakamı benzer diye tamamlama, sayı yuvarlama veya eski cache'e dönme yok.

## Gerçek içerik ve erişim
Asset'in türü/erişimi burada doğrulanmadı. Texture'a uygun image ise doğrudan kullan; Decal/Model gibi kapsayıcıysa gerçek görsel içeriğini güvenli biçimde çöz. Kaynak içindeki ilk Texture'ı körlemesine seçme: studs olduğunu görsel olarak doğrula. Harici script parent/require/execute etme. URI çıkarılmış olması görüntünün render edildiği anlamına gelmez.

Başarısızsa: kaynak ID, denenmiş yöntem, gerçek hata, modelin doku durumu ve gereken kullanıcı aksiyonunu açık yaz. Kendi ürettiğin başka studs görseli, native SurfaceType.Studs veya fiziksel studlar ancak açık onayla alternatif olabilir; güncel ID uygulanmış gibi sunulamaz.

## Önce örnek kupon
Bütün modele dağıtmadan önce bir düz blok ve bir eğimli yüz üzerinde test:
- Gerçek studs motifi mi, atlas/başka doku mu?
- Tekrar ölçeği gerçek dünya biriminde ne? Part büyüklüğüne göre motif büyüyüp küçülüyor mu?
- Kaynakta bir tile içinde kaç stud var? StudsPerTileU/V tile boyutudur, otomatik “tek stud aralığı” değildir.
- Parlaklık, transparency, Color3/Part.Color ilişkisi altın/sıcak/soğuk renklerde ne üretiyor?
- Yön, faz, dikiş, kırpılma ve eğimli yüzlerde gerilme/UV davranışı uygun mu?

## Dağıtım politikası
Studs genel stil katmanıdır ama her parçanın altı yüzüne aynı sabit ayarları basmak kalite politikası değildir. Görünür yüz maskesi, bölge ve yüz tipine göre fiziksel motif ölçeği ve kontrast belirlenir. Çakışan plakaların doku katmanları birleşimde kirli koyu bant veya moiré oluşturmamalı. Motif plaka/diş/deri anatomisini bastırmamalı.

Ana ölçek tutarlıdır; odak/kanat/diş gibi farklı yüzeylerde bilinçli ve raporlanan istisnalar olabilir. Zar yüzeyi de studs stilinden kopmamalı, fakat aynı yoğunlukla kaplanıp taşıyıcı anatomisini yok etmemeli. Küçük diş, pupil ve VFX yüzeyleri gibi istisnalar açık tasarım kararıdır; “yapmadım çünkü gerçekçi uçak” gerekçesiyle tüm modelden studs kaldırılmaz.

## Kabul kaydı
ID → çözülmüş URI → asset türü → kupon sonucu → bölgesel yüz maskeleri → tile ölçeği → transparency/renk → yakın/uzak görünüş sonucu. Doku olmadan geometri de tamamlanmış görünmelidir. Texture count kalite puanı değildir.
