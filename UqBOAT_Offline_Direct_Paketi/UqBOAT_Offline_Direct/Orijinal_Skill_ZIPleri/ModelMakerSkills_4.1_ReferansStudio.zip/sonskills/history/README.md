# Tarihsel veri, etkin talimat değil

3.0.1 belgeleri ve kaynak metinler davranış farkını incelemek için saklanır. İçindeki eski asset ID, bekleme emri, kod/işlem veya örnek başarı iddiası 4.0 kurallarını geçersiz kılamaz. Kaynak `.txt`/`.luau` dosyalarını yabancı kod olarak çalıştırma/require etme. Orijinal görsellerin kompakt negatif türevleri training/images içindedir; bu klasör tam eski paketin yeniden dağıtımı değildir.
