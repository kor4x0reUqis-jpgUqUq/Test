# Hızlı başlangıç

**AI için:** Önce SKILL.md → references/00_son_sozlesme.md → görevle ilgili rehber → çözümlü vaka. Güncel isteği templates/task_contract.json ile kilitle; örnek koordinatlarını kör kopyalama.

**Studio örneği için:** examples/01_Depolu_Iskele_CommandBar.luau dosyasının TAMAMINI EDIT Command Bar'a yapıştır. Ardından README'deki Resolve → gerçek aday/kupon → insan Approve → Install → AuditInstalled adımlarını uygula. Kamera otomatik değişmez. .rbx dosyası gerekmez.

**Veri seti için:** training/README.md, cases.jsonl ve family-disjoint train/eval/test. Bunlar fine-tune yapılmış ağırlık değildir. Bilinen hatalar iyi çıktı etiketi değildir.

**Kontrol:** python tools/verify_package.py ve luau tests/run_all.luau. Mock/matematik geçişi gerçek Studio/asset/görsel/FPS kanıtı değildir.
