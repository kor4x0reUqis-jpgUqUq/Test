# 4.1.0 — olumlu eşleştirme ve güvenli kaynak takibi

- 4 gerçek başarılı alt bölge: referans crop + gerçek kullanıcı çıktısı + tam807Part alt kümesi + origin/ölçü hesabı + Builder + standalone Installer.
- 76→80 vaka;57→61train,13eval/6test korunur. Bütün liman vakaları aynı ailede.
- 3 temel+4 eşleşmiş=7 bağımsız Command Bar örneği. Kamera/texture-gated kurulum yeni örneklerde de korunur.
- Kaynak görüntü dosya adları etiketli overview ile doğrulandı;4.0'daki01/05 ve04/07 semantik eşleme/link hataları düzeltildi. Orijinal görsel baytları ve önceki teslim ZIP'leri değiştirilmedi.
- Örtülü köprü karesini görsel gold'a zorlamak yerine net kulübe seçildi. Eksik doku/kamera/tekne başarı olarak öğretilmedi.
- YeniSource parity/mock testleri; canlı Studio/asset/FPS hâlâ NOT_RUN. AI ağırlığı eğitimi değildir.

## Önceki4.0 temeli
# 4.1.0 — 2026-10-24

## Kırıcı/öncelikli
- Son kullanıcı Model9454666962 tercihi aktif oldu; eski945466696 varsayılanı yalnız tarihsel alanda.
- Studio kurulum kodu ana çıktı; .rbx dosyası yerine geçmez.
- Required-studs kurulumunda gerçek image/fetch/insan kuponu olmadan main build engeli.
- Default kamera yazması kaldırılmış güvenli yeni örnek; opt-in capture restore/camera-swap koruması.
- Tekne kritik yakın planı bağımsız; 17 offline PASS + kullanıcı tekne FAIL vakası scoped veri.

## Eklendi
- Matematik: local/world, tek ölçek, dönüş, SAT, ışın, perspektif, weighted residual/scale, sRGB ve motif/tile hesabı.
- Kapalı sınır ve gerçek açık üstlü sentetik hull; directed-edge/manifold/no-lid/floor testleri.
- Tam inline Command Bar örneği; staged install, ownership, actual yüz audit ve manifest değiştirme koruması.
- Model çözümlemesinde yabancı kod unparented temizliği, Image tür kontrolü, kupon değiştirme/eksik yüz blokları.
- Hata sırasında owned replacement rollback, eski düzenlenebilir model backup.
- Yapılandırılmış vaka/karşıörnek eğitim veri seti, source hashes, düşük boyutlu gerçek referans türevleri; family-disjoint bölme ve SFT export.
- 389 VFX kaydı/263 ID korunması; orijinal arşiv değişmezlik kontrolü.

## Değişmedi
Anlamlı yüksek detay, silüet/anatomi/bölgesel bütünlük, görünen içler, gerçek editable rig/keyframe, semantik hareket/VFX, gizli bütçe olmaması, sahte API/ID/kanıt/garanti olmaması.

Mevcut liman/park/orijinal skill üzerinde değişiklik yapılmadı. Yeni skill, model onarımına eşitlenmedi.
