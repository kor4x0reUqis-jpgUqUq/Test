"""Review-record gate only. Does not inspect geometry or run Roblox."""
import json,sys
from pathlib import Path
CHECKS=['texture_coupon','surface_coverage','pipe_route_ports','elbow_geometry','overlap_classification','text_approval','vfx_catalog_binding','vfx_visual_match','studio_near_views']
OPTIONAL={'pipe_route_ports':'pipes','elbow_geometry':'pipes','text_approval':'text','vfx_catalog_binding':'vfx','vfx_visual_match':'vfx'}
def evaluate(record):
 errors=[]
 if record.get('schema_version')!=1:errors.append('invalid schema version')
 scope=record.get('scope',{})
 for key in ['pipes','text','vfx']:
  if not isinstance(scope.get(key),bool):errors.append('missing/invalid scope: '+key)
 checks=record.get('checks',{})
 for name in CHECKS:
  c=checks.get(name,{})
  if not isinstance(c,dict):errors.append(name+': invalid record');continue
  status=c.get('status')
  if status=='not_applicable':
   key=OPTIONAL.get(name)
   if key is None or scope.get(key) is not False or not c.get('reason','').strip():errors.append(name+': invalid exemption')
  elif status=='pass':
   evidence=c.get('evidence')
   if not isinstance(evidence,list) or not evidence or not all(isinstance(e,str) and e.strip() for e in evidence):errors.append(name+': missing evidence reference')
  else:errors.append(name+': '+str(status or 'missing'))
 return {'review_record_complete':not errors,'status':'REVIEW_RECORD_COMPLETE_NOT_ENGINE_CERTIFIED' if not errors else 'RELEASE_BLOCKED','errors':errors,'limitation':'Checks supplied review records only; evidence truth, geometry, engine appearance and VFX rights are not verified by this tool.'}
if __name__=='__main__':
 result=evaluate(json.loads(Path(sys.argv[1]).read_text()));print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['review_record_complete'] else 1)
