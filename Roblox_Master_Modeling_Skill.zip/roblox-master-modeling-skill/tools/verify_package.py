"""Package structure/integrity check only; no Roblox/AI installation implied."""
from pathlib import Path
import hashlib, json, re
root=Path(__file__).resolve().parent.parent
required=['references/onizleme_ve_dosya_teslimi.md','SKILL.md','README.md','CHANGELOG.md','DOGRULAMA.md',
'references/karar_sistemi.md','references/geometri_ve_yuzey.md',
'references/csg_karar_ve_guvenlik.md','references/optimizasyon.md',
'references/ic_mekan_ve_olcek.md','references/rig_animasyon_vfx.md',
'references/kalite_kabul.md','references/ogrenme_gunlugu.md',
'references/vfx_katalogu.json','tools/GeometriAraclari.luau','tools/GuvenliCSG.luau']
required += ['references/'+n+'.md' for n in ['gorsel_hata_otopsisi','tamamlama_ve_konum_sozlesmesi','durus_ve_anlamsal_animasyon','kalite_onceligi_ve_detay_modu','vfx_kullanim_dizini']]
required += ['templates/'+n+'.md' for n in ['bolgesel_tamamlama','konum_ve_teker_kontrolu','animasyon_manifesti','gorsel_kabul']]
required += ['references/'+n+'.md' for n in ['son_kullanici_sozlesmesi','ghidorah_siluet_anatomi_otopsisi','siluet_anatomi_ve_detay_kapilari','studs_945466696_sozlesmesi']]
required += ['references/kullanici_asset_tercihleri.json','templates/siluet_anatomi_studs_kabulu.md']
required += ['assestvfx/assestvfxx.txt','assestvfx/vfx_katalogu.json','assestvfx/vfx_katalogu.csv','assestvfx/vfx_ids.txt','assestvfx/KAYNAK.json','references/son_guncel_sozlesme.md','references/santral_hata_otopsisi.md','references/yuzey_boru_birlesim_kapilari.md','templates/yuzey_boru_vfx_kabulu.json','tools/check_release_gate.py','tools/test_release_gate.py']
for name in required: assert (root/name).is_file(),f'Missing {name}'
text=(root/'SKILL.md').read_text()
assert text.startswith('---\nname: tekdeneme\n')
for path in re.findall(r'`((?:references|templates|tools)/[^`]+\.(?:md|luau|json))`',text):
    assert (root/path).is_file(),f'Broken skill reference: {path}'
assets=json.loads((root/'references/vfx_katalogu.json').read_text())
assert len(assets)==389 and len({x['id']for x in assets})==263
import csv
with (root/'references/vfx_katalogu.csv').open() as f:
    assert list(csv.DictReader(f)) == assets
assert len(list((root/'examples/olumsuz_gorsel_kanit').glob('image-*.png'))) == 15
prefs=json.loads((root/'references/kullanici_asset_tercihleri.json').read_text())
assert prefs['studs']['approved_method']=='native_SurfaceType_Studs'
assert prefs['studs']['invalid_image_id']=='945466696'
assert prefs['animations']['editable_keyframes_required'] is True
assert prefs['vfx']['default_pool_for_requested_vfx'] is True
assert len(list((root/'examples/son_olumsuz_kanit').glob('kanit-*.png'))) >= 4
manifest=root/'SHA256.json'
if manifest.exists():
    for name,digest in json.loads(manifest.read_text()).items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,f'Changed bytes: {name}'
print('PACKAGE_STRUCTURE_AND_INTEGRITY_OK')
print('Not an engine, rendering, CSG, AI behavior or rights verification.')

# Reparse original bytes; preserve semantic duplicate records and all source types.
raw=(root/'assestvfx/assestvfxx.txt').read_bytes()
assert raw==(root/'examples/inceleme_kaynaklari/assestvfxx.txt').read_bytes()
source=json.loads((root/'assestvfx/KAYNAK.json').read_text());assert hashlib.sha256(raw).hexdigest()==source['source_sha256']
rows=[];category=None
for line in raw.decode('utf-8-sig').splitlines():
    m=re.match(r'^=== (.*?) ===$',line.strip())
    if m:category=m.group(1)
    m=re.match(r'^\s*(Particle|Beam|Sound|Trail|Decal|MeshId|TextureId):\s*(\d+)\s*$',line)
    if m:
        typ,aid=m.groups();rows.append(dict(category=category,type=typ,id=aid,uri='rbxassetid://'+aid))
assert rows==assets==json.loads((root/'assestvfx/vfx_katalogu.json').read_text())
with (root/'assestvfx/vfx_katalogu.csv').open() as f:assert list(csv.DictReader(f))==assets
assert set((root/'assestvfx/vfx_ids.txt').read_text().splitlines())=={x['id']for x in assets}
assert len(list((root/'examples/santral_olumsuz_kanit').glob('image-*.png')))==3
from check_release_gate import evaluate
assert not evaluate(json.loads((root/'templates/yuzey_boru_vfx_kabulu.json').read_text()))['review_record_complete']
print('TEKDENEME_VFX_SOURCE_DUPLICATES_AND_BLOCKING_TEMPLATE_OK')
