from pathlib import Path
import json,copy
from check_release_gate import evaluate,CHECKS
root=Path(__file__).resolve().parent.parent
template=json.loads((root/'templates/yuzey_boru_vfx_kabulu.json').read_text())
assert not evaluate(template)['review_record_complete']
good=copy.deepcopy(template)
for name in CHECKS:good['checks'][name]={'status':'pass','evidence':['fixture-only/not-real-engine-test'],'reason':''}
assert evaluate(good)['review_record_complete']
# Every missing/failing/unrun critical field must block; a disclaimer is not a pass.
n=1
for name in CHECKS:
 for state in ['fail','not_tested','unknown',None]:
  case=copy.deepcopy(good);case['checks'][name]['status']=state;assert not evaluate(case)['review_record_complete'];n+=1
 case=copy.deepcopy(good);case['checks'][name]['evidence']=[];assert not evaluate(case)['review_record_complete'];n+=1
case=copy.deepcopy(good);case['checks']['vfx_visual_match']={'status':'not_applicable','reason':'no Studio'}
assert not evaluate(case)['review_record_complete'];n+=1
case=copy.deepcopy(good);case['scope']['vfx']=False
for name in ['vfx_visual_match','vfx_catalog_binding']:case['checks'][name]={'status':'not_applicable','reason':'user explicitly requested no VFX'}
assert evaluate(case)['review_record_complete'];n+=1
case=copy.deepcopy(good);case['scope']['text']=False;case['checks']['text_approval']={'status':'not_applicable','reason':'no invented signage; no text requested'}
assert evaluate(case)['review_record_complete'];n+=1
print('REVIEW_GATE_REGRESSIONS_OK',n,'synthetic record cases; not engine tests')
