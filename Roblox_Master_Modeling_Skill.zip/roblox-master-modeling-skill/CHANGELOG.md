# 3.1.0 — 2026-10-21 / TEKDENEME
- Santral Studio yakın görüntüleriyle kullanıcının reddi kaydedildi; model düzeltmesi yapılmadı.
- Yarım/taşan motif, eksik doku, dirsek, penetrasyon, uydurma yazı ve anlamsız VFX bağlama için engelleyici kalite kapıları.
- 945466696 Place sonucu ve daha sonraki native Studs onayı aktif sözleşmeye işlendi.
- Orijinal VFX listesi assestvfx/ içinde byte eşit korundu; kataloglar yeniden türetildi, 389 kayıt/263 ID.
- Güncel tercih JSON'u, kabul şablonu, kayıt denetimi ve testleri; eski sanat/animasyon sözleşmeleri korundu.
- Yeni öğrenme → ilgili rehber + tercih + kanıt + sürüm + hash döngüsü zorunlu.

# 3.0.1 — Model paketinde Onizleme.png ve dürüst render etiketi zorunluluğu; README/test raporu/dosya teslim kaydı.

# 3.0.0 — 2026-10-20 / SONSKİLLS
- Yeni Ghidorah ekran görüntülerine dayalı silüet/anatomi/tekrar detay/studs otopsisi.
- Silüetten önce seri detay yasağı; kanat anatomisi ve büyük/orta/küçük işçilik kapıları.
- Güncel studs 945466696; eski 9454666962 tercihi kaldırıldı. Kupon, motif ölçeği, yüz maskesi, eğimli yüz ve görsel kabul zorunlu.
- Yeniden verilen assestvfxx dosyası byte olarak korundu; 389/263 tam havuz esas kaynak.
- Gerçek editlenebilir keyframe ve rig teslimi; runtime-only animasyon kabul edilmez.
- Yeni kullanıcı sözleşmesi, makine okunabilir asset tercihleri ve kabul şablonu.
- Eski modeller/ZIP'ler değiştirilmedi; Studio testi yapılmadı.

# 2.1.0 — 2026-10-20

- 15 ekran görüntüsüne dayalı negatif kalite otopsisi; doğrulanan nedenler ile yerleşim hipotezleri ayrıldı.
- Gövdede tüp/eliptik varsayılan kaldırıldı; detaylı kare/dikdörtgen çoklu hacimler.
- Bölgesel tamamlama, koordinat/ölçek/soket/kapanış ve tam teker protokolü.
- Gerçek ImportPose; türe özgü yaratıcı hareket, semantik klip/manifest/runtime sözleşmesi.
- Ultra + optimizasyon önemsiz talebinde gizli düşük bütçe yasağı.
- VFX görünür tam CSV ve tür/erişim rehberi; dört yeni kabul şablonu.
- Önceki modeller değiştirilmedi; yeni Studio çalıştırması yapılmadı.

# Değişiklikler

## 2.0.0 — 2026-10-20
- Ad: HarıkaModelleme; önceki BabaarYapar yaklaşımının devamı.
- Kare/küp/dikdörtgen Part önceliği ve Wedge/CSG seçim kuralları açıklaştırıldı.
- Yöntem seçimi, karar özeti, aşırı detay yükseltmesi ve durdur/yeniden değerlendir koşulları eklendi.
- Geometrik gradient, texture fazı ve görünür yüz optimizasyonu genişletildi.
- Modern CSG için resmi doküman kaynakları; primitive-only güvenli helper eklendi. Engine testi yapılmadığı belirtildi.
- Gemi iç mekânı, merdiven açıklığı/kiriş boşluğu ve avatar test dersleri eklendi.
- Seri01'den ortak rig sözleşmesi, 31 klip/19.568 Pose kaynak maliyeti ve üretim ayırma dersleri eklendi.
- High/Medium, mesafe kapısı, render LOD ve streaming kavramları ayrıldı.
- Kanıt düzeyli öğrenme günlüğü, karar/brief/teslim şablonları ve kalite kabul listesi eklendi.
- Kaynak kodlar veri olarak korundu; geçmiş görev talimatlarının bugünkü görevi geçersiz kılamayacağı açıklandı.

## 1.0 — BabaarYapar
İki ejderha/T-Rex incelemesi, temel üretim skill'i, VFX katalogu ve orijinal kaynak dosyalar.
