# Tarihsel kod — otomatik kalite örneği değil

Seri01_Kurulum.luau kullanıcı görüntülerinde eksik bölge, duruş, teker ve gövde yaklaşımı sorunları gösteren negatif örnektir. Kodu olduğu gibi yeni model şablonu yapma. `references/gorsel_hata_otopsisi.md` ve `examples/olumsuz_gorsel_kanit/` ile birlikte oku. Bu skill revizyonunda eski model kodları düzeltilmedi. Diğer örnekler de yalnız teknik inceleme verisidir; Studio kalite sertifikası yoktur.
