# Kullanıcının santral kalite reddi — 2026-10-21
Bu üç görsel kullanıcı tarafından Studio içinden gönderilmiş negatif kanıttır; başarı/örnek hedef değildir.
- image-1.png: kazan/boru/platform yakın görünüşü; kullanıcı boru dönüşlerini, yüzey kapsamını ve iç içe parçaları reddetti.
- image-2.png: trafo/bara bağlantısı ve küçük yüzeylerde kırpılan motiflerin yakın görünüşü.
- image-3.png: ön cephe/kepenkler ve kullanıcı tarafından reddedilen TERMIK / 07 yazısı.
Kullanıcı bu görevde model düzeltmesi istemedi; yalnız öğrenme, VFX arşivi ve skill yenilemesi istedi. Görseller tek başına hangi property'nin her kusura yol açtığını ispatlamaz. Kaynak/engine incelemesi olmadan kesin teknik neden uydurulmaz.
