# 3.1.0 — 2026-10-21 / TEKDENEME doğrulaması

## Bu revizyonda yapılanlar
- Önceki skill'in bilgi/örnekleri korunarak yeni aktif sözleşme, hata otopsisi, kalite kapıları, tercih JSON'u ve şablonlar eklendi/güncellendi.
- Yüklenen assestvfxx.txt dosyasının byte eşit iki kopyası ve SHA256 kaydı. Kaynaktan tam katalog yeniden çıkarıldı: 389 kayıt / 263 ID; Particle, Beam, Sound, Decal, MeshId, TextureId türleri ve kategori tekrarları korunur. Eski başvuru katalogları ile assestvfx katalogları eşleştirildi.
- Kullanıcının üç santral Studio görüntüsü byte olarak eklendi; tarihsel negatif görseller korunur.
- Giriş dosyasının relative başvuruları, katalog CSV/JSON eşliği, yeni şablonun eksik testleri engellemesi ve dosya manifesti kontrol edilir.
- Kabul kayıt denetleyicisi sentetik regresyonları: not_tested/fail/unknown/eksik kanıt ve yanlış muafiyet kabul edilmez. Bu yalnız kayıt kontrolüdür, gerçek engine/UV/geometri doğrulayıcısı değildir.
- Son paket ZIP CRC ve SHA256 kontrolünden geçirilir.

## Yapılmayanlar / değiştirilmeyenler
Bu görevde santral, Ghidorah, F16, vadi veya diğer model kodları/paketleri düzeltilmedi. Yeni bir model üretilmedi. Studio, yüzey kuponu, VFX render/erişim/hak, Roblox import, fizik/çarpışma veya performans testi yapılmadı. Kullanıcı görüntüleri önceki başarısızlığın kanıtıdır; bu skill revizyonunun model başarısı kanıtı değildir.

945466696'nın Place olduğu bilgisi önceki HTTP metaveri kontrolünden gelir; bu revizyonda yeniden sorgulanmadı. Native Studs onayı da önceki açık kullanıcı seçimidir. Skill'in başka bir AI aracına yüklenmesi veya aynı hataları bir daha asla yapmayacağı garantisi yoktur; kurallar ve engelleyici kayıtlar güçlendirildi. Önceki DOGRULAMA raporlarındaki geometri/Luau testleri tarihsel kalır, bu revizyonun testi diye sunulmaz.

Tekrar kontrol: python tools/verify_package.py ve python tools/test_release_gate.py.
