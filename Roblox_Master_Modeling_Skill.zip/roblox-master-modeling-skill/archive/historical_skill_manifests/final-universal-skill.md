---
name: final
description: Her tür Roblox modelinde güncel kapsam, doğru hacim/siluet, anlamlı detay, gerçek CSG/mesh, istenen studs-texture ve VFX, kolay kod kurulumu ve dürüst native doğrulama için evrensel üretim disiplini.
---
# FINAL — Evrensel Roblox modelleme skills'i

Bu paket tek bir robotun, aracın veya koleksiyonun tarifi değildir. Karakter, yaratık, araç, uçak, gemi, bina, kale, doğa/bitki, obje, makine, dekor ve set üretiminde güncel isteğe uyarlanır. Model türü, ölçü, stil, renk, yüzey, işlev ve klipler yeni kullanıcı talebinden alınır. Eski görevin 24-stud/altı-klip/renk/stud/timer gibi ayrıntıları genel varsayılan olmaz.

## Başlangıç ve öncelik
1. `FinalPRO.txt`: tek başına kullanılabilir EVRENSEL sözleşme; ZIP verilemediğinde metin yeterli kalite talimatıdır. Konu tarifini kullanıcının yeni isteği belirler.
2. `references/evrensel_uretim_kapilari.md`: tüm model türlerinde kapsam ve kabul matrisi.
3. `references/son_hatalar_ve_kurulum_sozlesmesi.md`: hatalardan türetilmiş genel kurallar.
4. `references/cases/`: açık etiketli vaka kaynakları; başarılı model kalıbı veya bütün işlere uygulanacak tarif değil.

## Modelleme işçiliği — genişletilmiş atölye
Bu pakette modelleme odağı artık kısa kurallardan uygulamalı akışa genişletildi. `references/modelleme_ve_oran.md` ile başla: yedi bölüm; referans ölçümü, kütle/kesit, on geometri reçetesi, detay/birleşim, model türleri, revizyon ve somut eğitim senaryosu. `templates/Modelleme_Calisma_Karti.md` ile iki CSV yeni işte doldurulur. Bunlar yeni/native onaylı model değil, çalışma ve inceleme araçlarıdır. Evrensel FinalPRO bu tur değiştirilmedi.

## Kapsam yönlendiricisi
- Yeni model / repair / varyasyon / yalnız animasyon / yalnız VFX / optimizasyon / yalnız skills-prompt güncellemesini ayır.
- Statik modele otomatik rig/altı klip koyma. Rig istenince gameplay kontrolcüsü de istenmiş sayma. Kontrolcü istenmişse yalnız poz klibiyle geçiştirme.
- Studs, texture, VFX, iç mekân, etiket veya animasyon ancak güncel kapsamda gerekli olduğunda uygulanır; açık istek varsa atlanmaz.
- Kullanıcı kod öncelikli kolay kurulum istiyorsa zor GLB/upload/manuel eşleme zincirini onaysız standart teslim yapma. Gerçek kalıcı özel mesh upload/izin gereksinimini üretimden ÖNCE anlat; imkânsız sıfır-upload vaadi ve onaysız all-Part fallback yok.

## Evrensel üretim sırası
1. Konu/kullanım/ref/stil/boyut/teknoloji/yüzey/işlev/kurulum/kabul tablosu.
2. Referansı gerçekten incele; görünen ve belirsiz bölgeleri ayır. Dosya basename'ine güvenme.
3. Birincil siluet, kesit, derinlik ve kütle dağılımı. Dolu görünüm ile içi rastgele doldurma farklıdır. Zayıf formu vida/seam/ışıkla saklama.
4. İkincil yapılar ve anlamlı üçüncül detay. Ön–arka–yan–üst–alt kapsamında tutarlı işçilik; yüzen parça/sahte bağlantı/boş nozul taklidi yok.
5. Doğru teknoloji: Part/Wedge, gerçek native CSG/Union/Negate, uygun özel MeshPart. Offline boolean native Union kanıtı değildir.
6. İstenen yüzey: renk/material/UV/PBR/studs/Texture ayrımını yap. Texture istenince SurfaceType veya perçin geometriyi texture diye sunma. Altı yüz/tiling/yön/eğimli yüzler gerekiyorsa native denetle.
7. İstenen işlev: rig/klip, etkileşim/fizik/kontrolcü ve VFX'yi ayrı kur. Dosyada tanım olması erişilebilir çalışması değildir.
8. Temiz Studio kurulum akışı, native görünüm, save-reopen/Play/publish/izin ve gerçek performans ayrı kapılardır.
9. Gerçek kaynak/kod/ZIP, kısa Türkçe rehber, actual-geometry preview ve kapsamı açık test raporu.

## Yüzey ve VFX kalite kapısı
- İstenen studs gerçekten uygulanmalı; Texture, legacy SurfaceType ve fiziksel stud geometri birbirinin adı değildir. Texture child sayısı UV/projeksiyon doğrulaması değildir. Gizli helper'a texture eklemek sayım hilesidir.
- Mesh/Union eğimli-kavisli yüzeylerde planar kaplama bozulabilir; native sonuç görülmelidir. Uydurma/izinsiz asset ID yok.
- GLB genel olarak material/texture/rig/animation taşıyabilir; belirli bir dosyanın içeriği ve import sonucu ayrı doğrulanır.
- VFX istenirse doğru parent/Attachment, yerel eksen, açma–kapama/reset ve native görünürlük gerekir. Idle'da kapalı bir emitter veya başka karakterin ateşi, kullanıcıya çalışan model VFX'i teslimi kanıtı değildir.
- Aşırı parlama ve alpha gövde detayını silemez. Global Lighting'i izinsiz değiştirerek iyi görünüm üretme. Thumbnail/runtime izin ayrımı korunur.

## Kabul ve dürüstlük
PASS, FAIL/USER_REJECTED, NOT_RUN, BLOCKED ve UNKNOWN ayrıdır. Offline derleme/topoloji/hash/FK/browser PASS; native görünüm, CSG kernel, editor erişimi, animasyon playback, studs, VFX, kalıcılık veya FPS kanıtı değildir. Kullanıcı ret verince sayıları göstererek başarı ilan etme.

Native imkân yoksa baştan açıkla. Kaynak teslimini native onaylı model gibi sunma; uzun uyarıyla kurulum yükünü kullanıcıya yıkmayı başarı sayma. Model istenince yalnız plan, belge güncellemesi istenince model tamiri yapma.

## Modüler başvurular
- `references/modelleme_ve_oran.md`: hacim ve siluet.
- `references/mesh_union_ve_kalicilik.md`: teknik geometri ve kalıcı asset ayrımı.
- `references/smooth_keyframe.md`, `references/ozel_rig_ve_editor_kayitlari.md`: yalnız animasyon/rig gereken işler.
- `references/optimizasyon_ve_vfx.md`: ölçüm ve anlamlı efektler.
- `references/etiket_ve_teslim.md`: yalnız ilgili etiket/yüzey/teslim talepleri; geçmiş koleksiyon ayarları evrensel değildir.
- `references/kabul_kapilari.md`: genel test çerçevesi; son sözleşme `FinalPRO.txt` ile günceldir.

## Araçlar ve örnekler
`tools/EditableClips.luau` genel ama native doğrulanmamış authoring şablonudur; her model için zorunlu değildir. `InflateTemplate.luau` eksik verili decoder şablonudur, bağımsız kurucu değil. `inspect_geometry.py` kaynak topolojisini inceler; estetik hacim/FPS ölçmez.

`references/source_examples/` altındaki özgün ejderha/ejderha2/trex ve `assestvfx/assestvfxx.txt` korunur, otomatik yürütülmez. Tercih edilen hareket örneği aynı bağlamda dikkate alınır; robot hareketi her modele taşınmaz. Kaynak sağlanmamışsa okunmuş gibi davranma.

## Hata arşivi ve dosya güvenliği
`references/cases/Mecha24_USER_REJECTED/` gerçek reddedilen bir vaka içerir: zayıf/detaysız/hatalı form, zor kurulum, yüzey ve animasyon/VFX erişim sorunları. Son dört native ekran ve studs/VFX geri bildirimi eklendi. Bu model onarılmadı; güncel template/başarı örneği değildir. Bu vakadan genel ders öğrenilir; gövde/klip/sabit ölçü kopyalanmaz.

Sadece açık kapsamda temizlik yap. Kaynakları/kanıtları önce hash ile koru. Aynı image-1.png adı tekrar kullanılabilir; eski kopyaları ezme. Reddedilen model veya ham örneği izinsiz repair/publish etme. Evrensel promptu bir sonraki işte yine son modele özelleştirerek bozma.
