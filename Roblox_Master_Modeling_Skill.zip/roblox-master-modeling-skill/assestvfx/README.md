# Kullanıcının tam VFX havuzu
- assestvfxx.txt: yüklenen özgün dosya, byte eşit korunmuş.
- vfx_katalogu.json / .csv: 389 kayıt; kategori ve tür tekrarları korunur.
- vfx_ids.txt: 263 benzersiz ID; kolay arama içindir, rol kataloğunun yerine geçmez.
- KAYNAK.json: dosya hash'i, sayımlar ve doğrulanmayan alanlar.
Türler: Particle, Beam, Sound, Decal, MeshId, TextureId. Kaynak etiketi Roblox gerçek asset türünün veya görsel rolün doğrulaması değildir. Bir kategoriye sahip ID tüm o efektin emitter preset'ini, attachment ağacını veya animasyonunu içerdiği anlamına gelmez.
Kullanım önce references/vfx_kullanim_dizini.md ve son_guncel_sozlesme.md ile değerlendirilir. VFX isteniyorsa gerçek bileşen/yer/rol/görünüş eşleşmesi gerekir; yalnız bu listeyi teslim etmek efekt kullanmak sayılmaz. Erişim ve haklar doğrulanmadı.
