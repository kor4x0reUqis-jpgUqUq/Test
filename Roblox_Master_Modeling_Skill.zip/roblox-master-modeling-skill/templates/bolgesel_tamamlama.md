# Bölgesel tamamlama matrisi
Model / DetailMode / PerformancePriority / istenen görünüşler:

Her anatomik/mekanik bölge için ayrı satır ekle. İlgisiz bölge N/A + gerekçe; tümünü topluca TAMAM yazma.
|Bölge|Ana hacim|İkincil hacim|Yüzey|Birleşim/kapanış|Ön/arka/alt görünüş|Durum/eksik|
|---|---|---|---|---|---|---|
|Kafa ön/yan/arka|TODO|TODO|TODO|TODO|TODO|Taslak|
|Gövde üst/yan/alt|TODO|TODO|TODO|TODO|TODO|Taslak|
|Uzuvlar/kanat/iniş takımı|TODO|TODO|TODO|TODO|TODO|Taslak|
|Kuyruk/arka uç/egzoz|TODO|TODO|TODO|TODO|TODO|Taslak|

Sonuç: Kritik taslak kaldı mı? Detay bir noktadan sonra azalıyor mu? VFX ve Texture kapalıyken bitmiş mi? Ultra talebinin somut ek işçiliği ne?
