# Konum, kapanış ve teker kontrolü
Ölçek birimi / root CFrame / ileri-yukarı-sağ eksenleri / ölçek uygulama noktası:

|Bağlantı|Parent uzayı|Beklenen soket|Ölçülen nokta|Sapma/tolerans|Sonuç|
|---|---|---|---|---|---|
|TODO|TODO|TODO|TODO|TODO|Bekliyor|

Uç listesi: CLOSED / INTENTIONAL_OPEN / CONNECTED_TO + hedef + görsel kontrol.
Rig: childWorld = parentWorld * C0 * Transform * C1:Inverse(); dinlenme ve uç pozlarda soket kontrolü.
Teker varsa: axle yönü, iki düzlem ekseni, yarıçap, lastik genişliği, sırt kapanışı, iki yanak, jant, göbek, aks, çamurluk boşluğu, zemin teması ve sağ/sol yerleşim.
Her madde: beklenen / ölçülen / geçmedi ise düzeltme. Sadece NaN yok demek yetmez.
