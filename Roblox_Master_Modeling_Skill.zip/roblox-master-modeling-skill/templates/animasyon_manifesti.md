> 3.0: son sözleşme ve siluet_anatomi_studs_kabulu.md kaydı zorunlu. Güncel studs ID 945466696, VFX kullanıcı havuzu, gerçek düzenlenebilir klipler; yapılmayan testler bekliyor.

# Semantik klip manifesti ve storyboard
Modelin davranış kimliği:
BindPose / gerçek uygulanmış ImportPose / başlangıç Idle:

Her klip için kopyala:
- Gerçek klip adı (örn. Wolf_Walk):
- Rol metadata'sı (örn. locomotion):
- Amaç ve türe özgü imza poz:
- Hazırlık / itki-temas / ana eylem / sekonder gecikme / toparlanma:
- Duration / Loop / Priority / in-place veya root-motion:
- Başlangıç / bitiş durumu ve geçiş hedefi:
- Marker / bölge / VFX ID / başlat-durdur:
- KeyframeSequence.Name / ClipSpecs / AnimationId anahtarı / runtime seçim karşılığı:
- Görsel test anları / soket ve penetrasyon sonucu:

ID yüklenmemişse boş/yerel kaynak diye belirt; var olmayan yayınlanmış ID uydurma. Fly poz klibi gerçek uçuş mekaniği demek değildir.
