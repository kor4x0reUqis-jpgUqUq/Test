> 3.0: son sözleşme ve siluet_anatomi_studs_kabulu.md kaydı zorunlu. Güncel studs ID 945466696, VFX kullanıcı havuzu, gerçek düzenlenebilir klipler; yapılmayan testler bekliyor.

# Görsel kabul — sayısal testten ayrı
Model / sürüm / gerçek Studio testi yapan / tarih:
Test yapılmadıysa: BEKLİYOR. Aşağıdaki kutuları varsayımla doldurma.

|Kapı|Kanıt/görünüş|Sonuç|Eksik ve düzeltme|
|---|---|---|---|
|Köşeli çok hacimli gövde, tüp/büyük boş kutu değil|Ön/yan/üst|Bekliyor||
|Bütün bölgeler bitmiş; yarıda azalan detay yok|Arka/alt/yakın|Bekliyor||
|Kapanış, soket, ölçek, anatomik devamlılık|Yakın görünüş|Bekliyor||
|Tekerlerin tam katmanları ve zemin teması|Ön/yan/aks görünüşü veya N/A|Bekliyor||
|ImportPose güçlü; T-pose değil|Animasyon kapalı ilk açılış|Bekliyor||
|Türe özgü yaratıcı hareket ve anlamlı adlar|Her klibin ana evreleri|Bekliyor||
|VFX kapalı geometri / açık zamanlama|İki ayrı kontrol|Bekliyor||
|Ultra talebinin gerçek ilave işçiliği|Bölgesel matris|Bekliyor||

Final kararı / açık kusurlar / yapılmamış testler:
Kritik kapı geçmediyse final kaliteli teslim iddiası yok. Studio yoksa kaynak ve sayısal kontrolleri raporla, görsel doğrulamayı bekliyor bırak.
