# Yeni zorunlu kabul kaydı
Model / referans / ayrılan büyük-orta-küçük işçilik / belirsizlikler:

|Kapı|Beklenen ilişki|Gerçek kanıt|Sonuç/eksik|
|---|---|---|---|
|Uzuv/baş/kuyruk sayısı|Referans ve kullanıcı hedefi||Bekliyor|
|Siyah silüet|Ön/yan/arka kütle ve negatif boşluk||Bekliyor|
|Anatomi|Omuz-göğüs-karın-kalça / boyun / bacak||Bekliyor|
|Bağlantı|Kök/soket hacmi ve hareket uçları||Bekliyor|
|Kanat|Kol-dirsek-bilek-parmak-zar; fan şerit gürültüsü yok||Bekliyor|
|Detay|Büyük/orta/küçük katmanlar ve her bölgenin bitmişliği||Bekliyor|
|Studs kuponu|945466696, doğru içerik/ölçek/yön/kontrast||Bekliyor|
|Studs model|Bölgesel yüz maskesi, eğimli yüz ve dikişler||Bekliyor|
|Animasyon|Rig'e bağlı gerçek KeyframeSequence/Pose; Editor kontrolü||Bekliyor|
|VFX|assestvfxx kaydı → bileşen → marker → erişim||Bekliyor|

Test yoksa BEKLİYOR. Source/compile/Part/Pose sayısını görsel kanıt sütununa yazma.
