> 3.0: son sözleşme ve siluet_anatomi_studs_kabulu.md kaydı zorunlu. Güncel studs ID 945466696, VFX kullanıcı havuzu, gerçek düzenlenebilir klipler; yapılmayan testler bekliyor.

# Teslim raporu
## Tamamlanan
- Dosyalar / modeller / klipler:
- Üretilen ile yalnız planlanan içerik ayrımı:
## Kısa tasarım özeti
- Silüet, detay, renk, boşluk, hareket kararları:
## Ölçümler
- Görünür geometri / root / rig / collider / Texture / weld / motor / Pose / ışık:
- VFX, saydamlık ve CSG yükü:
- Ölçüm ortamı:
## Testler
- [ ] Sözdizimi
- [ ] Sayısal geometri / rig
- [ ] Studio API / CSG
- [ ] Render / yüzey / görsel bütünlük
- [ ] Avatar / fizik / dolaşım
- [ ] Animasyon / marker / izin
- [ ] Hedef cihaz / yayın
Her işaretin yanında kullanılan yöntem ve gözlemi yaz. İşaretlenmeyen testleri başarı gibi anlatma.
## Kullanım
- Kurulum bağlamı ve adımlar:
- Config:
- Dış bağımlılıklar ve haklar:
- Sınırlar / kalan testler:

## Paket ve önizleme
- Ana paket adı / kaynak dosyalar:
- Onizleme.png dosyası:
- Aynı geometri/sürümden üretildi mi?:
- Gerçek Studio görüntüsü / yazılımsal geometri render'ı:
- Temsil edilmeyen texture/studs/VFX/materyaller:
- Ek ön/arka/yan/yakın görünüşler:
- README ve test raporu:
