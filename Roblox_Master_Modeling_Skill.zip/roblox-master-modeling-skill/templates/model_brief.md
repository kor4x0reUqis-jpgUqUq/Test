> 3.0: son sözleşme ve siluet_anatomi_studs_kabulu.md kaydı zorunlu. Güncel studs ID 945466696, VFX kullanıcı havuzu, gerçek düzenlenebilir klipler; yapılmayan testler bekliyor.

# Model brief
- İstenen model ve ayırt edici silüet:
- Kullanım: dekor / iç mekân / NPC / boss / binek / araç asseti / diğer:
- İstenen içerik: geometri / rig / klip / VFX / gameplay:
- Özellikle istenmeyenler:
- Referans ve sadakat önceliği:
- Ölçek ve hedef avatar aralığı:
- Yakın/orta/uzak görüntüleme:
- Hedef cihaz ve eşzamanlı görünür adet:
- Teslim biçimi ve çalıştırma bağlamı:
- Belirsizlikler / sorulacak kritik sorular:
- Kabul edilen varsayımlar:
