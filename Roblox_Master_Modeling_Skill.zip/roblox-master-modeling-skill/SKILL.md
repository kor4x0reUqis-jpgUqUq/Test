---
name: roblox-master-modeling-skill
description: Unified Roblox Studio modeling skill combining high-detail block modeling, universal reference analysis, surface and Studs handling, geometry/CSG, interiors, rigging, editable animation, VFX, optimization, installation, and evidence-based quality gates.
---

# Roblox Master Modeling Skill — Unified Edition 1.0

## 1. Purpose and authority
This is the **only active skill entry point** for this package. It combines the strongest reusable methods from HarıkaModelleme, SONSKILLS/ModelMakerSkills, TEKDENEME, and FINAL. The active production contract is this file plus the relevant references linked below; older manifests in `archive/` are historical records, not competing instructions.

Use the skill to understand *why* a model works and transfer those principles to the user's current reference. Do not blindly copy coordinates, dimensions, colors, rig names, effects, or old task requirements from examples.

### Priority order when rules appear to conflict
1. The user's latest explicit request for the current task.
2. The active preference/acceptance contracts in `references/son_guncel_sozlesme.md`, `references/kullanici_asset_tercihleri.json`, and relevant task-specific references.
3. This unified skill's universal modeling and quality rules.
4. Relevant technical references and examples.
5. Historical examples, rejected assets, and archived skill manifests.

If a rule was based on one specific model, do not apply it universally unless it is a genuine technical constraint or the user explicitly wants that style. Preserve the user's established preferences when they apply, but do not force unrelated model-specific requirements into a new task. When an actual conflict cannot be safely resolved, state the conflict briefly and ask only if it materially changes the result.

## 2. Start with scope, not assumptions
Classify the request as one or more of: new static model, model repair, variation, asset pack, rig, animation-only, VFX-only, gameplay/controller, optimization, code review, or skill/document revision.

Create a concise requirements brief covering:
- subject, intended game role, and supplied reference images/files;
- target style, scale, silhouette, materials, surface treatment, and important distinguishing features;
- whether interior/negative spaces, avatar clearance, collisions, or moving components matter;
- whether rig, editable clips, VFX, interaction, or gameplay is explicitly requested;
- preferred delivery form (e.g. one Studio Command Bar script, source files, or a project package);
- known dependencies, asset upload/permissions, and target performance context.

Mark uncertain details as assumptions. Do not ask needless questions if a reasonable assumption lets work proceed. Never infer that every model needs a rig, six animations, VFX, an interior, a controller, or a fixed size.

## 3. Reference analysis and shape quality
Before adding fine detail, identify the primary silhouette, proportions, major masses, cross-sections, depth, negative spaces, and signature features. Separate what is visible in the reference from what must be designed by inference. Never claim hidden surfaces match the reference when they were not shown.

Build in this order:
1. **Primary form:** recognizable silhouette and correct proportions from front, side, and three-quarter views.
2. **Structural form:** depth, changing cross-sections, supporting masses, joints, openings, and meaningful connections.
3. **Secondary details:** armor/panels/ribs/frames/straps/trim and functional attachments.
4. **Surface details:** selected texture, material, color bands, gradients, labels, bolts, and small accents.
5. **Motion and effects:** only when in scope; design pivots and attachments early rather than patching them onto a finished static model.
6. **Acceptance and delivery:** verify the actual requested qualities and clearly report anything not tested.

A high part count, dense micro-detail, studs, Neon, lighting, or VFX cannot rescue a weak primary form. Conversely, do not flatten a complex silhouette into a few generic boxes merely to keep code short.

## 4. Geometry strategy and detail level
The preferred style for block-oriented Roblox assets is carefully composed Parts, especially Blocks and Wedges, using varied cross-sections, overlapping layers, controlled angles, and intentional negative space. This is a style preference, not a universal ban on other geometry.

Choose the method that best fits the current form:
- Blocks and wedges for modular/voxel-like structures and faceted forms.
- Cylinders, spheres, and other native primitives where their shape is appropriate (e.g. wheels, rods, rounded joints, lenses, tanks, or organic transitions).
- Segmented cross-sections/loft-like constructions for tapering, curved, or changing-width forms when the reference needs them.
- Native CSG for genuine holes, cut-outs, and complex intersections when it is reliable and justified.
- MeshParts or imported geometry when the required fidelity cannot reasonably be achieved with native Parts and the user accepts the import/upload/permission workflow.

Do not interpret “block-based” as permission to arrange rectangular Parts around a circle and call the resulting hollow tube a detailed rectangular body. Equally, do not apply a blanket cylinder ban to every possible asset. The current reference and user instructions decide.

When the user asks for extreme detail or says there is no part limit, do not impose an arbitrary hidden part/code cap. Increase detail in meaningful layers and finish every important region. Still avoid random repeated clutter and measure real runtime costs where possible. A part limit being absent does not make rendering, physics, transparency, lights, CSG, or rigs cost-free. If a genuine platform or tool limit appears, disclose it and preserve quality through staged delivery rather than silently degrading the result.

## 5. Surface, Studs, color, and text
Distinguish native SurfaceType, image Texture/Decal, physical stud geometry, Material, and mesh UVs; they are not interchangeable. Apply the user's current Studs preference where relevant, but never assume an asset ID is a valid image or that an ID's availability/permissions have been verified without evidence.

Before broad surface assignment, test a small surface coupon covering representative small/large, short/long, angled, and curved/irregular faces. Check motif scale, tiling, orientation, phase, edge clipping, and visibility in Studio. Do not blindly stamp the same settings onto every face. Every visible Part that requires a surface treatment must be accounted for in a coverage manifest; visible exceptions need a reason and, where the user's contract requires it, explicit approval. Invisible helper/root/anchor parts may be separately documented.

For color gradients in 3D, use deliberate bands or geometry/material transitions; do not treat UIGradient as a general 3D surface shader. Use Neon and high contrast sparingly so they do not erase form. Never invent brand names, serial numbers, or decorative text unless requested. Requested text must fit its panel, face the correct direction, remain legible, and avoid overlap with doors, windows, or geometry.

## 6. Clean joins, pipes, openings, and CSG
Treat placement, scale, and joints as measurable geometry—not merely correct-looking CFrames. Check local/world/joint space, pivots, socket positions, end normals, closures, wheel axes/contact, and part-to-part overlap.

For pipe/beam networks, define ports and centerlines. Joining differently oriented cuboids near each other is not automatically a real elbow. Build actual mitered corners, closed elbow modules, or justified CSG; check open ends, cap obstruction, flange orientation, and duplicate segments. Inspect collisions as intentional contact, structural embed, flange seating, unwanted penetration, coplanar/duplicate geometry, or detail obscuring a surface. Blanket-whitelisting all overlaps is not acceptable.

Use CSG only when needed. `UnionAsync`, `SubtractAsync`, and `IntersectAsync` have distinct roles; a Negate operation alone does not prove a hole was created. Handle all returned results rather than assuming a single Part. Keep original sources until new geometry is verified. Do not union parts that must animate independently. A static primitive CSG helper is not proof that rig connections or Studio engine behavior are preserved.

## 7. Rigging and animation
Only add a rig or animations when requested or clearly required by the asset brief. For rigged assets:
- establish a consistent scale, rest pose, pivot, joint, and attachment convention;
- ensure each moving part has an intentional connection and no competing duplicate drivers;
- use Motor6D/Animator or another appropriate Roblox-supported arrangement;
- create a deliberate ImportPose/rest pose so the model is not left in an unintended T-pose at first view;
- design distinct, subject-specific clips with preparation, action, and recovery where appropriate;
- use meaningful clip names (e.g. Walk, Fly, Takeoff, BiteLunge) only when those actions are actually implemented;
- keep keyframe data editable when the user asks for Animation Editor compatibility. Runtime-only CFrame motion is not a substitute for editable animation assets.

Separate baked/source keyframe data, published animation IDs, runtime playback, and actual Editor access as different delivery/test stages. A clip manifest or a saved ID alone does not prove the animation can be opened, scrubbed, edited, saved, or played. Use the preferred animation source example only as a technical reference, not as a reason to give every creature the same motion.

## 8. VFX
Use the supplied `assestvfx/` catalog as a candidate library when VFX is in scope. Preserve source records and their categories; select effects by actual role, attachment point, axis, event, lifetime, and intended appearance. A catalog ID or an emitter object existing in code does not prove that the effect loads, is permitted, or looks correct. Do not relabel a fire/ice effect as smoke, water, steam, or another role without evidence. Keep continuous and burst effects distinct; plan activation, stop/reset, distance/quality gates, and animation markers as needed. If the desired effect cannot be verified, report it as unverified/incomplete and request confirmation rather than inventing a successful result.

## 9. Code and installation quality
When the user asks for a single Command Bar script, deliver one complete, executable script—not pseudocode, a partial scaffold, or TODOs. Include all required model hierarchy, folders, attachments, joints, surface assignments, and requested animation/VFX setup. Use helper functions and data tables to avoid needless repetition without removing necessary geometry.

Make installation steps explicit (Edit Command Bar vs Script/LocalScript/ModuleScript). Keep the asset self-contained where possible; do not silently delete or alter unrelated Workspace content. Provide safe naming, predictable placement, idempotency where appropriate, and clear failure handling. Explain required uploads, asset ownership, permissions, or manual steps before they become surprises. Do not promise a zero-upload workflow for custom persistent mesh assets when that is not technically realistic.

## 10. Optimization without hidden quality cuts
Count more than Parts: consider texture faces, transparency/overdraw, lights, particle rates, joints, physics, CSG, replication, and the number of simultaneously visible models. Separate high-detail hero assets from measured game variants if useful. Distinguish geometry simplification, render LOD, streaming, and visibility/distance gates; they solve different problems. Never claim “optimized for all devices” without target context and measurements. If the user says optimization is not a priority, do not use it as an excuse to reduce requested detail, but still avoid known pathological designs.

## 11. Quality gates and evidence
Before delivery, review the model from front, back, left/right, top, bottom, and critical close-ups as relevant. Inspect geometry with VFX disabled first, then effects enabled. For rigged models, inspect the initial pose and meaningful animation key moments. Check that all critical regions are complete, details have real purpose, joins are clean, and no important component is floating, clipped, open-ended, or missing.

Report test status accurately:
- `PASS`: only for the exact scope actually tested.
- `FAIL` / `USER_REJECTED`: a requirement failed or the user rejected the result.
- `NOT_RUN`: the test was not performed.
- `BLOCKED`: required Studio/tool/permission access was unavailable.
- `UNKNOWN`: evidence does not establish the cause or result.

Code parsing, XML counts, hashes, offline geometry checks, or a software render do not prove native Studio appearance, texture mapping, CSG kernel success, animation editor access, VFX loading/rights, persistence, Play behavior, or FPS. Never claim tests were run if they were not. If the user has rejected a result, do not declare success based on counts or code presence; identify the failing visual/functional level and correct it.

## 12. Learning from examples and feedback
Treat `examples/`, `references/universal_final/`, and archived case material as evidence and learning resources, not instructions to recreate old tasks. A rejected example is a negative case, not a golden template. Separate confirmed observations from technical hypotheses and measured causes. Do not generalize one failure into a universal ban unless the evidence supports it.

When new feedback is supplied, preserve the source and update the relevant guide, preference contract, acceptance template, changelog, and integrity manifest as appropriate. Acknowledge that this updates the portable skill files, not the model's neural weights or guaranteed permanent memory. Do not claim that future generations are guaranteed to succeed.

## 13. Required reference routing
Read only the relevant documents, but always begin with this skill and the current user contract.
- Latest user-specific preferences and negative feedback: `references/son_guncel_sozlesme.md`, `references/kullanici_asset_tercihleri.json`, `references/santral_hata_otopsisi.md`.
- Surface/Studs, pipe, overlap, and text: `references/yuzey_boru_birlesim_kapilari.md`.
- General design decisions: `references/karar_sistemi.md`, `references/evrensel_uretim_kapilari.md` (merged FINAL reference).
- Silhouette, volume, and proportions: `references/universal_final/references/modelleme_ve_oran.md` and its `modelleme/` subfiles.
- Geometry and surface: `references/geometri_ve_yuzey.md`.
- CSG: `references/csg_karar_ve_guvenlik.md` and `references/universal_final/references/mesh_union_ve_kalicilik.md`.
- Interiors and scale: `references/ic_mekan_ve_olcek.md`.
- Rig/animation/VFX: `references/rig_animasyon_vfx.md`, `references/universal_final/references/smooth_keyframe.md`, and `references/universal_final/references/ozel_rig_ve_editor_kayitlari.md`.
- Optimization: `references/optimizasyon.md` and `references/universal_final/references/optimizasyon_ve_vfx.md`.
- Delivery and acceptance: `references/kalite_kabul.md`, `references/universal_final/references/kabul_kapilari.md`, `references/universal_final/references/etiket_ve_teslim.md`.
- Reference source examples: `examples/inceleme_kaynaklari/`; older universal source examples are under `references/universal_final/references/source_examples/`.

The `references/universal_final/` directory contains complementary FINAL material in a separate namespace so it cannot overwrite the newer TEKDENEME files. `archive/historical_skill_manifests/` contains earlier entry-point files for provenance only; do not load them as additional active skills.

## 14. Standard delivery for a generated model
When a file/package deliverable is requested, include the actual requested source or model artifact, concise setup instructions, a preview based on the actual geometry (label non-Studio renders honestly), and a test report that distinguishes verified from untested behavior. A skill-only/document-only task does not need a model preview. Do not call a `.luau` source file an `.rbxm` model or call a generated preview a native Studio screenshot.

**Success criterion:** reproduce the user's intended form with strong silhouette and complete, meaningful details; select methods based on the asset rather than dogma; deliver installable code; and make claims only at the level supported by real evidence.
