# Roblox Master Modeling Skill — Unified Edition 1.0

This package consolidates five supplied skill archives into one active skill. Start with `SKILL.md`. It uses TEKDENEME 3.1.0 as the newest preference/quality-gate base, and adds FINAL's universal modeling workflow and unique technical references without overwriting newer files.

## Layout
- `SKILL.md`: sole active entry point.
- `references/`: current modeling, geometry, texture/Studs, rig/animation, VFX, acceptance, and user-specific feedback references.
- `references/universal_final/`: complementary FINAL references, examples, and tools in a separate namespace.
- `assestvfx/`: original VFX source and catalogs from TEKDENEME.
- `examples/`: reference source files and clearly marked negative evidence.
- `tools/`, `templates/`: validation and acceptance aids.
- `archive/historical_skill_manifests/`: prior SKILL.md files retained for provenance only; they are not active competing skills.

## Use
Upload/extract this folder in a skill-capable AI tool and activate the root `SKILL.md`. If the platform only accepts files in chat, attach `SKILL.md` plus the relevant reference files named in its routing section. Platform-specific automatic activation is not guaranteed.

## Validation limits
Package integrity can be checked locally, but this package itself does not prove Roblox Studio rendering, native CSG, texture access, VFX permissions, Animation Editor compatibility, save/reopen persistence, or performance. Those require their respective real tests.
