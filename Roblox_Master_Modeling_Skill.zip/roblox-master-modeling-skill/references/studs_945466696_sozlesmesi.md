# Studs sözleşmesi — 3.1.0 ile düzeltilmiş tarihsel yol
Bu dosya adındaki 945466696 bir güncel image talimatı DEĞİLDİR. Metaveri: https://economy.roblox.com/v2/assets/945466696/details → AssetTypeId 9 (Place); önceki oturumda alındı. Place ID'sini Texture diye bağlama. 9454666962'ye dönme.

Kullanıcı sonrasında native SurfaceType.Studs'u açıkça onayladı. Bu onay bütün yüzlerde uygunsuz Weld/X motifini veya dokusuz parçaları meşrulaştırmaz. Şimdi geçerli yüzey kuponu, eksiksiz yüz kapsamı ve kırpılma/ölçek kabulü `yuzey_boru_birlesim_kapilari.md` dosyasındadır. Yeni image/alternatif için kullanıcı onayı ve tür/erişim/görünüş kontrolü gerekir. Yeni skill revizyonu asset metadata'sını tekrar sorgulamamıştır; önceki doğrulanmış sonucun kaydıdır.
