# CSG: yöntem seçimi, güvenli uygulama ve sınırlamalar

## Kanıt durumu
Önceki gemi/asset generator'ları **CSG kullandıklarını iddia etmez**; açıklıkları panel atlayarak oluştururlar. Bu bölüm önceki kodda test edilmiş bir CSG başarısı değil, resmi dokümana dayalı yeni bir teknik rehberdir. 2026-10-20 tarihinde incelenen dokümanlar aşağıdadır; API ve Beta koşulları zamanla değişebilir.

- GeometryService boolean yöntemleri `UnionAsync`, `SubtractAsync`, `IntersectAsync` sunar ve sonuçları bir **dizi** olarak döndürür. [1](https://create.roblox.com/docs/reference/engine/classes/GeometryService)
- `SplitApart` ile ayrı gövdelerin ayrı sonuçlar olarak dönmesi kontrol edilir; modern sonuç listesi tek Part gibi ele alınmamalıdır. [3](https://create.roblox.com/docs/parts/solid-modeling)
- Seçeneklerde `CollisionFidelity`, `RenderFidelity`, `SplitApart` bulunur; örnekler constraint koruma akışını ayrıca ele alır. [6](https://create.roblox.com/docs/reference/engine/classes/PartOperation)
- Resmi sayfa Mesh üzerinde CSG, sweep ve fragment desteği için Beta etkinleştirme koşulu belirtir. Bunları tüm kullanıcı ortamlarında koşulsuz kullanılabilir sayma; mesh için watertight geometri gereksinimini de kontrol et. [3](https://create.roblox.com/docs/parts/solid-modeling)

## 1. İşlemlerin anlamı
- **Union:** hacimleri birleştir. Parçalar geometrik olarak ayrık kalıyorsa sonucunun nasıl bölüneceğini `SplitApart` ve gerçek çıktı üzerinden kontrol et.
- **Subtract:** kaynak hacimden kesici hacimleri çıkar. Bir kapı deliği, oyuk veya iç kanal için uygundur.
- **Intersect:** ortak hacmi koru. Özel kırpma/kesişim şekillerinde yararlıdır.
- **Negate:** Studio iş akışında kesici hacimleri negatif olarak işaretlemek için kullanılan kavramdır; yalnız negatif işaretli nesneyi gizlemek deliğin gerçekten açıldığı anlamına gelmez.

Bunları rastgele birbirinin yerine kullanma. “CSG var” demek görsel veya performans kalitesi kanıtı değildir.

## 2. Ne zaman CSG?
**İyi adaylar:** tek rijit parçadaki karakteristik delik/oyuk, karmaşık birleşim, katmanla temsil edildiğinde kötü silüet veren kırpma, düzgün kesilmiş giriş.

**Önce başka yöntemi düşün:** dikdörtgen kapı çevresinde birkaç panel; yüzlerce ayrı renkte gradient bandı; hareketli tüy/kanat eklemleri; küçük ve uzaktan görünmeyen delikler; her frame yeniden hesaplanacak dekor.

Bir gemi kapısını çevresindeki dört parça arasında gerçek boşluk bırakarak yapmak da doğru modellemedir. CSG şart değilse sırf araç kullanılmış olsun diye subtract ekleme.

## 3. Düşük Instance sayısı ≠ otomatik hızlı CSG
CSG sonucu tek Instance görünürken karmaşık render/çarpışma geometrisi taşıyabilir. Kaynak sayısı, geometri karmaşıklığı, render fidelity ve collision fidelity ile hedef cihaz yükünü ayrı değerlendir. Bir uçta çok fazla Part, diğer uçta gereksiz karmaşık bir union kötü olabilir. Ölçülmemiş bir seçeneği daha hızlı ilan etme.

Gezilebilir açıklıklarda çarpışma yaklaşımının deliği gerçekten koruduğunu test et. Görsel kapı açıkken bir convex collision hull onu kapatabilir. Gerektiğinde uygun fidelity veya basitleştirilmiş ayrı collider kullan; en pahalı seçeneği bütün union'lara otomatik uygulama.

## 4. İşlem sırası
1. Çalışmayı EDIT aşamasında planla. Gerçek runtime CSG yalnız istenen kullanımın parçasıysa eklenir.
2. Kaynaklar senin oluşturduğun geçici/staging parçalarsa kayıtlarını tut. Kullanıcıya ait ilgisiz parçaları işlem sonunda silme.
3. Kesiciyi yüzeye tam coplanar bırakmak yerine kontrollü biçimde geçir. Aşırı ince/sliver geometriyi azalt.
4. `pcall` ile çağır; hata, boş çıktı veya beklenmeyen tipte **kaynakları koru**.
5. Bütün sonuç listesini doğrula. Sonucun konumunu, pivotunu ve koordinat ilişkisini kontrol et; körlemesine her parçaya kaynak CFrame'ini kopyalama.
6. Görünüm/physics/isim/attribute/parent kararlarını açıkça uygula.
7. Rig/attachment/constraint bağlantılarını yeniden kur veya ilgili koruma API'sini dokümana göre kullan. Basit sonuç kopyalama bunları otomatik garanti etmez.
8. Yeni sonuç bütün olarak hazır olduktan sonra kaynakları isteğe bağlı kaldır; kesicileri temizle veya kaynak arşivinde sakla.
9. Deliği gerçek avatar/raycast/çarpışma ile test et. İç duvar kalınlığına ve ters yüzlere de bak.

## 5. Rig ve gradient ile sınırlar
- Farklı kemiklerdeki iki parçayı bir union'a çevirirsen ayrı hareket etme yeteneğini kaybedersin. Önce rig sınırlarına göre böl.
- Aynı taşıyıcıya bağlı dekorları birleştirmek daha makuldür; yine materyal, Texture ve çarpışma davranışını kontrol et.
- Renkli bantları union etmek gradient yapısını, yüzleri veya düzenlenebilirliği değiştirebilir. Kaynak bantlarını yedekle.
- PartOperation ve MeshPart çıktılarını aynı özellik setine sahip sanma. Örneğin tipe özel property'leri önce `IsA` ile kontrol et.

## 6. Kod örneği ve doğrulama
`tools/GuvenliCSG.luau`:
- Primitive statik parçalar için GeometryService çağrısını sarar.
- Sonuç dizisini doğrular; başarıdan önce kaynak silmez.
- Varsayılan olarak kaynakları **hiç silmez**; `DeleteSources=true` yalnız çağıranın sahip olduğu geçici kaynaklarda kullanılmalıdır.
- Kaynaklar varsayılan olarak Workspace'te görünür kalırsa orijinal duvar yeni deliği kapalı gösterebilir. Sonuç doğrulandıktan sonra kaynakları bir arşiv klasörüne taşı veya yalnız sahip olduğun geçici kaynakları açık tercih ile temizle.
- Bağlantı taşıyan rig parçalarında otomatik işlem yapmayı reddeder; bu örnek bir rig retarget aracı değildir.
- Kaynakların yerel konumları, texture/attachment'ları veya tüm stil farklarının çıktıya aktarılacağını garanti etmez.

Örnek helper'ın Luau sözdizimi kontrolü yapılabilir; bu Roblox CSG çalıştırma testi değildir. Studio sürümü, yetki/capability ve Beta ayarları hedef ortamda denenmelidir.
