> Aşırı detay + optimizasyon önemsiz talebinde `kalite_onceligi_ve_detay_modu.md` önceliklidir. Örtük 950 Part sınırı yoktur. Aşağıdaki maliyet azaltmaları görünür detaydan izinsiz vazgeçme gerekçesi değildir. Seri01 sayımları tarihsel başarısız örneğin metrikleridir, kalite sertifikası değil.

# Optimizasyon: kaliteyi koruyarak maliyeti azalt

## 1. Maliyet vektörü
Yalnız Part sayısını değil, şunları raporla:
- Görünür geometri + görünmez root/rig/collider BasePart'ları.
- Texture/Decal sayısı ve gerçekten görünen yüz oranı.
- Weld, Motor6D, rig zinciri uzunluğu ve aktif Animator sayısı.
- Kaynak Keyframe/Pose sayısı ve klon başına tekrar taşınması.
- CSG sonucu geometrinin render/çarpışma karmaşıklığı.
- Aktif emitter/Beam/Trail, particle Rate ve lifetime; yaklaşık steady-state particle adedi `Rate × ortalama Lifetime`.
- Ekran kaplayan saydam yüzeyler ve overdraw; cam/yelken/efekt üst üste binmesi.
- Işıklar, gölgeli ışıklar, büyük gölge atan yüzeyler.
- Script döngüleri, frekansları ve oyuncu × model tarama maliyeti.
- Yükleme/streaming, harici asset erişimi ve ilk kurulum süresi.

Bunlar aynı birimde değildir; tek bir toplam sayıyla bütün performans açıklanamaz.

## 2. Bütçeyi varsayımlara bağla
Tek bir yakın plan boss ile aynı ekranda 100 küçük yaratık farklıdır. Hedef cihaz ve görünür yoğunluk bilinmiyorsa High/Medium seçenekleri ve test planı ver; tahmini bütçeyi garanti diye sunma.

Part limitinin olmaması, ölçmeden sınırsız detay eklemek anlamına gelmez. Gerektiğinde daha fazla parça kullan; nedenini ve etkisini göster. 100.000 görünmeyen vida yüksek kalite kanıtı değildir.

## 3. İyi maliyet azaltma sırası
1. Gizli veya kopya yüzey/Texture'ları kaldır.
2. Çok küçük detayların bant sayısını azalt.
3. Uzun düz kesitlerde gereksiz loft istasyonlarını kaldır.
4. Kanopi/yelken gibi saydam yüzeylerde yeterli en düşük faset sayısını dene.
5. Önce mikro detayları azalt; ana silüeti ve imza özellikleri koru.
6. Gereksiz çarpışma/touch/query'yi dekorlarda kapat; gereken yere anlamlı collider/query hacmi koy.
7. Rig taşıyıcılarını minimum gerekli artikülasyonda tut; her pul için motor açma.
8. Offline bake + Animator ile her frame Luau geometri taşımasını önle.
9. Efektleri mesafe/klip/kaliteye göre kapat. VFX'i kapatmak kaynak geometry belleğini azaltmaz.
10. Üretim klonlarından gereksiz editör kaynaklarını çıkar; yedek ve yayınlanmış klip sözleşmesini koru.

## 4. High / Medium / uzak LOD ayrımı
- **High/Medium kurulum varyantı:** farklı geometri/texture bütçesiyle baştan üretilir.
- **Animasyon/VFX mesafe kontrolü:** uzakta oynatma ve emisyonu durdurur.
- **Geometrik LOD:** gerçekten farklı mesh/parça temsiline geçer.
- **Streaming/bölgesel yükleme:** istemcide mevcut olan içeriği yönetir.

Birini diğerinin adıyla pazarlama. Sunucuda “herhangi bir oyuncu yakında mı?” kontrolü oyuncu başına render LOD değildir. Çok sayıda oyuncu modeli farklı yerlerden görünür tutabilir.

## 5. Yeni çalışmalardan ölçümler — yalnız bağlam
|Çalışma|Sayısal üretim sonucu|Ders|
|---|---|---|
|Lobi + ilk gemi|9.772 BasePart, sentetik geçerli URI ile 16.767 Texture|Sahne kapsamı genişlediğinde yüz texture'ları hızla artar|
|Tam iç mekân gemisi|21.553 BasePart, 35.149 Texture, 13 ışık|Hero detay yüksek olabilir; düşük cihaz başarısı ölçülmeden söylenemez|
|10 asset High|Toplam 2.811 BasePart, 2.204 Texture|Rig/topoloji ve odak detaylarıyla daha az parçada tür kimliği kurulabilir|
|10 asset Medium|Toplam 2.201 BasePart, 524 Texture|Texture yüz seçimi önemli tasarruf sağlar; Medium rig değişmek zorunda değildir|

Bu rakamlar farklı ölçek ve amaçtaki işleri doğrudan kalite sıralamasına sokmaz. Test doubles sayımlarıdır, FPS/bellek ölçümü değildir. Harici image çözülemezse texture sayıları farklılaşır. Ayrıntı: `references/seri01_sayisal_manifest.json`.

## 6. Yayınlanmış animasyon için kaynak ayırma
Seri01'de 31 klipte 19.568 Pose üretildi. Bu veriyi her üretim klonunda taşımak gereksiz olabilir.

Düzen:
- Geliştirici sürümü: rig + AnimSaves + ClipSpecs + test altyapısı.
- Üretim sürümü: rig + küçük ClipSpecs + geçerli animasyon ID'leri + uygun runtime.
- Kaynaklar ayrı yedekte.

Runtime hâlâ `AnimSaves` bekliyorsa klasörü silme. Önce metadata üzerinden ad/loop/priority ve ID ile çalışan akışı kur. Animasyon erişim haklarını kontrol et. Paket örneği `examples/yeni_calismalar/Production_Hazirla.luau` ID biçimi kontrol eder, sahiplik veya gerçek oynatmayı doğrulamaz.

## 7. Kabul edilebilir performans iddiası
İyi: “High sayısal üretimde 701 BasePart; Medium 563. Hedef cihaz profiler testi bekliyor.”

Kötü: “Az Part olduğu için her telefonda 60 FPS.”

İyi: “Uzakta track/emitter duruyor; geometri streaming sistemi ayrıca gerekli.”

Kötü: “LOD tamamlandı” deyip yalnız ParticleEmitter.Enabled kapatmak.

## 8. Ölçüm planı
Tek modelden başlayıp görünür adet, oyuncu ve cihazı ayrı değiştir. FPS yanında script/physics/render maliyetini ayır. Bir darboğazı düzeltince tekrar ölç; tek örnekteki sonucu tüm projelere genelleme.
