# Son geçerli sözleşme — 3.1.0

## Kapsam
Bu tur yalnız skill güncellemesidir. Santral dosyaları, kurulumları veya önceki model teslimleri değiştirilmeyecek. Kullanıcı üç Studio görüntüsünü hata kanıtı olarak gönderdi; yeni hedef model/referans sanılmayacak.

## Kullanıcının doğruladığı redler
Yarıda kesilen/taşan garip doku; her Part'a uygulanmayan doku; gerçek dönüşü oluşturulmamış borular; iç içe parçalar; kötü/uydurulmuş yazı; hazır havuzun istenen VFX olarak kullanılmaması. Bu kusurlar tekrar eden kabul engelleridir. Sadece ID listesi veya Texture bağlamak anlamlı VFX teslimi değildir.

## Daha önce öğrenilip korunacaklar
- Kare/küp/dikdörtgen işçilik; silindirik ana gövde ve tek dev düz kutu yok. Bütün bölgeler aynı kalite seviyesinde. Gizli Part/kod sınırı yok.
- Referansların tamamı tek sahneye ait olabilir; kamera açılarını ayrı haritalar sanma. Gizli bölgeleri yorum olarak belirt; ölçüsüz birebirlik iddia etme.
- Detay ve ışık ayrı kabul kapılarıdır. Kamera içi gerçek oyuncu açısı, yakın birleşimler ve gece/gündüz gerekçesi gerekir. Global Lighting değişecekse bildir/önceki değerleri sakla; asset kurulumunda kendiliğinden sahne ışığını değiştirme.
- 945466696 için HTTP metaverisi AssetTypeId 9 Place sonucunu verdi. Resim değildir. Kullanıcı bunun ardından native studs'u kabul etti; bu son tercih eski 3.0 image-ID talimatını geçersiz kılar.
- Gerçek düzenlenebilir keyframe animasyonları; kullanıcı ejderha.txt animasyonlarını ejderha2.txt'ye tercih ediyor. Runtime-only hareket, anlamsız klip adları ve T-pose başlangıç kabul değil.
- Onizleme.png, kaynaklar, metrics, README ve dürüst test raporu model tesliminde zorunlu. Yazılım render'ı Studio kanıtı değil; VFX'i göstermeyen render VFX onayı değildir. Yalnız skill paketinde model önizlemesi gerekmez.

## Güncelleme döngüsü
Yeni geri bildirim → olduğu gibi kaynak kaydı → doğrulanmış gözlem / teknik hipotez / ölçülmüş neden ayrımı → ilgili rehber ve tercihler → kabul şablonu → sürüm notu → bütünlük kontrolü → kullanıcının istediği arşiv adıyla teslim. Önceki kuralları yalnız tekrarlamak öğrenme değildir; başarısızlığa izin veren aktif çelişkiler kaldırılır veya tarihsel olarak işaretlenir.
