# Silüet, anatomi ve anlamlı detay kapıları

## KAPI 1 — Referansı parçalara değil ilişkilere ayır
Ön/arka/yan referansta ana kütleler, oranlar, negatif boşluklar, eklem merkezleri, destek noktaları ve uç şekillerini çıkar. Baş/gövde, boyun/baş, omuz/kalça, bacak yüksekliği, kanat açıklığı gibi ilişkileri kaydet. Referans belirsizse görünmeyen anatomiyi tahmin diye etiketle. Uzuv/kuyruk adedini sessizce kanondan veya tahminden seçme; görseli ve kullanıcı hedefini karşılaştır, önemli belirsizlikte sor.

## KAPI 2 — Siyah silüet
Texture, studs, plaka, boynuz mikro detay ve VFX olmadan ön/yan/arka/üç çeyrek görünüşte okunurluk. Ana hacimlerden şu ilişkiler açık olmalı:
- Omuz → göğüs → karın → kalça, ayrı fakat devamlı.
- Boyun kökü → alt/orta/üst boyun → kafatası; kesit, eğri ve açı değişimi.
- Kalça → uyluk → diz → baldır → bilek → ayak; ağırlık taşıma ve kas hacmi.
- Kanat kökü → üst kol → dirsek → ön kol/bilek → parmaklar → zar sınırı.
- Kuyruk kökü → ağırlık taşıyan başlangıç → incelme → uç/club.

Tek büyük kutu, uzun sabit enli dikdörtgen boyun veya çubuk bacak varsa KAPI 2 geçmez. Cylinder yasak diye bu hatalara yönelme; köşeli çoklu hacimlerle yine anatomik geçiş kur.

## KAPI 3 — Bağlantı ve negatif boşluk
Her anatomik zincir için soket pozisyonu kadar eklem çevresindeki hacmi, örtüşmeyi, koltuk altı/kanat boşluğunu ve geçiş yüzeyini kontrol et. Bağlantı noktasını bir kutuyla kapatmak tek başına tamamlanmış çözüm değildir. Ön/yan/alt görünüş ve hareket uç anlarında incele.

## KAPI 4 — Detayı üç ölçeğe ayır
- Büyük: değişken hacimler, kabuk kalınlığı, omuz/göğüs ve bacak kasları.
- Orta: farklı plaka aileleri, kaş/yanak/çene, tendon/eklem, kanat zar sınırı ve taşıyıcıları.
- Küçük: pul kenarı, çentik, yüzey motifleri, studs.
Büyük ve orta ölçek yoksa küçük detay çoğaltma. Her bölgede aynı plaka boyutu/sıklığı kullanma. Boyun altı plakaları ile sırt pulları ve yüz pulları yön, büyüklük ve ritimde farklı olmalı. Rastgele varyasyon değil anatomik akış belirlesin.

## KAPI 5 — Kanat anatomisi
Zarı yalnız dar üçgen fan şeritleriyle doldurma. Taşıyıcı kemikler, eklem açıları ve parmak uzunlukları önce kurulur. Zar köke bağlanır, parmaklar arasında gergin ve kontrollü sarkık sınırlar taşır; kalınlık/ön-arka yüz tutarlı olmalı. Üçgen tessellation görünür bir yelpaze desenine dönüşmemeli. Rig'de gerçekten bükülebilecek panel/skin yöntemi seç; sert fanı döndürmek ile gerçek parmak/zar bükülmesini aynı şey diye sunma.

## KAPI 6 — Aşırı detay kabulü
Her görünür bölge tamamlanır, fakat her santimetre eşit gürültüye boğulmaz. Yüz, ayak, eklem, kanat kökü ve alt/arka yüzler gerçek işçilik alır. Part sayısını artırmak veya kaplama sıklığına yüklenmek tek başına kalite artışı değildir.

## KAPI 7 — Görsel kanıt
Ön/arka/yan/üst/alt ve odak yakın görünümler; texturesız, doğru studs ile ve VFX kapalı karşılaştırma. Silüet → anatomi → birleşim → detay → texture → animasyon → VFX sırası korunur. Gerçek Studio testi yoksa “geçti” değil BEKLİYOR yaz. Sayısal testleri bu kapılara vekil yapma.
