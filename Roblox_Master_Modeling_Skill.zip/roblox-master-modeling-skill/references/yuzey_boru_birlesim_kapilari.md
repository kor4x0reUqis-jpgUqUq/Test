# Yüzey, tesisat, birleşim ve metin kabulü

## 1 — Önce yüzey kuponu, sonra dağıtım
En küçük cıvata, dar profil, geniş panel, kısa flanş, eğimli dirsek ve pencere için gerçek seçilen yöntemle kupon oluştur. Native Studs/Weld ve image Texture aynı sistem değildir. Native yüzeylerde Texture.Offset/StudsPerTile kontrolü varmış gibi kod yazma; motif sığmıyorsa yüz ölçüsü/modül/uygun onaylı yöntem değişmelidir. Image Texture için görüntü türü, kaynak tile başına motif sayısı, StudsPerTileU/V, OffsetU/V ve yüz yerel ekseni ölçülür. Atlas kırpığı, yarım büyük X, uzama ve rastgele kesilmiş kenar teslim engelidir.

Her görünür Part: kimlik → yöntem → görünür yüzler → fiziksel motif ölçeği → kupon → istisna onayı. İstatistikte kapsanan/kapsanmayan Part ve yüzler raporlanır. Görünmez Root/ankrajı yüzey eksiği sayma; fakat görünür korkuluk, flanş, tel, cıvata ve lensi izinsiz hariç tutma. Stil için uygun doku yöntemi henüz yoksa kullanıcıdan istisna/onay al; rastgele görüntü ID'si uydurma.

## 2 — Soket tabanlı gerçek boru rotası
Her rota port giriş/çıkış CFrame'i, kesit, uç normal yönü, merkez çizgisi ve destek planıyla tanımlanır. Ardışık düğümleri beam ile bağlamak tek başına dirsek değildir. Kare kesitte 90 derece dönüş: doğru kesilmiş gönye birleşimi, kapalı köşeli dirsek modülü veya izinli kontrollü CSG. İç/dış köşe geometrisi okunmalı; açık yarık, uç kapağının yolu tıkaması ve çapraz giren flanş olmamalı. Flanş dirseğin rastgele üstüne değil düz eksene dik oturur; cıvatalar merkez ve yön olarak karşılıklı eşleşir.

Port mesafesi/açı toleransları model ölçeği ve kesitten türetilir ve raporlanır. Her ağda uçların makine portuna gerçekten bağlandığını ve havada bitmediğini kontrol et. 90, 180, düşey-yatay geçiş, dar iki dirsek ve T birleşim kuponları; açıkta kalan uçlar ancak tasarımda bilerek ve belgeli ise kabul.

## 3 — Çakışmaların sınıflandırılması
AABB yalnız geniş fazdır. Döndürülmüş parça için OBB/SAT veya engine kesişim sorgusu ve yüz/katı kontrolü gerekir. Her tespit: temas, kasıtlı yapısal gömme, flanş oturması, istenmeyen penetrasyon, çift yüz/coplanan yüz, yinelenen geometri, yüzeyi örten ayrıntı olarak sınıflanır. İzinli birleşimde iki öğe kimliği, sebep ve izinli derinlik kaydı gerekir. Tüm kesişimleri görmezden gelen blanket whitelist yok. Paylaşılan boru/bara segmentini üç kez üst üste üretme; tek ağ parçası üret. İstemsiz çakışma sayısı finalde sıfır olmalıdır; yalnız sayı değil kritik yakın resim de gerekir.

## 4 — Metin
Kullanıcı istemediyse marka/seri numarası/süs sloganı ekleme. İstenirse doğru içerik, okunur font, panel sınırı ve güvenli kenar payı, doğru Face/UV yönü ve okunabilir kamera mesafesi. Tabelayı pencere/kapı üstüne gömme; SurfaceGui'nin ışık ve depth davranışını test et. Yazı panelden taşamaz, tek satır için sıkışık ölçüsüz TextScaled çözümüyle yetinilmez.

## 5 — Kabul kanıtı
Oyuncu yüksekliğinden genel görünüş + her kritik boru dirseği/flanş/trafo/pencere/kepenk/tabela yakını + üst/arka. Geometri VFX kapalı incelenir, sonra gerçek VFX açık. Motor testi yoksa yapılmadı yaz; geometri render'ıyla native yüzey/VFX onayını taklit etme. Bu görevde mevcut model düzeltilmez.
