> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

# Kullanıcı önceliği: aşırı detay ile optimizasyonu karıştırma

## Ayrı kararlar
`DetailMode` ve `PerformancePriority` aynı ayar değildir.

|Kullanıcı isteği|Doğru davranış|Yanlış davranış|
|---|---|---|
|Yüksek detay + optimize|Önce eksiksiz bir High tasarım, sonra silüet/işçilik kaybını ölçerek maliyet azaltma|Baştan blockout seviyesine indirip “optimize” deme|
|Aşırı detay, optimizasyon önemli değil|Gerçekten Hero/Ultra işçilik: bütün görünür alanlar, karmaşık bağlantılar, yüz/uzuv/alt/arka detayları, gerektiğinde iç hacim ve çok daha zengin eylemler|Örtük 950/700/200 Part hedefini korumak, yarısında detay düşürmek|
|Sadece sade/stylized|İstenen sadelikte tutarlı bitmişlik|İstenmeden çok karmaşık yapı veya gameplay|
|Çok model + yüksek detay|Kaliteyi koruyacak daha küçük teslim partisi, ilerleme ve her model için ayrı kabul|İlk birkaç modele emek verip kalanları aynı kutu gövdeyle doldurmak|

## Hero / Ultra sözleşmesi
Kullanıcı “optimize dert değil”, “parça/kod sınırı yok”, “aşırı detay” dediğinde:
- Ana teslim daha düşük performans varyantı değil, yüksek işçilik sürümüdür.
- Yüz, kafa arka tarafı, karın/alt yüz, el/pati/pençe, eklem, kuyruk ucu, kanat altı ve mekanik bağlantıların detayı gerçekten tamamlanır.
- Bölge başına 1–2 detay koyup bırakma; yapısal mantık, hacim geçişi ve odak işçiliği artırılır.
- İki bant, sekiz çevre segmenti veya birkaç dikdörtgen tüy “her durumda yeterli” değildir. Sayı görsel sonuca göre değişir.
- Sabit düşük part limiti bu modda engel olamaz. Guardrail varsa uyarı/bilgilendirme veya bilinçli artırılabilir değer olmalı; görünür kaliteyi sessizce kesemez.
- Kaynak/yanıt sınırı varsa bunu açık söyle, partiyi küçült veya aşamalı teslim et. “Tamamlandı” deyip taslağı final diye verme.
- Gerekirse optimizasyon varyantı ayrıca sunulur; kullanıcının Ultra sürümünün yerine geçirilmez.

Bu, sonsuz tekrar döngüsü, anlamsız gizli parça veya kötü matematik talimatı değildir. Z-fighting, kopya yüzey, bellek sızıntısı ve bozuk rig her modda hatadır. Çalışma kararlılığı korunur; sadece performans gerekçesiyle görünür işçilikten izinsiz vazgeçilmez.

## Bölgesel yoğunluk ≠ yarım model
Odak alanı daha zengin olabilir. Buna karşılık arka başı tek kutu, kanat altını işlenmemiş levha, bacakları iki çubuk bırakmak odak hiyerarşisi değildir. Daha sakin alan da doğru hacim, kenar, birleşim, materyal ve tamamlanmış yüzey taşır.

## Daha fazla detayın somut anlamı
- **Kafa:** farklı kafatası hacimleri, orbital derinlik, kaş/yüz düzlemleri, yanak, burun/gaga kökü, ağız/çene kalınlığı ve arka geçiş.
- **Gövde:** omuz/göğüs/karın/kalça ayrımı; bloklar arası doğal ama kare mimari; hem üst hem alt geçiş.
- **Uzuv:** taşıyan hacim, eklem, tendon/zırh/kürk geçişi, el/pati/pençe bağlantıları; tekrar eden hazır çubuklar değil.
- **Kanat:** kök, taşıyıcı segment, değişen tüy/panel uzunluğu, ön/arka kenar, alt yüz, katlanma birleşimleri.
- **Mekanik:** plaka kalınlığı, kapak, vida/perçin gerektiği yerde, erişim açıklığı, boru/kablo/şasi bağlantısı, teker katmanları.
- **İç hacim:** sadece dış kabuk değil, görünen ağız/giriş/egzoz içinde gerçek geçiş ve iç yüzey.

## Kaliteyi sayıyla savunma
Part sayısı bir bütçe ölçümüdür; bitmişlik ve ustalık puanı değildir. Düşük sayı kendi başına başarı, yüksek sayı kendi başına ayrıntı değildir. Yüksek detay talebinin yerine getirildiği bölge matrisi, çok açılı görünüş ve istenen detayların gerçek geometride bulunmasıyla gösterilir.
