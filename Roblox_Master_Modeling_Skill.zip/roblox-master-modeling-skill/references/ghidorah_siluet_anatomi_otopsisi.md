# Ghidorah geri bildirimi: çok parça, yanlış biçim

Kullanıcı Studio görüntülerinde silüet, anatomi, konum, yetersiz/yanlış detay ve studs sorunlarını açıkça işaretledi. Referansın başarısı görüntülerdeki tekrar sayısıyla yakalanmadı. Bu görüntüler yeni bir başarılı sonuç değil, negatif kanıttır.

## Görselde görülen problemler
1. **Kutusal ana kütle:** geniş yüzeyli dikdörtgen göğüs, düz kenarlar ve sert üst bitiş canlıdaki göğüs/omuz/karın/kalça geçişlerini vermiyor. Gövdeye plaka döşemek anatomi değildir.
2. **Boyunlar şerit/direk gibi:** uzun, benzer genişlikli düz parçalara eklenmiş kaburgalar organik S eğrisi, kas hacmi ve kafaya geçişin yerine geçmiş. Ayrı baş karakterleri yalnız konum farkıyla çözülemez.
3. **Baş ve bacak hiyerarşisi zayıf:** boynuzlar baskınken kafatası/yüz düzlemleri ve taşıyıcı bacak kütleleri yeterince güçlü okunmuyor. Düz ayak bileği/alt bacakları uzun çubuk gibi bırakmak sağlam duruş değildir.
4. **Kanat fanı:** aynı merkezden çıkan yoğun ince üçgen şeritler zar anatomisi yerine yelpaze hissi üretiyor. Kanat kolu, dirsek, bilek, parmak eklemleri, zar gerginliği ve gövde bağlantısı birlikte tasarlanmamış.
5. **Detay dağılımı:** her sırada aynı plaka ve çıkıntı, yapısal işçilik yerine mekanik tekrar yaratıyor. Bazı bölgelerde görsel gürültü varken başka bölgeler büyük düz yüzey kalıyor.
6. **Studs baskınlığı:** yakın görünüşte kare/desenli izler yüzeyi kaplıyor, katmanların ölçeğini ve anatomiyi bastırıyor. Texture görünmesi doğru studs uygulandığını kanıtlamaz.
7. **Bağlantı/yerleşim:** boyun kökleri ve arka/kanat geçişleri ayrı eklenmiş parça hissi veriyor. Sayısal eklem uzunluğu testleri bu görsel devamlılığı ölçmedi.

## Kaynakla doğrulanan yanlış kararlar
- Torso, satır bazlı dikdörtgen core'lar ve tekrarlanan scale/lip parçalarıyla kurulmuş; göğüs katmanları ana hacmi yeterince değiştirmiyor.
- NeckSquareCore ve tekrarlanan yan/ön plakalar, değişken anatomik kesitler yerine aynı üretim dilini sürdürüyor.
- MembranePleat üretimi her bay'i beşer dar üçgene ayırıyor; sırf bölmek daha iyi zar şekli yaratmadı.
- Installer neredeyse bütün uygun parçalara altı yüz üzerinden aynı tile=.62 ve transparency=.28 değerlerini uyguluyor. Bölge, eğimli yüz, atlas/şeffaflık ve fiziksel motif ölçeği ayrıca doğrulanmıyor.
- Eski modelden Texture/Decal içeriği bulmak, bunun doğru studs deseni olduğunu teyit etmiyor. Yeni kullanıcı ID'si ayrıca değişti; eski assetin çıktısını yeni tercihin kanıtı yapma.
- 6.130 parça, 35.502 texture yüzü, 39.600 Pose gibi metrikler sonuç kalitesinin kanıtı değildi.

Görseller tek başına kesin bir CFrame eksen hatasını veya UV formül hatasını ispatlamaz. “Kesin U/V ters” gibi teşhis uydurma; yanlış görüntüyü kaydet, gerçek texture içeriği ve yüz eşlemesini test et.

## Zorunlu ders
Silüet/anatomi onaylanmadan seri detay çoğaltma yok. “Kare stil” düz büyük kutu demek değildir; yüzeyden önce hacim bölünmesi, kama/katman geçişleri, negatif boşluk ve ağırlık gerekir. Eski Ghidorah üretim mantığı başarı şablonu olarak kullanılamaz. Kanıtlar `examples/son_olumsuz_kanit/` altındadır. Bu revizyonda model kodu değiştirilmedi.
