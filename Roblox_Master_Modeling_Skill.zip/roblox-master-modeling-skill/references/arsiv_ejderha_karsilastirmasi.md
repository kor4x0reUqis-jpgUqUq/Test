# Roblox prosedürel modelleme bilgi tabanı — 01

## Kaynak ve doğrulama sınırı
Kaynaklar: uploads/ejderha.txt (RigVersion Caldera_2.0_Rectangular_Texture), uploads/ejderha2.txt (Caldera_2.2_JointPivot_LoopFixed), uploads/trex.txt, uploads/assestvfxx.txt.
Bu kayıt statik kod incelemesidir; Studio çalıştırması, render, asset erişimi ve performans testi yapılmadı. Görsel sonuçla ilgili çıkarımlar test edilmelidir. Dosya adları esas alınır; iki ejderha dosyasının da başlığında V2 bulunur.

## Kullanıcı yönlendirmesi
- ejderha.txt animasyonları, ejderha2.txt animasyonlarından daha başarılı: yeni tasarımlarda ana hareket referansı ilk dosya.
- Studs texture ve gradient uygulamaları iki dosya karşılaştırılarak kullanılacak.
- Verilen VFX assetleri sonraki tasarımlarda uygun yerlerde kullanılacak; her modele bütün efektler doldurulmayacak.
- Amaç kod veya koordinat kopyalamak değil, tasarım mantığını yeni forma uyarlamak.
- Kullanıcı yeni modeli daha sonra açıklayacak; henüz yeni model üretilmeyecek.

## 1. Form ve geometri ilkeleri
- Önce büyük kütle/silüet; sonra zırh/pul ritmi; en son küçük vurgu. Detay yoğunluğu tek başına kalite değildir.
- Ejderha shell(): birkaç iç içe dikdörtgen çekirdek kesiti doldurur. Uzunlamasına halkalar ve açısal sütunlar eliptik çevreye plakalar yerleştirir. sin/cos ile konum ve normal, surfaceCF ile yönelim hesaplanır.
- surfaceCF(): normali yerel Y yapar; uzunlamasına yönü normal düzlemine izdüşürür; çapraz çarpımla baz kurar. Paralellik için fallback gerekir.
- along()/beam(): iki uç arasında lookAt ile kiriş; uzunluğu kontrollü overlap ile büyütür. Amaç bağlantı boşluklarını azaltmaktır; aşırı overlap hareket sırasında çakışır.
- plate(): koyu ve biraz büyük alt sınır + renkli üst plaka. Geometrik gölge ve kenar kontrastı, ışığa tamamen bağımlı olmadan katmanları ayırır.
- Değişen plaka açıları, dönüşümlü palet ve kontrollü sıra ritmi tekdüzeliği azaltır. Tam rastgelelik yerine anatomi yönünü izleyen varyasyon.
- horn(): nokta zinciri boyunca küçük blok kesitleriyle daralma; kök/orta/uç renkleri formu okutur.
- Üçgen kanat zarı iki WedgePart ile kurulur. En uzun kenara göre yeniden sıralama, çapraz çarpım ve izdüşümle baz/yükseklik hesaplanır. Dejenere üçgen atlanmalıdır.
- Zarın arkasındaki merkezden 1.045 kat büyütülmüş koyu üçgen, kenar şeridi sağlar.
- Eklem kapakları küre yerine üst üste dikdörtgenlerdir. Proksimal kemiğe bağlanırlar; tüm hareket aralığında boşluk/çakışma kontrolü gerekir.

## 2. Studs texture karşılaştırması
### ejderha.txt
texturePart(), yaklaşık 530–556: 9454666962 doğrudan Texture.Texture URI'sine çevrilir. Model asset ID'si ise gerçek image kaynağı yerine geçmeyebilir. Yükleme başarısı varsayılmamalı.
- Tile: 0.72 * Scale; ana saydamlık 0.16, zar 0.58.
- Texture.Color3 = Part.Color ile yüzey rengine uyum.
- Bloklarda varsayılan altı yüz; wedge için Left/Right.
- Gradient bantları boyunca offsetZ ile doku fazını devam ettirme niyeti var.
### ejderha2.txt
resolveStudImage(), yaklaşık 223–323: assetten Texture/Decal/ImageLabel URI'si çıkarır; önceki model attribute'undan cache, manuel override ve farklı loader denemeleri vardır. Kod kaynaklarını siler; imported script require etmez. Bu önlem mutlak güvenlik garantisi olarak yorumlanmamalı.
studTexture(), yaklaşık 616–646:
- Model ID/image ID ayrımı açık; görüntü çözülemezse geometri üretilir fakat studs görünmez.
- Tile yine 0.72 * Scale; ana saydamlık 0.30, zar 0.62. İlk dosyanın dokusu parametre düzeyinde daha baskındır.
- Yüz alanı/eşik kontrolü: küçük yüzlere gereksiz texture eklenmez.
- U/V fazı ayrı ayarlanır. Gradientte yalnız dışa açık bitiş yüzleri eklenir.
### Yeni tasarıma aktarım
2D texture fiziksel kabartı/silüet oluşturmaz. 3D stud ile aynı sonuç değildir. Tekrarlama boyutu model ölçeğiyle birlikte büyütülürse göreli desen yoğunluğu korunur. Bölünmüş yüzlerde yön/işaret/faz sürekliliği Studio'da doğrulanmalı; sadece offset bulunması kesintisiz sonuç garantisi değildir.

## 3. Gradient karşılaştırması
- Her iki ejderhada da UIGradient veya özel shader yerine gerçek renkli Part bantları kullanılır. Part ve weld maliyetini artırır.
- ejderha.txt gradientBrick(), yaklaşık 575–608: Z yönünde bölme; uç renkleri smooth((i-1)/(n-1)) ile tam örnekler; her parçaya 0.003 ilave uzunluk. Küçük plakalar da width >= 0.65 ve length >= 0.62 eşiklerinden itibaren gradient alır.
- ejderha2.txt gradientBrick(), yaklaşık 682–755: Y veya Z ekseni; bant merkezinde u=(i-0.5)/bands ile örnekleme. Bu yüzden uç renkleri tam almaz. Dış yüz seçimi ve yüz yönüne göre U/V offset desteği vardır. plate gradient eşiği width >= 0.9, length >= 1.2 ve burada üç bant kullanılır.
- İkinci dosya membranePanel(), yaklaşık 1917–1965: üçgeni a noktasından b/c kenarlarına doğru şeritlere ayırır, her şeridi üçgenlerle kaplar; Wine'dan panel rengine geçiş. İlk dosyada membranePanel tek renkli ana üçgendir.
- Kalite ilkesi: ton yönü formu ve tasarım amacını desteklemeli; her küçük parçaya gradient görsel gürültü üretir. Geometrik yüzey gradienti, parçalar arası palet değişimi ve particle ColorSequence farklı mekanizmalardır.

## 4. Renk ve materyal
- Ejderhada koyu Wine/Obsidian altlık, Crimson/Scarlet ana zırh, açık Horn/Ivory diş-boynuz, Amber/Hot/Fire odakları.
- T-Rex'te koyu yeşil sırt, açık krem karın, amber göz, kemik diş ve yerel yara rengi; tabandaki kaya/yosun/fosil anlatısal bağlam sağlar.
- Ana materyal Plastic. Ejderhada göz ve ısı/ateş detayları gibi seçili bölgelerde Neon. Karmaşık PBR/SurfaceAppearance sistemi bu örneklerin temel kalite kaynağı değildir.
- Neon kendi başına ortamı aydınlatmaz; gerçek aydınlatma ayrı Light nesneleriyle ele alınır. Aşırı parlama detayları silebilir.

## 5. Animasyon: ejderha.txt ana referans
animationPose(), yaklaşık 2243–2675:
- Gövde FK; hedef ayak noktaları için analitik iki segmentli 3B IK.
- Duruş/taşıma ve havadan geri alma evreleri duty oranıyla ayrılır; smooth ile ileri-geri, sin² ile ayak kaldırma; pati/parmak pitch desteği.
- Omuz/kalça konumu gövde pozundan hesaplanır. İki uzunluk ve kosinüs teoremiyle diz/dirsek bulunur; pole vektörü bükülme düzlemini belirler. Erişim clamp'i sayısal sorunları azaltır.
- Bu, basit sinüzoidal açı sürmeye göre ayak hedefi kontrolünü güçlendirir; fakat dünya uzayında gerçek ayak kilidi/root motion otomatik sağlanmaz.
- Kuyrukta faz gecikmesi ve uca artan genlik; boyun/kafa ve kanat omuz-dirsek-bilek/parmaklarda gecikmeli takip.
- Kükreme: hazırlık, gövde yükselişi, çene, sönümlenen titreşim ve toparlanma.
- Uçuş ve sinematikte yerdeki çözüm ile havada bacak katlama arasında karışım.
- Hareketler KeyframeSequence olarak bake edilir; runtime'da bütün detayların CFrame'ini her kare elle güncellemek yerine Animator kullanılır.

### ejderha2.txt farkı
- gait() yaklaşık 2313: doğrudan sinüsle eklem açıları; analitik ayak IK'si yok.
- wingFlap() yaklaşık 2303: dirsek 0.12, bilek 0.05 genlik oranıyla sınırlandırılmış. Zar ayrılmasını azaltmayı hedefler, fakat ilk sürümdeki artikülasyon çeşitliliğini azaltır.
- addBone(): görünmez taşıyıcı eklem pivotuna taşınmıştır; ilk dosyada rest merkez ile pivot ayrıdır, C1 telafisi vardır.
- İkinci sürümün döngüleri periyodik örnekleme ve son kareyi dahil etme üzerine kuruludur. İlk/son poz ve hızın gerçekten eşleşmesi ayrıca test edilmeli.
- Eski kliplerin korunması güzel bir iş akışı özelliğidir, ancak aynı kemik adları tek başına uyumluluk garantisi değildir. Rest/pivot, C0/C1 ve marker sözleşmesi değişmiş olabilir.
- İlk dosya Footstep/FlameOn/FlameOff/Wingbeat/Impact; ikinci Stomp/BreathOn/BreathOff/Flap/Gust kullanır. Aktarımda marker eşlemesi şarttır.

## 6. T-Rex'ten aktarılacaklar
- Büyük kafatası, çene/diş eti/dil, kaş, kapak ve pupil katmanları; kontrollü asimetri/yara; segmentli kuyruk ve çevresel taban, karakter ve ölçek okumasını güçlendirir.
- createBrick() hem SurfaceType.Studs hem ilave Cylinder Part studları kullanır. Bunlar texture değildir. Parça maliyeti nedeniyle yeni modellerde otomatik varsayılan yapılmamalı.
- Anchored parçalar, Heartbeat, elle FK ve BoneAttachments üzerinden her detayın CFrame güncellemesi: editör gösterimi yaklaşımı. Motor6D bulunması bunu standart Animator sistemiyle eşdeğer yapmaz.
- Pozlar arasında CFrame:Lerp; cubic/sine/back easing; nefes, göz kırpma, pupil kayması, çene/dil titreşimi, kuyruk takip hareketleri ayrı katmanlardır.
- Tepki etkisi için anticipation → güçlü eylem → recovery örüntüsü yararlı.
- print içindeki 60FPS ifadesi ölçülmüş/sabit FPS garantisi değildir; Heartbeat hızına ve maliyete bağlıdır.
- TrailJaw/TrailTail ve kısa ışık darbeleri hız/etki okumasını destekler. Sonsuz, her yerde etkin trail yerine olay bazlı seçim tercih edilir.

## 7. VFX tasarım mantığı ve katalog
vfx_katalogu.json kaynak listedeki kategorileri, tipleri ve URI'leri içerir: 389 kayıt, 263 benzersiz ID. Tekrarlar kategori bağlamını korumak için tutuldu. Görseller ve izinler doğrulanmadı. Kategori adı assetin birebir görünüm garantisi değildir. Custom setup/no external ID satırları yeniden üretilebilir bir efekt tarifi değildir.
- Ateş: parlak dar çekirdek + geniş dış alev + daha uzun ömürlü duman + küçük kıvılcımlar.
- Nefes yönü Attachment yerel ekseni ve EmissionDirection ile uyuşmalı.
- Sürekli emisyon Rate/Enabled; tek seferlik darbe Emit().
- ColorSequence / NumberSequence ile ömür boyunca renk, boyut ve saydamlık; NumberRange ile kontrollü çeşitlilik; Acceleration, Drag, SpreadAngle, Speed ile karakter.
- Ayak tozu ilgili ayağın temas anındaki marker'ına bağlanmalı. İlk sürüm Footstep marker value'sunda ayak kimliği taşıyor.
- Ölçek değişiminde yalnız Part değil, attachment konumu, particle boyutu, hız/ivme, gerekirse trail/light menzili de gözden geçirilmeli.
- Örnek referanslar: alev 6706234595 ve 296874871; kıvılcım 867619398 / 1463874772; duman 1084955012; darbe 7524756305. Bunlar mevcut kod/listede geçer; yüklenebilirlikleri test edilmedi.
- Performans: yaklaşık eşzamanlı particle sayısı Rate × ortalama Lifetime; ekran kaplayan saydam katmanlarda overdraw. Texture stud da sınırsız ve bedelsiz değildir.

## 8. Yeni model için uygulama/kabul kontrolü
1. Kullanıcının yeni model tarifini bekle; anatomi, silüet, palet ve kullanım amacına göre tasarla.
2. Parametrik geometri yardımcıları; ana formu detaydan ayır.
3. İkinci ejderhanın image çözümleme/yüz seçimi mantığı + forma uygun bant gradientleri.
4. İlk ejderhanın hedef tabanlı bacak hareketi, çok eklemli takip, hazırlık ve toparlanma yaklaşımı.
5. T-Rex'in yüz ifadeleri ve anlatısal küçük detaylarını ihtiyaç oldukça uyarla.
6. Katalogdan uygun VFX seç; marker/attachment sözleşmesini tek bir yerde tanımla.
7. Her dekor tek taşıyıcıya, her rig parçası tek sürücü motora bağlı olsun; dekor Massless ve çarpışmasız; yalnız gerekli kök anchored.
8. Pivot/rest/C0/C1 değişiminde eski animasyonu körlemesine taşıma; gerekiyorsa yeniden bake/retarget.
9. Döngü sınırı, ayak kayması, zar kopması, eklem boşluğu, gradient dikişi/z-fighting, doku ölçeği, okunurluk ve parçacık maliyetini Studio'da kontrol et.
10. Ölçülmeyen performansı, görülmeyen renderı ve yüklenmeyen asseti doğrulanmış diye sunma.
