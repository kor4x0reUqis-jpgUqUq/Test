> KULLANIM: Bu modülü yalnız güncel istekte ilgiliyse uygula. Örneklerdeki modele özgü ölçü/renk/klip/stil evrensel kural değildir. Araç açıklaması native doğrulama garantisi vermez. Üst sözleşme: `../FinalPRO.txt`.

# Kabul kapıları
1. **İstek:** kapsam, referans, ad/ikon/etiket, animasyon gerekliliği net.
2. **Geometri:** pozitif ölçü, sonlu değer, ortonormal eksen; siluet ve en-boy oranı ayrı kontrol.
3. **Tema:** renk dışında karakteristik yapısal fark; eksik bölge veya rastgele VFX yok.
4. **Kaynak:** asset ID rolü ve hak/izin durumu; yanlış ikon Particle diye bağlanmaz.
5. **Offline:** derleme, veri dönüşümü, test çıktısı ve gerçek geometri render'ı.
6. **Native:** kurulum, renk/ışık, Texture yüklenmesi, UI rasterizasyonu, rig/klip ve VFX.
7. **Performans:** hedef cihaz, yakın/uzak, tek model/tam sahne, CPU/GPU/bellek ayrı ölçüm.
8. **Teslim:** ZIP bütünlüğü, kaynaklar, açık sınırlamalar ve gerçek temizleme raporu.

Kapı 5'in geçmesi 6/7'yi geçirmez. Profesyonel/oyuna hazır/FPS garantisi iddiaları ölçüm ve kullanıcı kabulü olmadan yapılmaz.
