> KULLANIM: Bu modülü yalnız güncel istekte ilgiliyse uygula. Örneklerdeki modele özgü ölçü/renk/klip/stil evrensel kural değildir. Araç açıklaması native doğrulama garantisi vermez. Üst sözleşme: `../FinalPRO.txt`.

# Smooth ve GERÇEK düzenlenebilir keyframe animasyon
## Sözleşme
Kullanıcı animasyon istediğinde yalnız runtime CFrame/Tween döngüsü yeterli değildir. Gerçek KeyframeSequence / Keyframe / Pose hiyerarşisi ve Motor6D rig oluştur. Klipler anlamlı isimli, kaydedilebilir ve Studio Animation/Clip Editor'a aktarılabilir olmalı. Motor içi editör açılıp test edilmediyse “editörde çalışıyor” deme.

## Rig
- Durağan kök ve hareketli parçalar; doğru Motor6D Part0/Part1, dinlenme C0/C1. Hareketli parçayı yanlışlıkla anchored bırakma.
- Kaynak Pose isimleri Motor6D'nin Part1 isimlerine karşılık gelir; root Pose ve çocukları fiziksel rig ağacını izler. Tek düz Pose listesi çok eklemli rig için yeterli değildir.
- Pose.CFrame eklemin dinlenme haline göre animasyon deltasıdır; dünya CFrame'i veya C0'ın kör kopyası değildir.
- Çevrim, duplicate part isimleri, eksik Part1 ve geçersiz root denetlenir. Ölçüler/mafsal noktaları animasyondan önce doğrudur.

## Hareket tasarımı
- Hazırlık → hızlanma → ana hareket → takip → oturma. Karaktere uygun stance ve semantik hareket; T-pose ya da anlamsız sallanma değil.
- Keyframe zamanları monoton; easing bilinçli. Sine/Cubic InOut ve ara temas anahtarları; ayak/teker/kapak temasını koru. Kare sayısı tek başına smooth hareket değildir.
- Döngüde ilk/son poz ve hız sürekliliği; kapak/tetik/kanat gibi eylemlerde dinlenme pozuna kontrollü dönüş. Euler sarılması/180° flip ve aşırı overshoot'u kontrol et.
- Kısa semantik adlar: Idle_Breath, WingFold, Hood_Open, Reveal_Settle. Her işe aynı klipleri zorla uygulama.

## Native kullanım ve test
`tools/EditableClips.luau` gerçek native klip üretir. Bu bir çalışma şablonudur; Studio'da bu paket için çalıştırılmadı. ServerStorage.RBX_ANIMSAVES altında saklar; Animation/Clip Editor sürümünün import/save akışı ayrıca doğrulanır. Klasörde olması tek başına editörde görüldüğünü kanıtlamaz.

Runtime Animator: yayımlama/asset yetkisiyle AnimationId kullanılmalıdır. Yerel keyframe registration API'lerinin Studio/plugin/izin sınırları vardır; sıradan oyunda bütün native Sequence'ler yüklenir diye varsayma. Gerekiyorsa aynı keyframe verisini kullanan preview player ekle fakat editlenebilir klibi bunun yerine sayma.

Kabul: editörde rig ve klip açılır, scrub ve loop gözlenir, oynatma/durdurma/reset çalışır, kök kayması ve clipping incelenir. Video/Studio kanıtı yoksa native kabul NOT_RUN kalır.
