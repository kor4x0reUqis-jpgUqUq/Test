# Evrensel kapsam ve kabul matrisi

Her yeni istekte bu tabloyu doldur. Satır durumları: GEREKLİ / İSTENMİYOR / BELİRSİZ. Açık talep olmadan model türü, ölçü, renk ve klip listesi devralınmaz.

| Katman | Sorulacak/çıkarılacak bilgi | Kabul kanıtı |
|---|---|---|
| Konu/kullanım | Hangi model, oyundaki rolü, kamera, kullanım sayısı? | Yeni talebe uygun çıktı |
| Stil/referans | Görsel/metin, özgün tasarım izni, görünen/örtülü alanlar | Gerçek kaynakla benzer kamerada kıyas |
| Boyut/hacim | Ana gövde ve aksesuar dahil ölçü; kesit/derinlik | Ön, arka, yan, ¾ ve ilgili üst/alt kontrol |
| Detay | Birincil/ikincil/üçüncül işçilik ve işlevsel bağlantılar | Kapsanan tüm yüzlerde temiz geometri |
| CSG/mesh | Kullanıcı ne istiyor, native sınırlar ve kalıcılık? | Gerçek sınıf, açıklık/normal, asset izinleri |
| Yüzey/studs | Texture mı, SurfaceType mı, fiziksel stud mu? Kaç yüz, hangi ölçek? | Native görünüm + doğru atama/yön/tiling; yalnız child sayısı değil |
| Rig/klip | Statik mi, hangi hareketler; editor erişimi gerekiyor mu? | Gerçek rig → tüm klipler → scrub/play/edit/save |
| Kontrolcü | Gameplay/fizik/etkileşim ayrıca var mı? | Gerçek kullanıcı girişinde/oyun durumunda çalışma |
| VFX | Hangi etki, hangi olay, nerede, ne zaman kapanır? | Doğru parent/eksen + native tetikleme/reset |
| Kurulum | Kod önceliği, zorunlu upload/izin/bağımlılık? | Temiz Studio'da en kısa gerçekçi akış |
| Kalıcılık | Save/reopen/Play/publish gereksinimi? | Gerçek yeniden açma ve uygun owner testi |
| Performans | Hedef cihaz, çoğaltma, görünürlük? | Gerçek frametime/Profiler; ayrı maliyetler |
| Teslim | Kod/kaynak/rehber/ZIP/test? | Gerçek dosya, CRC/hash ve dürüst durum |

## Kapsamın yanlış genellenmesini önle
- Her model bir karakter değildir; her karakter robot değildir.
- Her model 24 stud değildir. Boyut kullanıcının güncel isteğinden gelir.
- Her modelin altı klibi olmaz; statik işte klip gerekmeyebilir.
- Her modele studs/texture/VFX zorunlu değildir; açık istenmişse uygulanması zorunludur.
- Her bina iç mekân istemez; her araç oynanabilir kontrolcü istemez.
- Her koleksiyon etiket/timer/hatch istemez; eski arayüzler başka modele taşınmaz.

## Durum sınıfları
PASS yalnız test edilen kapsam için. FAIL/USER_REJECTED kullanıcı beklentisi karşılanmadı. NOT_RUN test yapılmadı. BLOCKED gerekli araç/izin yok. UNKNOWN kesin neden bulunamadı. Aynı projede offline PASS ile native USER_REJECTED aynı anda bulunabilir.

## Öncelik
Önce kapsam ve kurulabilirlik, sonra kütle, sonra detay/yüzey, sonra gerekli davranışlar; en sonunda native kabul/kalıcılık/performance ve teslim. Bu sıra bazı aşamaların paralel yürütülmesini yasaklamaz; ana form reddedildiği halde mikro süsü bitirip işi tamamlandı saymayı yasaklar.
