# Mecha24 — son kullanıcı geri bildirimi ve yeni kalite kapıları

## Kullanıcının söylediği
“Model dolu değil, zayıf duruyor”; kurulum dosyalarının neden kodla ve kolay olmadığı; GLB üzerinden gelen sonucun texturesiz ve animasyonsuz olduğu. Yeni iş emri robotu tamir etmek değil, skills'i bu hatalar/modellerle yenilemek ve bağımsız `FinalPRO.txt` üretmek.

## Kanıt ve belirsizlik ayrı
- Güncel native ekran: `cases/Mecha24_USER_REJECTED/Kullanici_Son_Sonuc.png` (423×494).
- Asıl konsept: aynı vaka altındaki `Konsept.png` (1536×1024); güncel uploads/image-1.png artık konsept değildir.
- Kullanıcı açısından son görünüm, hacim, kurulum ve animasyon erişimi başarısızdır. **USER_REJECTED**.
- Tek renkli/mavi ekran tek başına eksik UV/TextureID kanıtı değildir. Seçim highlight'ı, görüntü modu, ışık, import materyali veya kurulumda renk atamasının uygulanmaması gibi olasılıklar var; hangisi olduğu **UNKNOWN**. Kullanıcı yanlış yaptı varsayımı yok.
- GLB formatı genel olarak materyal/texture/rig/animation taşıyabilir. Bu projede ana GLB yalnız geometri taşıyordu; Motor6D ve klipler ayrı kurucuya bırakılmıştı. Dolayısıyla GLB'yi tek başına açan kullanıcı için bütün vaat edilen teslim elde değildi. Formatı suçlamak değil, parçalı teslimi düzeltmek gerekir.
- Kod içinde native Sequence üretimi ve kaynak JSON klipleri bulunması, kullanıcının editörde animasyon görebildiğini kanıtlamadı. Kurucunun çalıştırılıp çalıştırılmadığı, kayıt bağlantısının editör sürümünde tanınıp tanınmadığı ve gerçek playback nedeni bu ekranla kesinleştirilmez.

## Hata → karşı kural → kabul kanıtı

| Hata | Yeni karşı kural | Gereken kanıt |
|---|---|---|
| İnce/zayıf gövde | Önce göğüs/omuz/bel/kalça/uzuv kesiti ve derinliği; sonra mikro detay | Referansla benzer kamera/ölçekte ön, iki yan ve ¾ kıyas; kullanıcı hacim onayı |
| Çok mesh ile kaliteyi anlatmak | Mesh/triangle/Part sayısını sadece maliyet metriği say | Görsel kütle, katman, mafsal ve işçilik değerlendirmesi ayrı |
| Karmaşık GLB/upload/kurucu zinciri | Kod öncelikli en az adım; kaçınılmaz mesh upload koşulunu BAŞTAN onaya sun | Temiz Studio'da gerçek kurulum akışının denenmesi |
| Renkler yalnız preview'da doğru | Native materyal/renk/texture doğrulaması; seçim vurgusu kapalı görünüm | Studio ve Play ekranı + gerçek instance/material eşlemesi |
| Animasyon sadece dosyada | Rig seçimi → altı klibin listesi → scrub/play/edit/save | Hedef Clip Editor'da gerçek işlem; JSON sayısı değil |
| Union sadece kaynak boolean | Native seed/cut/UnionOperation sonuç ve temizlik denetimi | Native sınıf, açıklık, materyal ve rig bağlantısı |
| Kalıcılık belirsiz | Session-scoped opaque içerikten kalıcı asset yolunu ayır | Save/close/reopen, Play ve doğru owner ile yayın testi |
| Uzun sınırlama metniyle eksik teslimi kapatmak | Eksik kabul kapısını açık bırak; kaynak teslimini çalışan karakter diye adlandırma | Gerçek durum tablosu ve kısa, uygulanabilir adımlar |

## Dolu hacim için operasyonel kontrol
Göğüs genişliği/derinliği; omuz kalınlığı/alt kabuğu; boyun–yaka aralığı; belde gereksiz boşluk; pelvis bağlantısı; uyluk kesiti; baldır ön/yan/arka hacmi; ayak tabanı alanı; backpack'in ana gövdeyle kütle dengesi ayrı ele alınır. Görünmeyen iç parçalar yığmak estetik doluluk değildir. Ana form zayıfsa daha çok vida veya seam eklemek sorunu çözmez. Referans yoksa oranı görmüş gibi iddia etme.

## Kod önceliğinin fiziksel sınırı
Kullanıcı kolay kod istiyor; buna rağmen gerçek kalıcı özel mesh için upload/owner/security gereksinimi olabilir. İki yanlış uçtan kaçın:
1. Sıfır upload ile her ortamda özel kalıcı mesh vaat etmek.
2. Mesh isteğini açıklamadan bütün modeli Part/kutuya indirgemek.

Doğru yol gereksinimi baştan açıklayıp en kısa gerçekçi kurulumu onaya sunmak; tek akışta renk/rig/klipleri kurmak; eksikte abort/rollback yapmak. GLB, gerekirse ek kaynak; yalnız GLB bitmiş animasyonlu karakter yerine sayılmaz. CSG de native doğrulanmalı, geçici kesiciler temizlenmeli, farklı hareketli uzuvlar birleştirilmemeli.

## Native doğrulama olmayan araçlar
EditableClips helper, decoder, offline FK ve topology checker öğrenme araçlarıdır. Mevcut haliyle güncel Clip Editor'da başarı garantisi değildir. Native AnimSaves/AnimationGraph değişiklikleri araştırılıp hedef ortamda denenmelidir. Bu tur bu araçlar onarılmadı; yalnız statüleri ve kullanım sınırları düzeltildi.
