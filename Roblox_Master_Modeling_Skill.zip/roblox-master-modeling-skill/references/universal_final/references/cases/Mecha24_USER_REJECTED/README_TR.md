# REDDEDİLEN MODEL VAKASI — Mecha24

**Durum: USER_REJECTED. Bu klasör onaylı model veya native çalışan kurulum şablonu değildir.**

Kullanıcı hacmi zayıf/dolu olmayan, kurulumu zor, son görünümü renk/doku bakımından eksik ve animasyonu erişilemeyen bir teslim bildirdi. `Kullanici_Son_Sonuc.png` gerçek kullanıcı ekranıdır. Kesin materyal/animasyon kök nedeni bu ekranla kanıtlanmadı. Özgün referans `Konsept.png`; önceki farklı koleksiyonun Play hatası ayrıca isimlendirilmiştir.

## Neden model dosyaları da var?
Sadece “daha iyi yap” cümlesi değil, başarısızlığın gerçek geometrisi ve teslim mimarisi incelenebilsin:
- `Mecha24.glb`: önceki teslimin gerçek geometri kaynağı; rig/kliplerin bu GLB'ye gömülü olmadığı vaka için önemlidir.
- `geometry.json`: zırh/mesh grupları, offline CSG sonuçları ve native seed/cut tarifleri.
- `rig_meta.json`, `clips.json`: önceki özel rig ve altı klibin kaynak verisi; erişilebilir native klip kanıtı DEĞİLDİR.
- `build_geometry.py`, `build_clips.py`: kaynak üretim mantığı. Bunlar eski geometriyi tekrar üretir; yeni hacim düzeltmesi içermez. Aynı dizinde mesh_sources klasörü ve Python bağımlılıkları gibi önkoşulları vardır; çalışma kitabı örnekleridir, tek tıklık kurulum değildir.
- `Factory_UNVERIFIED.luau`: eski kurucunun okunabilir uygulama bölümü; D veri tablosu ve gerçek yüklenmiş meshler olmadan bağımsız kurulum değildir. Native güncel editör davranışı doğrulanmadı.
- `metrics_original.json`, `offline_results_original.json`: tarihsel offline ölçümler. İçlerindeki PASS ve native NOT_RUN, bugünkü USER_REJECTED kabul durumunun yerine geçmez.
- `PROVENANCE.json`: birebir kopyalanan kaynaklar ve orijinal teslim ZIP'inin hash kaydı. Eski ZIP burada iç içe tekrar paketlenmedi.

## İnceleme soruları
1. Göğüs, omuz, pelvis, uyluk ve baldır gerçek 3B kesitlerinde neden yeterince güçlü okunmuyor? Vida eklemek neden çözüm değil?
2. Gövde–bel, baş–yaka, dirsek/diz aralıklarında tasarlanmış mekanik açıklık ile zayıf/ayrık kütle nasıl ayrılıyor?
3. GLB geometri aşaması ile renk/rig/klip kurucusunun ayrılması neden kullanıcıya eksik bir model gibi yansıdı?
4. 129 mesh, 8 CSG tarifi ve 354 keyframe neden kullanıcıda çalışan, erişilebilir ve kabul edilen karakter anlamına gelmedi?
5. Renkli offline görsel neden tek renk görünen native ekranı çürütemez? Kök neden için hangi native kanıt eksik?
6. Kod öncelikli kurulum beklentisi, kalıcı mesh asset upload koşuluyla nasıl baştan ve dürüstçe uzlaştırılmalıydı?

Bu vaka kör kopyalanmaz veya varsayılan başlangıç gövdesi yapılmaz. Yeni karakterde uyarlanabilir modelleme/teslim mantığı öğrenilir. Vaka dosyalarını kendiliğinden çalıştırmak, yeniden asset publish etmek veya kullanıcı istemeden eski modeli onarmak yoktur.


## Son ek geri bildirim: dört native görünüş
`Son_Native_Geri_Bildirim_01.png` … `_04.png` son yüklemelerden byte-birebir korundu; kaynak/hash/boyutlar `SON_GERI_BILDIRIM_KAYNAKLARI.json` içindedir. Önceki 423×494 ekran ve asıl konsept EZİLMEDİ.

Kullanıcı modeli ayrıca aşırı detaysız ve hatalı buldu; beklediği studs texture'ın uygulanmadığını ve VFX olmadığını bildirdi. Yeni görünümler geniş sade yüzeylerin, bağlantı/aralıkların ve parlaklık altında detay okunurluğunun incelenmesi için tutulur. Kamera/ışık tek başına UV veya runtime olay nedenini kanıtlamaz. Sahnedeki başka karakterin alevi ya da taban grafiği modelin kendi VFX/texture'ı sayılmaz; parent/Attachment ve kapsam ayrımı gerekir. Kesin teknik kök neden UNKNOWN.

Bu vakadaki ölçü, robot parça isimleri, renkler ve altı klip evrensel prompta taşınmaz. Evrensel ders: güncel işin istediği hacim/detay/yüzey/VFX gerçekten uygulanmalı ve native doğrulanmalıdır. Robot bu tur TAMİR EDİLMEDİ.
