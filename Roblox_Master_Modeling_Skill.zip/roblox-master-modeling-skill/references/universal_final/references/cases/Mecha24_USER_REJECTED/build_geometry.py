"""Reference-guided hard surface geometry. Coordinates: +Y up; -Z forward. Stud units.
All mesh nodes have translation-only transforms; no skinned/session-only content.
"""
from pathlib import Path
from collections import defaultdict
import json, math
import numpy as np
import trimesh as tm
from scipy.spatial.transform import Rotation
R=Path(__file__).parent
for old in (R/'mesh_sources').glob('MC*.obj'):old.unlink()
C={'White':[229,233,237],'Porcelain':[247,249,250],'Navy':[27,33,64],'Shadow':[12,17,29],'Steel':[80,92,108],'Silver':[157,169,182],'Gold':[247,190,26],'GoldDark':[171,111,10],'Red':[188,40,27],'Sensor':[23,188,176]}
N=[]
def node(name,parent,p): N.append({'name':name,'parent':parent,'p':list(p)})
node('HumanoidRootPart',None,(0,12.4,0));node('LowerTorso','HumanoidRootPart',(0,12.4,0));node('UpperTorso','LowerTorso',(0,15.4,0));node('Neck','UpperTorso',(0,18.5,0));node('Head','Neck',(0,19,0));node('Backpack','UpperTorso',(0,16.4,1.55))
for side,s in [('L',-1),('R',1)]:
 node('Shoulder'+side,'UpperTorso',(s*3.7,17.4,0));node('UpperArm'+side,'Shoulder'+side,(s*4.4,17.3,0));node('LowerArm'+side,'UpperArm'+side,(s*4.4,14.2,0));node('Hand'+side,'LowerArm'+side,(s*4.4,11.5,0));node('UpperLeg'+side,'LowerTorso',(s*1.35,12.35,0));node('LowerLeg'+side,'UpperLeg'+side,(s*1.35,7.4,0));node('Foot'+side,'LowerLeg'+side,(s*1.35,1.75,0));node('FrontSkirt'+side,'LowerTorso',(s*1.1,12.25,-.98));node('SideSkirt'+side,'LowerTorso',(s*2,12.2,0));node('BackSkirt'+side,'LowerTorso',(s*1.05,12.25,1.0));node('Binder'+side,'Backpack',(s*1.8,16.05,2.15))
P={n['name']:np.array(n['p'],float) for n in N}; groups=defaultdict(list); elements=[]; csg=[]
def add(n,m,c,label):
 assert m.is_watertight,(n,label,'non-closed')
 if m.volume<0:m.invert()
 m.apply_translation(-P[n]);groups[n,c].append(m);elements.append({'node':n,'material':c,'label':label,'triangles':len(m.faces)})
def mesh(v,f):
 m=tm.Trimesh(vertices=v,faces=f,process=True);m.fix_normals();return m
def xform(m,p=(0,0,0),a=(0,0,0)):
 T=np.eye(4);T[:3,:3]=Rotation.from_euler('xyz',a,degrees=True).as_matrix();T[:3,3]=p;m=m.copy();m.apply_transform(T);return m

def outline(w,d,b):return np.array([[-w/2+b,-d/2],[w/2-b,-d/2],[w/2,-d/2+b],[w/2,d/2-b],[w/2-b,d/2],[-w/2+b,d/2],[-w/2,d/2-b],[-w/2,-d/2+b]])
def loft(rings):
 # ring = y,width,depth,centerZ; capped chamfered rectangular section
 v=[]
 for y,w,d,z in rings:
  o=outline(w,d,min(w,d)*.14);v.extend([[x,y,t+z] for x,t in o])
 f=[];k=8
 for j in range(len(rings)-1):
  for i in range(k):a=j*k+i;b=j*k+(i+1)%k;c=(j+1)*k+(i+1)%k;d=(j+1)*k+i;f.extend([[a,b,c],[a,c,d]])
 for i in range(1,k-1):f.extend([[0,i+1,i],[(len(rings)-1)*k,(len(rings)-1)*k+i,(len(rings)-1)*k+i+1]])
 return mesh(v,f)
def box(n,p,s,c,label,a=(0,0,0),bevel=.07):
 w,h,d=s;b=min(bevel,h*.24,w*.2,d*.2)
 m=loft([(-h/2,w-b*1.3,d-b*1.3,0),(-h/2+b,w,d,0),(h/2-b,w,d,0),(h/2,w-b*1.3,d-b*1.3,0)])
 add(n,xform(m,p,a),c,label)
def plate(n,xy,z0,z1,c,label):
 xy=np.array(xy,float);center=xy.mean(axis=0);v=[]
 for z,scale in [(z0,.94),(z0+.055,1),(z1-.035,1),(z1,.97)]:v.extend([[*q,z]for q in (xy-center)*scale+center])
 k=len(xy);f=[]
 for j in range(3):
  for i in range(k):a=j*k+i;b=j*k+(i+1)%k;cc=(j+1)*k+(i+1)%k;d=(j+1)*k+i;f.extend([[a,b,cc],[a,cc,d]])
 for i in range(1,k-1):f.extend([[0,i+1,i],[3*k,3*k+i,3*k+i+1]])
 add(n,mesh(v,f),c,label)
def cyl(n,p,r,l,c,label,axis=(0,1,0),sections=12,r2=None):
 a=np.array(axis,dtype=float);a/=np.linalg.norm(a);rot=tm.geometry.align_vectors([0,0,1],a)
 m=tm.creation.cylinder(radius=r,height=l,sections=sections) if r2 is None else tm.creation.conical_frustum(radius_top=r2,radius_base=r,height=l,sections=sections)
 m.apply_transform(rot);m.apply_translation(p);add(n,m,c,label)
def rod(n,a,b,r,c,label):
 a=np.array(a);b=np.array(b);cyl(n,(a+b)/2,r,np.linalg.norm(b-a),c,label,b-a)
def tube(n,p,axis,outer,inner,length,c,label,sections=16):
 v=[]
 for z,r in [(-length/2,outer),(-length/2,inner),(length/2,outer*.91),(length/2,inner*.91)]:
  for i in range(sections):q=2*math.pi*i/sections;v.append([r*math.cos(q),r*math.sin(q),z])
 f=[]
 for a,b in [(0,1),(0,2),(1,3),(2,3)]:
  for i in range(sections):j=(i+1)%sections;f.extend([[a*sections+i,a*sections+j,b*sections+j],[a*sections+i,b*sections+j,b*sections+i]])
 m=mesh(v,f);T=tm.geometry.align_vectors([0,0,1],axis);m.apply_transform(T);m.apply_translation(p);add(n,m,c,label)
def bolts(n,pts,axis=(0,0,-1),r=.045):
 for p in pts:cyl(n,p,r,.045,'Steel','recessed hex fastener',axis,6)
def native_vent(n,p,s,holes,c,label):
 seed=tm.creation.box(s);seed.apply_translation(p);cuts=[]
 for hp,hs in holes:
  m=tm.creation.box(hs);m.apply_translation(hp);cuts.append(m)
 result=tm.boolean.difference([seed,*cuts],engine='manifold');assert result.is_watertight
 # Preserve local vertices and an exact all-Part native CSG recipe, not a disguised mesh.
 result.apply_translation(-P[n]);csg.append({'node':n,'c':C[c],'material':c,'name':label,'seed':{'p':(np.array(p)-P[n]).tolist(),'s':list(s)},'cuts':[{'p':(np.array(hp)-P[n]).tolist(),'s':list(hs)}for hp,hs in holes],'v':np.round(result.vertices,6).tolist(),'f':result.faces.tolist()})

def mirrored(poly,s,offset=0):return [(s*x+offset,y)for x,y in poly]
# Pelvis, abdomen and articulated overlapping waist armor.
add('LowerTorso',loft([(11.6,3.05,1.8,.1),(12.5,3.9,2.3,0),(13.35,3.0,1.8,0)]),'Navy','faceted pelvis transmission')
for y in [13.0,13.35,13.7]:box('UpperTorso',(0,y,.05),(2.65,.25,1.65),'Steel','floating abdominal vertebra')
for s,side in [(-1,'L'),(1,'R')]:
 box('UpperTorso',(s*1.42,13.85,-.12),(.85,1.7,1.65),'White','rib armor',a=(0,0,-s*6))
 plate('FrontSkirt'+side,mirrored([(.23,12.48),(1.9,12.38),(2.16,10.17),(.65,9.72)],s),-1.55,-.91,'White','front skirt principal tapered armor')
 plate('FrontSkirt'+side,mirrored([(.4,12.07),(1.74,12.02),(1.85,10.42),(.78,10.05)],s),-1.62,-1.52,'Porcelain','front skirt inset plate')
 box('FrontSkirt'+side,(s*1.05,12.26,-1.65),(.73,.38,.17),'Gold','waist identification insert')
 box('FrontSkirt'+side,(s*1.86,11.56,-1.5),(.09,.68,.1),'Steel','skirt seam end')
 box('SideSkirt'+side,(s*2.19,11.45,.04),(.55,2.46,1.88),'White','splayed side skirt',a=(0,0,s*13))
 box('SideSkirt'+side,(s*2.41,11.8,-.64),(.13,.72,.37),'Shadow','side skirt opening')
 box('SideSkirt'+side,(s*2.5,11.05,.15),(.17,1.15,1.35),'Porcelain','side skirt armor applique',a=(0,0,s*13))
 plate('BackSkirt'+side,mirrored([(.18,12.4),(1.77,12.35),(2.02,10.1),(.43,10.3)],s),1.0,1.65,'White','rear segmented skirt')
 box('BackSkirt'+side,(s*1.05,11.7,1.73),(.95,.36,.15),'Gold','rear skirt vent border')
 for y in [11.61,11.72,11.83]:box('BackSkirt'+side,(s*1.05,y,1.83),(.67,.045,.06),'Shadow','rear skirt vent slat')
 for yy in [10.71,10.9]:box('SideSkirt'+side,(s*2.63,yy,.17),(.05,.045,.62),'Steel','side skirt retaining track')
 bolts('FrontSkirt'+side,[(s*.55,12.05,-1.69),(s*1.6,10.43,-1.69)])
plate('LowerTorso',[(-.49,12.6),(.49,12.6),(.38,10.32),(-.38,10.32)],-1.78,-1.15,'White','central pelvic keel')
box('LowerTorso',(0,12.63,-1.71),(.74,.5,.29),'Navy','belt buckle recess')
plate('LowerTorso',[(-.3,12.8),(.3,12.8),(.23,12.48),(-.23,12.48)],-1.94,-1.73,'Gold','gold pelvis clasp')
# Chest is a many-plane shaped shell; vent holes are true native CSG cut-outs.
add('UpperTorso',loft([(14.1,2.85,2.05,.05),(15.4,4.2,2.65,0),(17.1,5.25,2.9,.05),(18.05,4.35,2.25,.2)]),'Navy','multi plane chest shell')
for s,side in [(-1,'L'),(1,'R')]:
 plate('UpperTorso',mirrored([(.45,17.92),(2.62,17.95),(2.78,16.51),(1.4,16.36),(.56,16.83)],s),-1.61,-.94,'Navy','upper chest armored wing')
 plate('UpperTorso',mirrored([(1.5,16.33),(2.68,16.32),(2.27,14.35),(.77,14.03)],s),-1.55,-.79,'Navy','lower chest chamfer')
 box('UpperTorso',(s*1.65,16.55,-1.82),(1.6,1.04,.12),'Shadow','vent dark well')
 holes=[((s*1.65,y,-1.96),(1.28,.17,.78))for y in [16.27,16.55,16.83]]
 native_vent('UpperTorso',(s*1.65,16.55,-1.99),(1.62,1.06,.27),holes,'Gold','ChestVent'+side)
 for y in [16.28,16.56,16.84]:box('UpperTorso',(s*1.65,y,-1.99),(1.22,.075,.19),'GoldDark','inset louver blade',a=(14,0,0))
 box('UpperTorso',(s*2.15,17.54,-1.7),(.72,.08,.09),'Steel','chest panel seam')
 bolts('UpperTorso',[(s*2.51,17.7,-1.68),(s*2.12,14.65,-1.61)])
plate('UpperTorso',[(-.7,17.03),(.7,17.03),(.62,15.04),(.34,13.93),(-.34,13.93),(-.62,15.04)],-1.86,-1.45,'Shadow','sternum engine cavity')
for s in [-1,1]:plate('UpperTorso',mirrored([(.16,16.83),(.49,16.83),(.48,14.94),(.21,14.18)],s),-2.00,-1.87,'Red','twin red sternum rails')
box('UpperTorso',(0,17.45,-1.5),(2.25,.65,.36),'Navy','sternum upper plate')
# Collar and exposed neck mechanics.
for s in [-1,1]:
 box('UpperTorso',(s*1.02,18.1,-.19),(.26,.95,1.76),'Navy','raised armored collar',a=(0,0,-s*15))
 box('UpperTorso',(s*.78,18.07,-.35),(.15,.7,1.43),'Gold','gold collar rail',a=(0,0,-s*15))
cyl('Neck',(0,18.8,.05),.57,.68,'Shadow','neck column')
for s in [-1,1]:
 rod('Neck',(s*.43,18.45,-.23),(s*.43,19.15,-.23),.10,'Steel','neck lateral piston')
box('Neck',(0,18.66,-.47),(.66,.42,.15),'Steel','neck vertebral front')
# Head shell: open-faced faceted helmet; separate crown panels, visor, cheeks and crest.
for i in range(16):
 a=2*math.pi*i/16;b=2*math.pi*(i+1)/16
 # z=cos(a), so front opening uses cos<-.45.
 front=math.cos((a+b)/2)<-.45
 low=20.68 if front else 19.72
 rings=[(low,1.2,.97),(20.92,1.3,1.06),(21.52,.91,.78),(21.88,.43,.43)]
 if front:rings=[(20.86,1.25,1.05),(21.52,.91,.78),(21.88,.43,.43)]
 v=[]
 for y,rx,rz in rings:
  for angle in [a+.012,b-.012]:v.append([rx*math.sin(angle),y,rz*math.cos(angle)+.08])
 # Each strip is a solid plate, not an open render surface.
 vv=v+[[x*.89,y-.025,(z-.08)*.89+.08]for x,y,z in v];k=len(v);f=[]
 for j in range(len(rings)-1):
  q=2*j;f.extend([[q,q+1,q+3],[q,q+3,q+2],[k+q,k+q+3,k+q+1],[k+q,k+q+2,k+q+3]])
 border=[0,1]+[2*j+1 for j in range(1,len(rings))]+[2*(len(rings)-1)]+[2*j for j in range(len(rings)-2,0,-1)]
 for q,qq in zip(border,border[1:]+border[:1]):f.extend([[q,qq,k+qq],[q,k+qq,k+q]])
 add('Head',mesh(vv,f),'White' if i%3 else 'Porcelain','individual helmet crown sector')
box('Head',(0,20.15,-.76),(1.94,1.32,.68),'Shadow','recessed face and visor understructure')
for s in [-1,1]:
 plate('Head',mirrored([(.08,20.49),(1.02,20.73),(1.1,20.5),(.16,20.22)],s),-1.25,-.99,'Porcelain','slanted armored brow')
 plate('Head',mirrored([(.14,20.31),(.95,20.5),(.85,20.22),(.24,20.1)],s),-1.275,-1.17,'Sensor','recessed cyan eye')
 plate('Head',mirrored([(.66,20.13),(1.11,20.35),(1.13,19.44),(.71,19.16)],s),-1.16,-.57,'White','cheek guard outer')
 box('Head',(s*.86,19.83,-1.23),(.16,.69,.14),'Porcelain','cheek column')
 for y in [19.66,19.88,20.1]:box('Head',(s*1.08,y,-1.21),(.105,.12,.07),'Shadow','cheek breathing slit')
 cyl('Head',(s*1.29,20.42,.04),.43,.19,'Steel','ear bearing',axis=(1,0,0),sections=16)
 cyl('Head',(s*1.4,20.42,.04),.31,.07,'Shadow','ear bearing recessed ring',axis=(1,0,0),sections=16)
 cyl('Head',(s*1.445,20.42,.04),.17,.075,'Steel','ear bearing spindle',axis=(1,0,0))
 box('Head',(s*1.05,20.95,-.5),(.29,.17,.18),'Gold','helmet temple accent',a=(0,0,s*12))
plate('Head',[(-.56,20.17),(.56,20.17),(.49,19.51),(0,19.22),(-.49,19.51)],-1.33,-.96,'Porcelain','sculpted face mask')
for y,w in [(19.97,.29),(19.83,.36),(19.69,.29)]:box('Head',(0,y,-1.354),(w,.035,.045),'Shadow','mask exhaust slit',bevel=.008)
plate('Head',[(-.14,19.62),(.14,19.62),(.21,19.19),(.12,18.99),(-.12,18.99),(-.21,19.19)],-1.48,-1.25,'Red','red chin keel')
plate('Head',[(-.15,20.38),(.15,20.38),(.31,20.98),(-.31,20.98)],-1.42,-1.15,'Red','crest red mounting shoe')
for s in [-1,1]:
 plate('Head',mirrored([(.12,20.64),(.25,21.03),(1.18,21.66),(2.42,23.15),(1.48,21.32),(.42,20.7)],s),-1.44,-1.23,'Gold','tapered V fin solid blade')
 plate('Head',mirrored([(.38,20.86),(1.35,21.46),(2.3,23.0),(1.08,21.63)],s),-1.465,-1.43,'GoldDark','V fin beveled ridge')
plate('Head',[(-.2,20.47),(.2,20.47),(.31,21.54),(.22,22.04),(-.22,22.04),(-.31,21.54)],-1.47,-.99,'Porcelain','forehead crest blade')
box('Head',(0,21.59,-1.488),(.36,.62,.08),'Shadow','forehead sensor recessed frame')
box('Head',(0,21.59,-1.538),(.24,.46,.035),'Sensor','forehead optical sensor',bevel=.025)
box('Head',(0,21.46,.97),(.39,.53,.08),'Shadow','rear crown sensor frame')
box('Head',(0,21.46,1.025),(.25,.36,.04),'Sensor','rear crown sensor')
for y in [19.84,20.33,20.82]:box('Head',(0,y,1.04),(.65,.43,.13),'White','rear head layered crown seam')
# Shoulders / arms / articulated wrists / five mechanically segmented digits per hand.
for side,s in [('L',-1),('R',1)]:
 sh='Shoulder'+side;ua='UpperArm'+side;la='LowerArm'+side;ha='Hand'+side
 cyl(sh,(s*3.66,17.24,0),.77,1.1,'Shadow','shoulder gimbal',axis=(1,0,0),sections=16)
 rod(sh,(s*2.3,17.45,0),(s*4.2,17.45,0),.28,'Steel','shoulder crossshaft')
 poly=mirrored([(2.9,18.32),(5.62,18.95),(5.89,18.4),(5.29,16.35),(3.4,16.12),(3.01,16.6)],s)
 plate(sh,poly,-.95,.92,'White','broad winged pauldron')
 plate(sh,mirrored([(3.23,18.03),(5.39,18.51),(5.54,18.12),(5.05,16.64),(3.56,16.41)],s),-1.04,-.91,'Porcelain','pauldron front applique')
 plate(sh,mirrored([(3.44,18.13),(5.45,18.62),(5.6,18.29),(3.43,17.79)],s),.93,1.08,'Porcelain','pauldron rear ridge')
 box(sh,(s*4.1,17.99,-1.06),(.6,.12,.08),'Shadow','pauldron recessed panel notch',a=(0,0,s*10))
 box(sh,(s*4.4,17.74,-1.065),(.07,.37,.06),'Steel','pauldron seam stop')
 box(sh,(s*5.46,17.22,.1),(.15,.73,1.04),'Porcelain','pauldron side armor lip',a=(0,0,s*13))
 for zz in [-.42,.12,.56]:box(sh,(s*5.60,17.53,zz),(.06,.12,.16),'Steel','pauldron lateral service latch')
 bolts(sh,[(s*5.2,18.05,-1.08),(s*3.5,16.67,-1.08)])
 cyl(ua,(s*4.4,16.8,0),.51,1.5,'Steel','upper arm core')
 box(ua,(s*4.4,15.9,0),(1.34,2.35,1.43),'White','upper arm sloped shell',a=(0,0,-s*4),bevel=.18)
 box(ua,(s*4.4,15.9,-.79),(.87,1.8,.16),'Porcelain','bicep front layered plate',a=(0,0,-s*4))
 box(ua,(s*4.4,15.8,.79),(.78,1.7,.21),'White','bicep rear armor')
 rod(ua,(s*4.92,15.05,.4),(s*4.92,16.7,.4),.10,'Silver','arm hydraulic rod')
 cyl(la,(s*4.4,14.2,0),.57,1.42,'Navy','elbow bearing housing',axis=(1,0,0),sections=16)
 cyl(la,(s*5.14,14.2,0),.35,.13,'Steel','outer elbow bearing',axis=(1,0,0),sections=16)
 cyl(la,(s*5.23,14.2,0),.18,.08,'Shadow','elbow axle',axis=(1,0,0))
 box(la,(s*4.4,12.9,-.02),(1.62,2.33,1.6),'White','forearm primary armor',bevel=.17)
 plate(la,mirrored([(3.66,13.96),(5.13,13.78),(5.24,11.95),(4.88,11.6),(3.7,11.87)],s),-.99,-.79,'Porcelain','forearm front overlapping armor')
 box(la,(s*5.19,12.9,.12),(.14,1.3,.72),'White','forearm lateral applique')
 box(la,(s*4.4,14.03,-.82),(.78,.42,.18),'Gold','forearm upper latch')
 box(la,(s*4.4,12.8,.84),(.7,.8,.10),'Shadow','forearm rear vent recess')
 native_vent(la,(s*4.4,12.8,.94),(.85,.95,.17),[((s*4.4,12.8,.94),(.48,.59,.5))],'Gold','ForearmVent'+side)
 for y in [12.65,12.8,12.95]:box(la,(s*4.4,y,.975),(.44,.055,.06),'Steel','forearm heat sink fins')
 cyl(ha,(s*4.4,11.55,0),.39,.63,'Steel','wrist swivel')
 box(ha,(s*4.4,11.0,-.03),(1.18,.82,1.0),'Navy','hand metacarpal armor',bevel=.15)
 box(ha,(s*4.4,11.18,-.6),(1.0,.4,.20),'Navy','dorsal knuckle plate')
 for j in range(4):
  x=s*4.4+(j-1.5)*.255
  box(ha,(x,10.76,-.43),(.22,.45,.39),'Navy','finger proximal phalanx '+str(j),a=(-17,0,0),bevel=.045)
  cyl(ha,(x,10.55,-.45),.115,.22,'Steel','finger hinge '+str(j),axis=(1,0,0),sections=8)
  box(ha,(x,10.46,-.28),(.22,.29,.39),'Navy','finger curled distal '+str(j),a=(22,0,0),bevel=.045)
  box(ha,(x,11.08,-.73),(.205,.25,.08),'Steel','individual knuckle inset '+str(j),bevel=.025)
 box(ha,(s*3.84,10.92,-.26),(.32,.55,.4),'Navy','thumb proximal',a=(0,-s*24,s*24),bevel=.06)
 box(ha,(s*3.84,10.65,-.49),(.34,.33,.36),'Navy','thumb distal',a=(0,0,s*14),bevel=.07)
 # Long thighs with independent thigh/knee/shin/foot rig segments.
 ul='UpperLeg'+side;ll='LowerLeg'+side;fo='Foot'+side;x=s*1.35
 cyl(ul,(x,12.12,.04),.59,1.6,'Shadow','hip ball housing',axis=(1,0,0),sections=16)
 box(ul,(x,10.1,.03),(1.26,3.95,1.35),'Steel','thigh load frame',bevel=.14)
 plate(ul,[(x-.79,11.98),(x+.79,11.98),(x+.7,8.26),(x+.4,7.94),(x-.55,8.12)],-.91,.61,'White','long thigh outer shell')
 plate(ul,[(x-.56,11.65),(x+.56,11.65),(x+.49,8.6),(x-.46,8.45)],-1.0,-.89,'Porcelain','thigh front long floating panel')
 box(ul,(x,10.2, .86),(1.3,3.0,.32),'White','rear thigh shell',bevel=.12)
 for off in [-.54,.54]:rod(ul,(x+off,8.02,.36),(x+off,11.5,.36),.09,'Silver','thigh hydraulic shaft')
 box(ul,(x,8.05,-.92),(.84,.32,.15),'Shadow','upper knee recess')
 cyl(ll,(x,7.4,0),.68,1.65,'Navy','knee hinge case',axis=(1,0,0),sections=16)
 cyl(ll,(x+s*.86,7.4,0),.43,.12,'Steel','knee outside annulus',axis=(1,0,0),sections=16)
 cyl(ll,(x+s*.94,7.4,0),.24,.08,'Shadow','knee axle cap',axis=(1,0,0))
 plate(ll,[(x-.66,7.72),(x+.66,7.72),(x+.48,6.8),(x,6.5),(x-.48,6.8)],-.91,-.46,'White','pointed knee armor')
 plate(ll,[(x-.32,7.52),(x+.32,7.52),(x,7.03)],-1.02,-.9,'Gold','triangular knee accent')
 add(ll,xform(loft([(1.95,1.12,1.25,.03),(3.3,2.02,1.92,.16),(5.05,2.18,2.12,.16),(7.13,1.65,1.65,.14)]),(x,0,0)),'White','tall faceted calf shell')
 plate(ll,[(x-.57,6.92),(x+.57,6.92),(x+.72,4.71),(x+.39,3.7),(x-.39,3.7),(x-.72,4.71)],-1.04,-.78,'Porcelain','central shin floating armor')
 box(ll,(x,5.6,-1.07),(.36,1.22,.13),'Shadow','shin service slot recess')
 native_vent(ll,(x,5.6,-1.15),(.48,1.35,.15),[((x,5.6,-1.15),(.23,1.05,.46))],'White','ShinSlot'+side)
 for y in [5.25,5.5,5.75,6.0]:box(ll,(x,y,-1.16),(.22,.045,.04),'Steel','shin inset radiator fin')
 plate(ll,mirrored([(2.1,6.6),(2.49,5.67),(2.7,3.49),(2.16,2.4),(1.93,3.4)],s),-.39,.72,'White','outer calf blade')
 plate(ll,[(x-.76,3.68),(x+.76,3.68),(x+.84,2.26),(x+.38,1.75),(x-.38,1.75),(x-.84,2.26)],-1.21,-.71,'White','pointed ankle cuff')
 box(ll,(x,5.27,1.28),(1.4,2.01,.45),'White','rear calf layered shroud',bevel=.14)
 box(ll,(x+s*.85,3.3,.55),(.23,.53,.66),'Gold','calf side gold latch')
 # Calf thrust vector points backward and downward; real hollow bell.
 axis=np.array([0,-.62,.78]);p=np.array([x,3.8,1.34]);tube(ll,p,axis,.43,.29,.75,'Steel','calf hollow thruster bell')
 tube(ll,p+axis*.29,axis,.46,.32,.14,'Navy','calf nozzle armor rim')
 cyl(ll,p-axis*.32,.275,.05,'Shadow','calf nozzle deep cavity',axis)
 cyl(ll,p-axis*.29,.13,.03,'Sensor','calf nozzle emitter core',axis)
 # Layered foot, gold toe and heel armor. Foot shape is beveled wedge, not a box.
 add(fo,xform(loft([(.0,2.13,3.24,-.63),(.26,2.2,3.35,-.64),(.82,2.13,3.13,-.55),(1.51,1.42,1.9,-.05),(1.84,1.2,1.55,.12)]),(x,0,0)),'Navy','multiplane armored foot wedge')
 plate(fo,[(x-.68,1.1),(x+.68,1.1),(x+.92,.38),(x-.92,.38)],-1.93,-1.55,'White','white toe instep')
 box(fo,(x,1.05,-1.88),(1.57,.18,1.18),'Porcelain','sloped white toe upper',a=(-35,0,0),bevel=.06)
 box(fo,(x,.27,-2.17),(1.96,.48,.31),'Gold','gold toe bumper',bevel=.10)
 for sd in [-1,1]:box(fo,(x+sd*.97,.22,.72),(.29,.42,.69),'Gold','gold heel corner',bevel=.07)
 box(fo,(x,.12,-.5),(1.95,.21,2.82),'Shadow','mechanical outsole',bevel=.05)
 box(fo,(x,1.42,-.75),(1.1,.42,.47),'Navy','dorsal boot armor')
 for y,z in [(.42,.83),(.73,.57),(1.02,.30)]:box(fo,(x,y,z),(1.47,.09,.17),'Steel','heel step articulation seam')
 for zz in [.1,.65]:box(ll,(x+s*1.1,4.9,zz),(.09,.85,.13),'Silver','calf lateral split seam',a=(0,0,-s*8))
 for yy in [2.4,2.63]:box(ll,(x,yy,-1.24),(.57,.055,.05),'Steel','ankle cuff short seam')
 bolts(ll,[(x-.5,6.65,-1.08),(x+.5,4.93,-1.10)])
# Backpack with two main bells, two auxiliaries, deep recessed bays and long split-color binders.
add('Backpack',loft([(14.72,3.45,1.68,2.24),(15.2,4.02,2.17,2.32),(18.32,3.78,1.89,2.25),(18.56,3.36,1.67,2.22)]),'Navy','backpack beveled central housing')
box('Backpack',(0,16.9,3.42),(1.37,2.53,.31),'Navy','central backpack panel')
for s,side in [(-1,'L'),(1,'R')]:
 box('Backpack',(s*1.23,16.65,3.35),(.88,2.65,.48),'Navy','rear split equipment bay')
 native_vent('Backpack',(s*1.19,17.74,3.67),(.86,.52,.20),[((s*1.19,17.74,3.67),(.59,.26,.58))],'Steel','BackpackVent'+side)
 for y in [16.1,16.4,16.7,17.0]:box('Backpack',(s*1.23,y,3.63),(.56,.08,.14),'Steel','equipment bay rib')
 axis=np.array([0,-.96,.28]);p=np.array([s*.91,14.87,2.91])
 tube('Backpack',p,axis,.59,.39,1.04,'Steel','main backpack hollow bell')
 tube('Backpack',p+axis*.38,axis,.64,.43,.15,'Navy','main thruster rim')
 cyl('Backpack',p-axis*.4,.36,.06,'Shadow','main thruster dark depth',axis)
 cyl('Backpack',p-axis*.36,.19,.035,'Sensor','main thruster ceramic core',axis)
 p2=np.array([s*1.6,15.07,2.66]);tube('Backpack',p2,axis,.29,.19,.61,'GoldDark','auxiliary thrust nozzle')
 rod('Backpack',(s*1.6,16.8,2.15),(s*2.13,18.0,2.09),.17,'Steel','binder support actuator')
 bn='Binder'+side
 # Build vertically in a temporary local frame then rotate outwards about its hinge.
 start=len(elements);before={k:len(v)for k,v in groups.items()}
 bx=s*1.8
 box(bn,(bx,18.25,2.23),(.85,4.6,.92),'Navy','binder lower armored spine',bevel=.09)
 box(bn,(bx,21.84,2.23),(.72,3.08,.85),'White','binder long upper outer armor',bevel=.08)
 box(bn,(bx,23.55,2.23),(.65,.55,.73),'Navy','binder end cap')
 box(bn,(bx,21.78,1.755),(.48,2.55,.11),'Porcelain','binder front inset applique')
 box(bn,(bx,18.22,2.76),(.58,3.75,.2),'Navy','binder rear segmented armor')
 for y in [17.45,18.35,19.2]:box(bn,(bx,y,2.91),(.43,.08,.12),'Steel','binder panel seam')
 box(bn,(bx,16.45,1.7),(.48,.83,.12),'Gold','binder lower gold lock')
 # Native end vent rotates with the full binder segment via Motor6D, recipe already pre-tilted below.
 # Use mesh slats here; total native vent count remains ten and is exact elsewhere.
 box(bn,(bx,22.8,1.745),(.5,.56,.12),'Gold','binder tip sensor bezel')
 box(bn,(bx,22.8,1.666),(.29,.36,.06),'Shadow','binder tip recess')
 box(bn,(bx,22.8,1.625),(.18,.25,.04),'Steel','binder tip sensor')
 rot=Rotation.from_euler('z',-s*9,degrees=True).as_matrix()
 for k,ms in groups.items():
  if k[0]!=bn:continue
  for m in ms:m.vertices=m.vertices@rot.T
 # Cap extent determined by geometry. Entire robot is rescaled to exact 24-stud full binder height below.
# Exact height normalization uniformly scales joints, source meshes, CSG recipes and animation units.
allv=np.concatenate([m.vertices+P[n]for (n,c),ms in groups.items()for m in ms]+[np.array(q['v'])+P[q['node']]for q in csg]);lo=allv.min(axis=0);hi=allv.max(axis=0);scale=24/(hi[1]-lo[1]);shift=np.array([0,-lo[1]*scale,0]);
for n in N:n['p']=(np.array(n['p'])*scale+shift).round(7).tolist()
for key,ms in groups.items():
 for m in ms:m.apply_scale(scale)
for q in csg:
 q['v']=(np.array(q['v'])*scale).round(7).tolist()
 for item in [q['seed'],*q['cuts']]:item['p']=(np.array(item['p'])*scale).round(7).tolist();item['s']=(np.array(item['s'])*scale).round(7).tolist()
P={n['name']:np.array(n['p'])for n in N};out=[];scene=tm.Scene()
for i,((n,c),ms) in enumerate(groups.items(),1):
 m=tm.util.concatenate(ms);center=m.bounds.mean(axis=0);m.apply_translation(-center);key=f'MC{i:03d}';extent=m.extents
 # Force flat normals on hard-surface triangles without changing source topology.
 gl=m.copy();gl=tm.Trimesh(vertices=gl.vertices[gl.faces].reshape(-1,3),faces=np.arange(len(gl.faces)*3).reshape(-1,3),process=False)
 gl.visual=tm.visual.TextureVisuals(material=tm.visual.material.PBRMaterial(name=c,baseColorFactor=C[c]+[255],metallicFactor=.42 if c in ['Steel','Silver','Gold','GoldDark']else .06,roughnessFactor=.38))
 T=np.eye(4);T[:3,3]=P[n]+center;scene.add_geometry(gl,node_name=key,geom_name=key,transform=T)
 m.export(R/'mesh_sources'/f'{key}_{n}_{c}.obj')
 out.append({'key':key,'node':n,'material':c,'c':C[c],'center':center.round(7).tolist(),'size':extent.round(7).tolist(),'v':np.round(m.vertices,7).tolist(),'f':m.faces.tolist(),'components':len(ms)})
(R/'mesh_sources'/'Mecha24.glb').write_bytes(scene.export(file_type='glb'))
D={'name':'Mecha_Ref24','height':24,'scale':scale,'palette':C,'nodes':N,'meshes':out,'csg':csg,'elements':elements}
(R/'geometry.json').write_text(json.dumps(D,separators=(',',':')))
meta={k:v for k,v in D.items()if k not in ['elements','meshes','csg']};meta['meshes']=[{k:v for k,v in q.items()if k not in ['v','f']}for q in out];meta['csg']=[{k:v for k,v in q.items()if k not in ['v','f']}for q in csg];(R/'rig_meta.json').write_text(json.dumps(meta,separators=(',',':')))
metrics={'height_studs':24,'rig_parts':len(N),'motors':len(N)-1,'persistent_meshparts':len(out),'native_union_operations':len(csg),'authored_solid_elements':len(elements),'mesh_triangles':sum(len(q['f'])for q in out),'offline_union_triangles':sum(len(q['f'])for q in csg),'largest_mesh_triangles':max(len(q['f'])for q in out),'scale':scale,'native_studio':'NOT_RUN'}
(R/'metrics.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
