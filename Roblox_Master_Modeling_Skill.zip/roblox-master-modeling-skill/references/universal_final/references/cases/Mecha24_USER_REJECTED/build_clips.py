"""Six authored native-keyframe clips. In-place locomotion uses 2-bone ankle-target IK.
The same local 4x4 Pose transforms drive offline FK and Studio KeyframeSequences.
"""
import json,math
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation,Slerp
R=Path(__file__).parent;D=json.loads((R/'rig_meta.json').read_text());S=D['scale'];N=D['nodes'];P={n['name']:np.array(n['p'])for n in N};names=list(P)
def cf(x=0,y=0,z=0,rx=0,ry=0,rz=0):
 T=np.eye(4);T[:3,:3]=Rotation.from_euler('xyz',[rx,ry,rz],degrees=True).as_matrix();T[:3,3]=np.array([x,y,z])*S;return T
def smooth(x):x=np.clip(x,0,1);return x*x*x*(x*(x*6-15)+10)
def blend(a,b,t):
 out={};u=float(np.clip(smooth(t),0,1))
 for name in names:
  aa=a[name];bb=b[name];m=np.eye(4);m[:3,3]=aa[:3,3]*(1-u)+bb[:3,3]*u
  m[:3,:3]=Slerp([0,1],Rotation.from_matrix([aa[:3,:3],bb[:3,:3]]))([u]).as_matrix()[0];out[name]=m
 return out

def base():return {n:np.eye(4)for n in names}
def legs(q,targets):
 root=q['LowerTorso'];hipBase=P['LowerTorso']+root[:3,3];rot=root[:3,:3]
 for side,s in [('L',-1),('R',1)]:
  hip=P['UpperLeg'+side]-P['LowerTorso'];hip=hipBase+rot@hip;target,pitch=targets[side];local=rot.T@(np.array(target)*S-hip)
  abduct=math.atan2(local[0],-local[1]);down=math.hypot(local[0],local[1]);front=-local[2];l1=4.95*S;l2=5.65*S
  k=-math.acos(float(np.clip((down*down+front*front-l1*l1-l2*l2)/(2*l1*l2),-.999999,.999999)))
  h=math.atan2(front,down)-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))
  upper=cf(rz=math.degrees(abduct))@cf(rx=math.degrees(h));lower=cf(rx=math.degrees(k));foot=np.eye(4);foot[:3,:3]=(rot@upper[:3,:3]@lower[:3,:3]).T@cf(rx=pitch)[:3,:3]
  q['UpperLeg'+side]=upper;q['LowerLeg'+side]=lower;q['Foot'+side]=foot
  q['FrontSkirt'+side]=cf(rx=max(0,math.degrees(h)*.67),rz=-s*2)
  q['BackSkirt'+side]=cf(rx=min(0,math.degrees(h+k)*.22))
  q['SideSkirt'+side]=cf(rz=s*(3+max(0,math.degrees(h)*.07)))
 return q

def idle(t):
 q=base();w=2*math.pi*t/4;b=math.sin(w);q['LowerTorso']=cf(y=-.035+.014*b,rx=-.7);q['UpperTorso']=cf(y=.025*b,rx=.45*b);q['Head']=cf(rx=-1.15+1.0*b,ry=.7*math.sin(w+.5));q['Neck']=cf(y=.011*b)
 for side,s in [('L',-1),('R',1)]:
  q['Shoulder'+side]=cf(y=.017*b,rz=s*(.35+.3*b));q['UpperArm'+side]=cf(rx=2.6,rz=s*1);q['LowerArm'+side]=cf(rx=5.5+.4*b);q['Hand'+side]=cf(rx=-2)
 return legs(q,{side:([s*1.35,1.75,0],0)for side,s in [('L',-1),('R',1)]})
def locomotion(t,run=False):
 dur=.8 if run else 1.2;ph=t/dur;v=math.sin(2*math.pi*ph);q=base();q['LowerTorso']=cf(y=(-.47 if run else -.19)+(.10 if run else .035)*math.cos(4*math.pi*ph),rx=-7 if run else -2,rz=(1.6 if run else .8)*v);q['UpperTorso']=cf(rx=-4 if run else -1,ry=(7 if run else 3.8)*v,rz=-(1.3 if run else .6)*v);q['Head']=cf(rx=3 if run else 0,ry=-(5 if run else 2)*v)
 targets={};stance=.48 if run else .62;step=5.5 if run else 2.8;lift=2.65 if run else .74
 for side,s,off in [('L',-1,0),('R',1,.5)]:
  p=(ph+off)%1
  if p<stance:
   u=p/stance;z=-step/2+step*u;y=1.75;pitch=-15*smooth((u-.77)/.23)
  else:
   u=(p-stance)/(1-stance);z=step/2-step*float(smooth(u));y=1.75+lift*math.sin(math.pi*u)**1.25;pitch=-15*(1-float(smooth(u/.25)))+12*math.sin(math.pi*u)
  targets[side]=([s*1.35,y,z],pitch)
  arm=math.sin(2*math.pi*(ph+off));q['UpperArm'+side]=cf(rx=-(42 if run else 22)*arm,rz=s*(3 if run else 1.6));q['LowerArm'+side]=cf(rx=(63 if run else 15)+(9 if run else 6)*arm);q['Hand'+side]=cf(rx=-7,ry=s*5)
  q['Shoulder'+side]=cf(ry=-(3 if run else 1.5)*arm,rz=s*.6)
  q['Binder'+side]=cf(rx=1.0*math.sin(4*math.pi*ph+.3),rz=s*.5*v)
 return legs(q,targets)
def flight(t):
 q=base();w=2*math.pi*t/1.8;q['LowerTorso']=cf(y=8+.10*math.sin(w),rx=-82+1*math.sin(w),rz=1.2*math.sin(w));q['UpperTorso']=cf(rx=1.5);q['Neck']=cf(rx=14);q['Head']=cf(rx=58,ry=1.3*math.sin(w))
 for side,s in [('L',-1),('R',1)]:
  q['UpperArm'+side]=cf(rx=-14,rz=s*8);q['LowerArm'+side]=cf(rx=23+1.5*math.sin(w));q['Hand'+side]=cf(rx=3,ry=s*8);q['Shoulder'+side]=cf(rz=-s*3)
  q['UpperLeg'+side]=cf(rx=8,rz=s*2.3);q['LowerLeg'+side]=cf(rx=-18-1.3*math.sin(w));q['Foot'+side]=cf(rx=-4)
  q['FrontSkirt'+side]=cf(rx=14);q['BackSkirt'+side]=cf(rx=-6);q['SideSkirt'+side]=cf(rz=s*6)
  q['Binder'+side]=cf(rx=11+1.0*math.sin(w),rz=-s*2)
 return q
IDLE=idle(0);FLY=flight(0)
def crouch(amount):
 q=base();q['LowerTorso']=cf(y=-amount,rx=-6);q['UpperTorso']=cf(rx=-5);q['Head']=cf(rx=5)
 for side,s in [('L',-1),('R',1)]:q['UpperArm'+side]=cf(rx=-15,rz=s*9);q['LowerArm'+side]=cf(rx=37);q['Shoulder'+side]=cf(rz=s*3)
 return legs(q,{side:([s*1.35,1.75,.18],0)for side,s in [('L',-1),('R',1)]})
CROUCH=crouch(1.1)
def takeoff(t):
 if t<.55:
  u=float(smooth(t/.55));q=blend(IDLE,CROUCH,t/.55);return legs(q,{side:([s*1.35,1.75,.18*u],0)for side,s in [('L',-1),('R',1)]})
 if t<1.12:
  launch=blend(CROUCH,FLY,.58);launch['LowerTorso']=cf(y=3.2,rx=-20);launch['Head']=cf(rx=8)
  return blend(CROUCH,launch,(t-.55)/.57)
 return blend(launch_pose(),FLY,(t-1.12)/.88)
def launch_pose():
 q=blend(CROUCH,FLY,.58);q['LowerTorso']=cf(y=3.2,rx=-20);q['Head']=cf(rx=8);return q

def landing(t):
 upright=base();upright=blend(IDLE,FLY,.25);upright['LowerTorso']=cf(y=2.7,rx=-6);upright['UpperTorso']=cf(rx=-2);upright['Head']=cf(rx=1)
 if t<.65:return blend(FLY,upright,t/.65)
 if t<1.0:return blend(upright,CROUCH,(t-.65)/.35)
 u=float(smooth((t-1)/.8));q=blend(CROUCH,IDLE,(t-1)/.8);return legs(q,{side:([s*1.35,1.75,.18*(1-u)],0)for side,s in [('L',-1),('R',1)]})
G=json.loads((R/'geometry.json').read_text());FV={side:np.concatenate([np.array(m['v'])+m['center']for m in G['meshes']if m['node']=='Foot'+side])for side in ['L','R']}
def floor_guard(q):
 world={}
 for n in N:
  rest=np.eye(4);rest[:3,3]=P[n['name']]-(P[n['parent']]if n['parent'] else 0);world[n['name']]=(world[n['parent']]if n['parent']else np.eye(4))@rest@q[n['name']]
 floor=min((FV[side]@world['Foot'+side][:3,:3].T+world['Foot'+side][:3,3])[:,1].min()for side in ['L','R'])
 if floor<0:q['LowerTorso'][1,3]-=floor
 return q
clips=[]
for name,dur,count,loop,fun,priority,markers in [('Idle',4,121,True,idle,'Idle',[]),('Walk',1.2,37,True,lambda t:locomotion(t),'Movement',[(0,'FootL'),(.6,'FootR')]),('Run',.8,25,True,lambda t:locomotion(t,True),'Movement',[(0,'FootL'),(.4,'FootR')]),('Takeoff',2,61,False,takeoff,'Action',[(17/30,'ThrustersOn')]),('Flight',1.8,55,True,flight,'Action',[(0,'ThrustersOn')]),('Landing',1.8,55,False,landing,'Action',[(.9,'ThrustersOff'),(1,'Touchdown')])]:
 frames=[]
 for t in np.linspace(0,dur,count):
  q=floor_guard(fun(float(t)));frames.append({'time':round(float(t),7),'poses':{n:np.round(q[n],8).tolist()for n in names}})
 if loop:frames[-1]['poses']=frames[0]['poses']
 clips.append({'name':name,'duration':dur,'loop':loop,'priority':priority,'frames':frames,'markers':[{'time':t,'name':m}for t,m in markers]})
(R/'clips.json').write_text(json.dumps({'clips':clips},separators=(',',':')))
print([(q['name'],len(q['frames']))for q in clips])
