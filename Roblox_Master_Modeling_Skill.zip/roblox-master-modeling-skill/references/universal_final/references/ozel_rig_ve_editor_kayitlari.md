> KULLANIM: Bu modülü yalnız güncel istekte ilgiliyse uygula. Örneklerdeki modele özgü ölçü/renk/klip/stil evrensel kural değildir. Araç açıklaması native doğrulama garantisi vermez. Üst sözleşme: `../FinalPRO.txt`.

# Referans karakteri / özel rig / Clip Editor / kalıcılık

## Yeni dersler
- Kullanıcı yalnız kendi rig ve kliplerini istiyorsa oynanabilir Humanoid/uçuş kontrolcüsü ekleyerek kapsamı büyütme. Statik model, kendi rigli model, yerel düzenlenebilir klip ve yayımlanmış gameplay animasyonu dört ayrı teslimdir.
- Referansın ölçüsünü netleştir: mecha örneğinde 24 stud, altı klip Idle/Walk/Run/Takeoff/Flight/Landing. Koleksiyon etiket/stud/timer istekleri bir robota taşınmaz.
- Ön/arka/yan/¾ ve baş yakın planındaki şekillerden ortak 3B iskelet kur. Büyük form, ikincil plakalar, gerçek açıklıklar ve küçük mekanikler ayrı değerlendirilir. Yalnız vida sayısını artırmak referans sadakati değildir.
- Her rijit segmentin eklem pivotu aynı kaynak koordinatında tanımlansın. Görseller bu segmente weld edilir. `Motor6D.C0/C1` rest uzayları ile `Pose.CFrame` delta uzayı birbirine karıştırılmaz. Meshleri dünyada oynatmak tek başına düzenlenebilir klip oluşturmaz.
- Native klip: `KeyframeSequence → Keyframe → Pose` ve tam parça-adı/ebeveyn ağacı. Sabit root Pose Weight=0, hareketli eklemler=1. Tek motor ebeveyni, bağlantılı ağaç, benzersiz Pose adları doğrulanır.
- `rig.AnimSaves` **ObjectValue** olmalı ve ServerStorage.RBX_ANIMSAVES içindeki rig kayıt konteynerini göstermeli. Aynı rig için her klibe ayrı konteyner ve eski AnimSaves Folder üretme. Konteyner ObjectValue kullanıldığında Value=rig; tüm klipler onun doğrudan çocuklarıdır. Mevcut geçerli bağlantıyı kullan, düzenlenmiş kayıtların üzerine sessizce yazma.
- Resmi belge `rig.AnimSaves.Value.[SavedAnimation]` yolunu tarif eder. Yeni AnimationGraph/Clip Editor sürümlerinin native UI keşfi, bu veri yapısının offline doğrulanmasıyla kanıtlanamaz. Studio'da altı kaydın Load listesinde görünmesini ayrıca test et.
- Modeli seçmek, kapalı Clip Editor'ı kendiliğinden açmaz. Doğru iş akışı: Animation/Clip Editor aç → rig seç → Load → timeline scrub/keyframe düzenle.
- `PrimaryPart` assembly root garantisi değildir. Sabit kök için anchoring/RootPriority/gerçek AssemblyRootPart'ı native incele. Diğer helper/görsel parçalar massless, yanlış anchored parça yok.
- Ayak hedefli IK sadece veriyi yazarken kullanılabilir; sonuç gerçek Pose anahtarlarıdır. Sadece ayak pivotunu değil, gerçek taban üçgenlerini de zemine göre denetle. Bu, ara keyframe native interpolation ve tüm zırhların kendi arasında çarpışma testi değildir.
- Athletic run için karşı kol, dirsek kıvrımı, yüksek diz, gövde eğimi; yatay uçuşta kök eğimi, ileri bakan baş, nozul ekseni, etek/bindir hareketi birlikte düşünülür. Idle küçük nefes/baş/omuz/diz hareketi olmalı; parçalardan kopma ve abartılı salınım değil.
- Loop sonunu ilkine eşitle; Takeoff sonu Flight başlangıcı, Flight sonu Landing başlangıcı ve Landing sonu Idle başlangıcını doğrula. Bu sadece C0 sürekliliği testidir; ara hız/ivme ve görsel kalitenin yerine geçmez.
- 30 FPS'ye yazılan anahtarlar native timeline ızgarasına oturur. Yoğun sinüs/IK örneklerinde her aralığa Cubic InOut koymak her anahtarda dur-kalk yaratabilir; örneklenmiş düzgün eğri + Linear quaternion interpolation bilinçli seçim olabilir.
- RegisterAnimationClip'in geçici Studio ID'si yayınlanmış AnimationId değildir. KeyframeSequence/ServerStorage kayıtları istemciye otomatik replike olmaz; gameplay için doğru sahiplikle publish gerekir.

## Kalıcı mesh aktarımı
- Session-scoped opaque mesh içeriğini Play/save/publish sonrası kalıcıymış gibi sunma. Önceki koleksiyonun oyunda bozulduğuna dair kullanıcı ekranı var; kesin kök neden tanısı yok. Kullanıcı onarım istemediyse onarma.
- GLB/OBJ → 3D Importer → **Upload to Roblox** → yayımlanmış gerçek MeshId → clone/weld yolunu kullan. İzinleri oyun sahibi/grup ile eşleştir. ID uydurma ve eksik mesh için kutu fallback'i yapma.
- glTF tek geometriyi Model→Model→MeshPart olarak katmanlayabilir. Eşleme çocuklara rekürsif iner; benzersiz mesh key'i mesh veya üst Model adında bulur. Bir key için iki primitive çıkarsa sessizce birini atma.
- Mesh asset'in yerel merkez/boyutunu kaydet. Translation-only kaynak node dönüşümleri belirsiz bake/eksen dönüşlerini azaltır; yine de native importta eksen/bounds/pivot test edilir. Ölçek 24-stud joint ve CSG tarifine de uygulanır.
- Aynı eklem+materyal içindeki detayları gruplamak draw-call sayısını azaltma stratejisidir; 129 grup içinde yüzlerce katman olabilir. Bu ölçüm FPS garantisi değildir. Semantik OBJ ve üretici kaynak korunmalı.
- Native CSG tarifleri seed/cut boyutu ve ekleme göre konumu taşır. Offline manifold boolean, native UnionOperation başarısı değildir. Native işlem başarısızsa rollback et; Part'ı Union diye adlandırma.
- Offline HTML, tüm kütüphane/data inline olursa ağsız file preview'da çalışabilir. Gerçek geometri ve aynı quaternion FK kullan; yazılım WebGL/temsili shader diye etiketle. Native UI görüntüsü taklidiyle doğrulama varmış gibi davranma.

Dayanaklar:
https://create.roblox.com/docs/animation/editor
https://create.roblox.com/docs/studio/importer
https://create.roblox.com/docs/reference/engine/classes/AnimationClipProvider
https://devforum.roblox.com/t/important-changes-for-the-animation-clip-editor-animsaves-folder/2732912
