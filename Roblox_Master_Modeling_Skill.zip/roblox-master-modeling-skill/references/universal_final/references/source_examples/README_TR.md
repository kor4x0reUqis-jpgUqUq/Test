# Kullanıcının hareket/model kaynak örnekleri
Orijinal ejderha.txt, ejderha2.txt, trex.txt kaynakları korunmuştur. Bu turda çalıştırılmadı veya native rig/animasyon başarısı olarak doğrulanmadı. Kullanıcı daha önce ejderha.txt hareketlerini tercih etti; bu yalnız hareket dili karşılaştırması içindir.

Gelecekte animasyon istenirse hareket mantığını incele; dosyaları kör kopyalama/çalıştırma. Runtime CFrame hareketini gerçek KeyframeSequence yerine sayma. Bu kaynakları mevcut 10 modele uygulatma: bu modeller için animasyon istenmedi.
