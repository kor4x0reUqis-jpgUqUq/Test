# 01 — Referansı ölçülebilir model planına dönüştürme

## 1. Görseli parçalara değil, yapıya ayır
Önce konunun kimliğini taşıyan 3–5 özelliği yaz: kütle dağılımı, ana dış hat, karakteristik kesit, açıklık veya yapısal bağ. Sonra bölgeler ve bağlantılar çıkar. Renkleri kapatsan kimliği kaybolan bir tasarımda yalnız palet üzerinden ilerleme.

Referans envanteri oluştur: dosya/hash, görünüş, okunabilen bölgeler, örtülen bölgeler, perspektif/ışık etkisi. Aynı isimli iki yükleme aynı kaynak değildir. Silueti seçili nesne çerçevesinden, gölgeden, zeminden ve başka karakterlerden ayır.

## 2. Ortak koordinat sistemi
İşin başında eksenleri ve ön yönü sabitle. Roblox için +Y yukarı, ön -Z kullanılabilir; farklı kaynakta dönüşümü açıkça kaydet. Orijin: taban teması, gövde merkezi veya işlevsel pivot; hangisini seçtiğini belirt. Görsel model, rig ve CSG reçetesi aynı birim/eksen mantığını kullanmalı.

Toplam boyut ile ana gövde boyutu farklıdır:
- Ana gövde sınırı: aksesuar/anten/teker dışı kütle için açık tanım.
- Aksesuar dahil sınır: görünür son siluet.
- Taban/platform: varsa ayrı sınır.
Bir platformun boyu veya bir antenin yüksekliği gövdenin en-boy oranını doğruymuş gibi gösteremez.

## 3. Normalize edilmiş ölçü tablosu
Yeterince ortografik aynı görünüşte toplam gövde yüksekliğini H kabul et. Görselde bir aralığın uzunluğu p ve H'nin piksel karşılığı P ise yaklaşık oran r=p/P, hedef stud karşılığı r×hedef_H olur. Bu yöntem perspektifli resimlerde gerçek fiziksel ölçü garantisi değildir.

Ölçülecekler: ana genişlik, birkaç yükseklikte kesit genişliği, yan derinlik, taban uzunluğu/genişliği, bağlantı merkezleri, önemli kırılma/eğim noktaları, negatif boşluklar. Yalnız dış AABB ölçme; iki farklı kütle aynı AABB'ye sahip olabilir.

Her ölçüye kaynak ve güven yaz:
- Yüksek: açık, benzer ölçekte ortografik görünüş.
- Orta: perspektifli ama birden çok görünüşle destekli.
- Düşük: örtülü, belirsiz veya tasarım kararı.
Güven yüzdesi uydurma; karar gerekçesi yaz. Farklı perspektiflerin piksellerini doğrudan eşit ölçek sayma.

## 4. Landmark ve kesit istasyonları
Mutlak dış sınırın yanında konuyu taşıyan noktaları belirle. Örnekler: araçta dingiller/kabin köşeleri; canlıda eklemler; binada kat/çatı/kemer başlangıcı; bitkide kök/dal ayrımları; makinede gövde/kapak/şaft merkezleri.

Uzun eksen boyunca istasyonlar tanımla: başlangıç, genişleyen kesit, en dolu kesit, daralma, bitiş. Her istasyonda genişlik, derinlik, merkez kayması ve gerekiyorsa dönüş yaz. Her nesneye aynı sayıda ring/aynı dağılım dayatma; formun kırıldığı yerde istasyon gerekir.

## 5. Referans çelişkileri ve görünmeyen taraf
Çizimlerde görünüşler küçük ölçü farkları taşıyabilir. Ana kimliği, fiziksel tutarlılığı ve birden fazla açıdaki desteği değerlendir; sessizce rastgele birini seçme. Görünmeyen tarafta devam eden yapısal mantık kullanılabilir, fakat bunun tasarım kararı olduğu belirtilir. “Birebir” iddiası yalnız gerçekten gözlenen ayrıntı için yapılabilir.

## Çıkış kaydı
Çalışma kartında: eksen/orijin, H tanımı, gövde/aksesuar/taban sınırları, kritik oran tablosu, landmark listesi, belirsiz kararlar. Bunlar oluşmadan detay üretimine geçme. Kısıtlı brief'te her adım uzun bir rapor gerektirmez; kritik kararlar yine kaybolmamalı.
