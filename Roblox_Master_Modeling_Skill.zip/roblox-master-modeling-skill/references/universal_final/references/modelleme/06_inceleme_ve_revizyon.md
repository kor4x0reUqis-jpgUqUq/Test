# 06 — Modeli inceleme ve doğru seviyede revize etme

## İnceleme oturumunu sabitle
Kaynak ve çıktı sürümü, kameralar, ölçek, ışık, materyal modu, viewport/studio/Play ortamı kaydedilir. Seçim highlight'ı kapalı görünüm alınır. Karede başka model/karakter/taban varsa modelin kendi geometri/efektinden ayrılır.

Her kusur için: bölge, görünüş, kanıt, görünen sorun, olası neden, kesinlik, en küçük yeterli düzeltme, etkileyebileceği komşular ve yeniden test yaz. UNKNOWN bir nedeni kesin diye kapatma.

## Sorun → doğru müdahale katmanı
| Geri bildirim | Önce kontrol | Yanlış tepki |
|---|---|---|
| Zayıf/yassı | Kesit, derinlik, gövde-bağlantı kütlesi | Daha çok vida/stud/VFX |
| Bodur/şişkin | Ana oran, yükseklik kırılmaları, taban/aksesuar ayrımı | Bütün modele kör ölçek |
| Kutumsu | Kesit değişimi, eğim, taper, plane break | Sadece küçük bevel |
| Kopuk/yüzen | Parent/pivot, fiziksel temas ve bağlantı sınıfı | Her şeyi daha fazla gömmek |
| Detaysız | Hangi bölge/katman/mesafede eksik? | Her yüzeye rastgele greeble |
| Işıkta kayboluyor | Material/Bloom/ışık, normal ve yüzey geçişi | Sadece renderı koyulaştırmak |
| Studs yok/bozuk | İstenen yöntem, gerçek atama, yüz/yön/ölçek/UV | Texture child sayısı göstermek |
| Nozul düz disk | İç duvar, ağız kalınlığı ve derinlik | Daireyi daha koyu boyamak |
| Hareket bozuk | Eksen/pivot/rest uzayı ve hareket zarfı | Geometriyi statik pozda saklamak |
| VFX yok/yanlış yerde | Parent/Attachment/eksen/izin/tetik/reset | Başka karakterin ateşini göstermek |
| Oyunda bozuluyor | Kalıcı asset/izin, load/startup/save-reopen | Offline renderı kanıt saymak |

## Revizyon sırası
1. Kapsam/kurulum engeli varsa önce çöz; yanlış teslim yolu üzerine yeni ayrıntı ekleme.
2. Ana oran/kütle/siluet kusurları.
3. Bağlantı, kesit, açıklık ve hareket zarfı.
4. İkincil/üçüncül ayrıntı ve yüzey.
5. Gerekli rig/efekt/işlev; ardından kalıcılık ve performans etkisi.

Önceden doğru bir bölgeyi düzeltirken bozmamak için komşu ilişkilere tekrar bak. Yerel kalınlaştırma pivot/çarpışma/texture ölçeğini etkileyebilir. Bütün modeli yeniden üretmek her hatanın en küçük doğru çözümü değildir; kullanıcı onarım istememişse hiç müdahale etme.

## Geçişi kapatacak kanıt
- Siluet: benzer kamerada referans/önce/sonra ve ana ölçüler.
- Detay/birleşim: odak yakın planı ve destek/kalınlık görünüşü.
- Yüzey: native seçim kapalı görünüm + ilgili atamalar.
- İşlev: gerçek scrub/play/tetikleme/reset; tek resim animasyon kanıtı değil.
- Kalıcılık: tekrar açma/Play ve gerekiyorsa yayın/owner testi.

PASS yalnız denenen kapsamda. Kullanıcı reddettiyse eski offline PASS'i öne sürerek o sorunu kapatma. Güvenilir görsel kalite için tek 0–100 puan üretme; açık kusur ve kabul kanıtı daha değerlidir.

## Çalışma kartıyla bağlantı
`templates/Modelleme_Calisma_Karti.md` tasarım niyetini, `Bolge_Kapsama_Matrisi.csv` nerelerin kontrol edildiğini, `Revizyon_Kaydi.csv` neyin değiştiğini tutar. Şablon doldurmak test yapmak değildir. Belirsizliği görünür kılmak ve yanlış katmanda çalışma döngüsünü önlemek içindir.
