# 04 — Detay hiyerarşisi, temiz birleşim ve yüzey işçiliği

## Birincil/ikincil/üçüncül katman
- Birincil: konuyu taşıyan ana hacimler ve dış hat.
- İkincil: kabuk/kapak, yapısal destek, girinti/çıkıntı, büyük panel, dal/kat/kanat gibi alt yapılar.
- Üçüncül: perçin/vida, küçük seam, damar, lamel, kilit ve mikro yüzey.

Bunlar sabit parça yüzdesi değildir. Ana formun hangi mesafeden okunacağını düşün. Uzak silueti bozmayan mikro detayın yüküyle modeli doldurma; yakın odakta boş yassı yüzey bırakma. Sessiz geniş yüzey ve yoğun odak alanı bilinçli dağıtılır. Her yüzeye eşit rastgele çizgi profesyonel detay değildir.

## Her detaya gerekçe sor
Taşıyor mu, açılıyor mu, soğutuyor mu, bağlanıyor mu, korunuyor mu, büyüyor mu, su/ışık geçiriyor mu? İşlevsiz süs stilin parçası olabilir; ama bütün yüzeyi gerekçesiz greeble'a çevirme. Referanstaki işlevsel ayrıntıyı süs resmiyle geçiştirme.

## Birleşim sınıfları
1. Sürekli yüzey: kütleler kesintisiz akmalı; dikiş/çizgi istenmiyorsa rastgele çatlak bırakma.
2. Montajlı parça: aralık, kalınlık, flanş/vida/kilit veya kaynak mantığı okunmalı.
3. Hareketli parça: menteşe/mafsal ve hareket payı görünmeli; sadece değen yüzey yetmez.
4. Organik birleşim: köken/taper ve akış mantığı; yapıştırılmış çubuk değil.
5. Kasıtlı floating tasarım: kullanıcı/referans bunu istiyorsa izinli; destekli montajmış gibi anlatma.

Yanlış boşluk görünce önce sınıfını belirle. Her şeyi birbirine gömmek veya bütün aralıkları kapatmak düzeltme değildir.

## Seam ve kenar disiplini
Büyük panel ayrımı gerçek geometri/boşluk/kanal olabilir. Mikro yüzey çizgisi texture/normal olabilir; ana derinliği map ile taklit etme. Seam kalınlığı mesafe/ölçek/stile göre seçilir, evrensel stud değeri yok. Aynı düzlemde üst üste yüzey z-fighting üretir. Köşe dönüşlerinde kanal devamlılığı ve kapak bitişi düşünülür. Vida seam'in üstünde/boşta durmamalı; taşıyacak kalınlık bulunmalı.

## Arka ve alt yüz kalite haritası
Bölge matrisi kullan: ön/arka/sol/sağ/üst/alt + kritik yakın plan. Her satır: kapsam, birincil form, ikincil yapı, bağlantı, yüzey ve test durumu. Görünmeyecek ve kapsam dışı kısımlar açıkça öyle etiketlenebilir. Görünecek arka yüzün boşluğunu ön renderla saklama.

## Studs/texture ve malzeme
Studs istenirse doğru türü uygula: Texture, eski SurfaceType ve fiziksel stud ayrı yöntemlerdir. İstenen yöntem açıkken diğerine sessizce geçme. Altı yüz istenirse gerekli yüzlerde ölçek/yön/tiling ve kenar sürekliliğini native incele. Mesh/Union eğrilerinde planar Texture nesneleri UV'nin eşdeğeri değildir.

Renk/material ayrımları geometrinin katmanını desteklemeli. Aşırı Neon/Bloom ile beyaz bölgelerde ayrıntıyı silme. Texture'ı ana kütle hatasının üstünü kapatmak için kullanma. Global ışığı kullanıcıdan habersiz değiştirerek modelin normal ortamda nasıl okunduğunu saklama.

## VFX'nin modellemeyle bağlantısı
Efekt istendiyse çıkış noktası ve bağlantı geometrisi önce tasarlanır. Alev boru/nozuldan, duman doğru ağzından, su uygun kanaldan çıkmalı. Attachment yerel ekseni yüzey/işlevle uyuşmalı. Kaynak tanımı veya başka bir karakterin ateşi bu modelin VFX'i değildir. Efekt açıldığında geometri kayboluyorsa ölçek/alpha/ışık azaltılır; eksik form efektle saklanmaz.

## Bitiş incelemesi
Nötr materyal, gerçek materyal, seçim kapalı native normal ışık. Odak yakın planı, uzak kamera, arka/alt. Kenar kalınlığı, birleşim, clipping ve yüzey işlevi ayrı notlanır. “Daha çok detay” diye belirsiz revizyon yerine hangi bölge/katman/mesafede hangi kusurun görüldüğünü yaz.
