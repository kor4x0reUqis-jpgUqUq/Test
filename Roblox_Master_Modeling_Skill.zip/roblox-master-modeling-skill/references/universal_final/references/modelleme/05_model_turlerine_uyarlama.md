# 05 — Aynı yöntemi farklı model türlerine uyarlamak

Bu dosya sabit geometri kalıbı vermez. Her türün farklı yapı mantığını hatırlatır. Renk, boyut, studs, VFX, klip veya iç mekân gereksinimi güncel talepten gelir.

## Karakter / robot / humanoid
Baş–boyun–gövde–pelvis–uzuv ilişkisini ve ön/yan kesitleri çöz. Kıyafet/zırhı taşıyan iskelet ve hareketli kabuk ayrı düşünülür. Yanlış dirsek/diz boşluğu, uzun çubuk boyun, dar bel ve yüzeyden kopmuş omuzlar sık kusurdur. Canlı anatomisiyle mekanik mafsal mantığı birbirine karıştırılmaz. El/ayak okunurluğu, gerçek destek ve hareket zarfı önemlidir. Her karaktere aynı iri göğüs/uzun bacak oranını dayatma.

## Yaratık / hayvan
İskelet hattı, omurga/pelvis/omuz kuşağı ve ağırlık dağılımı; ayak veya kanat kökleri. Siluet kimliği boynuz eklemekten ibaret değildir. Kas/yumuşak doku ve zırh/kabuk farklı yüzey geçişleri ister. Organik akışın üstüne rastgele top/silindir dizmekten kaçın. Türün taşıyıcı temaslarını ve anatomisini kaynakla karşılaştır. Fantastik anatomide de kendi içinde tutarlı bağlantı gerekir.

## Kara aracı / iş makinesi
Dingil merkezleri, dingil mesafesi, iz genişliği, teker/palet çapı ve yer açıklığı gövde detayından önce. Kabin/kaput/şasi oranı ve yan profil belirleyici. Tekerlerin gövdeye girme, yanlış yön, yere basmama ve aks uyumsuzluğu hatalarını kontrol et. Davlumbazlar gerçek boşluk, camlar gerçek açıklık/uygun yüzey, kapılar doğru çizgi/kalınlık taşımalı. Direksiyon/süspansiyon yalnız istenmişse işlevsel kurulur.

## Uçak / hava aracı
Gövde istasyonları, burun/kuyruk taper, kanat kökü ve planform; üst/yan görünüşü birlikte çöz. Kanat kesitini derin kutu veya sıfır kalın levhaya indirgeme. Motor/nozul iç derinliği ve iniş takımı bağlantıları anlamlı olsun. Fiziksel kontrol istendiyse statik uçuş pozu onun yerine geçmez. Kasıtlı stilizasyon teknik doğrulukla karıştırılmaz.

## Gemi / tekne
Omurga, en kesitler, baş/kıç ve borda eğrisi; su hattı ve güverte yüksekliği. Yalnız dikdörtgen kutu üstüne odalar yapma. Güverte yapılarını gövdenin taşıyabileceği ilişkiyle yerleştir. Korkuluk/direk/baca ve açıklıklar ölçekle uyumlu olsun. Su altı/iç mekân kapsamını ayrıca netleştir; görünmeyen alanı otomatik detay yükü yapma.

## Bina / kale / mimari
Plan, kat kotları, duvar kalınlığı, açıklık oranı ve çatı/kule ilişkisi. Kapı/pencere/kemer gerçek okunur derinlik taşımalı; koyu dikdörtgen her zaman delik yerine geçmez. Duvar modülleri köşede nasıl birleşiyor? Çatı duvara oturuyor mu? Tekrar elemanları bitiş/köşe parçası gerektiriyor mu? Taş/tuğla rastgele noise değil yapı düzeni taşımalı. Dış-only istekte bütün iç mekânı izinsiz yapma; iç istendiyse cepheyle işi kapatma.

## Bitki / ağaç / mantar / doğa
Büyüme akışı, gövde-kök ve dallanma hiyerarşisi. Taç kütlesini önce gruplar halinde çöz; sonra yaprak/çiçek. Tekrarlanan aynı şekillerden top yaratma. Yaprakların yönü, dal desteği ve boşluk dağılımı olsun. Taş/kaya formunda belirgin düzlem kümeleri ve erozyon mantığı; her yere aynı noise değil. Organik asimetri referansa bağlıdır, otomatik rastgelelik değildir.

## Obje / silah / ürün / makine
Ana işlev ve üretim mantığı. Tutulan/kullanılan yüzeyler, kapak/yuva/şaft/namlu/kol gibi öğelerin ölçeği ve bağlantısı. İnce detayları ana ergonomiyi/şekli bozmadan ekle. Nozul/namlu veya yuvanın içi gerekiyorsa gerçek cavity. Ürün yüzeyinde temiz highlight, doğru bevel ve tutarlı birleşim; kirli greeble her stile uygun değildir.

## Koleksiyon / çoklu set
Önce modellerin yapısal çeşitlilik tablosunu kur: siluet, kütle düzeni, kesit, açık/kapalı form, odak detayı. Sadece palette/isim değişikliği çeşitlilik sayılmaz. Ortak dil kullanılabilir ama aynı ana gövdeye farklı aksesuar yapıştırma döngüsüne düşme. Referans/stil ortaklığı oranların birebir kopyası değildir. Etiket, studs, animasyon ve VFX yalnız güncel kapsamda istenir.

## Karışık tür
Örneğin yürüyen bina, organik makine veya uçan bitki: ilgili yapı mantıklarını birlikte kullan. Bir türün kuralını diğerine kör uygulama. Ortak ağırlık merkezi, bağlantı, malzeme geçişi ve işlev zinciri açıklanabilir olsun.
