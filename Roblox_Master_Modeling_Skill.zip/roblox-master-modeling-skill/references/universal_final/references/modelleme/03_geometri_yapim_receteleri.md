# 03 — Uygulanabilir geometri yapım reçeteleri

Reçeteler tek modele özgü hazır script değildir. Boyut, kesit ve yöntem referansa göre seçilir. Hangi yöntemin kullanıldığı kaynakta izlenebilir olmalı; native CSG/mesh kalıcılığı ayrıca doğrulanır.

## A. Çok kesitli loft — gövde, kabuk, kök, organik uzuv
1. Uzun eksen ve istasyon konumlarını seç.
2. Her istasyonda kapalı çevrim noktaları üret; tutarlı winding ve eşleşen nokta sırası kullan.
3. Ringler arasında yüzler kur. Nokta sayıları farklıysa kontrollü yeniden örnekleme veya açık topoloji geçişi yap; rastgele indeks bağlama.
4. Gerekiyorsa uçları doğru triangülasyonla kapat.
5. Kesit merkez kayması/bükülme ile profil oluştur; yalnız global Size büyütme kullanma.
6. Twist, ters normal, öz-kesişim, aşırı daralma ve sıfır alanlı üçgen denetle.

Sert yüzeyde seçili plane break; organikte akıcı eğrilik. Her şeyi sekizgen aynı loft gövdesinden türetmek çeşitlilik değildir.

## B. Bevel/chamfer'lı kütle — zırh, ürün, taş kenarı
Ana yüzleri ve hangi kenarın ışık yakalaması gerektiğini belirle. Kenar kırığını ölçekte okunacak kadar ver; her kenara aynı bevel'i zorla uygulama. Ana formun oranını bevel ile yuvarlayıp kaybetme. İnce yüzeylerde bevel kesişmesini kontrol et. Sert/soft normal sınırları gerçek yüzey tasarımını izlemeli.

Primitif + uygun bevel yeterliyse gereksiz CSG kurma; özel profili dikdörtgen bevel kutuya indirgeme.

## C. Profilli ekstrüzyon — kanat/plaka, kemer çerçevesi, yaprak
Önce 2B konturu doğru tanımla; sonra kalınlık ve gerekiyorsa taper/katman oluştur. Düz konturu derin bir gövde yerine kullanma. Başlangıç/arka yüz ve yan duvarların normalini kontrol et.

**Kritik:** Concave veya delikli poligonda basit fan triangulation her durumda doğru değildir. Ear clipping, constrained triangulation veya uygun ayrıştırma kullan; delik çevrimlerini doğru ele al. “Watertight” kontrolü kendi içine geçen veya üst üste binen yüzleri tek başına yakalamaz. Gerçek konturu farklı açılarda ve kenar görünümünde incele.

## D. Katmanlı kabuk — gövde üstü zırh, kapak, cephe
Taşıyıcı/core → gerçek yapısal ara katman → dış kabuk/aplike şeklinde kur. Katmanlar her yerde eşit offset olmak zorunda değildir. Ayrım çizgisini yüzeyleri aynı düzleme bindirerek yapma. Açıklığın arkasında boşluk görünüyorsa iç yüz/astar veya gerçek cavity tasarla. Kalınlık son kenarda okunmalı.

Hareketli kapak ayrı rijit parça/pivot ister. Kullanıcıya edit granülerliğini söyle; katmanları tek mesh içinde batch etmek ayrı Part düzenlemesiyle aynı değildir.

## E. Gerçek oyuk/menfez — negatif hacim
1. Açıklığın işlevini ve sınırını belirle.
2. Cutter hacmini yüzeyi güvenle geçecek şekilde tasarla; coplanar bitişten kaçın.
3. Native kesim gerekiyorsa gerçek Subtract/CSG uygula ve sınıfı doğrula.
4. Kalın duvar, iç yüz, karanlık cavity, lamel ve varsa arka mekanizmayı anlamlı kur.
5. Cutter/seed artığını temizle; yüzey rengini/ölçeğini/konumunu kontrol et.

Siyah dikdörtgeni beyaz yüzeye yapıştırmak gerçek delik değildir. Lamel sayısı değil derinlik, boşluk ve kesit önemlidir. Delik görünür geometride doğru olsa da collision ayrıca kontrol edilir.

## F. İçi boş tüp/nozul — boru, baca, thruster, namlu
Dış ve iç kesiti, ağız kalınlığını, boğaz daralmasını, iç derinliği ve bağlantı flanşını ayrı düşün. Yalnız disk veya koyu daire kullanma. Ringleri iç/dış duvarlarla bağla, ağız kenarını oluştur; kapalı uç gerekiyorsa doğru yerde kapat. İç yüz normali cavity'ye bakmalı. Native CSG veya doğrudan özel mesh seçilebilir; ikisini aynı kanıt sayma.

## G. Mafsal/menteşe/şaft — hareket mantığı
İşlevsel eksen → iki taşıyıcı → mil/yatak → boşluk/kapak → hareket zarfı. Önce pivotu, sonra etrafındaki kabuğu tasarla. Menteşe iki parçayı gerçekten bağlamalı; yalnız dekoratif silindir olmamalı. Ayrı hareket eden parçaları Union'a kaynatma. Uç konumlarda collision/clipping ve koruyucu kabuk açıklığını incele.

## H. Dallanma ve organik yapı
Merkez akış/iskelet hattı oluştur. Dalı ana gövdeden gerçek bir geçişle çıkar; kabuğa yapıştırılmış bağımsız çubuk bırakma. Kesit taper, eğrilik ve kalınlık hiyerarşisi kullan. Doğal asimetri amaçlıdır; rastgele noise ile silueti boğma. Yaprak/taç kümeleri yön ve ağırlık ilişkisi taşır; hepsini aynı açıda/ölçekte saçma.

## I. Tekrarlanan elemanlar — tuğla, perçin, lamel, yaprak
Önce tekrarın yapısal düzenini tanımla. Referans düzenliyse gereksiz noise ekleme; organikse kontrollü varyasyon kullan. Köşe/kenar/bitiş parçaları normal orta tekrardan farklı olabilir. Texture veya gruplama uygunsa tek tek BasePart yerine kullan; siluet/boşluk/geometri gereksinimi kaybolmasın.

## J. Birleşik transform ve merkez yönetimi
Kaynak model uzayı, segment yerel uzayı ve dünya uzayını ayrı tut. Dönen bir parçayı dünya XYZ boyutlarıyla keyfi ölçeklemek yerel kesiti korumayabilir; non-uniform scale/shear etkilerini düşün. Mesh merkez/extent ile parça CFrame'i uyumlu olmalı. Offline görüntü doğru diye importer'ın dönüşüm davranışını varsayma.

## Ortak bitiş kontrolü
Normal/winding, degeneracy, açıklık, öz-kesişim, gereksiz örtüşme, kalınlık, triangülasyon, bounding/ölçek, semantik parent, native malzeme ve asset kalıcılığı. Geometri kapalı olsa bile görsel kütle ve referans sadakati ayrıca değerlendirilir.
