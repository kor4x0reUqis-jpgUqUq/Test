# 02 — Kütle, kesit ve siluet işçiliği

## Blockout bir teslim değil, teşhis aracıdır
Modeli önce az sayıda anlamlı ana hacimle kur. Blockout aşamasında düz primitifler kullanılabilir; son üründe kaba kutuların değişmeden kalmasını meşrulaştırmaz. Renk/texture/VFX kapalı, düz nötr materyalle incele. Sonra gerçek renkleri ekleyerek kontrolleri tekrarla.

## Dört ayrı okuma
1. **Siluet:** küçük resim boyutunda dış hat ve ana açıklıklar konuyu anlatıyor mu?
2. **Kütle:** önde/yanda/arkada ağırlık nerede toplanmış? Geçişler cılız veya aşırı şişkin mi?
3. **Kesit:** aynı dış sınır içindeki yüzeyler hangi düzlemlerle dönüyor? Yan derinlik yeterli mi?
4. **Bağlantı:** hacimler gerçek destek, eklem, kök veya birleşimle mi bağlanıyor; yalnız değiyor gibi mi?

## Yassılık teşhisi
Önden iyi görünen modeli yan ve ¾'ye çevir. Ön cepheye yapıştırılmış dekor, tek kalınlıkta levha, çok dar bel/bağlantı veya derinliksiz arka yüz varsa sorun üçgen sayısı değildir. Çözüm: doğru istasyon kesitleri, merkez kayması, ön/arka hacim ve taşıyıcı geçiş. Bütün modele tek eksende kör ölçek uygulama; bazı bölgeler doğruyken onlar da bozulur.

## Doluluk ve boşluk
Güçlü kütle istenen bölgede görünür kesiti büyüt; gereksiz iç dolgu ekleme. Her boşluk hata değildir: teker davlumbazı, kemer, dal arası, eklem aralığı, boru/nozul ağzı konunun kimliğini taşıyabilir. Her boşluk için neden yaz: işlevsel açıklık / hareket payı / tasarım / kazara kopukluk.

Kapalı manifold mesh matematiksel bir koşuldur. Kalın görünen, dengeli, estetik veya referansa sadık model anlamına gelmez. Tersine açık kabuk bilinçli bir yüzey tasarımı olabilir; fizik, normal ve kalınlık gereksinimleri yine çözülmelidir.

## İstasyonlarla form düzeltme
- Uzun eksendeki kesitlerin genişlik/derinlik/merkezini ayrı kontrol et.
- Eğimi yalnız bir Wedge ile geçiştirmek yerine formun gerçekten kırıldığı noktaları kullan.
- En dolu yer ile bağlantı boynu arasındaki değişim referansa uygun olsun.
- Ön ve arka yüzü aynı offsetle kopyalamak zorunda değilsin; ağırlık merkezi ve profil farklı olabilir.
- Dönüşümlü yüzeyde kontrollü plane break kullan; gereksiz ring eklemek biçimi iyileştirmez.

## Denge ve temas
Statik durumda destek alanları ile görsel ağırlık ilişkisini incele. Fiziksel olarak mümkün olmayan stilize tasarım açıkça istenebilir; kazara dengesizlikle karıştırma. Ayak/teker/taban temasında sadece pivot değil gerçek geometri kontrol edilir. İnce bir taşıyıcı ağır bir hacmi taşıyorsa bağlantı detayı mantıklı olmalı. Hareketli parçada sadece duruş değil hareket zarfı da değerlendirilir.

## Karşılaştırma düzeni
Aynı zoom/ölçekle ön, arka, iki yan, iki ¾; ilgiliyse üst/alt. Perspektif ve ışık sabit kalsın. Renkli ve nötr yüzeyli iki inceleme farklı kusurları gösterebilir. Arka görünüş eksikse ön renderla tamamlandı deme. Siluet ret verirse ana hacme dön; mikrodetaya yatırım yapmayı durdur.

## Blockout'tan çıkış
Kimlik okunuyor; ana ölçüler kaynağa bağlı; kritik kesitler/derinlik doğru; bağlantılar/boşluklar mantıklı; taban/aksesuar oranı gövdeyi yanıltmıyor. Bu, kullanıcının/native kabulün yerine geçen otomatik bir sertifika değildir.
