# 07 — Somut uygulama akışı: taş çeşme örneği

**Bu bir eğitim senaryosudur. Üretilmiş/native denenmiş model veya kullanıcıya yeni tasarım teslimi değildir.** Çeşme ölçüsü/stili başka modellere varsayılan olmaz. Gerçek işte referans ve kullanıcı şartları değiştirilir.

## Varsayımsal brief
Referansa sadık, dış mekânda kullanılacak taş çeşme. Ana hazne, taşıyıcı gövde, ağız/nozul ve taban okunacak. Kullanıcı rig/animasyon istememiş; su VFX'inin gerekip gerekmediği henüz net değil. İlk karar VFX'yi otomatik eklemek veya atlamak değil, kapsamı netleştirmek.

## 1 — Ana yapıyı çıkar
Kimlik: haznenin dolu kesiti, taşıyıcı gövdenin taper'ı, su çıkışının hazneyle yön ilişkisi, taş katmanlarının düzeni. Toplam boyu tabanla birlikte ve taban hariç ayrı ölç. Ön görünüşte genişliği; yan görünüşte hazne derinliğini doğrula. Görülmeyen arka tarafı birebir bildiğini iddia etme.

## 2 — Hacim planı
Taban / taşıyıcı / hazne dış hacmi / üst bitiş / çıkış ağzı olarak birkaç ana kütle. Hazne sadece ince önden plaka olursa ¾ görünümde yassı kalır. Gereksiz büyütmek yerine referanstaki dış–iç kesiti ve ağız kalınlığını doğru kur.

## 3 — Uygun reçeteler
- Taşıyıcı profil: birkaç anlamlı istasyonla taper/merkez değişimi; her halka aynı kutu değil.
- Hazne: dış hacim + uygun iç cavity. İç kenar kalınlığı ve taban yüzeyi korunmalı. Native CSG istenmişse gerçek kesim; sırf siyah alan ekleme değil.
- Taş modüller: düzenli kat/derz; köşe/bitiş taşları ayrı karar. Her taşı rastgele döndürmek taş işçiliği değildir.
- Ağız/nozul: içi boş tüp veya profilli ekstrüzyon; gerçek ağız kalınlığı ve taşıyıcıya flanş/taş geçişi.
- Astar/iç yüz: cavity içinde görülecek bölgeyi bitir; yalnız dış cepheyle tamamlandı deme.

## 4 — Detay ve yüzey kararı
Referans sade işlenmiş taşsa rastgele mekanik vida/perçin ekleme. Büyük kenar kırığı, kat ayrımı, doğru oluk ve az sayıda anlamlı aşınma formu taşısın. Texture mikro taş hissini destekleyebilir; gerçek hazne derinliğinin yerine geçemez. Studs ancak kullanıcı bunu istiyorsa ayrı yüzey gereksinimi olur.

## 5 — Native ve kapsam kontrolü
CSG kernel sonucu hazneyi gerçekten açmış mı? Delik alt yüzeyi yanlışlıkla delmiş mi? Malzeme taş yüzeyini okunur gösteriyor mu? Kesiciler temizlenmiş mi? Collision oyuncunun hareketini bozuyor mu? Kurulum gereksiz özel asset yüklemesine bağımlıysa bu yol daha önce açıklanmış mı?

Su VFX'i istenirse: çıkış Attachment'ı nozul ağzında, doğru eksende, akış hazneye yönelmiş; açma-kapama/temizlik; su başka objeden geliyormuş gibi değil. Static/efektsiz istekse sırf güzel render için particle zorunlu yapılmaz.

## 6 — Örnek revizyon zinciri
- Geri bildirim: “Hazne ince bir levha gibi.” → Yan kesit ve cavity kalınlığına dön; taş noise ekleme.
- Geri bildirim: “Detaysız.” → Hangi mesafe ve hangi bölge? İç kenar/oluk/taş bitişi gerçekten eksikse ikincil yapıyı işle; her yere çizgi ekleme.
- Geri bildirim: “Su yok.” → Su kapsamda mı? Evetse native emitter/mesh akış yöntemini, kaynağı, parent/eksen/izin/tetiklemeyi denetle; renderdaki çizilmiş suyu kanıt sayma.
- Geri bildirim: “Oyunda boş/bozuk.” → Kalıcı geometri/asset/izin/load/CSG sonucunu native incele. Önceki kaynak renderının iyi olması bu hatayı geçersiz kılmaz.

## 7 — Başka türe transfer
Bu senaryonun hazne/nozul ayrıntılarını başka modele kopyalama. Transfer edilecek mantık: kapsam → referans/ölçü → ana kütle → doğru kesit/açıklık → anlamlı katman/yüzey → gereken işlev → native kabul. Aynı adımlar bir araçta dingil/gövde, bir ağaçta kök/dal/taç veya bir mimaride plan/duvar/çatı için farklı geometri kararları üretir.
