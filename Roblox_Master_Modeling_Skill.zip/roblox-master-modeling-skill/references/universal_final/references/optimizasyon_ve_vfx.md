# Ölçülebilir optimizasyon ve VFX
## Geometri
Ayrı raporla: Part, Texture, constraint, ışık, emitter, Beam, aktif parçacık tahmini. Kaynak sayısı FPS değildir. 50 modeli aynı anda göstermek tek modelden farklıdır.

Aynı renk/malzemedeki bitişik hücreler geometri korunarak birleştirilebilir; birleşim hücre kapsamını test et. Renk sadeleştirme yapıldıysa kayıpsız optimizasyon diye sunma. Birleştirilen yüzeylerde Texture UV fazı değişebilir. Kullanıcı altı yüz doku istiyorsa boşta duran binlerce mikro-Part'tan kaçın; bir Part altı ek Instance demektir.

## VFX
- Asset adı rolün kanıtı değildir. Particle/Trail adı verilmiş resim ikon olabilir. Thumbnail'i incele; native izin ve kullanım hakkının ayrıca kontrol edilmesi gerektiğini belirt.
- Haze için yumuşak doku/düşük alpha; elektrik için kısa ömür/az sayı; glint için küçük boyut; Beam için doğru uçlar, genişlik ve TextureMode. İlgisiz görüntüyü esneterek efekt uydurma.
- Sürekli full-screen beyaz Neon/Bloom gövdeyi siler. Okunaklılık için emisyonu kontrol et; oyunun Lighting ayarlarını izinsiz değiştirme.
- Kamera uzaklığına göre yerel emitter/Beam kapatma, eşik histerezisi ve düşük sıklıklı kontrol kullan. Her kare bütün Part CFrame'lerini yazmak optimizasyon değildir.
- Native VFX görüntüsünü yazılımsal geometri PNG'sinde varmış gibi gösterme. Snapshot tahmini ise açıkça söyle.
