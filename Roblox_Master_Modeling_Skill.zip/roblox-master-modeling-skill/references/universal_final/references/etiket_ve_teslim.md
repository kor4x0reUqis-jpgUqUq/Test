# Etiket ve teslim
- İsim/nadirlik/Clock/sabit süre istenmişse ekstra ikon/kart ekleme. Yeni referanstaki panel, önceki panelsiz talebi otomatik olarak geçersiz kılmaz.
- Montserrat: Font.new('rbxasset://fonts/families/Montserrat.json', weight, style). Native FontWeight ile önizleme değişken font ağırlığını eşleştir.
- TextWrapped/TextScaled ayar sırası, UITextSizeConstraint ve world/pixel billboard boyutu birlikte değerlendirilir. Native ekranda isim küçükken süre büyük çıkıyorsa kaynak testiyle düzeldiğini ilan etme; motor görüntüsü gerekir.
- Etiket ankrajı en üst aksesuar sınırından türetilir. Uzaklık kesmesi ve AlwaysOnTop seçimi önemlidir; her kamerada etiket çakışmaz garantisi verme.
- Ana teslim ZIP istenmişse ZIP'i görünür sun. `.luau` kurulum, kaynak, gerçek veriden PNG, CSV/metrik ve açık test raporu ekle. `.rbxmx` istemeyen kullanıcıya XML kurulum yaklaşımını tekrarlama.
