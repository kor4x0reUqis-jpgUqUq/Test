# Modelleme işçiliği — giriş ve uygulama yolu

Bu bölüm artık yalnız kısa bir kural listesi değildir. Her model türüne uyarlanabilen çalışma yöntemi, yapım reçetesi, inceleme ve revizyon şablonları içerir. Gerçek model üzerinde çalışırken aşağıdaki sırayı kullan. Referans ve gereksinim belirlemeden şablondaki örnekleri model tarifi sanma.

## Okuma / uygulama sırası
1. `modelleme/01_referans_ve_oran.md` — referansı ölçülebilir, belirsizlikleri görünür bir tasarım dosyasına çevir.
2. `modelleme/02_kutle_kesit_ve_siluet.md` — doğru birincil hacim; dolu görünüm, kesit ve negatif boşluk.
3. `modelleme/03_geometri_yapim_receteleri.md` — düz kutu dışına çıkmak için somut geometri yöntemleri.
4. `modelleme/04_detay_birlesim_ve_yuzey.md` — anlamlı katmanlar, temiz bağlantı ve doğru yüzey.
5. `modelleme/05_model_turlerine_uyarlama.md` — karakter, organik, araç, mimari ve obje için farklı yapım mantıkları.
6. `modelleme/06_inceleme_ve_revizyon.md` — kusuru hangi seviyede düzelteceğine karar ver; kabul kanıtını kaydet.
7. `modelleme/07_ornek_is_akisi.md` — bir çeşme üzerinde yöntem transferini gösteren eğitim senaryosu.
8. `../templates/Modelleme_Calisma_Karti.md` — yeni işte doldurulacak çalışma dosyası.
9. `../templates/Bolge_Kapsama_Matrisi.csv` ve `../templates/Revizyon_Kaydi.csv` — yüz/bölge eksikliği ve revizyon takibi.

## Ana ilke
Birincil form reddedildiyse üçüncül detay ekleyerek ilerleme. Kullanıcının “zayıf” dediği gövdeyi kapalı manifold testiyle veya yüksek parça sayısıyla savunma. Ana gövdeyi anten/kanat/taban dahil AABB'den ayır. Genişliği doğru ama derinliği yetersiz form ¾ görünümde yine yassı kalır.

Ağırlık/denge, referans sadakati, anlamlı açıklık, gerçek bağlantı ve tüm ilgili görünüşlerde tutarlı işçilik ölçülür. Bunların hiçbiri tek bir sayısal güzellik puanına indirgenmez. Her model kalınlaştırılmaz: narin, boşluklu veya hafif form referansın özelliğiyse korunur.

## Bu ekin sınırı
Reçeteler çalışma yöntemidir; native onaylı hazır model değildir. Şablonlar kaliteyi belgeleme aracıdır; doldurulmuş kutular görsel/native kabulün yerine geçmez. Eski reddedilen modeller onarılmadı ve onaylı örnek yapılmadı.
