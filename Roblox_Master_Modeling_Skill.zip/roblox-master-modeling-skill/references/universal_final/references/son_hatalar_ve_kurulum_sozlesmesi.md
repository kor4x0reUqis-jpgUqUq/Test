# Hatalardan türetilmiş EVRENSEL üretim ve kurulum kuralları

Bu dosya bir modelin yapım tarifi değildir. Vaka ayrıntıları `cases/` altında kalır; buradaki dersler her model türünde güncel talebe uyarlanır.

| Gözlenen/raporlanan hata | Evrensel ders | Doğrulama |
|---|---|---|
| Zayıf/yassı/boş/bodur ana form | Ana kütle ve kesit önce çözülür; mikro detay çözüm değildir | Benzer kamerada ön/yan/¾ ve referans kıyası |
| Detaysız veya hatalı bölgeler | Tüm ilgili yüzlerde semantik ayrıntı, doğru bağlantı ve kalınlık | Yakın plan, arka/alt/üst; sahte eklem/kesişim denetimi |
| Çok mesh/sayaç ile kalite savunması | Sayılar maliyet metriğidir, görsel kabul değildir | Kullanıcı gereksinimiyle ayrı değerlendirme |
| İstenen studs texture yok | Texture/SurfaceType/fiziksel stud farkı; doğru yüzlere gerçek uygulama | Native tiling/yön/UV; child count yeterli değil |
| İstenen VFX yok veya modelden kopuk | Tanım/ID değil, doğru parent/eksen/durumda çalışan efekt | Native tetikleme/stop/reset ve izin testi |
| Aşırı beyaz/parlak yüzey | Material/Lighting/Bloom/texture seçimlerini ayır; detay okunurluğunu koru | Seçim vurgusu kapalı, normal ışıkta görüntü |
| Zor çok-aşamalı kurulum | Kurulabilirlik mimarisini üretimden önce çöz; kod önceliğine uy | Temiz Studio'da gerçek minimum adım akışı |
| GLB tek başına bütün teslim sayıldı | Format kapasitesi ile dosya içeriği farklıdır | Materyal/rig/klip gerçekten var mı, native aldı mı? |
| Kodda/JSON'da klip var, kullanıcı açamıyor | Erişilebilir native klip ayrı kabul kapısı | Model seç → liste → scrub/play/edit/save |
| Offline boolean Union sayıldı | Native sınıf ve kernel sonucu ayrı | UnionOperation, gerçek delik ve kesici temizliği |
| Play'de bozulma/kalıcılık belirsiz | Geçici opaque içerik kalıcı mesh değildir | Save/close/reopen/Play/publish ve owner izinleri |
| Sadece renderla iş tamamlandı | Render test edilen geometriyi gösterir, native başarıyı değil | Native görünüm/işlev/persistence bağımsız |
| Evrensel prompt tek modele bağlandı | Konu/ölçü/renk/klip yeni talepte belirlenir | Genel promptta modele özgü zorunluluk olmaması |
| Yalnız belge isteğinde modele müdahale | Güncel iş emri sınırına uy | Model/kurucu/asset değişmedi kaydı |

## Texture ve VFX kapsamını doğru genelle
Bir işte studs/VFX eksikliği kullanıcı tarafından bildirildiyse bunu kaydet. Sonraki her modele otomatik aynı texture/efekt ekleme. Yeni istekte satırları GEREKLİ/İSTENMİYOR/BELİRSİZ yap. Açık isteneni atlama; istenmeyeni eski hataya tepki olarak zorla ekleme.

## Kolay kod kurulumunun gerçek sınırı
Kalıcı özel mesh için upload/asset izni gerekebilir. Bunu baştan anlat. Sıfır-upload ile her ortamda sınırsız özel kalıcı mesh vaadi de, onaysız all-Part/kutu indirgemesi de yanlıştır. Seçilen yol sonradan sürpriz olmamalı. Kod renk/yüzey/rig/işlev bağlarını tek anlaşılır akışta kurmalı; hata halinde rollback yapmalı.

## Kanıt disiplinini koru
Kullanıcı ekranı görünür sonucu destekler; UV, izin, emitter etkinliği veya editor sürümü gibi kesin nedenleri tek başına teşhis etmez. Seçim vurgusu/ışık/asset/kurulum olasılıklarını kanıtla ayır. Kullanıcının karşılanmamış gereksinimini kodda nesne bulunduğunu söyleyerek geçersiz sayma.

## Başarı şablonu değil, hata vakası
Reddedilen geometri ve eski scriptler yalnız açık etiketli vaka olarak saklanır. Yeni modelde uyarlanabilir mantık öğrenilir; aynı yanlış gövde veya kurulum zinciri varsayılan yapılmaz. Mevcut vaka ayrıntıları ve kullanıcı ekranları `cases/Mecha24_USER_REJECTED/` altındadır. Bu güncelleme model tamiri değildir.
