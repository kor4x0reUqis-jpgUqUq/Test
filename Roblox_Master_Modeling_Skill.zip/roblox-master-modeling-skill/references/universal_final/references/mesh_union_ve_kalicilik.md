> KULLANIM: Bu modülü yalnız güncel istekte ilgiliyse uygula. Örneklerdeki modele özgü ölçü/renk/klip/stil evrensel kural değildir. Araç açıklaması native doğrulama garantisi vermez. Üst sözleşme: `../FinalPRO.txt`.

# MeshPart, CSG ve kalıcılık — yeni kalite kapısı
- Model çeşitliliği, aynı kademeli gövdenin farklı renkleri değildir. Silueti ve negatif boşluğu değiştir: açık reaktör, şişe, kabuk, çerçeve, ikiz kule, kıvrımlı kök gibi gerçek yapısal kararlar.
- Model oranını ana gövde, tüm aksesuar silueti ve taban için ayrı değerlendir. “Daha dolgun” talebine cevap verirken bütün modelleri basık piramide çevirmek yanlıştır.
- Detay yalnız Part sayısıyla ölçülmez. Yaprak/perçin/tüp gibi ayrıntıları aynı materyalli semantik MeshPart gruplarında birleştir; fakat edit granülaritesinin değiştiğini söyle. Kaynak OBJ ve üretici gerekir.
- Union kullanıldı demek için native UnionAsync/SubtractAsync çıktısı gerçekten UnionOperation olmalı. Bir Part'ın adını Union yapmak, offline boolean sonucu veya Studio dışı görüntü native CSG kanıtı değildir.
- Negatif boşluk gerçek geometri kesimi olmalı. Kesim hacmi azalıyor mu, sonuç kapalı mı, kaynak doğru mu offline kontrol et; native kernel'i ayrıca test et.
- MeshPart ve EditableMesh farklı şeylerdir. CreateEditableMesh → vertices/triangles/UV/normals → CreateMeshPartAsync doğru native akıştır. Permission/memory/API hatasında kullanıcı MeshPart istemişken Part fallback yapma.
- CreateDataModelContentAsync bake ile EditableMesh bellek bütçesini serbest bırakmak mümkün olsa da opaque içerik oturum kapsamlıdır. Save/publish ile kalıcı URI-backed asset aynı şey değildir. AssetService dokümanı ve 2026 static Content duyurusunu kontrol et.
- Kalıcı üretim: kendi OBJ/meshlerini kullanıcıya upload ettir, gerçek Mesh ID eşlemesini kullan. ID uydurma, otomatik/izinsiz publish yapma. Source-only kurulum ve doğru mesh merkez/extent verisi, kapalı Mesh API durumunda gerekli olabilir.
- Kalıcı model tesliminde session-scoped bake/rebuild yolunu kalıcı upload yerine kullanma. Geçici prototip ayrıca istenirse onu açıkça geçici diye etiketle; startup rebuild ve cold-start, kalıcı asset testinin yerine geçmez.
- Altı yön Texture child count testi UV/projeksiyon görünümünü kanıtlamaz. Görünmez ankrajlara dekor texture gerekmez. Native MeshPart/Union yüzeyini farklı açılardan kontrol et.
- Neon geometri + oyunun Bloom'u detayları silebilir. Gövdeyi Plastic/uygun malzeme tutup çok küçük VFX, düşük LightEmission/Brightness kullan; global Lighting'i izinsiz değiştirme.
- Toplam object, material/texture ve üçgen bütçesi birlikte ölçülür. Az MeshPart yüksek üçgen/alpha maliyetini gizleyebilir; yalnız Part sayısıyla optimize/FPS garantisi verme.

Kaynaklar:
https://create.roblox.com/docs/reference/engine/classes/AssetService
https://create.roblox.com/docs/reference/engine/classes/EditableMesh
https://devforum.roblox.com/t/full-release-introducing-createdatamodelcontent-convert-editable-mesh-and-image-data-into-static-content/4541898
