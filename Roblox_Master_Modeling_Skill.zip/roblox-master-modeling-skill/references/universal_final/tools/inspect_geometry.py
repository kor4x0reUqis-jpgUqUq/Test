"""Offline geometry checks, NOT a native render/API/animation/performance test."""
import json,sys,math
from pathlib import Path
from collections import Counter
D=json.loads(Path(sys.argv[1]).read_text());objects=D.get('models',D.get('eggs'))
if objects is None and 'meshes'in D:objects=[D]
assert objects
parts=meshes=csg=faces=0
def inspect_mesh(v,f):
 assert all(math.isfinite(x)for p in v for x in p);edges=Counter()
 for a,b,c in f:
  assert min(a,b,c)>=0 and max(a,b,c)<len(v) and len({a,b,c})==3
  for i,j in [(a,b),(b,c),(c,a)]:edges[tuple(sorted((i,j)))]+=1
 assert all(n==2 for n in edges.values()),'Open/nonmanifold edge'
 return len(f)
for o in objects:
 for p in o.get('parts',[]):
  assert all(math.isfinite(v)and v>0 for v in p['s']);assert all(math.isfinite(v)for v in p['p']);parts+=1
 for m in o.get('meshes',[]):faces+=inspect_mesh(m['v'],m['f']);meshes+=1
 for q in o.get('csg',[]):geo=q.get('preview',q);faces+=inspect_mesh(geo['v'],geo['f']);csg+=1
print('GEOMETRY_OFFLINE_PASS',len(objects),'models',parts,'Parts',meshes,'MeshGroups',csg,'CSG previews',faces,'triangles')
