# Modelleme işçiliği genişletmesi — test kapsamı

## Belge/şablon güncellemesi
- Modelleme girişi uygulamalı okuma yoluna genişletildi.
- Yedi atölye bölümü: referans/oran; kütle/kesit; geometri yapım reçeteleri; detay/birleşim/yüzey; model türlerine uyarlama; inceleme/revizyon; somut eğitim senaryosu.
- Üç şablon: Modelleme_Calisma_Karti.md, Bolge_Kapsama_Matrisi.csv, Revizyon_Kaydi.csv.
- SKILL.md ve README yeni çalışma yoluna bağlandı. Örnek senaryo gerçek üretilmiş veya native doğrulanmış model olarak sunulmuyor.

## Kontroller
- Yeni belge ve şablon dosyalarının varlığı, UTF-8 okunması, modelleme girişindeki yerel başvuru yolları.
- CSV başlıkları, satır genişlikleri ve boş şablonların PASS iddiası taşımaması.
- Evrensel FinalPRO'nun önceki manifestle aynı kalması; kök kopyayla byte eşitliği.
- Ham VFX, üç özgün hareket örneği, negatif vaka geometri/klip/Factory/konsept/ekran kaynakları ve orijinal model ZIP hashlerinin korunması.
- Son ZIP'in CRC ve manifest SHA256 paritesi; eklenen atölye/şablonların gerçekten archive içinde olması.

## Sınırlar
Bu tur model üretimi/onarımı, renderer, native CSG/Studio/import, texture/studs uygulaması, rig/clip playback, VFX, kalıcılık veya FPS testi yapılmadı. Kullanıcı modelleme skills'ini geliştirmeyi seçti. Yeni yöntemler/şablonlar çalışma rehberidir; gerçek model üzerindeki uygulama başarısı veya native kabul sertifikası değildir.

Negatif vaka USER_REJECTED olarak kalır; kök neden UNKNOWN; yeni native test NOT_RUN. Eski offline ölçümler kullanıcı reddini geçersiz kılmaz.
