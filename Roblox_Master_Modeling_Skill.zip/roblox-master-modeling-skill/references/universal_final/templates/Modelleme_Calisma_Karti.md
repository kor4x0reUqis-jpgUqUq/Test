# Modelleme çalışma kartı — yeni işte kopyala ve doldur

Bu dosya boş şablondur; model tarifi ve başarı sertifikası değildir. `[...]` alanları yeni kullanıcı talebi/kaynağıyla doldurulur. Eksik veri PASS sayılmaz.

## A — Kapsam
- İş emri: [yeni model / onarım / varyasyon / yalnız belge / diğer]
- Konu ve oyun rolü: [...]
- Stil / referans / tasarım izni: [...]
- Kullanıcı özellikle istiyor: [...]
- Kullanıcı özellikle istemiyor / kapsam dışı: [...]
- Kritik açık soru / yanıt: [...]
- Kurulum yolu ve önceden açıklanan bağımlılıklar: [...]

## B — Referans kaydı
| Dosya/hash | Görünüş | Okunan bölge | Örtülü/belirsiz | Perspektif/ışık etkisi |
|---|---|---|---|---|
| [...] | [...] | [...] | [...] | [...] |

## C — Koordinat, boyut ve oran
- Birim / eksen / ön yön / orijin: [...]
- H tanımı ve hedef boy: [...]
- Ana gövde sınırı: [...]
- Aksesuar dahil sınır: [...]
- Taban/platform ayrı sınırı: [...]

| Landmark / ölçü | Kaynak | Normalize oran / hedef ölçü | Güven ve neden |
|---|---|---|---|
| [...] | [...] | [...] | [...] |

## D — Yapısal plan
- Kimliği taşıyan 3–5 özellik: [...]
- Birincil hacimler: [...]
- Kesit istasyonları: [konum / genişlik / derinlik / merkez kayması / dönüş]
- Negatif boşluklar ve nedenleri: [...]
- Bağlantı sınıfları: [sürekli / montajlı / hareketli / organik / kasıtlı floating]
- Görünmeyen taraf için tasarım kararları: [...]

## E — İkincil ve üçüncül işçilik
| Bölge | İkincil yapı | Üçüncül detay | İşlev/gerekçe | Gerekli kamera mesafesi |
|---|---|---|---|---|
| [...] | [...] | [...] | [...] | [...] |

## F — Teknoloji/yüzey/işlev
| Gereksinim | Gerekli / istenmiyor / belirsiz | Yöntem ve gerekçe | Kabul kanıtı |
|---|---|---|---|
| Part/Wedge/özel mesh/CSG | [...] | [...] | [...] |
| Renk/materyal/UV/PBR | [...] | [...] | [...] |
| Studs: Texture / SurfaceType / geometri | [...] | [...] | [...] |
| Rig / klip / kontrolcü | [...] | [...] | [...] |
| VFX / tetikleme / reset | [...] | [...] | [...] |
| Collision / interaction | [...] | [...] | [...] |

## G — İnceleme ve karar
- Nötr materyal + ön/arka/yan/¾: [durum ve kanıt]
- Gerçek yüzey + ilgili yakın plan: [durum ve kanıt]
- Native kurulum / görünüm / yüzey: [durum ve kanıt]
- İstenen işlev: [durum ve kanıt]
- Save/reopen/Play/publish: [durum ve kanıt]
- Performans: [kullanım senaryosu / ayrı maliyetler / gerçek ölçüm]
- Kullanıcı değerlendirmesi ve açık retler: [...]
- Sonraki revizyonun seviyesi ve nedeni: [...]

Durumlar: PASS / FAIL / USER_REJECTED / NOT_RUN / BLOCKED / UNKNOWN. Kaliteyi tek puanla değerlendirme; kusur ve kanıtı yaz. Açık ret varken üçüncül süsle kapatmaya çalışma.
