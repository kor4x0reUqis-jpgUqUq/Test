# Kullanıcının VFX kaynak havuzu
Kullanıcının daha önce sağladığı kaynak metin ve türetilmiş ID/katalog dosyalarıdır. Kaynak ID'ler değiştirilmez; anlamsal tekrarlar korunur. Bunlar model/script kurulumu değildir.

Her kullanımda asset rolü, thumbnail ve native erişim kontrol edilir. Listede Particle/Beam yazması görüntünün o rolde uygun olduğunu veya kullanım hakkı verildiğini kanıtlamaz. Yeni koleksiyonda bütün havuz değil, uygun doğrulanmış thumbnail alt kümesi kullanılmıştır.
