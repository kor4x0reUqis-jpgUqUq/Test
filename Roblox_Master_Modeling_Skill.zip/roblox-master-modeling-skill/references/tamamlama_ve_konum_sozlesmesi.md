> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

# Bölüm bütünlüğü, matematik ve konumlandırma sözleşmesi

## 1. Blok tabanlı ama işlenmiş hacim
Bu kullanıcı için ana vücut/gövde silindir, kapsül, tek tüp veya bunların dairesel panel dizisi olamaz. Kare/küp/dikdörtgen hacimler; farklı boy, genişlik, yükseklik, kırılma, kademe ve yönlerle ayrıntılı ana formu oluşturur.

Bu kural, kafayı tek dev küp bırakma izni değildir. Bir kurt başının en azından kafatası, alın, orbital kenar, yanak, burun kökü, burun ucu, çene ve boyun bağlantısı; bir kuşun gaga kökü, üst/alt gaga, göz çevresi ve arka baş geçişi işlenir. Bölge sayısı mekanik bir puan hedefi değil, anatomik görev kontrolüdür.

İşlevsel teker, motor ağzı veya optik halka gibi yerel yuvarlak mekanik detay gerekiyorsa bloklardan katmanlı çokgen geometri kurulabilir. Bu istisna bütün vücudu tüpe çevirme gerekçesi değildir. Kullanıcı özellikle primitive Cylinder isterse o yerel talep ayrıca değerlendirilir.

## 2. Tamamlama matrisi
Başlamadan önce modele özgü parça/alan listesi oluştur:
- Baş/burun/yüz/arka baş veya burun/kokpit.
- Göğüs/omuz, sırt, iki yan, karın/alt yüz.
- Kalça/arka gövde ve geçişleri.
- Her uzvun üst/alt segmenti, eklemi, eli/patisi/pençesi.
- Kanat kökü, iç/orta/dış kanat, ön/arka kenar, alt yüz.
- Kuyruk kökü, segmentler, uç.
- Araçta teker/iniş takımı, bağlantı, motor/egzoz, kapak ve erişim paneli.
- Gerekiyorsa iç mekân, iç duvarlar ve işlevsel açıklıklar.

Her bölge için `blockout / form / ikincil detay / yüzey / birleşim / görsel kontrol` durumunu tut. Bir bölge “gereksiz” ise açık gerekçe yaz. Büyük görünen bir alanı listeden çıkararak bitmiş sayma.

**Kural:** Kritik bölgelerden biri hâlâ blockout ise bütün model final değildir. Ön taraf tamamlanınca arka/alt yüzde detay seviyesini habersiz düşürme. Performans varyantı dışında bir uzvu ayrıntılı, eşini basit bırakma; kasıtlı asimetri gerekçeli olmalıdır.

## 3. Koordinat sözleşmesi
Önce eksenleri yaz: örneğin +Y yukarı, -Z ön, +X sağ. Hangi uzayın hangi değişkende tutulduğu isimde belli olsun: `modelLocalCF`, `boneRestCF`, `worldCF`, `socketLocalCF`.

- `partWorld = modelWorld * partModelLocal`.
- `detailBoneLocal = boneRestModelLocal:ToObjectSpace(detailModelLocal)`.
- `attachmentBoneLocal = boneRestModelLocal:ToObjectSpace(attachmentModelLocal)`.
- Motor ilişkisi: `childWorld = parentWorld * C0 * Transform * C1:Inverse()`.

World ofseti iki kez uygulanmaz; model-local konum doğrudan world sanılmaz. Yalnız translation ölçeklenir; rotasyon açıları ve birim eksenler ölçeklenmez. Ölçek tüm root, pivot, joint offset, geometri ve ilgili Attachment translation'ında aynı sözleşmeyle uygulanır.

Bir pivotun “yaklaşık omuzun yanında” olması yeterli değildir. Eklemin gerçek birleşim noktası üzerinden tanımlanır; parça merkezini sırf kolay diye eklem sanma.

## 4. Simetri ve dönüşüm
- Sağ/sol için tek `side` kullanmak yararlı; ama ayna almak yalnız X işaretini değiştirmek değildir. Yerel yönler, yüz yönü, rotasyon işaretleri ve asimetrik detaylar da kontrol edilir.
- Ayna matrisi negatif determinantlı olabilir; onu doğrudan geçerli rotasyon kabul etme. Sağ elli baz oluştur ve beklenen normal ile doğrula.
- Rastgele birkaç radian/degree karışıklığı birim eksen testinden geçebilir. Açı birimini açık tut; trig girdileri radian.
- lookAt için hedef ve fallback up, sıfır/parallel durumları ele alınır. LookVector'ün yerel -Z olduğu sözleşmesi unutulmaz.
- Matematiksel doğru üçgen yardımcı fonksiyonu yanlış a/b/c köşeleriyle çağrılırsa yine yanlış şekil üretir; sadece fonksiyon içi testi yeterli değildir.

## 5. Birleşim ve kapanış testleri
Her bağlantıya iki soket veya kontrol noktası tanımla. Komşuların rest ve kritik pozlarda socket world farkını ölç. Hedef tolerans ölçek ve birleşim tipine göre seçilir; hiçbir proje için sihirli sabit değildir.

Kesitler için:
- Kapak gereken açık uçları etiketle.
- Bağlanan halkaların çevre sırası/yönü, radyus/genişlik/yükseklik ve merkezleri uyumlu mu?
- Büyükten küçüğe geçişte omuz/transition/contour devam ediyor mu?
- Kapalı hacim ile kasıtlı ağız/giriş/egzoz ayrımı doğru mu?
- Açık ağızın karanlık bir düzlemden ibaret olmaması için yanak, damak, diş eti ve iç geçiş var mı?
- Gövde parçası içi boş sanılırken karşı yüzünden arka plan görünüyor mu?

Kapalı yüzeyde kenar komşuluğu ve winding kontrolü yapılabilir; WedgePart/solid parçalarla kurulan modellerde soyut üçgen ağı değil, gerçek hacim örtüşmesi ve görüntü de incelenir.

## 6. Pozitif boyut testinin ötesi
Gerekli ek kontroller:
- Beklenen dünya sınırı ve model içi bölge sınırı.
- Kontrol noktaları/soketler ve anlamlı mesafeler.
- Parçanın beklenen normaline karşı gerçek yönü.
- Sağ/sol landmark'ların simetrisi.
- Eklem açıldığında gap/intersection.
- Ayak/teker temas düzlemi ve yerden yükseklik.
- Baş/muzzle/gaga ve gövde oran aralıkları.
- Görünen yan/arka/alt yüzlerin bitmişliği.

Bir sanity testi başarısızsa epsilon'ı sonsuza büyütme veya parçayı gizleme. Önce uzay/pivot/veri sözleşmesini düzelt.

## 7. Tekerlek modelleme protokolü
1. Aks yönünü tek açık birim vektörle tanımla.
2. Teker merkezini strut/aks soketinden türet; her parçaya ayrı tahmini world koordinatı yazma.
3. Aksa dik ortonormal U/V düzlemi kur.
4. Çokgen sırt segment merkezleri `center + radius*(cosθ*U + sinθ*V)`; tanjant yönleri ve segment boyları aynı geometriden türesin.
5. Çemberi kapat: segment sayısı ile chord/tangent genişliği tutarlı; büyük açık boşluk veya aşırı sivri örtüşme olmasın.
6. Sadece sırt halkası yetmez: iç/dış yanak, jant yatağı, jant, göbek ve aks bağlantısı gerekir. Cıvata/fren/lastik sırt detayı istenen kaliteye göre eklenir.
7. Dış yarıçap, genişlik, axle yönü, göbek merkezliliği, strut uç noktası ve en alt temas yüksekliği doğrulanır.
8. Önden ve yandan bak: bir açıdan yuvarlak halka görünüp diğerinde eksik şerit olmamalı.

Tekerleği birkaç siyah blok ve ortada beyaz küple bitmiş sayma. Radyus yanlışlığını sadece daha fazla segmentle saklama.
