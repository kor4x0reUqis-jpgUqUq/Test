# Santral: negatif öğrenme, düzeltme emri değil
Kanıt: `../examples/santral_olumsuz_kanit/` içindeki üç kullanıcı Studio görüntüsü. Kullanıcı reddi kesin; her kusurun tam property/UV nedeni bu görüntülerden tek başına kesinleştirilemez.

| Gözlenen / kullanıcı reddi | Önceki yanlış kabul | Yeni engelleyici kapı |
|---|---|---|
| Küçük yüzlerde yarım X/studs veya kenarda taşmış gibi görünen motif | Her yüzeye aynı native/Weld veya sabit tile atamak yeterli | Kupon: en küçük/en büyük, kısa/uzun, eğimli yüz; faz, tekrar, bitiş, kenar ve fiziksel motif ölçeği yakın kontrol |
| Bazı görünen parçalar düz/dokusuz | İnce metal, korkuluk, bolt diye texture=False kabulü | Görünür her Part'ın uygulanmış yöntemi/yüzleri manifestte; sessiz istisna teslim engeli |
| Boru dönüşleri yapılmamış | Farklı yönlü cuboid beam uçlarını yaklaştırmak boru dirseği sayıldı | Giriş/çıkış soketleri, gerçek kesitli dirsek, uç normal yönü, kapanma ve yakın görünüş |
| İç içe parçalar / düzensiz ekler | Ortonormal CFrame, doğru parça sayısı ve temel XML kontrolü doğru birleşim sayıldı | Temas/derin gömülme/coplanan yüz/flanş ilişkileri ayrı incelenir; izinli birleşimler gerekçeli whitelist |
| TERMIK / 07 gibi kötü yazı | Asistanın uydurduğu marka ve SurfaceGui varlığı yeterli sayıldı | İstenmeyen yazı yok; istenirse içerik onayı, kenar payı, yön/ölçek, yüz üstüne oturma testi |
| VFX görünmüyor/istenen mevcut efekt kullanılmıyor | Catalog ID'sini emitter'a bağlamak, aday diye dipnot düşmek yeterli sayıldı | Kaynak/erişim/rol/gerçek görünüş ayrı; istenen son görünüm doğrulanmadan efekt tamamlandı denmez |

Kaynak kodunda ince beam'lere Smooth/texture=False atanması ve doğrulanmamış Ice/Fireball adaylarının farklı role uyarlanması önceki teslim mantığının eksikleridir. Bunlar bu görevde düzeltilmedi; model kodu yazılmadı. Kullanıcı kare boru istediği için çözüm otomatik yuvarlak silindir/torus yapmak değildir. Geometri, yüzey ve birleşim beraber tasarlanır.

## Yanlış başarı kanıtlarından vazgeç
1.948 parça, 1.952 XML Part'ı, ortonormal eksen veya derleme sonucu görsel başarı sertifikası değildir. Başarısız role sahip VFX'e dürüst bir dipnot eklemek kusuru çözmez. Yazılım önizlemesi ve kullanıcı Studio görüntüsü çelişirse engine görüntüsünü görmezden gelme; render kapsamını/algısını düzelt, başarısız kabulü geri çek.
