> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

# Sağlam duruş, yaratıcı hareket ve gerçek klip adları

## Üç ayrı poz
- **BindPose:** rig'in yapısal referansı. Açık kanat/uzuv teknik olarak burada bulunabilir.
- **ImportPose:** model ilk açıldığında görünen sunum pozudur. Final model burada tamamlanmış ve dengeli görünmelidir.
- **Idle:** oynatılan dinlenme davranışı. ImportPose ile çelişmemeli; runtime/izin gelene kadar T-pose'da beklemek çözüm değildir.

Bir attribute'a `ActiveClip=Idle` yazmak ImportPose'u düzeltmez. İlk açılış duruşu gerçekten geometri/rig üzerinde hazırlanmalı; bunun bind/rest ve kliplerle ilişkisi test edilmelidir. Motor C0/C1 veya bind pozunu değiştirip eski klipleri kontrolsüz bırakma.

## Sağlam duruş kontrolü
Yerdeki karakterde ayaklar aynı temas yüzeyine anlamlı biçimde basar. Destek çokgeni ve gövde projeksiyonu, kalça/omuz ağırlığı ve diz/dirsek açısı birlikte değerlendirilir. Gerçek dinamik denge simülasyonu istenmediyse yapıldığını iddia etme; en azından görsel denge ve temas kontrolü yapılır.

- Kurt: tetikte nötr baş, doğal dört ayak açıklığı, hafif eklem bükümü; cetvel gibi dört çubuk değil.
- Kaiju: geniş ama amaçlı destek, ağırlık taşıyan kalça/diz, kuyruğun karşı dengesi; dik kutu gövde ve boşta eller değil.
- Kuş: yerdeyse pençeler basar, kanatlar gövde yanına katlanır; uçuşta ise bacaklar toplanır, kanatlar gerçekten hava taşıyan bir pozdadır. İkisini yarım bir pozda karıştırma.
- Griffin: ön/arka ayak ve kanat kütlesini birlikte dengele; kartal kanatlı donmuş aslan pozu yerine davranış belirle.
- Uçak: park pozunda lastikler ve iniş takımının gövdeyle ilişkisi tutarlı, stabilizatörler nötrdür. Motor/kanopi kontrol gösterisi ayrı kliptir.
- Yüzücü: gövdede amaçlı yüzüş hattı; sadece düzende durduğu için yüzgeçleri T-pose benzeri yatay çubuk yapma.

## Yaratıcılık: smooth ≠ karakter
Sinüs, pulse ve Lerp yalnız araçtır. Her ana hareket için en az şu storyboard kararlarını ver:
1. Niyet: dinlenme, arama, tehdit, kaçış, av, kalkış?
2. Hazırlık: hangi kütle önce ağırlık alıyor?
3. Ana imza poz: bu türe özgü güçlü okunabilir şekil ne?
4. İtki/temas: ayak, su, kanat veya motor hangi anda güç veriyor?
5. Sekonder hareket: baş, kuyruk, tüy, deri/kapak nasıl gecikiyor?
6. Toparlanma: enerji nereye sönüyor, sonraki poz nasıl bağlanıyor?

Her modele aynı dalganın genliğini değiştirip farklı isim vermek yaratıcı çeşitlilik değildir. Tempo, asimetri, duraklama, bakış, yer teması ve geçiş yapısı da türe göre değişir. Tüm uzuvları sürekli sallamak yerine bazıları stabil kalsın.

## Gerçek, türe özgü klip adları
Klipler kullanıcıya ve entegrasyona gerçekte ne yaptıklarını söylemelidir. Son teslimde bütün türleri yalnız `Locomotion` / `Action` altında saklama. Ad değiştirmek sadece manifest açıklamasında değil; KeyframeSequence.Name, ClipSpecs, AnimationId attribute anahtarı, seçim listesi, runtime ve belgelerde birlikte yapılır.

Örnek isim aileleri; **tamamı her görev için otomatik zorunlu değildir**, vaat edilen kapsamla tutarlı seçilir:
- `Griffin_GroundedIdle`, `Griffin_Walk`, `Griffin_Takeoff`, `Griffin_Fly`, `Griffin_Land`, `Griffin_ChallengeRoar`.
- `Owl_PerchIdle`, `Owl_LookAround`, `Owl_Takeoff`, `Owl_Fly`, `Owl_Glide`, `Owl_Land`.
- `Wolf_StandAlert`, `Wolf_Walk`, `Wolf_Trot`, `Wolf_Run`, `Wolf_Howl`, `Wolf_Pounce`, `Wolf_Recover`.
- `Titanoboa_RestCoil`, `Titanoboa_Slither`, `Titanoboa_RearThreat`, `Titanoboa_Strike`, `Titanoboa_Recover`.
- `Kaiju_BalancedIdle`, `Kaiju_HeavyWalk`, `Kaiju_Stomp`, `Kaiju_ResonanceRoar`.
- `Megalodon_SlowCruise`, `Megalodon_FastSwim`, `Megalodon_TurnLeft`, `Megalodon_BiteLunge`, `Megalodon_Recover`.
- `Eagle_PerchIdle`, `Eagle_Takeoff`, `Eagle_Fly`, `Eagle_Glide`, `Eagle_Dive`, `Eagle_Land`.
- `F16_ParkedIdle`, `F16_Taxi`, `F16_Takeoff`, `F16_Flying`, `F16_GearRetract`, `F16_CanopyOpen`.
- `Rocket_PadIdle`, `Rocket_Ignition`, `Rocket_Liftoff`, `Rocket_Ascent`, `Rocket_BoosterSeparation`, `Rocket_StageSeparation`.
- `Phoenix_EmberIdle`, `Phoenix_Takeoff`, `Phoenix_Fly`, `Phoenix_FlareDisplay`, `Phoenix_Land`.

Uçuş pozu klibi gerçek uçuş kontrol/physics sistemi anlamına gelmez. `Walk` adı verilmiş klip gerçekten adım evreleri ve temas içermeli; kanat çırpışına Walk deme. Genel runtime kategorileri gerekiyorsa `role=locomotion` gibi metadata olabilir; görünen klip adını anlamsızlaştırmamalıdır.

## Animasyon manifest'i
Her klip: gerçek isim, amaç, loop, duration, priority, in-place/root-motion, başlangıç/bitiş durumu, marker'lar, VFX bağlantıları ve AnimationId anahtarını taşır. Action dışındaki bütün kliplere körlemesine Loop=true uygulanmaz. Takeoff/Land/Strike gibi geçişler tek sefer olabilir.

Yeni klip türü eklendiğinde runtime'da sabit üç ad listesi bırakma. Kimliği ClipSpecs/manifest üzerinden keşfet; bitişte döneceği klip de metadata ile belirlenir. Rastgele bütün klipleri Idle'a zorlamak özel akışları bozabilir.

## Kontrol
- Animasyon kapalıyken ImportPose.
- Her klibin ilk kare, hazırlık, tepe eylem, temas ve toparlanma anları.
- Eklem/kanat/çene uç noktalarında kopma ve penetrasyon.
- Döngü poz/hız sürekliliği ve klipler arası blend.
- Geri dönüş pozu ve isim/ID/marker sözleşmesi.
- VFX kapalı görünüş; sonra zamanlanmış VFX ile görünüş.

Yaratıcılık sayısal bir easing kontrolünden geçmez. Görsel storyboard ve tür davranışı incelemesi olmadan “smooth ve yaratıcı tamamlandı” deme.
