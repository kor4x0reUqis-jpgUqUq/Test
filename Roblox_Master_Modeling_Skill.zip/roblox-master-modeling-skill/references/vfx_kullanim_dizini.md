# 3.1.0 — VFX için gerçek kullanım ve görünüş kapısı
Esas tam dosya `../assestvfx/assestvfxx.txt`. Aynı klasörde 389 kayıtlı JSON/CSV ve 263 benzersiz ID'li vfx_ids.txt var. Kategori ve tür tekrarları korunur; tekil liste semantik kataloğun yerine geçmez.

- Kullanıcının havuzunu istenen rolde gerçekten kullan; yalnız ID listeleme/manifest/Texture ataması başarı değildir.
- Katalog türü kaynak etiketi; gerçek Roblox asset türü ve görsel rol ayrı doğrulanır. Katalog bir yeniden kurulum asset’i değil; orijinal emitter preset'leri, attachment ağacı ve efekt paket ayarları listeden çıkarılamaz. Bunları varmış gibi iddia etme.
- Önce adayları incele/kuponla; bir Ice/Fireball etiketini renk değiştirerek su/duman/buhar sayma. Kategori tek başına uygunluğu veya uygunsuzluğu kanıtlamaz; gözlenen şekil/hareket karar verir.
- Kaynak ID → doğru bileşen property → doğru attachment/bölge → istenen rol → boyut/hız/ömür/renk/zamanlama → engine içinde görünür sonuç kaydı zorunlu.
- Erişim, görünürlük, sanatsal rol ve haklar ayrı durumlar. Preload Success yalnız yüklemedir. Her alana pass/not_tested/fail yaz; hepsini asset_loaded=true içine sıkıştırma.
- Havuzdan istenen görünüşü doğrulayamıyorsan efekt EKSİK/DOĞRULANMAMIŞ olarak kalır; teslimin tamamlandığını söyleme. Uygun preset/Studio görüntüsü/model örneği veya kullanıcı teyidi iste. Sessiz native Smoke/Sparkles ya da dış ID fallback'i yok.
- Animasyonda gerçek marker/attachment eşleştirmesi; statik tesisin çevresel bacasında gereksiz marker veya runtime Script şartı yok. Kaynak liste tüm efekt ayarlarını sağlamıyorsa bu sınırı belirt.

Aşağıdaki eski dizin bu sözleşmeyle birlikte okunur; üstteki 3.1 kapıları önceliklidir.

> 3.0: VFX istenen tüm görevlerde varsayılan ve esas havuz kullanıcının yeniden eklediği assestvfxx.txt dosyasıdır. Başka ID ancak açık onayla. Havuzdaki ID gerçek Beam/Particle/Sound bileşenine bağlanır; listelemek veya native efekti sessizce yerine koymak yeterli değildir.

# Önceden verilen VFX ID’leri — kullanılabilir dizin

Tam liste: `vfx_katalogu.json` ve tablo olarak `vfx_katalogu.csv`: **389 kayıt, 263 benzersiz ID**. Tek ID birden fazla kategori/türde geçtiği için kayıtları tekilleştirip rollerini kaybetme. Özgün kaynak: `../examples/inceleme_kaynaklari/assestvfxx.txt`. Bunlar yeni üretilmiş ID değil; önceden verilen listenin korunmuş dizinidir.

## Kaynakta bulunan örnekler
|ID|Kaynak türü|Kaynak kategori örneği|
|---|---|---|
|6706234595|Particle|Buso / Diable Jambe / Hiken / Meteor|
|296874871|Particle|FireballJutsu|
|867619398|Particle|GiganticCrush / SSJ3 / Silva orbs2|
|1084955012|Particle|Silva orbs2|
|7524756305|Particle|Orange / Purple / Red / Teal|
|1463874772|Particle|BasicHit|
|1135136643|Beam|Buso|
|1771082037|Beam|Buso|
|258126401|Particle|Pheonix Punch / Slash|
|1084991215|Particle ve Beam|Ball / GigChain|

Bu kategori isimleri **kaynak etiketidir**, texture görünüşü teyidi değildir. Her ID için tam eşleşmeyi katalogdan oku.

## Kullanım sözleşmesi
1. İstenen eylem, emitter/beam/trail/sound rolü, bölge ve marker zamanını belirle.
2. Katalogda kategori + type filtrele, gerçek uri’yi al. Sound'u Texture'a bağlama. Model ID’sini resim diye kullanma.
3. Kaynak Particle genellikle ParticleEmitter.Texture adayıdır; Beam, Beam.Texture adayıdır. Erişim/tür uygunluğu Studio'da kontrol edilmeden kesin çalışır deme. Beam için Attachment0/1 ve yön/mesafe gerekir; ID tek başına efekt sistemi değildir.
4. Texture/Sound yüklenmesi, moderasyon/izin ve deneyime erişim koşulları ayrı doğrulanır. Başarısızsa sessizce farklı ID uydurma; hatayı ve efektsiz fallback'i bildir.
5. Klip marker’ıyla başlat/durdur; süre/Rate/Lifetime/Size/Transparency/Color ve temizleme politikasını eyleme göre ayarla. VFX boş geometriyi saklamaz.
6. Dağıtım/satış hakkı ID listesinde bulunduğu için kazanılmaz. Kullanım hakları ayrıca araştırılır.

Örnek filtre (Python): `rows = [r for r in catalog if r["type"] == "Beam"]`. Oyuna Python eklemek gerekmez; bu dizin inceleme örneğidir.
