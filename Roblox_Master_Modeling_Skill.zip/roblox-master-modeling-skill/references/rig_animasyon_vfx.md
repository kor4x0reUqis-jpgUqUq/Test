> 3.1.0 önceliği: `son_guncel_sozlesme.md`, `yuzey_boru_birlesim_kapilari.md` ve `vfx_kullanim_dizini.md` geçerlidir. Native Studs onaylıdır; 945466696 Place olduğu için image diye kullanılmaz. Tüm uygun görünür Part yüzeyleri kapsanır; gerçek dirsek/çakışma/metin/VFX rol kabulü eksikse derleme veya uzak önizleme teslim başarısı sayılmaz. Aşağıdaki eski genel öneriler bununla çelişirse uygulanmaz.

> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

> `durus_ve_anlamsal_animasyon.md` zorunludur: gerçek ImportPose, T-pose olmayan duruş, türe özgü storyboard ve tüm klip/manifest/runtime katmanlarında anlamlı adlar. VFX erişimi için `vfx_kullanim_dizini.md`.

# Rig, animasyon ve VFX

## Rig sözleşmesi
- Root/pivot/rest pozlarını tanımla. Görünür şeklin merkeziyle eklem dönme noktasını ayır.
- Motor6D ilişkisi için `Part1Frame = Part0Frame * C0 * Transform * C1:Inverse()` mantığını koru.
- Her rig parçasını tek motor sürsün. Dekor tek taşıyıcıya weld olsun.
- Animasyonlu dekor unanchored/Massless; display rig'in kökü anchored olabilir. Oynanabilir fizik için bu ayrı karardır.
- Rig'i daha az parçalı görünüme geçirirken ad/hiyerarşi/rest/pivot sözleşmesini koru veya klipleri yeniden üret.

## Hareketin kalitesi
Hazırlık → ana eylem → takip → toparlanma. Güçlü pozlar ve ağırlık aktarımı, her ekleme yüksek frekanslı sinüs eklemekten daha değerlidir.

- Dört ayaklı: duty ile basma/geri alma evresi; hedef ayak yörüngesi; iki segmentli IK; pole yönü ve erişim clamp'i; pati/parmak açısı.
- İki ayaklı dev: gövde yatışı, karşı fazlı adım, ayak basma ve kuyruk dengelemesi. Basit FK kullandıysan bütün hareketlerin IK olduğunu iddia etme.
- Kuş/griffin: omuz baskın hareket, dış kanatta gecikme; kanat açıklığına uygun tempo. Baykuş ve kartalın aynı frekans/genlikte olması gerekmez.
- Serpent: zincir boyunca faz gecikmesi; toplam eğriliği kontrol et. Tekil küçük açılar uzun zincirde büyük sonuç verir.
- Balık: gövdeden kuyruk ucuna artan yanal dalga; dikey kaudal yüzgeçli türde memeli kuyruğu gibi yukarı-aşağı sürme.
- Uçak: ayrı aileron/flaperon, stabilizatör ve rudder pivotları. Kontrol yüzeyi klibi aerodinamik simülasyon değildir.
- Roket: kademe ve booster ayrılma gösterisi kalıcı fiziksel kopmayla aynı şey değildir.

## Kaynaklardan alınan tercih
Kullanıcı `ejderha.txt` animasyonlarını ikinci ejderhaya göre daha başarılı buldu. İlk dosyada analitik IK ve çok eklemli takip var; ikinci sürümde kanat hareketi zar ayrılmasını azaltmak için kısıtlanmış. Çıkarım: iyi hareketi korurken zar/kapak geometri sınırlarını ayrıca çöz; yalnız bütün genlikleri azaltarak kaliteyi kaybetme.

Arşiv: `arsiv_ejderha_karsilastirmasi.md`. Arşivdeki eski görev durumu güncel talimat değildir.

## Bake ve yayın
1. Poz örneklerini model-local uzayda üret.
2. Pose hiyerarşisi Motor6D ağacını izlesin.
3. Ölçeği yalnız translation'a doğru uygula; rotasyonu ölçekleme.
4. Loop ilk/son pozları aynı olsun; mümkünse hız sürekliliğini de kontrol et.
5. Marker'ları ayak teması, nefes, darbe ve kanat vuruşuyla eşleştir.
6. Bake edilen KeyframeSequence, Studio preview kaydı ve yayınlanmış animation asset ID'sini ayrı kavramlar olarak belgele.
7. Oyun/grup sahipliği ve izinleri gerçek yayın ortamında test et.

## VFX tasarımı
- Katmanların görevi ayrı olsun: dar sıcak çekirdek, daha geniş dış efekt, kısa kıvılcım, uzun ömürlü ama seyrek duman.
- Sürekli efekt Rate/Enabled; tek darbe Emit().
- ColorSequence: ömür boyunca renk; NumberSequence: boyut/saydamlık; NumberRange: kontrollü çeşitlilik.
- Attachment yönü ile emisyon yönünü kontrol et. Ağız -Z yönüne bakarken egzoz gibi +Z yayma.
- Aynı VFX bütün kliplerde açılmasın: kaiju nefesi Action'da, ayak tozu temas marker'ında, egzoz motor/uçuş gösterisinde.
- Burst dahil sayıları sınırla. Uzakta Rate=0/Enabled=false yeterli olabilir; biriken particle'lar kendi lifetime'ıyla sönene kadar kalabilir.
- Beam/Trail'i de kalite ve mesafe kapısına dahil et; yalnız emitter kapatıp ışını açık bırakma.
- Statik parlak Neon bir Light değildir. Işık gerekiyorsa az ve hedefli kullan.
- VFX dekoratifse hasar/AI olmadığını söyle.

## Asset katalogu
`vfx_katalogu.json`: 389 kategorili kayıt, 263 benzersiz ID. Görünüm, izin veya yeniden satış hakkı doğrulanmış değildir. Kategori isimleri tek başına efektin sonucunu ispatlamaz. ID'yi tipe uygun özelliğe bağla; başka türde asseti ParticleEmitter.Texture diye kullanma.

Ticari teslimde harici görüntüler yerine yetkili kaynak kullan; animasyonların alıcının hesabı/grubu için yayın/erişim akışını açıkla.
