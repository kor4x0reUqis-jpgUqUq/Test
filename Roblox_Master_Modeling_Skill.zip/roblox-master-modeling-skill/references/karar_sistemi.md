> 3.0 önceliği: `son_kullanici_sozlesmesi.md`, `siluet_anatomi_ve_detay_kapilari.md` ve `studs_945466696_sozlesmesi.md` zorunludur. Silüet/anatomi onayı olmadan tekrar detay çoğaltma; studs güncel ID 945466696; animasyonlar gerçek editlenebilir keyframe klipleridir.

> Önce SKILL.md bölüm 0; detay ve kullanıcı önceliği sözleşmesi geçerlidir.

# Tasarım karar sistemi

Bu rehber özel bir modelin gizli iç muhakemesini kopyalamaz. Yaratıcı ve teknik kararları düzenleyen, gerekçesi kısa biçimde paylaşılabilen bir çalışma yöntemidir.

## 1. İsteği uygulanabilir sözleşmeye çevir
|Alan|Karar sorusu|Belirsizse davranış|
|---|---|---|
|Kimlik|Model uzaktan hangi özellikleriyle tanınacak?|3–5 ayırt edici öğe seç|
|Amaç|Dekor, gezilebilir yapı, NPC, boss, binek, satılacak asset?|Sonucu değiştirecekse sor|
|Kapsam|Yalnız model mi; animasyon/VFX/gameplay ayrı ayrı istendi mi?|İstenmeyen sistemi ekleme|
|Ölçek|Avatar veya çevreye göre boyut?|Varsayılanı belirt; yürüme boşluğunu koru|
|Sadakat|Referansın silüeti mi, renkleri mi, birebir oranları mı öncelikli?|Görünmeyen yüzleri özgün yorum diye ayır|
|Performans|Hedef cihaz, görünür model adedi, oyuncu sayısı?|Garanti verme; kalite seçenekleri ve test planı sun|
|Teslim|Command Bar kodu, editlenebilir model, paket?|Gerçek dosya biçimini doğru isimlendir|

## 2. Sorunu parçalara böl
Örnek korsan gemisi:
- Kimlik: raked pruva, yüksek kıç, üç direk, siyah yelken, altın kuşak.
- Yapı: değişen en kesitleri, boş iç hacim, dört yürüme seviyesi.
- İşlev: gerçek kapı, merdiven ve tavan açıklıkları.
- Odak: pruva figürü, kıç pencere galerisi, kaptan masası.
- Maliyet: kaplama parçaları, texture yüzleri, saydam cam/yelken, ışıklar.

Örnek F-16 referanslı uçak:
- Kimlik: tek dikey stabilizatör, kanat kökü uzantıları, süpürülmüş kanat, çene altı hava girişi, bubble canopy.
- Yapı: gövde istasyonları ve kesit radyusları; ayrı kontrol yüzeyleri.
- Odak: burun, kokpit, hava girişi ve egzoz; yalnız küp gövde + iki kanatla geçiştirme.
- Maliyet: loft çevre bölüm sayısı, kanopi cam fasetleri ve dış yükler.
- Kullanım ayrımı: kontrol yüzeyi animasyonu uçuş kontrol sistemi değildir.

Örnek kurt:
- Kimlik: uzun burun, üçgen kulaklar, göğüs/kuyruk oranı, dört ayak duruşu.
- Yapı: ince gövde, göğüs hacmi, gerçek kalça/omuz pivotları.
- Odak: yüz/ruff/patiler; tüm yüzeyi aynı plakayla kaplama.
- Hareket: hedef ayak yörüngesi ve beden ağırlığı. Ayak konumunu kontrol etmek, tüm eklemleri aynı sinüsle döndürmekten farklıdır.

## 3. Yöntem seçim matrisi
|İhtiyaç|Öncelikli yöntem|İkinci seçenek|Kaçınılacak kısa yol|
|---|---|---|---|
|Detaylı köşeli gövde|Bağlantılı kare/dikdörtgen çoklu hacim|Köşeli ve kapanışı tanımlı loft|Silindirik tüp, eliptik mantle veya tek boş kutu|
|Dikdörtgen kapı/pencere|Duvarı açıklık çevresinde böl|CSG subtract|Siyah dikdörtgeni kapalı duvara yapıştırmak|
|Düz panelde oyuk|CSG veya katmanlı gerçek recess|Açık kenarlardan modüler çerçeve|Gölge etiketiyle derinlik varmış gibi iddia|
|Kanat/yelken|Kalınlıklı üçgen veya fasetli panel|İstenen stile göre basamaklı blok|Üst üste coplanar yüzeyler|
|Renk geçişi|Az sayıda form yönlü Part bandı|Parçalar arası palet değişimi|Her küçük parçayı 10 banda bölmek|
|Tekrarlanan tüy/pul|Parametrik sıra, daralma, kontrollü açı|Birkaç el yerleşimli odak tüyü|Tam rastgele açı/renk gürültüsü|
|Oyun animasyonu|Rig + bake + Animator|İhtiyaca özel kontrollü procedural sistem|Her frame bütün detayların CFrame'ini yazmak|
|Yüksek sayıda klon|Yayınlanmış animasyon + küçük metadata|Bölgesel yükleme/streaming|Her klonda gereksiz kaynak bake ağacı|

## 4. “Aşırı detay” yükseltme protokolü
1. Ana formu daha doğru yap: kesit sayısı, kalınlık, taper ve oranlar.
2. Orta ölçekli yapıyı artır: kaburgalar, katmanlı çerçeveler, eklem kapakları.
3. Malzemeyi anlat: ahşap plank ritmi, zırh plakaları, kumaş dikişi, metal kenarlar.
4. Oyuncuya yakın alanı derinleştir: göz, kokpit, kapı kolu, iç mobilya.
5. Hikâye ekle: az sayıda yara, yük, onarım, kullanım izi. Her yere aşınma koyma.
6. Hareketi zenginleştir: sekonder takip ve doğru temas; daha çok titreşim her zaman daha iyi değildir.
7. Aynı açıdan önce/sonra karşılaştır. Eklenen ayrıntı görünmüyorsa veya ana formu bozuyorsa geri al.
8. High ve Game sürümlerini aynı silüet/rig temelinden türet; farkları say.

“Sınır yok” demek yalnız sonsuz döngü veya math.huge bütçe açmak değildir. Ölçülebilir kalite artışı varsa sayıyı artır; sayıyı kalite kanıtı yapma.

## 5. Kısa karar özeti formatı
- **Hedef:** küçük ölçekte okunaklı, yakından gezilebilir gemi.
- **Yöntem:** içi boş kesit gövde + açıklıklı modüler güverte; yalnız özel oyuklarda CSG.
- **Görsel gerekçe:** plank ve koyu alt sınırlar katmanları ayırıyor.
- **Maliyet tercihi:** studs kabartı yerine texture; cam ve ışıklar odak alanlarında.
- **Doğrulama:** Studio avatar rotası ve hedef cihaz testi gerekiyor.

Bu özet sonuç odaklıdır; uzun ham düşünce zinciri sunmak gerekmez.

## 6. Durdur / yeniden değerlendir koşulları
- Silüet referanstan belirgin saparken yalnız mikro detay artıyorsa.
- İç mekân eklendiği söylenip erişim yolları kapalıysa.
- Animasyon eklenince zar, plaka veya eklem kapakları kopuyorsa.
- CSG'yi sırf Instance sayısı azaldı diye hızlı kabul ediyorsan.
- Saydamlık veya ışık ana yüzey ayrımını siliyorsa.
- Çoklu model isteğinde hepsi aynı orana/rig'e dönüşüyorsa.
- Test doubles sonucunu gerçek Studio başarısı sanıyorsan.
