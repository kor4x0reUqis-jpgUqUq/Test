# Seri01 görsel hata otopsisi — olumsuz örnekler

## Durum ve kapsam
Kullanıcı 15 gerçek Studio ekran görüntüsüyle önceki modellerin detay, hacim, konumlandırma ve duruş hatalarını gösterdi. Bu geri bildirim geçerlidir. Önceki “sayısal test geçti” raporu, yüksek modelleme kalitesini kanıtlamıyordu. Model paketleri bu güncellemede düzeltilmedi; yalnız skill'in kabul kuralları değiştirildi.

Görseller `examples/olumsuz_gorsel_kanit/` altındadır. Eski Seri01 generator'ı başarılı görsel kalite şablonu değil, **bu kusurları incelemek için arşiv kaynağıdır**. 15 görselin tamamı önceki kalite iddialarının sınırını gösterir; yeni sonuçların bu görünümleri tekrar etmesi kabul edilmez.

## Kaynakla doğrulanan nedenler
|Gözlem|Kodda bulunan neden|Yeni zorunlu kural|
|---|---|---|
|Megalodon ağzı/kesitleri çatı veya açık kabuk gibi; iç açıklık çözümlenmemiş|`loft()` ardışık çevreleri birleştiriyor; açık uçların cap/transition politikasını üretmiyor. Baş, çatı plaka, siyah ağız ve çene ayrı eklenmiş; hacim sürekliliği test edilmiyor.|Her kesitin ucu CLOSED / INTENTIONAL_OPEN / CONNECTED_TO olarak işaretlenir. Ağız açık olacaksa yanak, damak, diş eti ve çene birleşimi tasarlanır; deliği rastgele kapakla doldurmak da çözüm değildir.|
|Başlar büyük işlenmemiş kutular; gövde kaplamalıyken yüz/uzuvlar çok basit|Başlar çoğunlukla tek `part` + göz helper'ı; mantle/plate döngüleri esas olarak gövdeye uygulanıyor. Detay bütçesi bölge bazında takip edilmiyor.|Blockout, bitmiş kafa değildir. Kafatası, alın, kaş, göz yuvası, yanak, burun/gaga, çene ve arka baş geçişleri ayrı tamamlanır. Bölüm matrisi olmadan “High tamamlandı” denmez.|
|Yüzeylerin bir kısmı boş, bir kısmı studs kaplı; modelin yarısı bitmemiş hissi|Varsayılan Texture yalnız Top/Front; plate texture'ı üst yüzle sınırlı. Mantle da sınırlı çevresel açı aralığında. Bu kararlar modelin bütün bakışlarını kapsayan görsel denetimle desteklenmemiş.|Her yüze zorunlu texture eklemek yerine her görünen yüzün **geometri + malzeme + detay** amacı kontrol edilir. Texture eksik hacmi telafi etmez.|
|Kuşlar editörde kanatlar dümdüz açık/T-pose; ayaklar sağlam basmıyor|Geometri yayılmış kanat bind/rest pozunda üretiliyor. `ActiveClip=Idle` attribute'u konmuş ama editör import pozuna gerçek onaylı Idle uygulanmıyor; playback izin/Play/yakınlık koşuluna bağlı.|BindPose, ImportPose ve Idle ayrı tanımlanır. İlk açılışta runtime beklemeden onaylı dinlenme/sunum duruşu görünür. Kuş yerdeyse ayakları basar, kanatları gövdeye anatomik biçimde toplanır.|
|Gövde kare parçalı olsa da tüp/silindir hissi baskın|Roket `tube()` fonksiyonu panelleri daire çevresine diziyor; bazı gövdeler eliptik loft'a dayanıyor.|Bu kullanıcı için “Cylinder kullanmadım” yeterli değil. Silindirik/kapsül ana gövdeyi bloklarla dolaylı taklit etmek de varsayılan çözüm olamaz. Çok hacimli kare/dikdörtgen gövde mimarisi kurulur.|
|Tekerlekler ince halka/sekiz küçük blok ve kübik göbek gibi, zayıf|`Tyre_Tread` sekiz ayrı küçük parçayla kuruluyor; tek `Wheel_Hub` var. Kapalı yanak, jant yatağı, geçiş ve bağlantı detayları eksik.|Dış sırt, iç/dış yanak, jant, göbek, aks bağlantısı ve yere temas ayrı kabul maddeleridir. Halkada boşluk kalmaması matematiksel ve görsel kontrol ister.|
|Farklı hareketlere genel Idle/Locomotion/Action adları|`bake()` bütün türler için aynı üç ismi kuruyor, tür davranışı `sample()` içinde anahtarla ayrılıyor. Görünen isim semantiği yeterince yansıtmıyor.|Gerçek klip adları tür ve davranışa özgü olur: Wolf_Walk, Eagle_Fly, Megalodon_BiteLunge vb. Yalnız açıklama tablosunda ad değiştirmek yeterli değildir.|
|Smooth ama yaratıcılık ve karakter az|Pek çok hareket sinüs/pulse ile oluşturulmuş; ortak kanat, bacak ve göz helper'ları birçok türe aynı temel dil veriyor.|Zamanlama, hazırlık, ağırlık, imza poz ve toparlanma türe özel storyboard ile belirlenir. Matematik yalnız onu uygular; ortak dalgaya farklı ad vermek kabul edilmez.|
|Yüksek detay talebi düşük parça hedefiyle bastırılmış|Varsayılan 950 hard guard, az bant/az segment ve ortak sade yardımcılar üretim tasarımına yön vermiş. Bu tek başına her kusurun nedeni değildir; kaliteyi sayımla savunmak yanlıştı.|Kalite modu ile performans modu ayrılır. Kullanıcı optimizasyon önemsiz derse örtük küçük bütçe uygulanmaz; gerekiyorsa daha çok emek/kod/parça veya daha küçük teslim partisi kullanılır.|

## Konumlandırma ve matematik: kesinlik sınırı
Görsellerde parça birleşimi, boşluk ve hizalama sorunları var. Ancak her birinin hangi CFrame çarpımından doğduğunu yalnız fotoğraftan kesinleştirmek doğru değil. Kaynakta model-local, kemik rest ve world uzayları birlikte kullanılıyor; testler ise büyük ölçüde pozitif boyut, NaN, birim eksen, parça sayısı ve ilk/son pose eşleşmesini denetledi.

**Birim/ortogonal bir CFrame yine de tamamen yanlış yerde veya ters yönde olabilir.** Önceki testler anatomik bağlanma, uç nokta sürekliliği, yüz yönü, tüm açılardan kapanış, hacim ve gerçek görünüşü kanıtlamıyordu. Bu nedenle yeni koordinat sözleşmesi ve birleşim testleri zorunlu.

## Kabul edilmeyen savunmalar
- “Optimize olduğu için baş tek kutu.”
- “Bütün boyutlar pozitif, model doğru.”
- “701 Part var, yüksek detay sayılır.”
- “Animasyon başlayınca duruş düzelir, import pozu önemli değil.”
- “Daha çok studs veya VFX eklersem eksik model kapanır.”
- “Bir Cylinder kullanmadım; dolayısıyla tüp gibi görünen gövde blok stiline uygundur.”

## Yeni kanıt sırası
1. Kullanıcı görsel geri bildirimi, ilgili görsel eksik için önceki varsayımı geçersiz kılar.
2. Kaynak incelemesi hangi nedenlerin doğrulandığını belirler.
3. Sayısal kontroller belirli matematik hatalarını eler; estetik veya tam bitmişlik belgesi değildir.
4. Yeni modelin ön/arka/yan/üst/alt ve üç çeyrek görünüşleri incelenir.
5. Animasyon kapalı import pozu ve açık kritik animasyon anları ayrı kabul edilir.
6. Studio renderı yoksa “görsel kabul bekliyor” denir; sayısal geçişi görsel onay diye pazarlama.
