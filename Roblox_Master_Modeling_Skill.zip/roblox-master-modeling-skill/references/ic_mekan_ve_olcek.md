# İç mekân, gerçek açıklık ve avatar ölçeği

## Boşluğu baştan tasarla
Dış gövde bittikten sonra içine kutu oda sıkıştırma. Gezilebilir modelin kabuğu, döşemesi ve taşıyıcıları iç hacmi hesaba katmalı.

- Kabuk ince/boş; döşemeler doğru seviyede.
- Kapı/pencere gerçekten açık; yalnız siyah yüzey veya yarı saydam kaplama değil.
- Merdiven hattı boyunca döşeme, taşıyıcı kiriş, railing ve dekor için gerekli boşluk bırak.
- Merdiven çıkışındaki landing'i korkulukla kapatma.
- Mobilya yerleşimini girişten çalışma alanına kesintisiz rotayla kontrol et.
- Görünüşü açık olan CSG deliğinin collision hull tarafından kapanmadığını test et.

## Sayısal açıklıklar hedef, garanti değil
Standart R6/R15 için önceki tam iç mekân gemisinde kapılar 6.4–8.2 stud genişlik, normal kapı yükseklikleri 8.8, ambar geçişi yaklaşık 7.95; merdiven genişlikleri 4–5 ve rise en fazla .43 stud seçildi. Bunlar kullanışlı **örnek başlangıç değerleri**, bütün projeler için evrensel minimum değildir.

Avatar scale, aksesuar, WalkSpeed, jump ayarı, kamera ve kumanda türü sonucu değiştirir. Modeli küçültürsen bütün açıklıkları da küçültmüş olursun. “R15 uyumlu” etiketi için oyunun izin verdiği gerçek avatar aralığını test et.

## Merdiven ve kat planı
Döşeme üretimini açıklık listesiyle yap. Her plank sırasının [xmin,xmax] aralığından, o Z diliminde kesişen merdiven/ambar aralıklarını çıkar. Birden fazla veya üst üste açıklığı destekle. Negatif genişlikli parçayı üretme.

Sadece döşemeyi kesmek yetmez: aynı bölgeden geçen alt kirişleri de böl. Gemi çalışmasında bu fark sayısal geçiş kontrolü sırasında özellikle ele alındı.

Gerçek basamaklar arasında rise/run, nosing ve korkuluk konumları uyumlu olsun. Gizli collider rampası kullanılıyorsa bunu açıkça belirt; görünür basamakla oynanabilir yüzey çelişmesin. Basamak veya collider kullanımı kullanıcı talebine göre seçilir; ikisi de otomatik başarı değildir.

## Çarpışma ve query ayrımı
- Görsel dekor: genellikle CanCollide/CanTouch=false; query gerekmiyorsa CanQuery=false.
- Walkable zemin: çarpışma gerekir.
- QueryHitbox: raycast başlangıç hacmi olabilir; karakter collision veya uzuv bazlı hasar değildir.
- Cam: saydam olması fiziksel açıklık olması gerektiği anlamına gelmez. Düşmeyi engellemesi isteniyorsa collider davranışını ayarla.
- Halat/yelken: görsel ince detayların avatarı takmasını önle; gerçekten tırmanılabilir olması isteniyorsa bunu ayrı tasarla.

## Doğrulama rotası
1. Ana güverte giriş ve dönüş.
2. Tüm katlar arasında iniş/çıkış.
3. Her kapıdan giriş; oda içi temel dolaşım.
4. Dar geçitte kamera ve aksesuar.
5. R6 ve R15; izin verilen en büyük avatar.
6. Mobil/klavye kontrol, farklı yürüme hızları.
7. Sınır durum: merdiven tepesinde korkuluk, kapı kanadı ve tavan.

Sayısal zarf/örnek noktası taraması erken hata bulur; bütün rotayı veya Humanoid fiziğini kanıtlamaz. Önceki gemide dikdörtgen parçalara karşı merkez hattı örneklemesinde 0 temas bulunması, gerçek Studio yürüyüşü yapılmış demek değildir.
