> 3.1.0: Bu dosyanın eski ID ve alternatif kısımları tarihsel bağlamdır. Güncel sözleşme `son_guncel_sozlesme.md`; 945466696 Place, güncel onay native Studs. Yeni santral redleri bütün eski başarı varsayımlarının üzerindedir.

# En son kullanıcı sözleşmesi — öncelikli
Tarih 2026-10-20, sürüm 3.0.0. Bu dosya eski örnekler, varsayılanlar ve önceki texture seçimlerinin üzerindedir.

## Sabit tercihler
- Kare/küp/dikdörtgen Part ağırlıklı, aşırı detaylı fakat anlamlı hacim işçiliği. Ana gövde silindirik/tüp olamaz; ancak büyük kutu da kabul değildir.
- Studs texture varsayılan olarak ZORUNLU stil katmanıdır. Güncel kullanıcı ID'si **945466696**, URI **rbxassetid://945466696**. Eski **9454666962** farklı bir ID'dir ve varsayılan olamaz. Sayıya 2 ekleme; önceki koddan otomatik alma.
- Bu yeni ID'nin asset türü, erişimi ve görünüşü burada doğrulanmadı. Texture image olarak kullanılabilirliği test edilir. Model/Decal çıkarsa doğru içerik URI'si çözülür; sayı doğru diye tür kontrolünü atlama. Başarısızlıkta açık uyarı; rastgele ID veya native studs/Neon ile sessiz ikame yok.
- VFX için kullanıcının yeniden eklediği `examples/inceleme_kaynaklari/assestvfxx.txt` esas kaynaktır. JSON ve CSV katalogları bu dosyanın dizinidir. VFX istenen her görevde bu havuzdan uygun kayıt seç, gerçek bileşene bağla, ID → tür → bölge → marker eşleşmesini raporla. Rastgele başka asset ID'si üretme. Başka kaynak ancak açık kullanıcı onayıyla.
- Statik/VFX istenmeyen göreve zorla efekt veya gameplay ekleme. VFX havuzu varsayılan kaynaktır, her ID'yi her modele yığmak değildir. Sound/Beam/Particle rollerini karıştırma. Asset bulunması lisans veya erişim doğrulaması değildir.
- Animasyonlar Animation Editor'a alınabilir gerçek KeyframeSequence/Keyframe/Pose ve uygun Motor6D/Bone hiyerarşisiyle teslim edilir. Semantik klip adları zorunludur. Yalnız runtime CFrame/PivotTo gösterisi veya klip adı listesi yeterli değildir.
- Opsiyonel Animator/VFX önizlemesi, düzenlenebilir kliplerin yerine geçmez. Published AnimationId yoksa varmış gibi gösterme. Yerel klip oluşturma ile editörde gerçekten açıldığının kanıtını ayır.
- Gizli Part/kod sınırı yok. Aşırı detay isteğini tekrarlanan panel/texture sayısıyla savuşturma. Kaynak sınırında partiyi küçült, kaliteyi sessizce düşürme.

## Bu revizyonun kapsamı
Kullanıcı mevcut Ghidorah veya F16 kodunu onarmayı istemedi. Bu paket yalnız skill düzeltmesidir. Sonraki üretimde aynı başarısız yardımcıları/kesitleri otomatik tekrar kullanma. Skill, bir referans ve talimat paketidir; belirli AI çıktısını veya Studio başarısını garanti etmez.
