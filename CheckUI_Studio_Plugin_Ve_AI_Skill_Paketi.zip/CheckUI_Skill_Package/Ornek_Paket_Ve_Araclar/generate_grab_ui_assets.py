#!/usr/bin/env python3
"""
generate_grab_ui_assets.py — GRAB! v4 UI asset generator.

Sources:
  * The user's "Free Icon Pack 3.0.1 (Basic).zip" (repo: kor4x0reUqis-jpgUqUq/Test)
  * Procedural isometric map appearance thumbnails for the 5 arena maps.

Outputs (into ui_pack_src/):
  images/<key>.png    preview PNG
  pixels/<key>.rgba   raw RGBA buffer (width*height*4) for native EditableImage preview

Every generated map thumbnail is a TRUE ISOMETRIC voxel diorama of the actual
arena (ground, border rim, theme props) — not a generic icon.
"""
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "ui_pack_src"
IMAGES = SRC / "images"
PIXELS = SRC / "pixels"

ICON_REPO = Path("/tmp/refs_new/icons/Free Icon Pack 3.0.1 (Basic)")

# key -> (icon-pack relative folder, file stem)
ICON_SOURCES = {
    "icon_shop": ("Main/Shopping Bag", "Golden Shopping Bag 1st Outline 256px.png"),
    "icon_skills": ("Main/Upgrade", "Golden Upgrade 1st Outline 256px.png"),
    "icon_vote": ("Main/Wheel", "Wheel 1st Outline 256px.png"),
    "icon_cash": ("Currency/Cash", "Golden Cash 1st Outline 256px.png"),
    "icon_wins": ("Item/Trophy", "Golden Trophy 1st Outline 256px.png"),
    "icon_streak": ("Item/Medal", "Golden Medal 1st Outline 256px.png"),
    "icon_vip": ("Exclusive/VIP", "VIP 1st Outline 256px.png"),
    "icon_close": ("UI/Close Button", "Close Button 1st Outline 256px.png"),
    "icon_info": ("UI/Info", "Info 1st Outline 256px.png"),
    "icon_warning": ("UI/Warning", "Warning 1st Outline 256px.png"),
    "icon_check": ("UI/Checkmark", "Checkmark 1st Outline 256px.png"),
    "icon_location": ("Item/Location Pin", "Location Pin 1st Outline 256px.png"),
    "icon_star": ("Main/Star", "Golden Star 1st Outline 256px.png"),
    "icon_player": ("Player/Player", "Player 1st Outline 256px.png"),
    "icon_rip": ("Player/RIP", "RIP 1st Outline 256px.png"),
    "icon_skull": ("Player/Skull", "Skull 1st Outline 256px.png"),
    "icon_friend": ("Player/Friend", "Friend 1st Outline 256px.png"),
    "icon_coin": ("Currency/Coin", "Golden Coin 1st Outline 256px.png"),
    "icon_cloud": ("Nature/Cloud", "Cloud 1st Outline 256px.png"),
    "icon_leaf": ("Nature/Leaf", "Leaf 1st Outline 256px.png"),
    "icon_wheat": ("Nature/Wheat", "Wheat 1st Outline 256px.png"),
    "icon_thunder": ("Nature/Thunderstorm", "Thunderstorm 1st Outline 256px.png"),
    "icon_fire": ("Main/Fire", "Fire 1st Outline 256px.png"),
    "icon_magnify": ("Main/Magnifying Glass", "Magnifying Glass 1st Outline 256px.png"),
    "icon_save": ("Main/Save", "Save 1st Outline 256px.png"),
    "icon_trade": ("Main/Trade", "Trade 1st Outline 256px.png"),
    "icon_verify": ("Main/Verify", "Verify 1st Outline 256px.png"),
    "icon_house": ("Main/House", "Blue House 1st Outline 256px.png"),
    "icon_settings": ("Main/Settings", "Settings 1 1st Outline 256px.png"),
    "icon_stats": ("Main/Stats", "Stats 1st Outline 256px.png"),
    "icon_wheel": ("Main/Wheel", "Wheel 1st Outline 256px.png"),
    "skill_dash": ("Item/Shoe", "Blue Shoe 1st Outline 256px.png"),
    "skill_superthrow": ("Item/Rocket", "Rocket 1st Outline 256px.png"),
    "skill_shield": ("Item/Shield", "Shield 1st Outline 256px.png"),
    "skill_telekinesis": ("Item/Magnet", "Golden Magnet 1st Outline 256px.png"),
    "skill_shockwave": ("Item/Target", "Golden Target 1st Outline 256px.png"),
    "skill_shadowblink": ("Exclusive/Magical Teleport", "Purple Magical Teleport 1st Outline 256px.png"),
}

MAPS = {
    "map_orman": {
        "title": "ORMAN ADASI",
        "sky": (128, 190, 235),
        "sky2": (206, 230, 246),
        "water": (48, 140, 186),
        "ground": (106, 168, 79),
        "ground2": (74, 128, 58),
        "rock": (154, 162, 170),
        "rock2": (104, 112, 122),
        "props": "trees",
    },
    "map_volkanik": {
        "title": "VOLKANİK KRATER",
        "sky": (126, 92, 128),
        "sky2": (222, 142, 104),
        "water": (96, 72, 104),
        "ground": (74, 64, 86),
        "ground2": (48, 42, 58),
        "rock": (128, 128, 134),
        "rock2": (78, 78, 84),
        "props": "volcano",
    },
    "map_halloween": {
        "title": "CADILAR BAYRAMI",
        "sky": (62, 44, 92),
        "sky2": (150, 96, 176),
        "water": (60, 48, 96),
        "ground": (58, 44, 74),
        "ground2": (40, 30, 54),
        "rock": (150, 148, 158),
        "rock2": (96, 94, 104),
        "props": "graves",
    },
    "map_insaat": {
        "title": "İNŞAAT ALANI",
        "sky": (150, 196, 236),
        "sky2": (214, 232, 244),
        "water": (86, 150, 184),
        "ground": (168, 170, 168),
        "ground2": (120, 122, 122),
        "rock": (150, 152, 150),
        "rock2": (96, 98, 96),
        "props": "scaffold",
    },
    "map_sirk": {
        "title": "SİRK ÇADIRI",
        "sky": (150, 190, 235),
        "sky2": (240, 214, 176),
        "water": (52, 140, 184),
        "ground": (223, 203, 155),
        "ground2": (188, 164, 116),
        "rock": (160, 72, 62),
        "rock2": (110, 44, 40),
        "props": "tent",
    },
}

W, H = 320, 200


def save(img: Image.Image, key: str) -> None:
    IMAGES.mkdir(parents=True, exist_ok=True)
    PIXELS.mkdir(parents=True, exist_ok=True)
    img = img.convert("RGBA")
    png_path = IMAGES / f"{key}.png"
    img.save(png_path, "PNG")
    (PIXELS / f"{key}.rgba").write_bytes(img.tobytes("raw", "RGBA"))


def iso(x: float, y: float, z: float):
    """Isometric projection: x right, y depth, z up."""
    sx = (x - y) * 0.866
    sy = (x + y) * 0.5 - z
    return sx, sy


def draw_box(d: ImageDraw.ImageDraw, x, y, z, w, d_, h, top, left, right, outline=None):
    """Draw an isometric box (voxel) at grid (x,y,z) with size w x d_ x h."""
    # top face
    p0 = iso(x, y, z + h)
    p1 = iso(x + w, y, z + h)
    p2 = iso(x + w, y + d_, z + h)
    p3 = iso(x, y + d_, z + h)
    d.polygon([p0, p1, p2, p3], fill=top)
    # left face
    q0 = iso(x, y + d_, z)
    q1 = iso(x + w, y + d_, z)
    q2 = iso(x + w, y + d_, z + h)
    q3 = iso(x, y + d_, z + h)
    d.polygon([q0, q1, q2, q3], fill=right)
    # right face
    r0 = iso(x + w, y, z)
    r1 = iso(x + w, y + d_, z)
    r2 = iso(x + w, y + d_, z + h)
    r3 = iso(x + w, y, z + h)
    d.polygon([r0, r1, r2, r3], fill=left)
    if outline:
        d.line([p0, p1, p2, p3, p0], fill=outline, width=1)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3])


def make_map_thumbnail(key: str, cfg: dict) -> Image.Image:
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # sky
    for y in range(H):
        t = y / H
        c = tuple(
            int(cfg["sky"][i] * (1 - t) + cfg["sky2"][i] * t) for i in range(3)
        )
        d.line([(0, y), (W, y)], fill=c + (255,))

    # sun / moon
    d.ellipse([W - 58, 16, W - 22, 52], fill=(255, 240, 180, 255))

    # water
    water_y = int(H * 0.62)
    for y in range(water_y, H):
        t = (y - water_y) / max(1, (H - water_y))
        c = tuple(
            int(cfg["water"][i] * (1 - t * 0.35) + 20 * t) for i in range(3)
        )
        d.line([(0, y), (W, y)], fill=c + (255,))

    # island (ellipse) in iso
    cx, cy = W / 2, H * 0.50
    rx, ry = W * 0.44, H * 0.26
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=cfg["ground2"] + (255,))
    d.ellipse(
        [cx - rx + 6, cy - ry + 5, cx + rx - 6, cy + ry - 8],
        fill=cfg["ground"] + (255,),
    )

    # border rim ring (the v4 border!) drawn as chunky segments
    segs = 22
    for i in range(segs):
        a = (i / segs) * math.tau
        bx = cx + math.cos(a) * (rx - 4)
        by = cy + math.sin(a) * (ry - 3)
        s = 9
        d.rectangle([bx - s / 2, by - s / 2, bx + s / 2, by + s / 2],
                    fill=cfg["rock"] + (255,), outline=shade(cfg["rock2"], 1.0) + (255,))

    # central medallion
    d.ellipse([cx - 24, cy - 11, cx + 24, cy + 11], fill=shade(cfg["ground"], 1.16) + (255,))
    d.ellipse([cx - 16, cy - 7, cx + 16, cy + 7], fill=shade(cfg["rock"], 1.1) + (255,))

    props = cfg["props"]
    if props == "trees":
        for (ox, oy, s) in [
            (-58, -14, 1.0), (-26, 16, 0.85), (18, -18, 1.1), (44, 12, 0.9), (8, 20, 0.7)
        ]:
            bx, by = cx + ox, cy + oy
            # trunk (iso block)
            d.rectangle([bx - 2 * s, by - 6 * s, bx + 2 * s, by + 6 * s], fill=(96, 66, 40, 255))
            d.rectangle([bx - 2 * s, by - 6 * s, bx + 0, by + 6 * s], fill=(66, 44, 26, 255))
            # canopy: 3 stacked iso slabs
            for lvl, (cw, ch, col) in enumerate(
                [
                    (13 * s, 5 * s, (74, 152, 62, 255)),
                    (10 * s, 4 * s, (96, 182, 78, 255)),
                    (7 * s, 3.5 * s, (126, 202, 102, 255)),
                ]
            ):
                yy = by - 8 * s - lvl * 6 * s
                d.polygon(
                    [
                        (bx - cw, yy),
                        (bx, yy - cw * 0.5),
                        (bx + cw, yy),
                        (bx, yy + cw * 0.5),
                    ],
                    fill=col,
                )
                d.polygon(
                    [
                        (bx - cw, yy),
                        (bx, yy - cw * 0.5),
                        (bx, yy + cw * 0.5),
                        (bx - cw, yy + cw * 0.5),
                    ],
                    fill=shade(col, 0.78) + (255,),
                )
    elif props == "volcano":
        # stepped volcano cone (iso blocks)
        for lvl, (wdt, hgt) in enumerate([(46, 12), (34, 12), (22, 11), (12, 10)]):
            bx = cx - wdt / 2
            by = cy + 6 - lvl * 11
            d.polygon(
                [(bx, by), (bx + wdt / 2, by - 11), (bx + wdt, by), (bx + wdt / 2, by + 11)],
                fill=shade(cfg["rock"], 1.0 - lvl * 0.05) + (255,),
            )
            d.polygon(
                [(bx, by), (bx + wdt / 2, by - 11), (bx + wdt / 2, by + 11), (bx, by + 6)],
                fill=shade(cfg["rock2"], 1.0) + (255,),
            )
        # glowing crater
        d.ellipse(
            [cx - 12, cy - 44, cx + 12, cy - 32], fill=(255, 150, 40, 255)
        )
        d.ellipse(
            [cx - 7, cy - 42, cx + 7, cy - 35], fill=(255, 226, 130, 255)
        )
        # lava pools (voxel discs with glow)
        for ox, oy in [(-44, 14), (30, 18), (-4, 24)]:
            bx, by = cx + ox, cy + oy
            d.ellipse([bx - 16, by - 7, bx + 16, by + 7], fill=(255, 122, 36, 255))
            d.ellipse([bx - 11, by - 4, bx + 11, by + 4], fill=(255, 200, 90, 255))
            d.ellipse([bx - 6, by - 2, bx + 6, by + 2], fill=(255, 240, 180, 255))
    elif props == "graves":
        # crooked tombstones
        for ox, oy, hgt in [(-42, 4, 20), (-8, 20, 17), (30, 2, 22), (52, 18, 16)]:
            bx, by = cx + ox, cy + oy
            d.polygon(
                [(bx - 7, by), (bx - 7, by - hgt), (bx, by - hgt - 6), (bx + 7, by - hgt), (bx + 7, by)],
                fill=(150, 148, 158, 255),
            )
            d.polygon(
                [(bx, by - hgt), (bx + 7, by - hgt), (bx + 7, by), (bx, by)],
                fill=(108, 106, 116, 255),
            )
        # pumpkins
        for ox, oy in [(-26, 22), (14, -4), (38, 24)]:
            bx, by = cx + ox, cy + oy
            d.ellipse([bx - 8, by - 7, bx + 8, by + 7], fill=(240, 146, 38, 255))
            d.ellipse([bx - 6, by - 6, bx + 2, by + 4], fill=(255, 186, 78, 255))
            d.rectangle([bx - 2, by - 12, bx + 2, by - 5], fill=(120, 200, 72, 255))
        # purple mist
        d.rectangle([cx - 110, cy + 22, cx + 110, cy + 40], fill=(178, 150, 220, 40))
    elif props == "scaffold":
        for ox, oy in [(-44, 2), (26, 14)]:
            bx, by = cx + ox, cy + oy
            for dx in (-15, 15):
                d.rectangle([bx + dx - 2, by - 32, bx + dx + 2, by + 8], fill=(240, 138, 46, 255))
                d.rectangle([bx + dx - 2, by - 32, bx + dx, by + 8], fill=(186, 102, 32, 255))
            for lvl in range(3):
                yy = by - 28 + lvl * 12
                d.polygon(
                    [(bx - 20, yy), (bx, yy - 6), (bx + 20, yy), (bx, yy + 6)],
                    fill=(184, 133, 76, 255),
                )
        # crane
        d.rectangle([cx + 44, cy - 46, cx + 49, cy + 8], fill=(240, 200, 60, 255))
        d.rectangle([cx + 44, cy - 46, cx + 46, cy + 8], fill=(190, 158, 40, 255))
        d.rectangle([cx + 26, cy - 50, cx + 76, cy - 44], fill=(240, 200, 60, 255))
        d.rectangle([cx + 66, cy - 44, cx + 68, cy - 14], fill=(64, 70, 78, 255))
        d.rectangle([cx + 62, cy - 18, cx + 72, cy - 12], fill=(64, 70, 78, 255))
        for ox, oy in [(-16, 24), (10, 26)]:
            bx, by = cx + ox, cy + oy
            d.ellipse([bx - 8, by - 8, bx + 8, by + 8], fill=(226, 92, 42, 255))
            d.ellipse([bx - 8, by - 8, bx - 1, by + 4], fill=(180, 68, 30, 255))
    else:  # tent
        d.polygon(
            [(cx - 36, cy + 8), (cx, cy - 38), (cx + 36, cy + 8)], fill=(206, 60, 52, 255)
        )
        for i in range(5):
            ox = -36 + i * 15
            d.polygon(
                [
                    (cx + ox, cy + 8),
                    (cx + ox + 7, cy - 32 + abs(2 - i) * 7),
                    (cx + ox + 15, cy + 8),
                ],
                fill=(240, 234, 214, 255),
            )
        d.polygon(
            [(cx - 7, cy - 38), (cx, cy - 50), (cx + 7, cy - 38)], fill=(206, 60, 52, 255)
        )
        d.rectangle([cx - 1, cy - 58, cx + 1, cy - 48], fill=(228, 178, 62, 255))
        for ox, oy in [(-54, 16), (48, 20)]:
            bx, by = cx + ox, cy + oy
            d.ellipse([bx - 11, by - 11, bx + 11, by + 11], outline=(240, 200, 60, 255), width=3)
            d.rectangle([bx - 1, by - 8, bx + 1, by + 8], fill=(240, 200, 60, 255))

    # vignette + border
    d.rectangle([0, 0, W - 1, H - 1], outline=(0, 0, 0, 255), width=3)
    return img


def make_stud_tile(size: int = 128) -> Image.Image:
    """A classic Roblox-style stud tile used as the UI background pattern."""
    img = Image.new("RGBA", (size, size), (255, 255, 255, 255))
    d = ImageDraw.Draw(img)
    cell = size / 2
    for gy in range(2):
        for gx in range(2):
            cx = gx * cell + cell / 2
            cy = gy * cell + cell / 2
            r = cell * 0.30
            d.ellipse([cx - r, cy - r - 1, cx + r, cy + r - 1], fill=(226, 232, 238, 255))
            d.ellipse(
                [cx - r, cy - r - 3, cx + r, cy + r - 3], fill=(248, 251, 254, 255)
            )
            d.ellipse(
                [cx - r * 0.55, cy - r * 0.75, cx + r * 0.35, cy + r * 0.15],
                fill=(255, 255, 255, 255),
            )
    return img


def make_checkerboard(size: int = 64) -> Image.Image:
    img = Image.new("RGBA", (size, size), (255, 255, 255, 255))
    d = ImageDraw.Draw(img)
    c = size / 2
    d.rectangle([0, 0, c - 1, c - 1], fill=(214, 220, 226, 255))
    d.rectangle([c, 0, size - 1, c - 1], fill=(246, 248, 250, 255))
    d.rectangle([0, c, c - 1, size - 1], fill=(246, 248, 250, 255))
    d.rectangle([c, c, size - 1, size - 1], fill=(214, 220, 226, 255))
    return img


def main() -> None:
    IMAGES.mkdir(parents=True, exist_ok=True)
    PIXELS.mkdir(parents=True, exist_ok=True)

    report = {}

    # 1) icon pack assets
    copied = 0
    missing = []
    for key, (folder, filename) in ICON_SOURCES.items():
        src = ICON_REPO / folder / "256px" / filename
        if not src.exists():
            # some folders use 256w
            src = ICON_REPO / folder / "256w" / filename
        if not src.exists():
            missing.append(key)
            continue
        with Image.open(src) as im:
            im = im.convert("RGBA")
            # trim fully transparent padding so the icon fills its UI slot
            bbox = im.getbbox()
            if bbox:
                im = im.crop(bbox)
            canvas = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
            im.thumbnail((236, 236), Image.LANCZOS)
            canvas.paste(im, ((256 - im.width) // 2, (256 - im.height) // 2), im)
            save(canvas, key)
            copied += 1

    # 2) procedural map thumbnails
    for key, cfg in MAPS.items():
        save(make_map_thumbnail(key, cfg), key)

    # 3) pattern assets
    save(make_stud_tile(128), "stud_tile")
    save(make_checkerboard(64), "checkerboard")

    report = {
        "icons_copied": copied,
        "icons_missing": missing,
        "maps": list(MAPS.keys()),
        "note": "Icons are the user's Free Icon Pack 3.0.1 (Basic) art; maps are true isometric voxel dioramas.",
    }
    (SRC / "generation_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    print(f"Generated {copied} icons, {len(MAPS)} map thumbnails, 2 patterns.")
    if missing:
        print("MISSING ICONS:", missing)


if __name__ == "__main__":
    main()
