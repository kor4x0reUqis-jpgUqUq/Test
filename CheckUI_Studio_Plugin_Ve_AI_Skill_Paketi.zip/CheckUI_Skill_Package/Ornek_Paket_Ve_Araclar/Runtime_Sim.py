#!/usr/bin/env python3
"""
Runtime_Sim.py — offline simulation of the GRAB! v4 round state machine.

Extracts the phase sequence from GrabGameServer.luau and verifies the
lifecycle invariants researched from popular round-system games:

  LOBBY (wait >= 2) -> MAP_VOTE -> MAP_LOAD -> COUNTDOWN -> ROUND -> RESULTS -> LOBBY

Rules checked:
  1. Round never starts with fewer than MIN_PLAYERS players.
  2. Items spawn ONLY during the COUNTDOWN window.
  3. The map is built before players are teleported to the arena.
  4. Every player is returned to the lobby at the end of a round.
  5. The lobby model is never destroyed (it always exists).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = ROOT / "Modeller_Ve_Kurulum_Kodlari" / "GrabGameServer.luau"
BUILDERS = ROOT / "Modeller_Ve_Kurulum_Kodlari" / "ModelMakerBuilders.luau"

src = SERVER.read_text(encoding="utf-8")
builders = BUILDERS.read_text(encoding="utf-8")

failures = []


def check(name, cond, detail=""):
    status = "PASS" if cond else "FAIL"
    print(f"  [{status}] {name}" + (f"  ({detail})" if detail and not cond else ""))
    if not cond:
        failures.append(name)


print("GRAB! v4 runtime simulation — round lifecycle invariants\n")

# ---------------------------------------------------------------- 1
print("1) Round start requires at least 2 players")
min_players = int(re.search(r"MIN_PLAYERS\s*=\s*(\d+)", src).group(1))
check("MIN_PLAYERS == 2", min_players == 2, f"got {min_players}")
check(
    "lobby loop waits for #Players >= needed",
    "while #Players:GetPlayers() < needed do" in src,
)
check(
    "poll interval is short (0.5s) so a 2nd player starts fast",
    "LOBBY_POLL_INTERVAL = 0.5" in src,
)

# ---------------------------------------------------------------- 2
print("\n2) Items spawn ONLY during the countdown")
check(
    "spawnItems() is called from startRound() right after COUNTDOWN starts",
    re.search(r'setPhase\("COUNTDOWN".*?spawnItems\(\)', src, re.S) is not None,
)
# ensure spawnItems is not called anywhere else
calls = re.findall(r"(?<!function )spawnItems\(\)", src)
check("spawnItems() has exactly one call site", len(calls) == 1, f"got {len(calls)}")
check(
    "no continuous item spawner / respawn loop",
    "spawnItems" not in re.search(r'while true do(.*?)end\nend', src, re.S).group(1)
    or src.count("spawnItems()") == 1,
)
check(
    "items get a white Highlight on spawn",
    'FillColor = Color3.fromRGB(255, 255, 255)' in src and "GRAB_SpawnHighlight" in src,
)
check(
    "a sound plays on spawn",
    'playSound("MatchStart")' in src,
)

# ---------------------------------------------------------------- 3
print("\n3) Map is built before players are teleported to the arena")
load_idx = src.find("loadMap(chosen)")
tele_idx = src.find("teleportToArena(p)")
check("loadMap() is called before the round starts", load_idx > 0)
loop_body = src[src.find("local function lobbyLoop"):]
check(
    "loadMap happens before startRound() inside the lobby loop",
    loop_body.find("loadMap(chosen)") < loop_body.find("startRound()"),
)
check(
    "teleportToArena is called inside startRound (after map load)",
    "teleportToArena(p)" in src[src.find("function startRound"):src.find("function endRound")],
)
check(
    "map rises with a tween (themed models animate into place)",
    "TweenService:Create(newMap" in src and "GRAB_ActiveArenaMap" in src,
)

# ---------------------------------------------------------------- 4
print("\n4) Everyone returns to the lobby after a round")
check(
    "end of round teleports all players to the lobby",
    re.search(
        r"-- back to the lobby for everyone\s*for _, p in ipairs\(Players:GetPlayers\(\)\) do\s*teleportToLobby\(p\)",
        src,
    )
    is not None,
)
check(
    "eliminated players are sent back to the lobby",
    "teleportToLobby(p)" in src[src.find("function eliminatePlayer"):src.find("-- Fall / death detection")],
)
check(
    "anti-fall watchdog returns stray players to the lobby",
    "teleportToLobby(p)" in src[src.find("Anti-fall watchdog"):src.find("task.defer(function()\n\t\tsendPlayerSync")],
)

# ---------------------------------------------------------------- 5
print("\n5) The lobby always exists")
check(
    "lobby model is never destroyed in the server",
    "GRAB_FrontLobby\").Destroy()" not in src and ":Destroy()\nlocal lobby" not in src,
)
check(
    "the ONLY SpawnLocation is inside the lobby (LobbySpawn)",
    'Instance.new("SpawnLocation")' in builders and 'Name = "LobbySpawn"' in builders,
)
check(
    "LobbySpawn is Neutral + Enabled so everyone spawns there",
    "spawn.Neutral = true" in builders and "spawn.Enabled = true" in builders,
)
check(
    "every player is teleported to the lobby on CharacterAdded",
    "CharacterAdded:Connect" in src and "teleportToLobby(p)" in src,
)
check(
    "player.RespawnLocation is set to the lobby spawn",
    "p.RespawnLocation = lobbySpawn" in src,
)

# ---------------------------------------------------------------- 6
print("\n6) BORDERS (the v4 headline fix)")
check(
    "buildBorder() exists in the builder",
    "function ModelMakerBuilders.buildBorder" in builders,
)
check(
    "border creates a visible cliff rim (not an invisible wall only)",
    'ModelMakerBuilders.folder(parent, "Border")' in builders
    and '"Cliff_"' in builders
    and '"Kerb_"' in builders,
)
check(
    "border creates an invisible collision barrier as well",
    'SetAttribute("GRAB_Barrier", true)' in builders,
)
check(
    "lobby uses the tall WALL border mode",
    'buildBorder(root, V(origin.X, TOP, origin.Z), RX, RZ, TOP, "WALL"' in builders,
)
arena_builder = (ROOT / "Modeller_Ve_Kurulum_Kodlari" / "ArenaMapBuilder.luau").read_text(encoding="utf-8")
check(
    "arena uses the knockable LIP border mode",
    '"LIP"' in arena_builder,
)
check(
    "arena maps are built with a border too",
    "ArenaMapBuilder.build" in src and "buildBorder" in
    (ROOT / "Modeller_Ve_Kurulum_Kodlari" / "ArenaMapBuilder.luau").read_text(encoding="utf-8"),
)

# ---------------------------------------------------------------- 7
print("\n7) Abilities")
for ability in ("Dash", "SuperThrow", "CounterShield", "Telekinesis", "Shockwave", "ShadowBlink"):
    check(f"{ability} implemented on the server", f'abilityId == "{ability}"' in src)
check(
    "only ONE Q slot in the UI (single skill button)",
    'skillHolder.Name = "SkillBarHUD"' in
    (ROOT / "Plugin_Ve_Yerel_Kopru" / "ui_pack_src" / "scripts" / "GrabUIController.luau").read_text(encoding="utf-8"),
)

# ---------------------------------------------------------------- 8
print("\n8) UI environment effects")
ui = (ROOT / "Plugin_Ve_Yerel_Kopru" / "ui_pack_src" / "scripts" / "GrabUIController.luau").read_text(encoding="utf-8")
comp = (ROOT / "Plugin_Ve_Yerel_Kopru" / "ui_pack_src" / "scripts" / "CheckUIComponents.luau").read_text(encoding="utf-8")
check("camera FOV widens 70 -> 84 on modal open", "FieldOfView = 84" in comp and "FieldOfView = 70" in comp)
check("background blur 0 -> 20 on modal open", "Size = 20" in comp and "Size = 0" in comp)
check("other HUD panels are hidden while a modal is open", "leftHud.Visible = not anyOpen" in ui)
check("responsive per-container UIScale", "AttachResponsiveScale" in comp and "AttachResponsiveScale" in ui)
check("HUD is docked to the real screen edges", "Window" in ui and "UDim2.fromScale(1, 1)" in ui)

# ---------------------------------------------------------------- 9
print("\n9) Sound coverage")
theme = (ROOT / "Plugin_Ve_Yerel_Kopru" / "ui_pack_src" / "scripts" / "CheckUITheme.luau").read_text(encoding="utf-8")
sound_block = re.search(r"CheckUITheme\.Sounds = \{(.*?)\n\}", theme, re.S).group(1)
sounds = re.findall(r'(\w+) = "rbxassetid', sound_block)
check(f"at least 13 sound cues defined (got {len(sounds)})", len(sounds) >= 13)
for needed in ("UIHover", "UIClick", "ModalOpen", "PurchaseSuccess", "CountdownBeep", "MatchStart", "Victory"):
    check(f"sound '{needed}' present", needed in sounds)

# ---------------------------------------------------------------- 10
print("\n10) VFX from the user's assestvfxx.txt pack")
vfx = (ROOT / "Modeller_Ve_Kurulum_Kodlari" / "VFXService.luau").read_text(encoding="utf-8")
vfx_ids = set(re.findall(r"rbxassetid://(\d+)", vfx))
pool = set(re.findall(r"Particle:\s*(\d+)|Sound:\s*(\d+)|Beam:\s*(\d+)|Decal:\s*(\d+)",
                       (Path("/home/user/uploads/assestvfxx.txt")).read_text(errors="replace")))
pool = {x for pair in pool for x in pair if x}
check(f"VFX service uses {len(vfx_ids)} asset ids", len(vfx_ids) > 10)
used_from_pool = vfx_ids & pool
check(f"at least 10 VFX ids come from the user's assestvfxx.txt (got {len(used_from_pool)})",
      len(used_from_pool) >= 10)

print()
if failures:
    print(f"FAILED {len(failures)} check(s):")
    for f in failures:
        print("  -", f)
    sys.exit(1)
print("ALL RUNTIME SIMULATION CHECKS PASSED")
