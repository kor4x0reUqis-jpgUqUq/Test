#!/usr/bin/env python3
"""
build_grab_ui_pack.py — GRAB! v4 UIPack/2 packager.

Produces GRAB_UI_Pack.zip containing:
  manifest.json   (UIPack/2 schema, controller = GrabUIController)
  images/*.png    (preview thumbnails)
  pixels/*.rgba   (raw RGBA byte buffers for native EditableImage preview)
  scripts/*.luau  (CheckUITheme / CheckUIComponents / CheckUIIcons / GrabUIController /
                    GrabClientInput / GrabServerBridge)
"""
import hashlib
import json
import os
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "ui_pack_src"
OUT = ROOT / "GRAB_UI_Pack.zip"

PACKAGE_ID = "grab_arena_ui"
TITLE = "GRAB! Arena — Check-UI v4 Arayüz Paketi"
DESIGN = [1280, 720]

# key -> (title, fallback rbxassetid)
ASSETS = {
    "stud_tile": ("Studs Texture 9454666962", "rbxassetid://9454666962"),
    "checkerboard": ("Checkerboard Damier", "rbxassetid://385956923"),
    "icon_shop": ("MAĞAZA ikonu", "rbxassetid://81391800986893"),
    "icon_skills": ("ÖZELLİKLER ikonu", "rbxassetid://134935514923667"),
    "icon_vote": ("HARİTA OYLA ikonu", "rbxassetid://113307446652263"),
    "icon_cash": ("Altın nakit ikonu", "rbxassetid://89267825858001"),
    "icon_wins": ("Kupa ikonu", "rbxassetid://85191169051998"),
    "icon_streak": ("Madalya ikonu", "rbxassetid://101110170593107"),
    "icon_vip": ("VIP ikonu", "rbxassetid://87880162965828"),
    "icon_close": ("Kapat butonu", "rbxassetid://121093709275694"),
    "icon_info": ("Bilgi ikonu", "rbxassetid://110199384922279"),
    "icon_warning": ("Uyarı ikonu", "rbxassetid://82000746005868"),
    "icon_check": ("Onay ikonu", "rbxassetid://75340450258025"),
    "icon_location": ("Konum iğnesi", "rbxassetid://125727545883099"),
    "icon_star": ("Altın yıldız", "rbxassetid://105103627769338"),
    "icon_player": ("Oyuncu ikonu", "rbxassetid://84565274576236"),
    "icon_rip": ("RIP ikonu", "rbxassetid://123202112919028"),
    "icon_skull": ("Kafatası", "rbxassetid://83738751439313"),
    "icon_friend": ("Arkadaş", "rbxassetid://104726247016522"),
    "icon_coin": ("Altın coin", "rbxassetid://81781760189273"),
    "icon_cloud": ("Bulut", "rbxassetid://90641474683767"),
    "icon_leaf": ("Yaprak", "rbxassetid://134887518393689"),
    "icon_wheat": ("Buğday", "rbxassetid://126430448804915"),
    "icon_thunder": ("Fırtına", "rbxassetid://103129368324258"),
    "icon_fire": ("Ateş", "rbxassetid://132160586991855"),
    "icon_magnify": ("Büyüteç", "rbxassetid://71166825735703"),
    "icon_save": ("Kaydet", "rbxassetid://105116447431895"),
    "icon_trade": ("Takas", "rbxassetid://91526512763195"),
    "icon_verify": ("Onay rozeti", "rbxassetid://83300666527669"),
    "icon_house": ("Ev", "rbxassetid://114849616028436"),
    "icon_settings": ("Ayarlar", "rbxassetid://75107759162473"),
    "icon_stats": ("İstatistik", "rbxassetid://140134117967096"),
    "icon_wheel": ("Çark", "rbxassetid://113307446652263"),
    "skill_dash": ("ATILMA - koşu ayakkabısı", "rbxassetid://98292714980053"),
    "skill_superthrow": ("SÜPER FIRLATMA - roket", "rbxassetid://102027666188634"),
    "skill_shield": ("KARŞI KALKAN - kalkan", "rbxassetid://116965577082727"),
    "skill_telekinesis": ("TELEKİNEZİ - mıknatıs", "rbxassetid://131659960050691"),
    "skill_shockwave": ("ŞOK DALGASI - hedef", "rbxassetid://100052184065891"),
    "skill_shadowblink": ("GÖLGE ADIMI - ışınlanma", "rbxassetid://134244641375149"),
    "map_orman": ("Orman Adası görünümü", "rbxassetid://9454666962"),
    "map_volkanik": ("Volkanik Krater görünümü", "rbxassetid://9454666962"),
    "map_halloween": ("Cadılar Bayramı görünümü", "rbxassetid://9454666962"),
    "map_insaat": ("İnşaat Alanı görünümü", "rbxassetid://9454666962"),
    "map_sirk": ("Sirk Çadırı görünümü", "rbxassetid://9454666962"),
}

SCRIPTS = [
    ("CheckUIIcons", "ModuleScript", "Shared", "scripts/CheckUIIcons.luau"),
    ("CheckUITheme", "ModuleScript", "Shared", "scripts/CheckUITheme.luau"),
    ("CheckUIComponents", "ModuleScript", "Shared", "scripts/CheckUIComponents.luau"),
    ("GrabUIController", "ModuleScript", "UI", "scripts/GrabUIController.luau"),
    ("GrabClientInput", "LocalScript", "Client", "scripts/GrabClientInput.luau"),
    ("GrabServerBridge", "Script", "Server", "scripts/GrabServerBridge.luau"),
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    images_dir = SRC / "images"
    pixels_dir = SRC / "pixels"
    scripts_dir = SRC / "scripts"
    for d in (images_dir, pixels_dir, scripts_dir):
        d.mkdir(parents=True, exist_ok=True)

    asset_entries = []
    for key, (title, fallback) in ASSETS.items():
        png = images_dir / f"{key}.png"
        rgba = pixels_dir / f"{key}.rgba"
        if not png.exists():
            # create a 1x1 transparent placeholder so the pack stays schema-valid
            png.write_bytes(
                bytes.fromhex(
                    "89504e470d0a1a0a0000000d494844520000000100000001080600000"
                    "01f15c4890000000d4944415478da63fcffff3f0300050001a5f645bf0000"
                    "000049454e44ae426082"
                )
            )
        if not rgba.exists():
            rgba.write_bytes(b"\x00\x00\x00\x00")

        # verify rgba size matches width*height*4
        from PIL import Image

        with Image.open(png) as im:
            w, h = im.size
        expected = w * h * 4
        if rgba.stat().st_size != expected:
            rgba.write_bytes(b"\x00" * expected)

        asset_entries.append(
            {
                "key": key,
                "title": title,
                "width": w,
                "height": h,
                "png": f"images/{key}.png",
                "rgba": f"pixels/{key}.rgba",
                "sha256": sha256(png),
                "fallbackId": fallback,
            }
        )

    manifest = {
        "format": "UIPack/2",
        "id": PACKAGE_ID,
        "title": TITLE,
        "designSize": DESIGN,
        "controller": "GrabUIController",
        "assets": asset_entries,
        "tree": {
            "class": "Frame",
            "name": "GRABRootCanvas",
            "props": {
                "Size": [1, 0, 1, 0],
                "Position": [0, 0, 0, 0],
                "BackgroundTransparency": 1,
                "ClipsDescendants": False,
                "ZIndex": 10,
            },
            "children": [],
        },
        "vfx": [],
        "scripts": [
            {"name": n, "kind": k, "target": t, "path": p} for (n, k, t, p) in SCRIPTS
        ],
        "metadata": {
            "game": "GRAB!",
            "texture_contract": "rbxassetid://9454666962",
            "responsive_scaling": "UIScale per anchored container (AttachResponsiveScale)",
            "modal_environment": "Camera FOV 70->84 + Lighting.GRAB_MenuBlur 0->20 + HUD auto-hide",
            "sounds": "SoundService.GRAB_Sounds (14 cues)",
            "icon_pack": "Free Icon Pack 3.0.1 (Basic) style — real rbxassetids",
        },
    }

    (SRC / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    (SRC / "assets_index.json").write_text(
        json.dumps({k: v[1] for k, v in ASSETS.items()}, ensure_ascii=False, indent=1),
        encoding="utf-8",
    )

    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(SRC / "manifest.json", "manifest.json")
        zf.write(SRC / "assets_index.json", "assets_index.json")
        for key in ASSETS:
            png = images_dir / f"{key}.png"
            rgba = pixels_dir / f"{key}.rgba"
            if png.exists():
                zf.write(png, f"images/{key}.png")
            if rgba.exists():
                zf.write(rgba, f"pixels/{key}.rgba")
        for _, _, _, path in SCRIPTS:
            f = SRC / path
            if f.exists():
                zf.write(f, path)

    print(f"Built {OUT} ({OUT.stat().st_size:,} bytes) with {len(ASSETS)} assets and {len(SCRIPTS)} scripts.")


if __name__ == "__main__":
    main()
