---
name: check-ui-studio-packager
description: >
  Roblox Studio "UI Studio 5.2" eklentisi (UI_Paket_Pro.lua) + yerel köprü (bridge.py) ile
  %100 uyumlu UIPack/2 (.zip) arayüz paketleri üretme kılavuzu. Hem bir Yapay Zeka (AI)
  modeline hem de bir insana hitap eder. Kullanıcı bu eklenti için yeni bir Roblox UI
  paketi (.zip) ürettirmeni istediğinde: UIPack/2 şemasına birebir uy, doku sözleşmesini
  (rbxassetid://9454666962) koru, Check-UI v4 stil kurallarını (studs panel, ekran
  hizalama, UIScale, FOV+Blur, ses) uygula, gerçek harita/öğe önizlemeleri üret.
version: 4.0.0
---

# 🎨 Check-UI v4 & UI Studio 5.2 — Yapay Zeka (AI) ve İnsan İçin Tam UI Paketi (`.zip`) Üretim Rehberi

Bu paket iki şey içerir:

1. **Çalışan araçlar:** Roblox Studio eklentisi (`UI_Paket_Pro.lua`), yerel köprü
   (`bridge.py`), paketleyici araçlar ve Check-UI bileşen kütüphanesi.
2. **Bu doküman:** Başka bir Yapay Zeka (AI) modeline veya bir geliştiriciye, bu eklentiyle
   **aynı tarzda**, çalışan, derlenmiş `.zip` UI paketleri nasıl üreteceğini anlatan
   adım adım kılavuz.

> ### 🤖 Yapay Zeka (AI) Asistanına Doğrudan Talimat
> Kullanıcı sana bu Skill paketini yükleyip *"şu oyun için eklentiyle uyumlu bir UI .zip
> paketi yap"* dediğinde şu 7 adımı **eksiksiz** uygula:
>
> 1. **`UIPack/2` şemasına birebir uy** (§2). Eksik alan kurulum hatası verir.
> 2. **Doku sözleşmesini koru:** 3B yüzeylerde `rbxassetid://9454666962`
>    (AssetTypeId **10** = Texture). 2D `ImageLabel` için bu ID **kullanılamaz**;
>    2D stud görseli `rbxassetid://113053849916466` (AssetTypeId 1 = Image) veya
>    paketin kendi yüklenmiş PNG'si kullanılmalı (§3).
> 3. **Check-UI v4 stil kurallarını** uygula: studs arka plan, çok katmanlı çerçeve,
>    eğik başlık bandı, 3B bevel butonlar (§4).
> 4. **Tam ekran kenar hizalama + `UIScale`:** `Window`/`Root` **her zaman**
>    `UDim2.fromScale(1, 1)`; her kenar paneline `AttachResponsiveScale` (§5).
> 5. **Menü açılışı:** Kamera FOV `70 → 84`, `Lighting.GRAB_MenuBlur` `Size 0 → 20`,
>    diğer HUD panelleri gizlenir (§6).
> 6. **Ses:** `SoundService.GRAB_Sounds` + hover/click/modal/purchase efektleri (§7).
> 7. **Alakasız ikon kullanma:** Harita/öğe kartlarında **gerçek görünüm** üret —
>    ya 3B prosedürel diyorama (`CreateMapPreviewBox`) ya da izometrik PNG (§8).
>
> Çıktı: **`bridge.py` veya eklentinin okuyabildiği tek bir `.zip` dosyası.**

---

## 1. SİSTEM MİMARİSİ — 3 PARÇA

```
  ┌──────────────────┐   HTTP (localhost)   ┌──────────────────┐
  │  UI_Paket_Pro    │ ───────────────────► │  bridge.py       │
  │  (Studio Plugin) │  ◄─────────────────── │  (127.0.0.1:     │
  │  Plugins klasörü │   JSON / bayt        │   38475)         │
  └────────┬─────────┘                      └────────┬─────────┘
           │ ZIP okur, doğrular, kurar              │ Open Cloud API
           │                                        ▼
           │                                 Roblox Asset (Image)
           ▼
  ┌──────────────────────────────────────────────────────────┐
  │  <Paket>.zip  (UIPack/2)                                │
  │   manifest.json + images/*.png + pixels/*.rgba + scripts/ │
  └──────────────────────────────────────────────────────────┘
```

| Parça | Görev |
|---|---|
| **`UI_Paket_Pro.lua`** | `%LOCALAPPDATA%\Roblox\Plugins\` içine kurulur. ZIP'i açar, `manifest.json`'ı doğrular, görselleri **ya** Open Cloud'a yükler **ya** `.rgba` baytlarından `EditableImage` ile önizler, scriptleri hedefe taşır, her şeyi **kendi yeniler**. |
| **`bridge/bridge.py`** | Python 3.10+, sadece stdlib. `127.0.0.1:38475`. API anahtarı **diske yazılmaz**, RAM'de tutulur. |
| **`<Paket>.zip`** | `UIPack/2` formatında arşiv (aşağıda tam şema). |

### Eklentinin kurulum hedefleri (otomatik)

| `manifest.scripts[].target` | Roblox hedefi |
|---|---|
| `Shared` | `ReplicatedStorage.UIP_Shared_<id>` içine `ModuleScript` |
| `UI` | `StarterGui.UIP_<id>` içine `ModuleScript` (**controller** buraya) |
| `Client` | `StarterPlayer.StarterPlayerScripts.UIP_Client_<id>` içine `LocalScript` |
| `Server` | `ServerScriptService.UIP_Server_<id>` içine `Script` |

`manifest.controller` adı verilen `UI` modülü, kurulumda otomatik olarak bir
`Package_Start` `LocalScript`'i ile çağrılır:

```luau
local ctx = {gui=script.Parent, preview=false, shared=game:GetService('ReplicatedStorage'):WaitForChild('UIP_Shared_<id>')}
local module = require(script.Parent:WaitForChild('<controller>'))
assert(type(module)=='table' and type(module.mount)=='function','Controller.mount gerekli')
module.mount(ctx)
```

Yani **controller modülü `return { mount = function(ctx) ... end }` biçiminde olmalıdır.**

---

## 2. `UIPack/2` ZIP ANATOMİSİ (ZORUNLU)

```
PaketAdi_UI_Pack.zip
├── manifest.json            ← ZORUNLU
├── images/                  ← ZORUNLU (PNG, 1..1024 px)
│   ├── stud_tile.png
│   ├── icon_shop.png
│   └── map_orman.png
├── pixels/                  ← ZORUNLU (ham RGBA8, tam olarak width*height*4 bayt)
│   ├── stud_tile.rgba
│   ├── icon_shop.rgba
│   └── map_orman.rgba
└── scripts/                 ← ZORUNLU (Luau kaynak)
    ├── CheckUIIcons.luau
    ├── CheckUITheme.luau
    ├── CheckUIComponents.luau
    ├── <Controller>.luau
    └── <ClientInput>.luau
```

### 2.1 `pixels/<key>.rgba` nedir?

`UI_Paket_Pro.lua`, **internet ve API anahtarı olmadan bile** görselleri Studio içinde
`EditableImage:WritePixelsBuffer` ile çizebilmek için her PNG'nin yanında
**sıkıştırılmamış ham RGBA bayt dizisi** bekler.

```python
from PIL import Image
import hashlib

def save_ui_asset(img: Image.Image, key: str, title: str, fallback_id: str, out_dir):
    img = img.convert("RGBA")
    w, h = img.size
    png_rel, rgba_rel = f"images/{key}.png", f"pixels/{key}.rgba"
    img.save(out_dir / png_rel, "PNG")
    (out_dir / rgba_rel).write_bytes(img.tobytes("raw", "RGBA"))
    return {
        "key": key, "title": title, "width": w, "height": h,
        "png": png_rel, "rgba": rgba_rel,
        "sha256": hashlib.sha256((out_dir / png_rel).read_bytes()).hexdigest(),
        "fallbackId": fallback_id,
    }
```

> **Kritik:** `.rgba` dosyasının boyutu **tam olarak** `width * height * 4` olmalıdır.
> Eklenti bunu doğrular; küçük/büyük olursa kurulum reddedilir.

### 2.2 `manifest.json` Şeması

```json
{
  "format": "UIPack/2",
  "id": "oyun_adi_ui",
  "title": "Oyun Adı — Check-UI v4 Arayüz Paketi",
  "designSize": [1280, 720],
  "controller": "OyunUIController",
  "assets": [
    {
      "key": "stud_tile",
      "title": "Studs Texture",
      "width": 128, "height": 128,
      "png": "images/stud_tile.png",
      "rgba": "pixels/stud_tile.rgba",
      "sha256": "…",
      "fallbackId": "rbxassetid://9454666962"
    }
  ],
  "tree": {
    "class": "Frame",
    "name": "OyunRootCanvas",
    "props": { "Size": [1,0,1,0], "Position": [0,0,0,0], "BackgroundTransparency": 1, "ClipsDescendants": false },
    "children": []
  },
  "vfx": [],
  "scripts": [
    { "name": "CheckUIIcons",      "kind": "ModuleScript", "target": "Shared", "path": "scripts/CheckUIIcons.luau" },
    { "name": "CheckUITheme",      "kind": "ModuleScript", "target": "Shared", "path": "scripts/CheckUITheme.luau" },
    { "name": "CheckUIComponents", "kind": "ModuleScript", "target": "Shared", "path": "scripts/CheckUIComponents.luau" },
    { "name": "OyunUIController",  "kind": "ModuleScript", "target": "UI",     "path": "scripts/OyunUIController.luau" }
  ]
}
```

**Doğrulama kuralları (`Schema.luau`):**
* `format` `UIPack/1`, `UIPack/2` veya `UIPack/3` olmalı.
* `id` sadece `A-Z a-z 0-9 _ -` içerebilir; `title` ≤ 120 karakter.
* `designSize` her iki boyutta da 200..4096 arası.
* `tree` bir `Frame` olmalı; adlar benzersiz ve `[A-Za-z_][A-Za-z0-9_]*` olmalı.
* `tree.props` içinde **yalnızca izin verilen** özellikler kullanılabilir
  (`Size`, `Position`, `AnchorPoint`, `BackgroundColor3`, `Text`, `Font`, `Image`…);
  `Enum` değerleri **string** olarak yazılır (`"GothamBlack"`, `"Tile"`, `"Border"`).
* `scripts` içinde: `Shared` → sadece `ModuleScript`, `Client` → sadece `LocalScript`,
  `Server` → sadece `LocalScript`/`Script`, `UI` → `ModuleScript`/`Script`/`LocalScript`.
* `controller` → `kind == "ModuleScript"` **ve** `target == "UI"` olmalı.
* `vfx[]` girdileri `texture` (bir `assets` key'i), `rate`, `lifetime`, `speed`,
  `size`, `color` alanlarını zorunlu tutar.

---

## 3. DOKU SÖZLEŞMESİ — `9454666962` (EN SIK YAPILAN HATA)

`rbxassetid://9454666962` Roblox'ta **AssetTypeId 10 = "Texture"**'tir
(`economy.roblox.com/v2/assets/9454666962/details` ile doğrulanabilir).

| Kullanım yeri | Doğru mu? | Yerine |
|---|---|---|
| 3B `Texture` instance (`part:FindFirstChild("MM4_Studs_Top")`) | ✅ **DOĞRU** | — |
| 2D `ImageLabel.Image` / `ImageButton.Image` | ❌ **YANLIŞ** (boş/kırık doku) | `rbxassetid://113053849916466` (AssetTypeId 1 = gerçek stud **Image**) veya paketin yüklenmiş PNG'si |

**Kural:**
* **3B dünya:** `Enum.Material.Plastic` + `Enum.SurfaceType.Studs` (native gerçek stud gölgesi)
  **+** 6 yüzlü `Texture` instance (`Top, Bottom, Left, Right, Front, Back`) →
  `Texture = "rbxassetid://9454666962"`, `StudsPerTileU/V = 4`, `Transparency ≈ 0.55`.
  (`Enum.Material.SmoothPlastic` kullanma — stud yüzeyini gizler.)
* **2D UI:** `Theme.ResolveDamierImage()` gibi bir çözümleyici kullan; önce sözleşme
  ID'sini dener, düşerse gerçek stud **Image**'ına düşer. Ekranda asla boş doku kalmasın.
* `945466696` (9 hane) **Place**'dir, resim değildir — **asla** kullanma.

---

## 4. CHECK-UI v4 GÖRSEL STİL KURALLARI (7 kural)

### Kural 1 — Studs / dama dokusu
2D arka plan daima `ScaleType = Enum.ScaleType.Tile` + `TileSize = UDim2.fromOffset(22, 22)`
(butonlarda 19-24) ile döşenir. `Stretch` bırakırsan doku bulanıklaşır.

### Kural 2 — Çok katmanlı 3B çerçeve
Her modal/kart şu katmanları içerir:
1. **Dış gölge** (4-8 px aşağıda, siyah, %42 saydam, 22-24 px köşe)
2. **Ana gövde** (dikey `UIGradient`, `UICorner` 14-22 px, `UIStroke` 3-4 px siyah)
3. **İç parlama çerçevesi** (`UIStroke` 1.2-1.5 px, beyaz, %40-80 saydam)
4. **Üst parlama şeridi** (üst %38 beyaz, %78 saydam)
5. **Eğik başlık bandı** (`Rotation = -2`, altın gradyan, `FredokaOne`/`GothamBlack`, siyah kontur)
6. **Sağ üst kırmızı çarpı** (ImageButton, `Rotation = 5`, kırmızı gradyan)

### Kural 3 — Tam ekran kenar hizalama + `UIScale`
`Window` ve `Root` **her zaman** `UDim2.fromScale(1, 1)` olmalıdır; aksi halde
kenar panelleri ekran ortasında yüzer (v3'te yaşanan hata buydü).
Ölçekleme `Window` üzerinde değil, **her panelin içinde** `UIScale` ile yapılır:

```luau
local scale = Comp.AttachResponsiveScale(leftHud, 1280, 720, 0.78, 1.15)
```

Kanonik kenar sabitleri:
```
Sol HUD      AnchorPoint (0, 0.5)   Position UDim2.new(0, 18, 0.5, 0)
Sağ-alt Q    AnchorPoint (1, 1)     Position UDim2.new(1, -24, 1, -22)
Üst banner   AnchorPoint (0.5, 0)   Position UDim2.new(0.5, 0, 0, 10)
Modallar     AnchorPoint (0.5, 0.5) Position UDim2.fromScale(0.5, 0.5)
```

### Kural 4 — Menü açılışı: FOV + Blur + HUD gizleme
```luau
Comp.SetModalEnvironmentEffects(true)  -- FOV 70->84, Blur 0->20
leftHud.Visible = false; skillHolder.Visible = false; reticle.Visible = false
```
Menü kapanınca hepsi geri gelir. `BlurEffect` adı **`GRAB_MenuBlur`** olmalı
(`Lighting` altında, `Size = 0` ile hazır bulunmalı).

### Kural 5 — Gerçek görünüm, alakasız ikon yok
Harita/eşya/sınıf kartlarında **içeriği temsil etmeyen** genel ikon kullanma.
İki yol:
* **3B prosedürel diyorama:** `Comp.CreateMapPreviewBox(parent, mapId, zIndex)` —
  gökyüzü gradyanı, güneş, bulut, su şeridi, **kenar rimli** ada, merkez madalyon,
  temaya özel dekor (ağaç/lav/kabak/scaffold/çadır).
* **İzometrik PNG:** `tools/generate_grab_ui_assets.py` ile üret (bkz. §9).

### Kural 6 — Ses
`Comp.EnsureSounds()` `SoundService.GRAB_Sounds` klasörünü kurar.
Buton `MouseEnter` → `UIHover`, `MouseButton1Down` → `UIClick`, modal açılış → `ModalOpen`,
satın alma → `PurchaseSuccess`.

### Kural 7 — Tipografi ve boyut
`Font = Enum.Font.GothamBlack`, metinler `UIStroke` (2-3 px siyah, `Contextual`) ile
konturlanır. HUD buton yazısı ≥ 26 px, başlık ≥ 38 px, fiyat ≥ 18 px.
Küçük yazı/ikon bırakma; her zaman `UIScale` ile büyüt.

---

## 5. ADIM ADIM YENİ PAKET ÜRETİM AKIŞI

### Adım 1 — Temel modülleri kopyala
Bu paketin `CheckUI_Temel_Moduller/` klasöründen şunları yeni paketin `scripts/`
klasörüne kopyala:
* `CheckUIIcons.luau` (1022 ikon, gerçek `rbxassetid`)
* `CheckUITheme.luau` (renkler, tipografi, asset kayıtları, harita/özellik katalogları)
* `CheckUIComponents.luau` (tüm üretici fonksiyonlar + v4 ekleri)

### Adım 2 — Controller modülünü yaz
```luau
--!nonstrict
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local OyunUIController = {}

function OyunUIController.mount(ctx: { gui: Instance, preview: boolean?, shared: Folder? })
    local gui = ctx.gui
    local shared = ctx.shared or ReplicatedStorage:WaitForChild("UIP_Shared_<id>")
    local Theme = require(shared:WaitForChild("CheckUITheme"))
    local Comp  = require(shared:WaitForChild("CheckUIComponents"))

    Comp.EnsureSounds()
    local assets = Theme.ResolveAssets(gui)

    -- 1) Window / Root TAM EKRAN
    local viewport = gui:FindFirstChild("Viewport")
    local window = viewport and viewport:FindFirstChild("Window")
    if window then
        window.Size = UDim2.fromScale(1, 1)
        window.Position = UDim2.fromScale(0, 0)
        window.AnchorPoint = Vector2.zero
        local rs = window:FindFirstChild("ResponsiveScale")
        if rs and rs:IsA("UIScale") then rs.Scale = 1 end
    end
    -- 2) HUD panellerini kenara yasla + AttachResponsiveScale
    -- 3) Modalları CreateModalShell ile kur
    -- 4) Modal aç/kapa -> Comp.SetModalEnvironmentEffects(anyOpen) + HUD gizle
    -- 5) Ağ bağlantısı (RemoteEvent dinleme)
end

return OyunUIController
```

### Adım 3 — Görselleri üret
`tools/generate_grab_ui_assets.py` çalıştır → `images/*.png` + `pixels/*.rgba` + `generation_report.json`.

### Adım 4 — Paketi birleştir
`tools/build_grab_ui_pack.py` çalıştır → `manifest.json` + `<Paket>.zip`.

### Adım 5 — Doğrula
```bash
python3 tools/build_grab_ui_pack.py
python3 Runtime_Sim.py                 # yaşam döngüsü / stil kontrolleri
luau-analyze scripts/*.luau             # sıfır SyntaxError
```

---

## 6. İKON KAYNAKLARI

### 6.1 Hazır Roblox ikonları (en güvenli)
`CheckUIIcons.luau` içinde **1022 gerçek `rbxassetid`** var (kullanıcının
"Free Icon Pack 3.0.1 (Basic)" paketinin Roblox'a yüklenmiş hâli).
Kullanım:

```luau
local CheckUIIcons = require(shared:WaitForChild("CheckUIIcons"))
Image = CheckUIIcons.Main.Shopping_Bag.Golden_Shopping_Bag_1st_Outline
Image = CheckUIIcons.Item.Shield.Shield_1st_Outline
Image = CheckUIIcons.Exclusive.Magical_Teleport.Purple_Magical_Teleport_1st_Outline
```

**Yararlı kategoriler:** `Currency` (Cash/Coin/Diamond/Ingot/Ticket), `Main`
(Shopping_Bag/Settings/Stats/Star/Trade/Upgrade/Verify/Wheel/House/Fire/Lighting/…),
`Item` (Shield/Rocket/Magnet/Target/Shoe/Crown/Trophy/Medal/Bomb/Dice/Chest/Clock/…),
`Exclusive` (VIP/Aura/Magical_Teleport/Trail/Angel_Heart), `Nature`
(Cloud/Leaf/Wheat/Thunderstorm/Planet/Apple/Strawberry), `Player` (Player/Skull/RIP/Friend/Full_Body),
`Food` (Pizza/Burger/Cookie/Apple…).

### 6.2 Kendi ikonunu aynı stilde üret
Gereken ikon pakette yoksa **aynı çizgi stiliyle** kendin üret
(`.png` + `.rgba` + `manifest` girdisi). Stil kuralları:
* 256×256 RGBA, şeffaf arka plan
* Kalın **koyu dış hat** (2D comic / "Free Icon Pack" tarzı)
* Doygun, sıcak renkler + tek bir açık ton
* `Icon` ikonu: `255,255,255` saydam olmayan; orta tonlarda kontur

Örnek üretim (Pillow) — bu paketin `tools/generate_grab_ui_assets.py` dosyasında
37 ikon bu şekilde kopyalanmış/üretilmiştir.

### 6.3 Anlamsal eşleşme kuralı
| Yetenek/özellik | Doğru ikon |
|---|---|
| Atılma / koşu / hız | `Item.Shoe.*` (ayakkabı) |
| Süper fırlatma / roket | `Item.Rocket.*` |
| Kalkan / savunma | `Item.Shield.*` |
| Çekme / mıknatıs | `Item.Magnet.*` |
| Şok dalgası / hedef | `Item.Target.*` |
| Işınlanma / teleport | `Exclusive.Magical_Teleport.*` |
| Mağaza / satın alma | `Main.Shopping_Bag.*` |
| Para / altın | `Currency.Cash.Golden_Cash_1st_Outline` |
| Zafer / kupa | `Item.Trophy.Golden_Trophy_1st_Outline` |
| Seri / madalya | `Item.Medal.Golden_Medal_1st_Outline` |
| VIP | `Exclusive.VIP.VIP_1st_Outline` |

---

## 7. HARİTA / ÖĞE ÖNİZLEME ÜRETİMİ (izometrik PNG)

Harita küçük resimleri **gerçek haritanın görünümünü** yansıtmalıdır.
Bu paketin üreteci: 320×200 PNG, gökyüzü gradyanı + güneş + su + **kenar rimli ada**
+ merkez madalyon + tema dekoru.

```python
from PIL import Image, ImageDraw
import math

W, H = 320, 200

def make_map_thumbnail(palette, props):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # 1) gökyüzü dikey gradyanı
    for y in range(H):
        t = y / H
        d.line([(0, y), (W, y)],
               fill=tuple(int(palette["sky"][i]*(1-t)+palette["sky2"][i]*t) for i in range(3)) + (255,))
    # 2) güneş
    d.ellipse([W-58, 16, W-22, 52], fill=(255, 240, 180, 255))
    # 3) su şeridi
    # 4) ada (elips) + BORDER rim (çevre bloklar)
    cx, cy, rx, ry = W/2, H*0.50, W*0.44, H*0.26
    d.ellipse([cx-rx, cy-ry, cx+rx, cy+ry], fill=palette["ground2"] + (255,))
    for i in range(22):                      # ← BORDER: kenar blokları
        a = (i / 22) * math.tau
        bx, by = cx + math.cos(a)*(rx-4), cy + math.sin(a)*(ry-3)
        d.rectangle([bx-4.5, by-4.5, bx+4.5, by+4.5],
                    fill=palette["rock"] + (255,), outline=palette["rock2"] + (255,))
    # 5) merkez madalyon
    # 6) tema dekoru (ağaç / lav / mezar / scaffold / çadır)
    return img
```

---

## 8. VFX KULLANIMI (kullanıcının `assestvfxx.txt` havuzu)

Kullanıcının VFX havuzu ID listesinden **gerçek** `ParticleEmitter` / `Beam` / `Sound`
varlıkları seç. **Sadece listelemek başarı değildir**; ID bir `ParticleEmitter.Texture`
ya da `Beam.Texture` olarak **gerçekten bağlanmalı** ve doğru role atanmalıdır.

```luau
local catalog = {
    BasicHit     = { "rbxassetid://1463874772", "rbxassetid://6489454124" },
    ShieldBlock  = { "rbxassetid://7225262171", "rbxassetid://7556074751" },
    DarkBlink    = { "rbxassetid://5234964512", "rbxassetid://4726930169" },
    FireMagma    = { "rbxassetid://6706234595", "rbxassetid://1084962479" },
}

local pe = Instance.new("ParticleEmitter")
pe.Texture = catalog.BasicHit[1]     -- gerçek havuz ID'si
pe.LightEmission = 0.85
pe.LightInfluence = 0.15
pe.Size = NumberSequence.new(...)
pe.Transparency = NumberSequence.new(...)
pe.Lifetime = NumberRange.new(0.3, 0.7)
pe.Speed = NumberRange.new(10, 28)
pe.Rate = 0
pe:Emit(18)
```

**Kabul kapısı:** ID'nin *gerçek* görünüşünü doğrulayamadıysan efekt "DOĞRULANMADI"
olarak işaretle, uydurma başarı bildirme.

---

## 9. PAKETİ DERLEME (tam komut satırı)

```bash
cd <paket_kok>
python3 tools/generate_grab_ui_assets.py     # ikon + harita görselleri
python3 tools/build_grab_ui_pack.py          # manifest.json + <Paket>.zip
python3 Runtime_Sim.py                       # stil/yaşam döngüsü kontrolleri
luau-analyze ui_pack_src/scripts/*.luau       # sıfır SyntaxError
```

Çıktı: `manifest.json` + `images/` + `pixels/` + `scripts/` içeren tek `.zip`.

---

## 10. SIK YAPILAN HATALAR VE DOĞRU ÇÖZÜMLERİ

| Hata | Belirti | Çözüm |
|---|---|---|
| `Window` sabit boyutlu (`1100x680`) | HUD ekran ortasında yüzer, kenarlara yapışmaz | `Window.Size = UDim2.fromScale(1,1)`, `Position = fromScale(0,0)`, `AnchorPoint = zero` |
| Tek `UIScale` tüm ekranda | Küçük ekranda her şey küçülür, büyük ekranda büyür | `Window.ResponsiveScale = 1`; ölçek **panel başına** `AttachResponsiveScale` |
| Texture ID'si 2D UI'da | Damier/ikon boş veya kırık | 3B'de `9454666962`, 2D'de gerçek **Image** ID'si kullan |
| `Theme.ResolveAssets` yükleme ID'lerini eziyor | Yeni yüklenen görseller görünmüyor | `AssetMap` değerleri `DefaultAssets`'ın **üzerine** yazabilmeli (stud hariç) |
| Alakasız ikon (harita kartında kalkan) | "Mapın görünümü yerine farklı görünümler kullanılmış" | `CreateMapPreviewBox` diyorması veya izometrik PNG |
| Plugin "Farklı içerik korunuyor" hatası | Yeniden kurulum engelleniyor | `Engine.canInstall` / `Engine.commit` içindeki koruma **kaldırılmalı** (v4: her zaman üzerine yaz) |
| `MAĞAZAYI AÇ` butonu | Kullanıcı istemedi | `Engine.build` içinden `Reopen` butonu silinmeli |
| Modallar açınca HUD görünüyor | "Diger UI görünürlükleri kapatılıp blur eklenmeli" | `syncHudAndEnvironmentToModals()` her modal değişiminde çağrılmalı |
| `.rgba` boyutu tutarsız | Kurulum reddediliyor | `width*height*4` bayta **tam** eşit olmalı |
| `require` edilemeyen modül | "Controller.mount gerekli" | `UI` hedefli modül `ModuleScript` olmalı ve `mount` dönmeli |

---

## 11. PAKET İÇERİĞİ

```
CheckUI_Skill_Package/
├── SKILL.md                          ← bu doküman
├── Plugin_Ve_Kurulum/
│   ├── UI_Paket_Pro.lua              ← Plugins klasörüne kurulacak derlenmiş eklenti
│   ├── Windows_Kur.cmd               ← tek tıkla kurulum + köprü başlatma
│   ├── Kopru_Baslat.cmd
│   ├── build.py                      ← src/*.luau -> UI_Paket_Pro.lua derleyici
│   ├── bridge/bridge.py              ← 127.0.0.1:38475 Open Cloud köprüsü
│   └── src/                          ← eklenti kaynak kodu (Binary/Library/Schema/Motion/
│                                        Icons/Theme/Bridge/Engine/Main)
├── CheckUI_Temel_Moduller/
│   ├── CheckUIIcons.luau             ← 1022 ikon (gerçek rbxassetid)
│   ├── CheckUITheme.luau             ← tasarım token'ları + asset kayıtları
│   ├── CheckUIComponents.luau        ← tüm üretici fonksiyonlar (v4 ekleriyle)
│   ├── GrabUIController.luau         ← tam örnek controller (HUD + 3 modal + oylama)
│   ├── GrabClientInput.luau          ← örnek client giriş/oyuncu scripti
│   └── GrabServerBridge.luau
└── Ornek_Paket_Ve_Araclar/
    ├── generate_grab_ui_assets.py    ← 37 ikon + 5 izometrik harita + desen üretici
    ├── build_grab_ui_pack.py         ← UIPack/2 paketleyici
    ├── Runtime_Sim.py                ← otomatik stil/yaşam döngüsü doğrulama
    ├── ui_pack_src/                  ← örnek paketin tam kaynak ağacı
    └── GRAB_UI_Pack.zip              ← hazır test paketi
```
