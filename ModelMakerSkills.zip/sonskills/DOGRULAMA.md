# 3.0 doğrulama ayrımı
Yeni sözleşmeler, referans yolları, JSON tercihleri, kaynak VFX byte eşitliği, negatif görseller ve ZIP/SHA kontrol edildi. Model kodları/paketleri revizyon öncesi SHA256 ile karşılaştırılarak değişmediği doğrulandı. Önceki Luau/geometry testleri tarihsel sonuçlardır; bu revizyonda Studio render/Animation Editor/asset erişimi testi yapılmadı. Yeni studs 945466696 için tür, erişim, görünüş ve haklar doğrulanmadı. Kullanıcı görselleri gerçek negatif kanıttır; asistanın yeni motor testi değildir.

# Paketin kontrol durumu

Tarih: 2026-10-20. Skill sürümü 2.1.0.

## Yapılanlar
- Ana SKILL.md giriş dosyası, başvuru dosyaları, şablonlar ve örneklerin paket yapısı kontrol edildi.
- VFX katalogu: 389 kayıt / 263 benzersiz ID; bu görüntü veya hak erişimi testi değildir.
- Yeni `GeometriAraclari.luau`, `GuvenliCSG.luau`, `Test_Geometri.luau` dosyaları Luau derleyicisi ile sözdizimi kontrolünden geçirildi.
- Geometri helper'ı engine dışı Vector3/CFrame test doubles ile denendi: X/Y/Z gradient toplam kapsamı, normal/dejenere üçgen, üst üste/dışarıda/tam kapsayan döşeme açıklıkları ve paralel normal fallback'i testleri geçti.
- Paket içindeki yeni çalışma `.luau` örnekleri sözdizimi derlemesinden geçirildi.
- Dört özgün TXT kaynak kopyasının byte bütünlüğü orijinallerle karşılaştırıldı.
- SKILL.md referans yolları, zorunlu dosyalar, SHA256 bütünlüğü ve ZIP arşiv bütünlüğü kontrol edildi.

## Yapılmayanlar
- Bu yeni CSG helper'ı Roblox Studio veya GeometryService motorunda çalıştırılmadı.
- Helper'ların gerçek render, çarpışma, avatar ve target-device testleri yapılmadı.
- Skill'in belirli bir üçüncü taraf AI uygulamasındaki otomatik yüklenmesi veya aynı çıktıyı üretmesi test edilmedi.
- Harici texture/VFX/animation asset erişimi veya ticari hakları doğrulanmadı.
- Önceki çalışmaların sayısal testleri Studio FPS veya görsel kalite sertifikası değildir.

## Kullanıcı tarafında
1. İlgili AI aracında skill'i yükle veya dosyaları ekle.
2. Küçük bir model isteğiyle tasarım kararlarını ve kod kalitesini incele.
3. Üretilen modeli Studio'da oluştur, görsel/rig/çarpışma kontrollerini yap.
4. Geri bildirimi öğrenme günlüğüne eklet; skill'i güncelle.

`tools/verify_package.py` Python standart kütüphanesiyle dosya yapısı/bütünlüğünü tekrar kontrol eder. Roblox çalıştırmaz. `Test_Geometri.luau` yalnız modül matematiği için test fonksiyonudur; CSG veya fizik testini temsil etmez.

## 2.1 revizyon kontrolü
- Önceki Luau testleri tarihsel sonuçlardır; bu revizyonda geometri helper kodu değiştirilmedi ve yeniden Studio testi yapılmadı.
- Yeni politika dosyaları, 15 özgün ekran görüntüsü, VFX CSV/JSON eşleşmesi ve referans yolları kontrol edildi.
- Eski asset kaynağı ve teslim edilmiş model ZIP SHA256 değerleri revizyon öncesiyle aynıdır.
- Talimat düzeltmesi, gelecekteki her AI çıktısının otomatik başarılı olacağını garanti etmez.
