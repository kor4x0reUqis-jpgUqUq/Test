# Check-UI Skill Index — Analiz ve Uygulama Notları

## 1. Repo çekme durumu

İstenen `TemporaryLooker22/Check-UI-Clean-Roblox` adresi şu anda doğrudan erişime `404` döndürüyor. Aynı içeriğin kamuya açık bir fork'u olan `diggofun/Check-UI-Clean-Roblox` üzerinden repo çekildi:

- Yerel klasör: `/home/user/Check-UI-Clean-Roblox`
- Commit: `52ac1edfe33b76d415c4f14dc5bd17307148f0a3`
- Sürüm: **v1.3.0 — Canonical Standard Iconless Button**
- Fork remote: `https://github.com/diggofun/Check-UI-Clean-Roblox.git`

Repo, Markdown veya Luau kaynaklarında gizli kontrol karakteri, prompt injection metni, `loadstring`, `getfenv`, `HttpService`, `InsertService` ya da sayısal `require(assetId)` çağrısı içermiyor.

## 2. Repo içeriği

```
Check-UI-Clean-Roblox/
├── SKILL.md                  # Agentic AI skill: 11 zorunlu tasarım kuralı
├── DESIGN_SYSTEM.md          # Matematiksel oranlar, katmanlar, tipografi
├── README.md                 # Hızlı başlangıç ve görsel showcase
├── release_notes.md          # v1.0.0 → v1.3.0 değişim geçmişi
├── assets/                   # 3 adet yüksek çözünürlüklü render
├── src/                      # 4 üretim Luau modülü
│   ├── CheckUITheme.luau         # Renk, tipografi, gradient, asset token'ları
│   ├── CheckUIComponents.luau    # Window, header, button, card, progress builder'ları
│   ├── CheckUIController.luau    # Responsive scale, pop tween, mikro etkileşim
│   └── CheckUIIcons.luau         # 1.022 adet 256px rbxassetid ikonu
└── examples/                 # Shop, Rebirth, Daily Rewards, Standard Button,
                              # Harmonized Menus örnek LocalScript'leri
```

## 3. Skill analizi — uygulanan ana kurallar

| Kural | Repo'daki değer | Bu önizlemede kullanımı |
|---|---|---|
| Tipografi | Sadece `Enum.Font.GothamBlack`, metin boyutuna göre 2.0–3.5px siyah UIStroke | Luau script'in bütün metinlerinde; HTML'de offline kalabilmesi için ağır sistem sans-serif yaklaşımı |
| Canvas | Solid `#3B5866`, dış border `#181E22`, 3.5px | HTML penceresinin ana zemini; recessed kart alanı `#1A2C34` |
| Header | 60px, 5 temadan biri, 2-tier 3px divider | Lime `DailyRewards` teması: `#98FF00 → #50D000`; üstte açık, altta koyu + siyah ayırıcı |
| Close button | 38×38 3D kare, burgundy bevel, pink→red face, pastel inner stroke | Sağ üstteki beveled kare `[X]` |
| Damier | `rbxassetid://385956923`, tile + 4 noktalı vertical transparency fade | Header ve kartlarda CSS checkerboard + maskeleme ile; Luau'da gerçek asset |
| Etkileşim | `AnchorPoint = (0.5,0.5)` + UIScale hover 1.05 / click 0.94 | Kartlar, close ve reopen butonları merkezden ölçekleniyor |
| Responsive | `min(viewport.X/1050, viewport.Y/620)` clamp `[0.52,1.18]` | HTML'de eşdeğer viewport scale; Luau'da `WindowScale` |
| Iconless button | 90° köşe, 3px `#0C141A` border, gradient, checkerboard, 3 iç highlight katmanı | Kapandıktan sonraki `OPEN SKILLS` butonu |
| Sunburst | Gizliyken duran, 20°/sn dönen bloom | Luau kartlarında düşük opaklıkla dönen `Sunburst` |
| Menü arketipleri | Shop / Codes / Rebirth / Settings / Daily Rewards | Referansın neon yeşil başlığı nedeniyle **Daily Rewards** paleti temel alındı |

## 4. Referans görselin analizi

- **Tuval:** 1211×766, oyun dünyası bulanık arka plan; pencere neredeyse tam ekran, siyah + sarı/lime dış kontur.
- **Header:** Neon yeşil gradient, çapraz ışık şeritleri, solda siyah plaka içinde italik beyaz `INDEX`, sağ üstte 3D kırmızı `[X]`.
- **İç zemin:** Koyu, hafif yeşile çalan recessed panel.
- **Kart ızgarası:** 6 sütun × 3 görünür satır, kare-ish kartlar; lime, amber, cyan, silver, magenta, lime tekrar eden gradient sırası.
- **Kart dokusu:** Aşağı doğru belirginleşen checkerboard, çapraz cam parlaması, altında renkli etiket şeridi ve siyah outline'lı beyaz yazı.
- **Scrollbar:** Sağda ince, yuvarlak, altın/sarı ray.
- **Genel dil:** Kalın konturlar, yüksek doygunluk, komik/oyunsu 3D derinlik.

## 5. “Aynısı olmasın, benzeri” için yapılan bilinçli farklar

1. Başlık `INDEX` yerine **`SKILLS`** ve alt etiket `CHECK-UI EDITION`.
2. Izgara 6×3 yerine **5 sütun × 5 satır** (25 kart, 5'i kilitli).
3. Kart isimleri `Pea Shooter` yerine özgün beceri adları: `VINE BOLT`, `FROST NOVA`, `PRISM VINE` vb.
4. Ana zemin referanstaki koyu yeşil yerine Check-UI'nin zorunlu **slate blue `#3B5866`** token'ı.
5. Ek olarak ince bir toolbar, nadirlik legend'ı, seçim durumu ve özel sürüklenebilir scrollbar eklendi.
6. Arka plan referans oyun görüntüsü kopyalanmadı; CSS ile üretilen soyut bulanık renk alanları kullanıldı.
7. Tüm dosyalar offline çalışır; dış font, CDN, resim veya API yok.

## 6. Teslim edilen dosyalar

- `index.html` — Ana, etkileşimli önizleme. Kartlara tıklayın, scrollbar'ı sürükleyin, `[X]` ile kapatıp `OPEN SKILLS` ile açın. `Esc` kapatır, `O` açar.
- `preview.png` — `index.html` dosyasının 1211×766 headless tarayıcı ile alınmış statik ekran görüntüsü.
- `preview-bottom.png` — Listenin altına kaydırılmış, kilitli kartları ve seçim mesajını gösteren ikinci statik görüntü.
- `SkillIndexPreview.luau` — Aynı tasarımın Roblox Studio için LocalScript versiyonu. Check-UI modüllerini `ReplicatedStorage.CheckUI` altından `require` eder.
- `.agents/skills/check-ui-clean-roblox/SKILL.md` — Skill'in bu çalışma alanına yüklenmiş kopyası.
- `.agents/skills/check-ui-clean-roblox/DESIGN_SYSTEM.md` — Detaylı tasarım referansı.
- `/home/user/Check-UI-Clean-Roblox` — Çekilmiş kaynak repo.

## 7. Luau script'i Studio'da kullanma

1. `src/` klasöründeki 4 ModuleScript'i `ReplicatedStorage > CheckUI` içine kopyala.
2. `SkillIndexPreview.luau` dosyasını `StarterPlayer > StarterPlayerScripts` altında bir `LocalScript`'e yapıştır.
3. Play'e bas. 1080×700'lük pencere, viewport'a göre `0.52–1.18` aralığında ölçeklenir.
4. Kapama butonu pencereyi gizler; ortadaki `OPEN SKILLS` butonu geri açar.

> Not: HTML önizleme, tarayıcıda GothamBlack bulunmadığı için ağır sistem fontu ile yaklaşık bir tipografi kullanır. Studio'daki Luau sürümü kural gereği tamamen `Enum.Font.GothamBlack` kullanır.
