WINTER SETTINGS — referans tabanlı katmanlı UI

UI Studio6.1+ gerekir.6.0 numeric slider state desteklemez; beraber verilen6.1 güncellemesini kur.

Paket: manifest.json + ayrı PNG/RGBA art katmanları + özgün WAV sesleri + numeric slider/boolean toggle/binding/clip/2D FX verisi.
Hazır marketplace GUI/script/uydurma assetID yok. Kullanıcının640x360 referansının sabit art katmanları ayrılıp kontrol bölgeleri restore edildi. Tek tam-UI ekran resmi kullanılmadı. Referansta görünmeyen yüksek çözünürlüklü asıl assetlere erişildi denmez.

Başlangıçlar: Music80%, SoundEffects65%, SnowfallON, NotificationsON, LowGraphicsOFF.
- Music/SFX gerçek sürüklenebilir slider; yüzde metni ve thumb/fill canlı.
- Snowfall sahibi olduğu UI kar efektini aç/kapatır.
- Notifications sahibi olduğu bildirim/toast akışını aç/kapatır.
- LowGraphics kendi UI particle/shimmer efektlerini azaltır/durdurur; global oyun grafik kalitesini gizlice değiştirmez veya FPS garantisi vermez.
- X kapanış; runtime Reopen düğmesi yeniden açar.
- UIScale giriş/fade kapanış, twinkle/shimmer/kar ve WAV feedback var.
- Görsel ses bilgisi içermediği için sesler özgün üretildi; orijinal referansın sesleri denmez.

Oyun entegrasyonu: kurulmuş GUI altında UIP_StateChanged BindableEvent; UIState değerleri UIPState_musicVolume/sfxVolume/snowEnabled/notificationsEnabled/lowGraphics attribute'larında. Bu olayları oyunun kendi Audio/Settings katmanına bağlayabilirsin. DataStore/alışveriş/hasar oyuna otomatik eklenmedi.

İçe aktar: ZIP aç → preview → ayarlar → görsel/ses upload açık onayı → gerçek kullanıcı/grup OpenCloudyetkisi → Roblox'aaktar.
Cloudkey/token ZIP/oyun koduna girmez. AssetID'ler gerçek upload sonucundan eşlenir; native Studio/permission/Play/save-reopen/FPS bu ortamda test edilmedi.
