"""UI Studio 5: localhost-only Open Cloud bridge. Python 3.10+, stdlib only.
No key/token on disk; no cookies; no redirects; no browser origins.
"""
import base64, concurrent.futures, hashlib, hmac, json, os, re, secrets, struct, threading, time, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib import request, error

BASE = 'https://apis.roblox.com/assets/v1/'
PORT = 38475
class Problem(Exception):
    def __init__(self, message, status=400): super().__init__(message); self.status=status
class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl): return None

def cloud(method, path, key, data=None, content_type=None):
    if path != 'assets' and not re.fullmatch(r'operations/[A-Za-z0-9_-]+', path):
        raise Problem('Beklenmeyen Roblox operation yolu', 502)
    headers={'x-api-key':key,'Accept':'application/json'}
    if content_type: headers['Content-Type']=content_type
    req=request.Request(BASE+path,data=data,headers=headers,method=method)
    # Never replay POST on timeout/5xx: the upload might already exist.
    try:
        with request.build_opener(NoRedirect()).open(req,timeout=35) as res:
            return json.loads(res.read(2_000_000))
    except error.HTTPError as e:
        code=e.code
        messages={401:'API anahtarı geçersiz veya süresi dolmuş.',403:'API yetkisi / creator kısıtı / IP listesi uygun değil.',429:'Roblox hız sınırı. Bir süre sonra tekrar dene.'}
        raise Problem(messages.get(code,'Roblox HTTP '+str(code)),code if code in (401,403,429) else 502) from None
    except (error.URLError, TimeoutError, json.JSONDecodeError):
        raise Problem('Roblox bağlantısı/yanıtı belirsiz. POST otomatik tekrarlanmadı; olası çift upload önlendi.',502) from None

def multipart(png, meta):
    boundary='UIStudio'+secrets.token_hex(16)
    body=(f'--{boundary}\r\nContent-Disposition: form-data; name="request"\r\nContent-Type: application/json\r\n\r\n'.encode()+json.dumps(meta).encode()+
          f'\r\n--{boundary}\r\nContent-Disposition: form-data; name="fileContent"; filename="image.png"\r\nContent-Type: image/png\r\n\r\n'.encode()+png+f'\r\n--{boundary}--\r\n'.encode())
    return body,'multipart/form-data; boundary='+boundary

class State:
    def __init__(self, path=None, cloud_fn=cloud, sleeper=time.sleep):
        self.path=Path(path) if path else Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.uistudio5')))/'UIStudio5'/'cache.json'
        self.remote=cloud_fn; self.sleep=sleeper; self.lock=threading.RLock()
        self.key=''; self.token=''; self.expires=0; self.jobs={}; self.by_hash={}; self.cache={}; self.transfers={}
        self.pool=concurrent.futures.ThreadPoolExecutor(max_workers=2)
        if self.path.exists():
            try:
                data=json.loads(self.path.read_text()); assert isinstance(data,dict)
                self.cache=data
            except Exception: raise RuntimeError('Cache okunamadı. cache.json dosyasını yedekle ve düzelt; sessiz sıfırlama yapılmadı.')
    def persist(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(self.cache)); os.replace(tmp,self.path)
    def configure(self, key):
        if not isinstance(key,str) or not 20<=len(key)<=8192 or any(ord(c)<33 or ord(c)>126 for c in key):
            raise Problem('API anahtarını boşluksuz yapıştır. Anahtar loglara yazılmaz.')
        with self.lock:
            if any(j['status']=='running' for j in self.jobs.values()): raise Problem('Yükleme sürerken anahtar değiştirilemez.',409)
            self.transfers.clear();self.key=key; self.token=secrets.token_urlsafe(32); self.expires=time.monotonic()+12*3600
            return {'token':self.token,'message':'Yerel bağlantı hazır; Roblox yetkisi ilk upload sırasında sınanır.'}
    def authorized(self, token):
        with self.lock:
            return bool(self.token and time.monotonic()<self.expires and hmac.compare_digest(token,self.token))
    def transfer(self, d):
        try:
            length=int(d['length']);crc=int(d['crc']);assert 0<length<=6_000_000 and 0<=crc<2**32
            assert isinstance(d['creator'],dict) and isinstance(d['name'],str)
        except Exception:raise Problem('Geçersiz transfer bilgisi.') from None
        with self.lock:
            self.transfers={k:v for k,v in self.transfers.items() if time.monotonic()-v['time']<600}
            if len(self.transfers)>=4:raise Problem('Çok fazla yarım transfer; köprüyü yeniden bağla.',409)
            ident=secrets.token_hex(16)
            self.transfers[ident]={'creator':d['creator'],'name':d['name'],'length':length,'crc':crc,'seq':0,'data':bytearray(),'time':time.monotonic()}
            return {'transfer':ident}
    def append(self, d):
        with self.lock:
            t=self.transfers.get(d.get('transfer'))
            if not t:raise Problem('Transfer bulunamadı.',404)
            if d.get('seq')!=t['seq']:raise Problem('Transfer parça sırası uyuşmadı.',409)
            try:part=base64.b64decode(d['chunk'],validate=True);assert 0<len(part)<=98304
            except Exception:raise Problem('Geçersiz transfer parçası.') from None
            if len(t['data'])+len(part)>t['length']:raise Problem('Transfer boyutu aşıldı.',413)
            t['data'].extend(part);t['seq']+=1;t['time']=time.monotonic();return {'next':t['seq']}
    def complete(self, d):
        with self.lock:
            t=self.transfers.pop(d.get('transfer'),None)
            if not t:raise Problem('Transfer bulunamadı.',404)
            raw=bytes(t['data'])
            if len(raw)!=t['length'] or zlib.crc32(raw)!=t['crc']:raise Problem('Transfer CRC/boyut kontrolü başarısız.')
            return self.submit({'name':t['name'],'creator':t['creator'],'png':base64.b64encode(raw).decode()})
    def submit(self, d):
        try:
            creator=d['creator']; ident=str(creator['id']); kind=creator['kind']
            assert kind in ('user','group') and ident.isascii() and ident.isdigit() and 0<int(ident)<=9007199254740991
            png=base64.b64decode(d['png'],validate=True)
            assert len(png)<=6_000_000 and png[:8]==b'\x89PNG\r\n\x1a\n' and png[12:16]==b'IHDR'
            w,h=struct.unpack('>II',png[16:24]); assert 1<=w<=1024 and 1<=h<=1024
            name=d['name']; assert isinstance(name,str) and 1<=len(name)<=50
        except Exception: raise Problem('Geçersiz PNG / creator / ad.') from None
        digest=hashlib.sha256((kind+':'+ident+':').encode()+png).hexdigest()
        with self.lock:
            if digest in self.by_hash:
                old=self.jobs[self.by_hash[digest]]
                if old['status']!='error': return {'job':self.by_hash[digest]}
            old=self.cache.get(digest,{})
            if old.get('state')=='uncertain': raise Problem('Önceki upload sonucu belirsiz. Creator Dashboard’u kontrol et; otomatik yeniden upload yapılmadı.',409)
            job=secrets.token_hex(16);self.by_hash[digest]=job
            self.jobs[job]={'status':'running','message':'Sırada','hash':digest}
            key=self.key
            self.pool.submit(self.work,job,png,name,kind,ident,key)
            return {'job':job}
    def work(self, job, png, name, kind, ident, key):
        digest=self.jobs[job]['hash']
        try:
            with self.lock: cached=self.cache.get(digest,{})
            if cached.get('assetId'):
                with self.lock:self.jobs[job].update(status='done',assetId=cached['assetId'],cached=True)
                return
            path=cached.get('operation')
            if not path:
                # Durable uncertainty marker BEFORE external POST; restart never blindly replays it.
                with self.lock:self.cache[digest]={'state':'uncertain'};self.persist()
                meta={'assetType':'Image','displayName':name,'description':'UI Studio 5 image','creationContext':{'creator':{kind+'Id':ident},'expectedPrice':0}}
                body,ctype=multipart(png,meta)
                try:
                    for attempt in range(4):
                        try:op=self.remote('POST','assets',key,body,ctype);break
                        except Problem as e:
                            if e.status==429 and attempt<3:self.sleep(min(20,2**(attempt+1)));continue
                            raise
                except Problem as e:
                    if e.status in (401,403,429):
                        with self.lock:self.cache.pop(digest,None);self.persist()
                    raise
                path=op.get('path','')
                if not re.fullmatch(r'operations/[A-Za-z0-9_-]+',path):raise Problem('Roblox operation yolu eksik; Dashboard’u kontrol et.',502)
                with self.lock:self.cache[digest]={'state':'pending','operation':path};self.persist()
            else:op={}
            deadline=time.monotonic()+300
            delay=.25;transient=0
            while not op.get('done'):
                if time.monotonic()>deadline:raise Problem('Roblox işlemi sürüyor. Tekrar deneme aynı operation’ı sorgular; yeni upload başlatmaz.',504)
                try:op=self.remote('GET',path,key)
                except Problem as e:
                    if e.status==429:self.sleep(5);continue
                    if e.status==502 and transient<3:transient+=1;self.sleep(.25*2**transient);continue
                    raise
                if not op.get('done'):self.sleep(delay);delay=min(2,delay*1.5)
            if op.get('error'):
                with self.lock:self.cache.pop(digest,None);self.persist()
                raise Problem('Roblox asset işlemi başarısız (kod '+str(op['error'].get('code','?'))+').',422)
            result=op.get('response',{});ident_asset=str(result.get('assetId',''))
            if not ident_asset.isdigit() or int(ident_asset)<=0:raise Problem('Roblox geçerli assetId döndürmedi.',502)
            with self.lock:
                self.cache[digest]={'state':'done','assetId':ident_asset};self.persist()
                self.jobs[job].update(status='done',assetId=ident_asset,cached=False)
        except Problem as e:
            with self.lock:self.jobs[job].update(status='error',message=str(e),code=e.status)
        except Exception:
            with self.lock:self.jobs[job].update(status='error',message='Yerel köprü hatası. Disk/cache erişimini kontrol et; anahtar loglanmadı.',code=500)

class Handler(BaseHTTPRequestHandler):
    server_version='UIStudio5'
    def log_message(self,*a):pass  # no request bodies, keys, tokens or paths in logs
    def send(self,code,data):
        payload=json.dumps(data).encode();self.send_response(code)
        self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(payload)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(payload)
    def handle_request(self):
        try:
            if self.headers.get('Origin') or self.headers.get('Sec-Fetch-Site'):raise Problem('Tarayıcı istekleri kabul edilmez.',403)
            if self.headers.get('Host') not in ('127.0.0.1:'+str(self.server.server_port),'localhost:'+str(self.server.server_port)):raise Problem('Host reddedildi.',403)
            s=self.server.state
            if self.command=='GET' and self.path=='/health':return self.send(200,{'app':'UIStudio5','version':'5.2','protocol':2,'maxUploads':2})
            if self.command=='POST':
                if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise Problem('JSON gerekli.',415)
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=9_000_000:raise Problem('İstek boyutu reddedildi.',413)
                d=json.loads(self.rfile.read(n))
                if self.path=='/configure':return self.send(200,s.configure(d.get('key')))
            token=self.headers.get('Authorization','').removeprefix('Bearer ')
            if not s.authorized(token):raise Problem('Yerel oturum kapalı; API anahtarını plugin ekranından yeniden bağla.',401)
            if self.command=='POST' and self.path=='/transfer':return self.send(200,s.transfer(d))
            if self.command=='POST' and self.path=='/chunk':return self.send(200,s.append(d))
            if self.command=='POST' and self.path=='/complete':return self.send(202,s.complete(d))
            if self.command=='POST' and self.path=='/abort':
                with s.lock:s.transfers.pop(d.get('transfer'),None)
                return self.send(200,{'aborted':True})
            if self.command=='POST' and self.path=='/upload':return self.send(202,s.submit(d))
            if self.command=='GET' and re.fullmatch(r'/jobs/[a-f0-9]{32}',self.path):
                with s.lock:job=s.jobs.get(self.path.split('/')[-1]);job=dict(job)if job else None
                if job is None:raise Problem('İş bulunamadı.',404)
                job.pop('hash',None);return self.send(200,job)
            raise Problem('Yol bulunamadı.',404)
        except Problem as e:self.send(e.status,{'error':str(e)})
        except Exception:self.send(400,{'error':'Geçersiz yerel istek.'})
    do_GET=handle_request
    do_POST=handle_request
    def do_OPTIONS(self):self.send(403,{'error':'Browser/CORS kapalı.'})

def make_server(port=PORT, state=None):
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler);server.daemon_threads=True;server.state=state or State();return server
if __name__=='__main__':
    try:
        server=make_server();print('UI STUDIO 5 KÖPRÜ HAZIR — 127.0.0.1:'+str(PORT));print('Bu pencere açık kalsın. API anahtarını Studio pluginine gir; buraya yazma. Ctrl+C kapatır.')
        server.serve_forever()
    except KeyboardInterrupt:pass
    except OSError:print('Port açılamadı. Eski köprü konsolunu kapat ve yeni Kopru_Baslat.cmd dosyasını yeniden aç.')
