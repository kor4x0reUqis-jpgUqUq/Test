@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -c "import sys; assert sys.version_info[:2] in [(3,i) for i in range(10,100)]" >nul 2>nul
 if not errorlevel 1 (
  py -3 "%~dp0bridge\bridge.py"
  goto done
 )
)
where python >nul 2>nul
if not errorlevel 1 (
 python -c "import sys; assert sys.version_info[:2] in [(3,i) for i in range(10,100)]" >nul 2>nul
 if not errorlevel 1 (
  python "%~dp0bridge\bridge.py"
  goto done
 )
)
echo Python 3.10 veya ustu gerekli. https://www.python.org/downloads/windows/
echo Kurulumda Python launcher / PATH secenegini etkinlestir, sonra tekrar ac.
:done
pause
endlocal
