"""Package a UIPack/1 manifest and its PNG assets. No Roblox credentials needed."""
from pathlib import Path
from PIL import Image
import json,zipfile,io,argparse

def pack(folder,output):
 folder=Path(folder).resolve();d=json.loads((folder/'manifest.json').read_text(encoding='utf-8'));assert d['format']in ['UIPack/1','UIPack/2'];files={}
 for a in d['assets']:
  rel=Path(a['png']);assert not rel.is_absolute()and '..'not in rel.parts
  p=(folder/rel).resolve();assert folder in p.parents
  im=Image.open(p).convert('RGBA');assert 0<im.width<=1024 and 0<im.height<=1024
  a.update(width=im.width,height=im.height,rgba='pixels/'+a['key']+'.rgba')
  files[a['png']]=p.read_bytes();files[a['rgba']]=im.tobytes()
 for c in d.get('scripts',[]):
  rel=Path(c['path']);assert not rel.is_absolute()and '..'not in rel.parts
  p=(folder/rel).resolve();assert folder in p.parents;files[c['path']]=p.read_bytes()
 files['manifest.json']=json.dumps(d,ensure_ascii=False,separators=(',',':')).encode()
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,raw in files.items():z.writestr(name,raw)
 return d
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('output');args=p.parse_args();pack(args.folder,args.output);print('UIPACK_WRITTEN',args.output)
