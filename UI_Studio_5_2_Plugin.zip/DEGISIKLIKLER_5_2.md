# 5.2 — Örnek stile uyarlama + yükleme optimizasyonu

## Tasarım
`ornekuı.txt` sadece stil referansı olarak okundu; dosyanın StarterGui / PlayerGui
silme-oluşturma ve oyun kodu çalıştırma bölümleri kullanılmadı.
Yeni plugin: cyan→mavi dış yüzey, koyu iç paneller, kullanıcının stud texture ID'si,
kalın beyaz/outline yazı, 4 px derinlikli renkli butonlar, üst gloss, hover shine,
press tepkisi. Açılış yine kapalı; anahtar maskeli ve yalnız RAM'de.
PNG dosyaları çevrimdışı TASARIM renderidir, Studio ekran görüntüsü değildir.

## Yavaşlık için yapılan değişiklikler
- DEFLATE tekrarlı veriyi byte-byte yazmak yerine güvenli buffer.copy bloklarıyla
  genişletir. STORED blokları buffer.writestring ile toplu aktarır.
- Her 64 KiB'de zorunlu frame bekletme kaldırıldı; yaklaşık 8 ms CPU bütçesiyle
  kooperatif yield kontrolü var. CRC ve boyut/bounds korumaları kaldırılmadı.
- RGBA artık load ve preview'de iki kez çözülmez. Native preview okumada doğrular;
  preview atlandıysa upload preflight, TÜM dosyaları ilk cloud mutation öncesi doğrular.
- PNG/manifest gibi RGBA dışı veriler için 16 MiB RAM cache vardır. Bu bir paket/
  görsel sayısı sınırı değildir; cache dışı dosyalar da normal yüklenir.
- Aynı kaynak ZIP tekrar açıldığında / yenilendiğinde EditableImage referansları
  yeniden kullanılır; gerçek paket byte'ları değişirse cache temizlenir.
- İstemci ve köprü en çok 2 eşzamanlı asset upload yürütür. Sınırsız paralellik yok.
- İlk operation GET öncesi 1.5 sn ve istemcideki 1 sn sabit beklemeler kaldırıldı;
  250 ms istemci sorgusu ve adaptif server poll kullanılıyor.
- Base64 içindeki frame yield sıklığı azaltıldı. 96 KiB parçalar korunuyor.
- Kesin HTTP 429 reddinde sınırlı backoff; güvenli GET geçici hatalarında tekrar
  var. Belirsiz POST (ağ timeout / 5xx) ASLA körlemesine tekrarlanmaz.

## Ölçümün sınırı
2 MiB deterministik veri, Luau CLI, fake task.wait sayımı:
Eski çözme+CRC ~0.255 sn, yeni ~0.110 sn. Zorunlu/bütçeli yield 64→12.
Bu yalnız yerel algoritma ölçümüdür: gerçek Studio toplam süre/FPS/Open Cloud
hız garantisi değildir. Ağ, hesap kotası ve Roblox moderasyonu hâlâ bekletebilir.

## Kurulumda önemli
ESKİ köprü konsolunu kapat. Yeni ZIP'teki Kopru_Baslat.cmd'yi aç.
Yeni plugin health.protocol=2 ister; eski köprüyle sessizce eski hıza dönmez.
Windows kurucusu ve gerçek Studio/Open Cloud upload burada NOT_RUN.
Shop UI bu tur ilerletilmedi; yeni sanat sonraki talimat için korundu.
