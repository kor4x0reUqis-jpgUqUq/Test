"""PNG design render based on native layout. NOT a Studio screenshot."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
R=Path(__file__).parent;S=2
WHITE='#ffffff';MUT='#c0d9ee';BLACK='#000000'
def font(n,b=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold'if b else'')+'.ttf',round(n*S))
def render(auth=False):
 im=Image.new('RGBA',(920*S,680*S),'#071323')
 def draw():return ImageDraw.Draw(im)
 def rect(box,c,r=0,outline=None,width=1):draw().rounded_rectangle(tuple(round(v*S)for v in box),r*S,fill=c,outline=outline,width=width*S)
 def text(x,y,t,n=12,c=WHITE,b=False,stroke=0):draw().multiline_text((x*S,y*S),t,font=font(n,b),fill=c,spacing=5*S,stroke_width=round(stroke*S),stroke_fill=BLACK)
 def icon(name,x,y,size):
  p=R/'preview_icons'/f'{name}.png'
  if p.exists():im.alpha_composite(Image.open(p).convert('RGBA').resize((size*S,size*S),Image.Resampling.LANCZOS),(x*S,y*S))
 def gradient(box,top,bot,r=12,stroke=True):
  x,y,x2,y2=[round(v*S)for v in box];w=x2-x;h=y2-y
  a=np.linspace(np.array(top),np.array(bot),h).astype('uint8');pix=np.repeat(a[:,None,:],w,axis=1);layer=Image.fromarray(pix).convert('RGBA');mask=Image.new('L',(w,h));ImageDraw.Draw(mask).rounded_rectangle((0,0,w-1,h-1),r*S,fill=255);layer.putalpha(mask);im.alpha_composite(layer,(x,y))
  if stroke:draw().rounded_rectangle((x,y,x2,y2),r*S,outline=BLACK,width=3*S)
 def studs(box,light=False):
  x,y,x2,y2=box;overlay=Image.new('RGBA',im.size);d=ImageDraw.Draw(overlay)
  for yy in range(y+10,y2-10,36):
   for xx in range(x+10,x2-10,36):
    d.ellipse((xx*S,yy*S,(xx+13)*S,(yy+13)*S),outline=(200,240,255,30)if light else(160,190,205,18),width=S)
  im.alpha_composite(overlay)
 def btn(y,t,key=None,top=(0,177,255),x=24,w=236,h=40):
  bot=tuple(int(c*.65)for c in top);rect((x,y+4,x+w,y+h+4),tuple(int(c*.38)for c in top),9,BLACK,2)
  gradient((x,y,x+w,y+h),top,bot,9)
  # Broad upper reflection, matching reference's rounded gloss.
  ref=Image.new('RGBA',im.size);rd=ImageDraw.Draw(ref);rd.rounded_rectangle((x*S,y*S,(x+w)*S,(y+h*.44)*S),9*S,fill=(255,255,255,32));im.alpha_composite(ref)
  if key:icon(key,x+12,y+(h-22)//2,22)
  text(x+(47 if key else 12),y+(h-15)//2,t,10 if w<150 else 12,WHITE,True,1)
 gradient((6,6,914,650),(0,238,255),(0,102,255),14);studs((10,10,906,644),True)
 icon('Shop',24,21,34);text(70,14,'UI STUDIO',27,WHITE,True,1.5);text(71,48,'PAKET YÖNETİCİSİ / 5.2',9)
 btn(22,'API BAĞLANTISI',None,x=733,w=142,h=32);icon('Close',888,27,22)
 btn(88,'PAKET',None,x=24,w=116,h=30);btn(88,'KAYDEDİLENLER',None,x=150,w=116,h=30)
 gradient((18,123,272,638),(28,40,52),(15,25,38),12);studs((18,123,272,638))
 btn(128,'ZIP PAKETİ AÇ','Plus',h=58)
 text(24,199,'ZIP seç • Native önizle • Oyuna kur',10,MUT)
 text(24,244,'API BAĞLANTISI BEKLENİYOR',10,'#00edff',True)
 rect((24,273,260,276),'#005e9f');text(24,291,'Oyun sahibi otomatik seçilir',10,MUT)
 btn(324,'[ ] Görsel yükleme onayı',None,h=36)
 btn(372,'OYUNA YÜKLE','Shop',(64,214,16));btn(420,'İSİMLE KAYDET','Save',(174,65,246));btn(468,'GELİŞMİŞ / GÜNLÜK','Settings')
 gradient((284,88,908,638),(28,40,52),(13,21,32),14);studs((284,88,908,638))
 text(300,105,'NATIVE ÖNİZLEME',10,'#b4bcd5',True);btn(98,'YENİLE',None,x=809,w=85,h=28)
 icon('Folder',544,250,70);text(390,337,'PAKETİN BURADA HAYAT BULUR',14,'#b9d1e5',True);text(414,374,'API bağlantısını kur, ardından ZIP aç.\nBu alan native Roblox nesneleridir.',11,'#939db8')
 text(300,617,'Önizleme upload yapmaz • Kodlar ayrıca onay ister',9,'#919bb4')
 if auth:
  im=Image.alpha_composite(im,Image.new('RGBA',im.size,(9,15,30,205)))
  rect((215,143,705,520),'#003f87',18,BLACK,3);gradient((215,137,705,513),(0,228,255),(0,102,255),18)
  icon('Verify',239,161,42);text(296,162,'ROBLOX BAĞLANTISI',19,WHITE,True,1.5);text(297,197,'OPEN CLOUD / YEREL VE ÖZEL',9,WHITE,True)
  gradient((232,222,688,398),(28,40,52),(15,25,38),10)
  text(244,234,'Önce yeni Kopru_Baslat.cmd açık olsun. Anahtar\ndosyaya veya loglara kaydedilmez; yalnızca\nyerel köprü RAM’inde kalır.',11,MUT)
  rect((239,304,681,350),'#121820',9,BLACK,2);text(252,320,'API anahtarını yapıştır…',13,MUT)
  text(244,366,'Bağlanmak asset yüklemez. Yetki ilk upload’da sınanır.',9,MUT)
  btn(415,'GÜVENLİ YEREL BAĞLANTIYI AÇ',None,(64,215,18),x=239,w=442,h=43)
  btn(474,'ŞİMDİLİK KAPAT',None,(236,60,91),x=338,w=244,h=25)
 rect((0,652,920,680),'#071323');text(15,661,'PNG TASARIM RENDERİ • STUDIO SCREENSHOT’U DEĞİL • ornekuı.txt STİLİNDEN UYARLANDI',9,'#a4b7cd')
 im.convert('RGB').save(R/('Plugin_Ilk_Acilis.png'if auth else'Plugin_Ana_Ekran.png'))
render();render(True)
