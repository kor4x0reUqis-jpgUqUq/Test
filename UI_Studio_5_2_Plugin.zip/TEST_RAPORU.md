# UI Studio 5.2 — doğrulama

## Çalıştırıldı
- Luau 0.743 kaynak/bundle/runtime derlemesi PASS.
- Binary/Schema: 31 çevrimdışı test PASS (küçük test fixture'ı; yeni shop tasarımı değil).
- Engine Open Cloud adaptör sözleşmesi: 15 mock test PASS.
- Transaction: 5 mock test PASS.
- Yerel kütüphane: 17 mock-settings test PASS.
- Bridge istemcisi: 12 Luau mock test PASS; base64 RFC vektörleri, 3 parçalı aktarım, transport kopması dahil.
- Python köprü: 25 test PASS; gerçek localhost HTTP sunucu sınırları, token, Origin/Host/CORS reddi, multipart gövdesi, PNG/creator kontrolü, CRC/sıra, hash/creator cache izolasyonu, pending resume, belirsiz POST tekrarını engelleme, credential/session disk sızıntısı kontrolü.

**Toplam: 110 offline/mock kontrol** (68 temel + 12 bridge istemcisi + 25 Python köprü + 4 paralellik + 1 performans regresyonu). Open Cloud testlerinde sahte transport kullanıldı; gerçek Roblox hesabına hiçbir upload yapılmadı.

## Çalıştırılmadı
- Windows CMD kurucusu / Python launcher keşfi: NOT_RUN.
- Gerçek Studio plugin GUI, ikon izinleri, ilk açılış maskeli kutu: NOT_RUN.
- Studio → localhost HTTP izin akışı: NOT_RUN.
- Gerçek Open Cloud anahtarı / hesap / grup upload / moderasyon: NOT_RUN.
- Native preview/Play/Undo/save-reopen ve kütüphane restart: NOT_RUN.
- FPS: NOT_MEASURED.

PNG'ler kaynak yerleşime göre çevrimdışı çizilmiş TASARIM renderidir. Studio screenshot'u değildir. İkon görselleri kullanıcı ID'lerinin public thumbnail yanıtlarından alınmıştır; 8 thumbnail Completed döndü, native kullanım erişimini garanti etmez.

## Güvenlik ve sınırlar
- Köprü yalnız 127.0.0.1:38475 dinler; tüm arayüzlere açılmaz.
- Anahtar ve oturum token'ı diske / plugin settings'e / loga yazılmaz. Anahtar köprü kapanana kadar RAM'dedir. Studio yeniden başlatılınca yeniden girilir.
- Anahtar yapı/uzunluk kontrolü bağlantı sırasında yapılır. Bu, Roblox read/write yetkisini doğrulama değildir; gerçek upload sırasında doğrulanır.
- Köprüde HTTP redirection kapalı; x-api-key yalnız sabit resmi Roblox URL'sine gönderilir.
- Browser Origin / Sec-Fetch istekleri ve CORS preflight reddedilir. Yetkili token upload/poll için zorunludur. /configure localhost'ta anahtarı alıp token üretir; diğer yerel yazılımlara karşı OS izolasyonu sağlamaz.
- 96 KiB PNG parçaları ve toplam CRC doğrulanır. 6 MB/1024×1024 sınırı. Upload en fazla 2 worker ile işlenir.
- Roblox POST'undan önce diske belirsizlik işareti yazılır. Operation yolu elde edilirse devam kaydı tutulur; POST yanıtı kayıpsa çift upload riskinden kaçınmak için otomatik tekrar engellenir. Böyle durumda Dashboard kontrolü gerekir.
- Cache dosyası `%LOCALAPPDATA%\UIStudio5\cache.json`: yalnız hash/assetId/operation durumu içerir. Silmek tekrar upload doğurabilir; özellikle pending/uncertain durumunda rastgele silmeyin.
- İptal başlamış cloud işlemini durdurma/silme garantisi değildir. Cloud asset silme yoktur.
- Library guard'ları gerçek Studio saklama kotası / atomik çok-oturum kilidi garantisi değildir; tek Studio oturumu önerilir.

## Yeniden test
Python 3.10+ köprü için yeterli; test/build-preview için Pillow gerekir.
Luau CLI 0.743'ü proje üst klasöründe `.cache/luau/` içine koyun.

```
python build.py
python tests/run_offline.py
python tests/test_bridge.py
../.cache/luau/luau tests/bridge_client_spec.luau
```

Bu sürüm plugin-only teslimdir. Yeni shop UI, sanat ve paket daha sonra ayrı üretilecek.

## 5.2 ek doğrulama
- 4 kooperatif Luau scheduler testi: max 2 in-flight, cache hit, tüm CRC preflight, hata sonrası worker bitişi PASS.
- 2 worker köprü gerçek thread/barrier testi PASS; HTTP 429 bounded backoff ve güvenli GET retry PASS.
- 2 MiB çözme+CRC eski/yeni byte eşitliği PASS; algoritma CPU ölçümü tests/performance_results.json.
- Native renk/shine/outline görünümü ve tüm Studio kullanıcı akışı hâlâ NOT_RUN.
- tests/Reference_Style.txt kullanıcı örneğidir; yürütülmez.
