-- UI Studio 5.2 | local plugin | Native Studio NOT_RUN
local Binary=(function()
local M={}
-- Cooperative CPU budget, not a mandatory frame delay per 64 KiB.
local function budget()
 local last=os.clock()
 return function()if task and os.clock()-last>=.008 then task.wait();last=os.clock()end end
end
function M.inflate(packed,expected)
 assert(expected>=0 and expected<=268435456,"Açılmış veri güvenlik sınırı")
local position=1;local bucket=0;local bits=0
local function read(n)
 while bits<n do local v=string.byte(packed,position);assert(v,'Truncated paket data');bucket+=v*2^bits;bits+=8;position+=1 end
 local result=bucket%2^n;bucket=math.floor(bucket/2^n);bits-=n;return result
end
local function tree(lengths,count)
 local counts={};for i=0,count-1 do local l=lengths[i]or 0;if l>0 then counts[l]=(counts[l]or 0)+1 end end
 local code=0;local nextCode={};local t={}
 for length=1,15 do code=(code+(counts[length-1]or 0))*2;nextCode[length]=code;t[length]={}end
 for symbol=0,count-1 do local len=lengths[symbol]or 0;if len>0 then t[len][nextCode[len]]=symbol;nextCode[len]+=1 end end
 return t
end
local function symbol(t)
 local code=0;for len=1,15 do code=code*2+read(1);local value=t[len][code];if value~=nil then return value end end
 error('Invalid paket Huffman code')
end
local LB={3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258}
local LE={0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0}
local DB={1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577}
local DE={0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13}
local order={16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15}
local output=buffer.create(expected);local written=0;local last=0;local yield=budget()
local function put(v)assert(written<expected,'Paket buffer overflow');buffer.writeu8(output,written,v);written+=1;if written%16384==0 then yield()end end
repeat
 last=read(1);local kind=read(2)
 if kind==0 then
  read(bits%8);local len=read(16);local complement=read(16);assert(len+complement==65535,'Invalid stored block')
  assert(written+len<=expected and position+len-1<=#packed,'Kesik/taşan stored blok');buffer.writestring(output,written,packed:sub(position,position+len-1));written+=len;position+=len;yield()
 else
  local litLengths={};local distLengths={};local litCount=288;local distCount=32
  if kind==1 then
   for i=0,287 do litLengths[i]=i<=143 and 8 or(i<=255 and 9 or(i<=279 and 7 or 8))end
   for i=0,31 do distLengths[i]=5 end
  elseif kind==2 then
   litCount=read(5)+257;distCount=read(5)+1;local numCodes=read(4)+4;local cl={}
   for i=1,numCodes do cl[order[i]]=read(3)end
   local clTree=tree(cl,19);local lengths={};local at=0
   while at<litCount+distCount do
    local value=symbol(clTree)
    if value<16 then lengths[at]=value;at+=1
    else
     local repeatCount;local previous=0
     if value==16 then assert(at>0,'Invalid repeat');previous=lengths[at-1];repeatCount=read(2)+3 elseif value==17 then repeatCount=read(3)+3 else repeatCount=read(7)+11 end
     for _=1,repeatCount do lengths[at]=previous;at+=1 end
    end
   end
   assert(at==litCount+distCount,'Invalid length tree')
   for i=0,litCount-1 do litLengths[i]=lengths[i]end
   for i=0,distCount-1 do distLengths[i]=lengths[litCount+i]end
  else error('Invalid DEFLATE block')end
  local litTree=tree(litLengths,litCount);local distTree=tree(distLengths,distCount)
  while true do
   local value=symbol(litTree)
   if value<256 then put(value)elseif value==256 then break else
    assert(value<=285,'Invalid length');local idx=value-256;local length=LB[idx]+read(LE[idx]);local distanceCode=symbol(distTree);assert(distanceCode<30,'Invalid distance')
    local distance=DB[distanceCode+1]+read(DE[distanceCode+1]);assert(distance<=written,'Invalid backward reference')
    assert(written+length<=expected,'Paket buffer overflow')
    local start=written-distance;local available=distance;local left=length;local before=written
    while left>0 do local n=math.min(left,available);buffer.copy(output,written,output,start,n);written+=n;available+=n;left-=n end
    if math.floor(before/16384)~=math.floor(written/16384)then yield()end
   end
  end
 end
until last==1
assert(written==expected,'Paket length mismatch')

return buffer.tostring(output)
end
local crcTable={}
for i=0,255 do local c=i;for _=1,8 do c=bit32.bxor(bit32.rshift(c,1),bit32.band(c,1)==1 and 0xEDB88320 or 0)end;crcTable[i]=c end
function M.crc(s)
 local c=0xFFFFFFFF;local yield=budget()
 for i=1,#s do if i%16384==0 then yield()end;c=bit32.bxor(bit32.rshift(c,8),crcTable[bit32.band(bit32.bxor(c,string.byte(s,i)),255)])end
 return bit32.bxor(c,0xFFFFFFFF)
end
function M.zip(s)
 assert(type(s)=='string'and #s<=134217728,'ZIP en fazla 128 MiB olmalı')
 local function u16(p)assert(p>=1 and p+1<=#s,'Kesik ZIP');local a,b=string.byte(s,p,p+1);return a+b*256 end
 local function u32(p)return u16(p)+u16(p+2)*65536 end
 local e
 for p=#s-21,math.max(1,#s-65557),-1 do
  if s:sub(p,p+3)=='PK\005\006'and p+21+u16(p+20)==#s then e=p;break end
 end
 assert(e,'ZIP merkez dizini bulunamadı');assert(u16(e+4)==0 and u16(e+6)==0,'Çok diskli ZIP desteklenmiyor')
 local count=u16(e+10);assert(count==u16(e+8)and count<65535,'ZIP64 desteklenmiyor')
 local centralSize,centralOffset=u32(e+12),u32(e+16);assert(centralOffset+centralSize==e-1,'Bozuk merkez dizini')
 local p=centralOffset+1;local entries={};local total=0
 for _=1,count do
  assert(s:sub(p,p+3)=='PK\001\002','Bozuk ZIP girdisi');local flag,method=u16(p+8),u16(p+10)
  assert(bit32.band(flag,1)==0,'Şifreli ZIP desteklenmiyor');assert(method==0 or method==8,'Yalnız ZIP Store/Deflate desteklenir')
  local crc,compressed,size=u32(p+16),u32(p+20),u32(p+24);local nl,xl,cl=u16(p+28),u16(p+30),u16(p+32);local start=u32(p+42)+1
  assert(size<0xFFFFFFFF and compressed<0xFFFFFFFF,'ZIP64 desteklenmiyor');local name=s:sub(p+46,p+45+nl)
  assert(#name==nl and nl>0 and not name:find('[%z\\:]')and name:sub(1,1)~='/'and not name:find('%.%.'),'Güvensiz ZIP yolu')
  assert(not entries[name],'Tekrarlanan ZIP yolu');assert(u16(p+34)==0,'Çok diskli girdi')
  assert(bit32.band(bit32.rshift(u32(p+38),16),0xF000)~=0xA000,'Sembolik bağ yasak')
  total+=size;assert(total<=268435456,'ZIP açılımı en fazla 256 MiB olabilir')
  assert(s:sub(start,start+3)=='PK\003\004','Yerel başlık yok');assert(u16(start+8)==method and u16(start+6)==flag,'ZIP başlık uyumsuzluğu')
  local lnl,lxl=u16(start+26),u16(start+28);assert(s:sub(start+30,start+29+lnl)==name,'ZIP ad uyumsuzluğu')
  local offset=start+30+lnl+lxl;assert(offset+compressed-1<=centralOffset,'ZIP veri sınırı yanlış')
  entries[name]={size=size,crc=crc,method=method,offset=offset,compressed=compressed}
  p+=46+nl+xl+cl
 end
 assert(p==e,'Merkez dizin uzunluğu yanlış')
 local z={entries=entries,verified={}};local cache={};local cachedBytes=0
 function z:read(name)
  local v=assert(entries[name],'ZIP dosyası eksik: '..tostring(name));if cache[name]then return cache[name]end;local packed=s:sub(v.offset,v.offset+v.compressed-1)
  local raw=v.method==0 and packed or M.inflate(packed,v.size)
  assert(#raw==v.size and M.crc(raw)==v.crc,'CRC/boyut hatası: '..name);self.verified[name]=true
  if not name:match('%.rgba$')and cachedBytes+#raw<=16777216 then cache[name]=raw;cachedBytes+=#raw end
  return raw
 end
 return z
end
return M

end)()
local Library=(function()
-- Durable local package library. Raw ZIPs, not filesystem paths or temporary IDs.
local M={};M.MAX_TOTAL_BYTES=128*1024*1024;M.CHUNK=48000
local function fold(s)return(s:gsub('İ','i'):gsub('I','ı'):gsub('Ç','ç'):gsub('Ğ','ğ'):gsub('Ö','ö'):gsub('Ş','ş'):gsub('Ü','ü')):lower()end
local KEY='UIPLibraryIndexV3';local alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local lookup={};for i=1,64 do lookup[alphabet:byte(i)]=i-1 end
local function clone(t)if type(t)~='table'then return t end;local c={};for k,v in pairs(t)do c[k]=clone(v)end;return c end
local function encode(s)
 local out={};for i=1,#s,3 do local a,b,c=s:byte(i,i+2);local n=a*65536+(b or 0)*256+(c or 0)
  out[#out+1]=alphabet:sub(math.floor(n/262144)%64+1,math.floor(n/262144)%64+1)..alphabet:sub(math.floor(n/4096)%64+1,math.floor(n/4096)%64+1)..(b and alphabet:sub(math.floor(n/64)%64+1,math.floor(n/64)%64+1)or'=')..(c and alphabet:sub(n%64+1,n%64+1)or'=')
 end;return table.concat(out)
end
local function decode(s)
 assert(#s%4==0,'Kütüphane base64 bozuk');local out={}
 for i=1,#s,4 do local aa,bb,cc,dd=s:byte(i,i+3);local a,b,c,d=lookup[aa],lookup[bb],lookup[cc],lookup[dd];assert(a and b and(c or cc==61)and(d or dd==61),'Kütüphane base64 karakteri bozuk')
  local n=a*262144+b*4096+(c or 0)*64+(d or 0);out[#out+1]=string.char(math.floor(n/65536)%256);if cc~=61 then out[#out+1]=string.char(math.floor(n/256)%256)end;if dd~=61 then out[#out+1]=string.char(n%256)end
 end;return table.concat(out)
end
function M.new(store)
 local L={}
 local function index()
  local v=store:get(KEY);if v==nil then return{version=3,revision=0,entries={}}end
  assert(type(v)=='table'and v.version==3 and type(v.entries)=='table'and type(v.revision)=='number','Kütüphane indeksi bozuk; otomatik üzerine yazılmadı')
  v=clone(v);local ids={}
  for _,e in ipairs(v.entries)do
   assert(type(e.id)=='string'and not ids[e.id]and type(e.name)=='string'and type(e.bytes)=='number'and e.bytes>=0 and type(e.payload)=='string'and type(e.chunks)=='number'and e.chunks>=1 and type(e.crc)=='number','Kütüphane kaydı bozuk');ids[e.id]=true
  end
  return v
 end
 local function collect(payload,chunks,entries)
  local readable,latest=pcall(index);if not readable then return end;entries=latest.entries
  for _,e in ipairs(entries)do if e.payload==payload then return end end
  for n=1,chunks do pcall(function()store:set(payload..'_'..n,nil)end)end
 end
 local function commit(before,after)
  assert(index().revision==before.revision,'Başka Studio oturumu kütüphaneyi değiştirdi; tekrar dene')
  after.revision=before.revision+1
  local ok,err=pcall(function()store:set(KEY,after);local check=index();assert(check.revision==after.revision and #check.entries==#after.entries,'Kütüphane yazısı doğrulanamadı');for i,e in ipairs(after.entries)do assert(check.entries[i].id==e.id and check.entries[i].payload==e.payload,'Kütüphane readback farklı')end end)
  if not ok then
   local readable,current=pcall(index);local ours=readable and current.revision==after.revision and #current.entries==#after.entries
   if ours then for i,e in ipairs(after.entries)do if current.entries[i].id~=e.id or current.entries[i].payload~=e.payload then ours=false;break end end end
   if ours then pcall(function()store:set(KEY,before)end)end
   error('Kaydetme başarısız; belirsiz/başka oturum indeksi ezilmedi: '..tostring(err),0)
  end
 end
 function L:list(query)
  local rows=index().entries;query=fold(query or'');local out={}
  for _,e in ipairs(rows)do if query==''or string.find(fold(e.name),query,1,true)then out[#out+1]=e end end
  table.sort(out,function(a,b)return a.updated>b.updated or(a.updated==b.updated and a.name<b.name)end);return out
 end
 function L:load(id)
  for _,e in ipairs(index().entries)do if e.id==id then
   local pieces={};for n=1,e.chunks do local s=store:get(e.payload..'_'..n);assert(type(s)=='string','Kayıt parçası eksik: '..n);pieces[n]=s end
   local raw=decode(table.concat(pieces));assert(#raw==e.bytes and Binary.crc(raw)==e.crc,'Kayıt boyut/CRC doğrulaması başarısız');return raw,clone(e)
  end end;error('Kütüphane kaydı bulunamadı',0)
 end
 function L:save(name,raw,meta,replace)
  assert(type(name)=='string','İsim gerekli');name=name:match('^%s*(.-)%s*$');assert(#name>0 and #name<=160 and not name:find('%c'),'İsim 1–160 UTF8 byte olmalı')
  assert(type(raw)=='string'and #raw>0,'Kaydedilecek ZIP yok');local before=index();local old
  for _,e in ipairs(before.entries)do if fold(e.name)==fold(name)then old=e;assert(replace,'Bu isim kayıtlı; açıkça Üzerine Yaz seç');break end end
  local total=#raw;for _,e in ipairs(before.entries)do if not old or e.id~=old.id then total+=e.bytes end end
  assert(total<=M.MAX_TOTAL_BYTES,'Yerel kütüphane güvenlik kotası aşıldı')
  local crc=Binary.crc(raw);local reused
  for _,e in ipairs(before.entries)do if e.bytes==#raw and e.crc==crc then local ok,data=pcall(self.load,self,e.id);if ok and data==raw then reused=e;break end end end
  local payload=reused and reused.payload or('UIPLibraryDataV3_'..store:uuid());local chunks=reused and reused.chunks or 0;local wrote=false
  local ok,result=xpcall(function()
   if not reused then
    local encoded=encode(raw);chunks=math.ceil(#encoded/M.CHUNK);wrote=true
    for n=1,chunks do store:set(payload..'_'..n,encoded:sub((n-1)*M.CHUNK+1,n*M.CHUNK));if task then task.wait()end end
    local verify={};for n=1,chunks do verify[n]=assert(store:get(payload..'_'..n),'Kayıt readback eksik')end
    local roundtrip=decode(table.concat(verify));assert(roundtrip==raw,'Kayıt readback byte eşleşmiyor')
   end
   local entry={id=old and old.id or store:uuid(),name=name,payload=payload,chunks=chunks,bytes=#raw,crc=crc,created=old and old.created or os.time(),updated=os.time(),title=meta.title,packageId=meta.packageId,assetCount=meta.assetCount or 0}
   local after=clone(before);local list={};for _,e in ipairs(after.entries)do if not old or e.id~=old.id then list[#list+1]=e end end;list[#list+1]=entry;after.entries=list;commit(before,after)
   if old and old.payload~=payload then collect(old.payload,old.chunks,after.entries)end
   return entry
  end,debug.traceback)
  if not ok then if wrote then collect(payload,chunks,before.entries)end;error(result,0)end
  return result
 end
 function L:delete(id)
  local before=index();local after=clone(before);after.entries={};local removed
  for _,e in ipairs(before.entries)do if e.id==id then removed=e else after.entries[#after.entries+1]=e end end
  assert(removed,'Silinecek kayıt bulunamadı');commit(before,after);collect(removed.payload,removed.chunks,after.entries);return removed
 end
 return L
end
return M

end)()
local Schema=(function()
local M={}
M.classes={Frame=true,TextLabel=true,TextButton=true,ImageLabel=true,ImageButton=true,ScrollingFrame=true,UIListLayout=true,UIGridLayout=true,UIPadding=true,UICorner=true,UIStroke=true,UIGradient=true,UIAspectRatioConstraint=true,UIScale=true,UISizeConstraint=true}
M.props={Size='u2',Position='u2',AnchorPoint='v2',BackgroundColor3='color',BackgroundTransparency='num',BorderSizePixel='num',Visible='bool',ClipsDescendants='bool',ZIndex='num',LayoutOrder='num',Rotation='num',Text='str',TextSize='num',TextColor3='color',TextTransparency='num',TextWrapped='bool',RichText='bool',AutoButtonColor='bool',TextStrokeTransparency='num',TextStrokeColor3='color',ImageColor3='color',ImageTransparency='num',ImageRectOffset='v2',ImageRectSize='v2',SliceCenter='rect',SliceScale='num',CanvasSize='u2',ScrollBarThickness='num',ScrollBarImageColor3='color',CornerRadius='u1',Thickness='num',Color='color',Transparency='num',Padding='u1',PaddingTop='u1',PaddingBottom='u1',PaddingLeft='u1',PaddingRight='u1',CellSize='u2',CellPadding='u2',FillDirectionMaxCells='num',AspectRatio='num',Scale='num',MinSize='v2',MaxSize='v2',Offset='v2'}
M.enums={Font={Gotham=true,GothamBold=true,GothamBlack=true,SourceSans=true,SourceSansBold=true},TextXAlignment={Left=true,Center=true,Right=true},TextYAlignment={Top=true,Center=true,Bottom=true},ScaleType={Stretch=true,Fit=true,Crop=true,Slice=true,Tile=true},AutomaticSize={None=true,X=true,Y=true,XY=true},AutomaticCanvasSize={None=true,X=true,Y=true,XY=true},FillDirection={Horizontal=true,Vertical=true},HorizontalAlignment={Left=true,Center=true,Right=true},VerticalAlignment={Top=true,Center=true,Bottom=true},SortOrder={LayoutOrder=true,Name=true},ApplyStrokeMode={Border=true,Contextual=true},LineJoinMode={Round=true,Bevel=true,Miter=true},ScrollingDirection={X=true,Y=true,XY=true}}
local function num(x)return type(x)=='number'and x==x and math.abs(x)<=1000000 end
local function tuple(v,n)if type(v)~='table'or #v~=n then return false end;for _,x in ipairs(v)do if not num(x)then return false end end;return true end
local function label(x,max)return type(x)=='string'and #x>0 and #x<=max end
function M.validate(d,z)
 assert(type(d)=='table'and (d.format=='UIPack/1'or d.format=='UIPack/2'),'Bu ZIP UIPack/1 veya UIPack/2 formatında değil')
 assert(label(d.id,80)and d.id:match('^[%w_%-]+$'),'Paket kimliği yanlış');assert(label(d.title,120),'Paket başlığı eksik')
 assert(type(d.assets)=='table'and type(d.tree)=='table','Görsel/ağaç bilgisi eksik')
 local ids={}
 for _,a in ipairs(d.assets)do
  assert(label(a.key,80)and a.key:match('^[%w_%-]+$')and not ids[a.key],'Görsel anahtarı yanlış');ids[a.key]=true
  assert(num(a.width)and num(a.height)and a.width%1==0 and a.height%1==0 and a.width>=1 and a.height>=1 and a.width<=1024 and a.height<=1024,'Görsel boyutu 1–1024 piksel olmalı')
  assert(label(a.rgba,200)and z.entries[a.rgba]and z.entries[a.rgba].size==a.width*a.height*4,'RGBA8 dosyası eksik/boyutu yanlış')
  assert(label(a.png,200)and z.entries[a.png],'PNG kaynağı eksik')
 end
 local count=0;local names={}
 local function visit(n,depth)
  assert(depth<=64 and type(n)=='table'and M.classes[n.class],'İzin verilmeyen UI sınıfı veya derinlik')
  count+=1;assert(label(n.name,80)and n.name:match('^[%a_][%w_]*$')and not names[n.name],'Benzersiz UI adı gerekli');names[n.name]=true
  for key,v in pairs(n.props or{})do
   local t=M.props[key];local e=M.enums[key]
   if e then assert(type(v)=='string'and e[v],'Enum değeri yanlış: '..key)
   elseif t=='num'then assert(num(v),'Sayı yanlış: '..key)
   elseif t=='bool'then assert(type(v)=='boolean','Boolean yanlış')
   elseif t=='str'then assert(type(v)=='string'and #v<=16000,'Metin çok uzun')
   elseif t=='color'then assert(tuple(v,3),'Renk yanlış');for _,c in ipairs(v)do assert(c>=0 and c<=255,'RGB aralığı yanlış')end
   elseif t=='u2'or t=='rect'then assert(tuple(v,4),'4 bileşen gerekli')
   elseif t=='u1'or t=='v2' then assert(tuple(v,2),'2 bileşen gerekli')
   else error('İzin verilmeyen özellik: '..tostring(key))end
  end
  if n.asset then assert(ids[n.asset]and(n.class=='ImageLabel'or n.class=='ImageButton'),'Görsel bağlantısı yanlış')end
  if n.action then assert(n.class=='TextButton'or n.class=='ImageButton','Aksiyon yalnız butonda');assert(n.action=='close'or n.action=='demo','Desteklenmeyen aksiyon')end
  if n.motion then assert(n.motion=='hover'or n.motion=='float'or n.motion=='glow'or n.motion=='snow','Desteklenmeyen hareket');if n.motion=='hover'then assert(n.class=='TextButton'or n.class=='ImageButton','Hover buton gerektirir')elseif n.motion=='snow'then assert(n.class=='Frame','Snow Frame gerektirir')elseif n.motion=='float'then assert(n.class=='ImageLabel'or n.class=='Frame'or n.class=='TextLabel','Float görsel nesne gerektirir')else assert(n.class=='ImageLabel'or n.class=='ImageButton','Glow görsel gerektirir')end end
  for _,c in ipairs(n.children or{})do visit(c,depth+1)end
 end
 visit(d.tree,1);assert(d.tree.class=='Frame','Kök Frame olmalı')
 assert(tuple(d.designSize,2)and d.designSize[1]>=200 and d.designSize[2]>=200 and d.designSize[1]<=4096 and d.designSize[2]<=4096,'Tasarım boyutu yanlış')
 local codeNames={}
 for _,c in ipairs(d.scripts or{})do
  assert(label(c.name,80)and c.name:match('^[%a_][%w_]*$')and not codeNames[c.name],'Kod adı yanlış/tekrarlı');codeNames[c.name]=c
  assert(c.kind=='LocalScript'or c.kind=='Script'or c.kind=='ModuleScript','Kod sınıfı yanlış')
  assert(c.target=='UI'or c.target=='Shared'or c.target=='Server'or c.target=='Client','Kod hedefi yanlış')
  assert((c.target~='Shared'or c.kind=='ModuleScript')and(c.target~='Client'or c.kind=='LocalScript')and(c.target~='UI'or c.kind~='Script')and(c.target~='Server'or c.kind~='LocalScript'),'Kod hedef/sınıf çifti yanlış')
  assert(label(c.path,240)and z.entries[c.path]and z.entries[c.path].size>0,'Kod dosyası eksik')
  assert(c.name~='UI_Motion'and c.name~='Package_Start'and c.name~='AssetMap'and c.name~='VFX'and c.name~='Viewport','Ayrılmış kod adı')
 end
 if d.controller then assert(codeNames[d.controller]and codeNames[d.controller].kind=='ModuleScript'and codeNames[d.controller].target=='UI','Controller UI ModuleScript olmalı')end
 local fxNames={}
 for _,f in ipairs(d.vfx or{})do
  assert(label(f.name,80)and f.name:match('^[%a_][%w_]*$')and not fxNames[f.name],'VFX adı yanlış');fxNames[f.name]=true
  assert(ids[f.texture],'VFX texture anahtarı eksik')
  assert(num(f.rate)and f.rate>=0 and f.rate<=10000,'VFX rate yanlış')
  assert(tuple(f.lifetime,2)and f.lifetime[1]>0 and f.lifetime[2]>=f.lifetime[1]and f.lifetime[2]<=30,'VFX lifetime yanlış')
  assert(tuple(f.speed,2)and f.speed[1]>=0 and f.speed[2]>=f.speed[1],'VFX speed yanlış')
  assert(tuple(f.size,2)and f.size[1]>=0 and f.size[2]>=0 and tuple(f.color,3),'VFX boyut/renk yanlış')
  for _,v in ipairs(f.color)do assert(v>=0 and v<=255,'VFX renk aralığı yanlış')end
 end
 return count
end
return M

end)()
local Motion=(function()
local M={}
function M.mount(gui)
 local TweenService=game:GetService('TweenService')
 local viewport=gui:WaitForChild('Viewport');local window=viewport:WaitForChild('Window');local scale=window:WaitForChild('ResponsiveScale');local backdrop=viewport:WaitForChild('Backdrop');local reopen=viewport:WaitForChild('Reopen');local toast=viewport:WaitForChild('Toast')
 local width,height=gui:GetAttribute('DesignWidth'),gui:GetAttribute('DesignHeight')
 local connections={};local opened=true;local target=1;local dead=false;local active={};local token=0
 local function bind(signal,fn)table.insert(connections,signal:Connect(fn))end
 local function tween(obj,t,props)
  if active[obj]then active[obj]:Cancel()end
  local tw=TweenService:Create(obj,TweenInfo.new(t,Enum.EasingStyle.Quint,Enum.EasingDirection.Out),props);active[obj]=tw;tw:Play();return tw
 end
 local function fit()
  target=math.min((viewport.AbsoluteSize.X-28)/width,(viewport.AbsoluteSize.Y-28)/height,1.12);target=math.max(.05,target)
  if opened then tween(scale,.18,{Scale=target})end
 end
 local function notify(text)
  token+=1;local id=token;toast.Text=text;toast.Visible=true;toast.Position=UDim2.new(.5,0,1,50);tween(toast,.3,{Position=UDim2.new(.5,0,1,-22)})
  task.delay(2.4,function()if not dead and id==token then tween(toast,.2,{Position=UDim2.new(.5,0,1,60)})end end)
 end
 local function setOpen(value)
  opened=value;reopen.Visible=not value
  if value then window.Visible=true;scale.Scale=target*.94;window.GroupTransparency=1;tween(scale,.36,{Scale=target});tween(window,.25,{GroupTransparency=0});tween(backdrop,.25,{BackgroundTransparency=.32})
  else local closing=tween(window,.18,{GroupTransparency=1});closing.Completed:Once(function()if not dead and not opened then window.Visible=false end end);tween(scale,.18,{Scale=target*.94});tween(backdrop,.18,{BackgroundTransparency=1})end
 end
 bind(viewport:GetPropertyChangedSignal('AbsoluteSize'),fit)

 for _,layer in ipairs(window:GetDescendants())do
  if layer:GetAttribute('UIPMotion')=='snow'then
   local rng=Random.new(421);local snow={}
   for i=1,32 do
    local f=Instance.new('Frame');f.Name='Snow_'..i;f.BorderSizePixel=0;f.BackgroundColor3=Color3.fromRGB(239,248,255);f.BackgroundTransparency=rng:NextNumber(.35,.72);f.ZIndex=layer.ZIndex
    local size=rng:NextInteger(2,5);f.Size=UDim2.fromOffset(size,size);f.Position=UDim2.fromScale(rng:NextNumber(),rng:NextNumber());f.Parent=layer
    local c=Instance.new('UICorner');c.CornerRadius=UDim.new(1,0);c.Parent=f;snow[i]={f=f,x=rng:NextNumber(),y=rng:NextNumber(),speed=rng:NextNumber(.035,.085),phase=rng:NextNumber(0,6.28)}
   end
   local elapsed=0
   bind(game:GetService('RunService').Heartbeat,function(dt)
    if dead or not opened then return end;elapsed+=dt
    for _,r in ipairs(snow)do r.y=(r.y+dt*r.speed)%1;r.f.Position=UDim2.fromScale(r.x+math.sin(elapsed*.6+r.phase)*.018,r.y)end
   end)
  end
 end
 for _,button in ipairs(window:GetDescendants())do
  if button:GetAttribute('UIPMotion')=='glow'and(button:IsA('ImageLabel')or button:IsA('ImageButton'))then local tw=TweenService:Create(button,TweenInfo.new(1.8,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{ImageColor3=Color3.fromRGB(255,238,220),ImageTransparency=.65});active[button]=tw;tw:Play()end
  if button:GetAttribute('UIPMotion')=='float'and button:IsA('GuiObject')then
   local tw=TweenService:Create(button,TweenInfo.new(2.1,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{Position=button.Position+UDim2.fromOffset(0,-4)});active[button]=tw;tw:Play()
  end
  if button:IsA('GuiButton')then
   if button:GetAttribute('UIPMotion')=='hover'then
    local s=Instance.new('UIScale');s.Name='UIPHover';s.Parent=button
    bind(button.MouseEnter,function()tween(s,.18,{Scale=1.035})end);bind(button.MouseLeave,function()tween(s,.2,{Scale=1})end)
    bind(button.MouseButton1Down,function()tween(s,.08,{Scale=.97})end);bind(button.MouseButton1Up,function()tween(s,.18,{Scale=1})end)
   end
   bind(button.Activated,function()
    if button:GetAttribute('UIPAction')=='close'then setOpen(false)
    elseif button:GetAttribute('UIPAction')=='demo'then notify('DEMO • Satın alma yapılmadı. Ürün bağlantısı ayrıca eklenir.')end
   end)
  end
 end
 bind(reopen.Activated,function()setOpen(true)end)
 bind(gui.Destroying,function()dead=true;for _,c in ipairs(connections)do c:Disconnect()end;for _,tw in pairs(active)do tw:Cancel()end end)
 fit();setOpen(true)
end
return M

end)()
local Icons=(function()
-- User-supplied Roblox asset IDs. Availability/permissions are decided by Roblox.
return {Shine=132173413740664,Close=114936431903992,Info=79885363269826,Plus=115287835952580,Question=121363654242981,Warning=118983277585782,Check=112111658571247,Save=72722644339742,Settings=83975950794008,Shop=133261037814108,Search=138693280049178,Codes=137017013769006,Trash=84650312727393,Verify=97006822120664,Home=112069341799916,Stats=123576336722734,Gift=129266605358776,Folder=120050644580049,Clock=115714784891439}

end)()
local Theme=(function()
-- Reference-inspired comic UI. No StarterGui creation or deletion from the sample.
local M={};local Tween=game:GetService('TweenService')
local function new(cl,p,props)local x=Instance.new(cl);for k,v in pairs(props)do x[k]=v end;x.Parent=p;return x end
local function corner(x,r)new('UICorner',x,{CornerRadius=UDim.new(0,r)})end
function M.outline(x,size)
 if x:FindFirstChild('ComicOutline')then return end
 local s=new('UIStroke',x,{Name='ComicOutline',Color=Color3.new(0,0,0),Thickness=size or 2,ApplyStrokeMode=x:IsA('TextLabel')and Enum.ApplyStrokeMode.Contextual or Enum.ApplyStrokeMode.Border,LineJoinMode=Enum.LineJoinMode.Round});return s
end
function M.panel(x,top,bottom,texture)
 x.BackgroundColor3=Color3.new(1,1,1);corner(x,14);M.outline(x,3)
 new('UIGradient',x,{Name='ComicGradient',Color=ColorSequence.new(top,bottom),Rotation=90})
 if texture then
  new('ImageLabel',x,{Name='StudTexture',Size=UDim2.fromScale(1,1),BackgroundTransparency=1,BorderSizePixel=0,Image='rbxassetid://113053849916466',ImageTransparency=.9,ScaleType=Enum.ScaleType.Tile,TileSize=UDim2.fromOffset(48,48),ZIndex=1})
 end
end
function M.button(b)
 if b:FindFirstChild('ComicFace')then return end
 local z=b.ZIndex;local base=b.BackgroundColor3
 b.BackgroundTransparency=1;b.TextTransparency=1;b.AutoButtonColor=false;b.ClipsDescendants=false
 local depth=new('Frame',b,{Name='ComicDepth',Position=UDim2.fromOffset(0,4),Size=UDim2.fromScale(1,1),BackgroundColor3=Color3.fromRGB(0,48,100),BorderSizePixel=0,ZIndex=z});corner(depth,9);M.outline(depth,2)
 local face=new('Frame',b,{Name='ComicFace',Size=UDim2.fromScale(1,1),BackgroundColor3=Color3.new(1,1,1),BorderSizePixel=0,ZIndex=z+1,ClipsDescendants=true});corner(face,9);M.outline(face,2)
 local grad=new('UIGradient',face,{Rotation=90})
 local function color()
  local c=b.BackgroundColor3
  grad.Color=ColorSequence.new(c:Lerp(Color3.new(1,1,1),.18),c:Lerp(Color3.new(0,0,0),.18));depth.BackgroundColor3=c:Lerp(Color3.new(0,0,0),.55)
 end;color();b:GetPropertyChangedSignal('BackgroundColor3'):Connect(color)
 local gloss=new('Frame',face,{Name='Gloss',Size=UDim2.new(1,0,.46,0),BackgroundColor3=Color3.new(1,1,1),BorderSizePixel=0,ZIndex=z+2});corner(gloss,9)
 new('UIGradient',gloss,{Rotation=90,Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,.62),NumberSequenceKeypoint.new(1,1)})})
 local shine=new('Frame',face,{Name='Shine',Size=UDim2.fromScale(1,1),BackgroundColor3=Color3.new(1,1,1),BorderSizePixel=0,ZIndex=z+3,Visible=false});corner(shine,9)
 local sg=new('UIGradient',shine,{Rotation=25,Offset=Vector2.new(-1.5,0),Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(.35,1),NumberSequenceKeypoint.new(.39,.45),NumberSequenceKeypoint.new(.43,1),NumberSequenceKeypoint.new(.48,1),NumberSequenceKeypoint.new(.52,.24),NumberSequenceKeypoint.new(.62,.24),NumberSequenceKeypoint.new(.68,1),NumberSequenceKeypoint.new(1,1)})})
 local tx=new('TextLabel',b,{Name='ComicLabel',Size=UDim2.fromScale(1,1),BackgroundTransparency=1,Text=b.Text,TextSize=b.TextSize,TextColor3=Color3.new(1,1,1),TextWrapped=b.TextWrapped,Font=Enum.Font.GothamBlack,BorderSizePixel=0,ZIndex=z+5});M.outline(tx,1.5)
 for _,prop in ipairs({'Text','TextSize','TextWrapped'})do b:GetPropertyChangedSignal(prop):Connect(function()tx[prop]=b[prop]end)end
 local hover
 b.MouseEnter:Connect(function()
  if hover then hover:Cancel()end;shine.Visible=true;sg.Offset=Vector2.new(-1.5,0)
  hover=Tween:Create(sg,TweenInfo.new(.45,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{Offset=Vector2.new(1.5,0)});hover:Play()
 end)
 b.MouseLeave:Connect(function()if hover then hover:Cancel()end;shine.Visible=false;face.Position=UDim2.fromOffset(0,0);tx.Position=UDim2.fromOffset(0,0)end)
 b.MouseButton1Down:Connect(function()face.Position=UDim2.fromOffset(0,3);tx.Position=UDim2.fromOffset(0,3)end)
 b.MouseButton1Up:Connect(function()face.Position=UDim2.fromOffset(0,0);tx.Position=UDim2.fromOffset(0,0)end)
end
return M

end)()
local Bridge=(function()
local M={ready=false}
local HS=game:GetService('HttpService');local BASE='http://127.0.0.1:38475';local token=''
local alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
function M.base64(raw)
 local out={}
 for i=1,#raw,3 do
  local a,b,c=raw:byte(i,i+2);local n=a*65536+(b or 0)*256+(c or 0)
  local x=math.floor(n/262144)%64;local y=math.floor(n/4096)%64;local z=math.floor(n/64)%64;local w=n%64
  out[#out+1]=alphabet:sub(x+1,x+1)..alphabet:sub(y+1,y+1)..(b and alphabet:sub(z+1,z+1)or'=')..(c and alphabet:sub(w+1,w+1)or'=')
  if i%49152==1 and i>1 then task.wait()end
 end
 return table.concat(out)
end
local function call(path,method,data,public)
 local headers={['Content-Type']='application/json'};if not public then headers.Authorization='Bearer '..token end
 local request={Url=BASE..path,Method=method,Headers=headers};if data then request.Body=HS:JSONEncode(data)end
 local ok,response=pcall(HS.RequestAsync,HS,request)
 if not ok then M.ready=false;token='';error('Yerel köprüye ulaşılamadı. Kopru_Baslat.cmd açık olmalı; Studio HTTP/yerel ağ iznini kontrol et.',0)end
 local parsed,value=pcall(HS.JSONDecode,HS,response.Body)
 if not parsed or type(value)~='table'then error('Köprü beklenen JSON yanıtını vermedi.',0)end
 if not response.Success then
  if response.StatusCode==401 then M.ready=false;token=''end
  error(value.error or('Köprü HTTP '..response.StatusCode),0)
 end
 return value
end
function M.connect(key)
 M.ready=false;token=''
 local health=call('/health','GET',nil,true);assert(health.app=='UIStudio5','Bu portta başka bir servis var');assert(health.protocol==2,'Eski köprü açık. Eski konsolu kapatıp yeni Kopru_Baslat.cmd dosyasını aç.')
 local result=call('/configure','POST',{key=key},true);assert(type(result.token)=='string'and #result.token>20,'Köprü oturumu açılamadı')
 token=result.token;M.ready=true;return result.message
end
function M.forget()M.ready=false;token=''end
function M.upload(pack,a,owner,cancel,log)
 assert(M.ready,'Önce API bağlantısını aç');assert(not cancel(),'İptal edildi')
 local raw=pack.zip:read(a.png)
 local transfer=call('/transfer','POST',{name=(pack.data.id..'_'..a.key):sub(1,50),creator={id=tostring(owner.id),kind=owner.group and'group'or'user'},length=#raw,crc=Binary.crc(raw)})
 assert(type(transfer.transfer)=='string','Transfer numarası eksik')
 local seq=0
 for pos=1,#raw,98304 do
  if cancel()then pcall(call,'/abort','POST',{transfer=transfer.transfer});error('Transfer iptal edildi',0)end
  local part=raw:sub(pos,pos+98303)
  local ack=call('/chunk','POST',{transfer=transfer.transfer,seq=seq,chunk=M.base64(part)})
  seq+=1;assert(ack.next==seq,'Transfer parçası doğrulanmadı')
 end
 local result=call('/complete','POST',{transfer=transfer.transfer})
 assert(type(result.job)=='string'and result.job:match('^[a-f0-9]+$'),'Köprü iş numarası eksik')
 local deadline=os.clock()+360
 while true do
  assert(not cancel(),'İptal: başlamış cloud işi köprüde tamamlanabilir; tekrar denemede hash cache kullanılır')
  local state=call('/jobs/'..result.job,'GET')
  if state.status=='done'then
   local id=tostring(state.assetId);assert(id:match('^%d+$')and tonumber(id)>0,'Geçersiz gerçek assetId');return id
  elseif state.status=='error'then if state.code==401 then M.ready=false;token=''end;error(state.message or'Open Cloud upload başarısız',0)end
  assert(os.clock()<deadline,'Upload bekleme süresi doldu; köprü açıkken aynı paketle tekrar dene')
  task.wait(.25)
 end
end
return M

end)()
local RuntimeSource=[=[local Motion=(function()
local M={}
function M.mount(gui)
 local TweenService=game:GetService('TweenService')
 local viewport=gui:WaitForChild('Viewport');local window=viewport:WaitForChild('Window');local scale=window:WaitForChild('ResponsiveScale');local backdrop=viewport:WaitForChild('Backdrop');local reopen=viewport:WaitForChild('Reopen');local toast=viewport:WaitForChild('Toast')
 local width,height=gui:GetAttribute('DesignWidth'),gui:GetAttribute('DesignHeight')
 local connections={};local opened=true;local target=1;local dead=false;local active={};local token=0
 local function bind(signal,fn)table.insert(connections,signal:Connect(fn))end
 local function tween(obj,t,props)
  if active[obj]then active[obj]:Cancel()end
  local tw=TweenService:Create(obj,TweenInfo.new(t,Enum.EasingStyle.Quint,Enum.EasingDirection.Out),props);active[obj]=tw;tw:Play();return tw
 end
 local function fit()
  target=math.min((viewport.AbsoluteSize.X-28)/width,(viewport.AbsoluteSize.Y-28)/height,1.12);target=math.max(.05,target)
  if opened then tween(scale,.18,{Scale=target})end
 end
 local function notify(text)
  token+=1;local id=token;toast.Text=text;toast.Visible=true;toast.Position=UDim2.new(.5,0,1,50);tween(toast,.3,{Position=UDim2.new(.5,0,1,-22)})
  task.delay(2.4,function()if not dead and id==token then tween(toast,.2,{Position=UDim2.new(.5,0,1,60)})end end)
 end
 local function setOpen(value)
  opened=value;reopen.Visible=not value
  if value then window.Visible=true;scale.Scale=target*.94;window.GroupTransparency=1;tween(scale,.36,{Scale=target});tween(window,.25,{GroupTransparency=0});tween(backdrop,.25,{BackgroundTransparency=.32})
  else local closing=tween(window,.18,{GroupTransparency=1});closing.Completed:Once(function()if not dead and not opened then window.Visible=false end end);tween(scale,.18,{Scale=target*.94});tween(backdrop,.18,{BackgroundTransparency=1})end
 end
 bind(viewport:GetPropertyChangedSignal('AbsoluteSize'),fit)

 for _,layer in ipairs(window:GetDescendants())do
  if layer:GetAttribute('UIPMotion')=='snow'then
   local rng=Random.new(421);local snow={}
   for i=1,32 do
    local f=Instance.new('Frame');f.Name='Snow_'..i;f.BorderSizePixel=0;f.BackgroundColor3=Color3.fromRGB(239,248,255);f.BackgroundTransparency=rng:NextNumber(.35,.72);f.ZIndex=layer.ZIndex
    local size=rng:NextInteger(2,5);f.Size=UDim2.fromOffset(size,size);f.Position=UDim2.fromScale(rng:NextNumber(),rng:NextNumber());f.Parent=layer
    local c=Instance.new('UICorner');c.CornerRadius=UDim.new(1,0);c.Parent=f;snow[i]={f=f,x=rng:NextNumber(),y=rng:NextNumber(),speed=rng:NextNumber(.035,.085),phase=rng:NextNumber(0,6.28)}
   end
   local elapsed=0
   bind(game:GetService('RunService').Heartbeat,function(dt)
    if dead or not opened then return end;elapsed+=dt
    for _,r in ipairs(snow)do r.y=(r.y+dt*r.speed)%1;r.f.Position=UDim2.fromScale(r.x+math.sin(elapsed*.6+r.phase)*.018,r.y)end
   end)
  end
 end
 for _,button in ipairs(window:GetDescendants())do
  if button:GetAttribute('UIPMotion')=='glow'and(button:IsA('ImageLabel')or button:IsA('ImageButton'))then local tw=TweenService:Create(button,TweenInfo.new(1.8,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{ImageColor3=Color3.fromRGB(255,238,220),ImageTransparency=.65});active[button]=tw;tw:Play()end
  if button:GetAttribute('UIPMotion')=='float'and button:IsA('GuiObject')then
   local tw=TweenService:Create(button,TweenInfo.new(2.1,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{Position=button.Position+UDim2.fromOffset(0,-4)});active[button]=tw;tw:Play()
  end
  if button:IsA('GuiButton')then
   if button:GetAttribute('UIPMotion')=='hover'then
    local s=Instance.new('UIScale');s.Name='UIPHover';s.Parent=button
    bind(button.MouseEnter,function()tween(s,.18,{Scale=1.035})end);bind(button.MouseLeave,function()tween(s,.2,{Scale=1})end)
    bind(button.MouseButton1Down,function()tween(s,.08,{Scale=.97})end);bind(button.MouseButton1Up,function()tween(s,.18,{Scale=1})end)
   end
   bind(button.Activated,function()
    if button:GetAttribute('UIPAction')=='close'then setOpen(false)
    elseif button:GetAttribute('UIPAction')=='demo'then notify('DEMO • Satın alma yapılmadı. Ürün bağlantısı ayrıca eklenir.')end
   end)
  end
 end
 bind(reopen.Activated,function()setOpen(true)end)
 bind(gui.Destroying,function()dead=true;for _,c in ipairs(connections)do c:Disconnect()end;for _,tw in pairs(active)do tw:Cancel()end end)
 fit();setOpen(true)
end
return M

end)()
Motion.mount(script.Parent)
]=]
local Engine=(function()
local M={}
local HS=game:GetService('HttpService');local AS=game:GetService('AssetService');local Studio=game:GetService('StudioService')
function M.owner(mode,id)
 if mode=='Grup'then local n=tonumber(id);assert(n and n>0 and n%1==0,'Geçerli grup ID gerekli');return {id=n,group=true,label='Grup #'..n}end
 if mode=='Hesabım'then local n=Studio:GetUserId();assert(n>0,'Studio hesabında oturum aç');return{id=n,group=false,label='Hesabım #'..n}end
 if game.CreatorId>0 then return{id=game.CreatorId,group=game.CreatorType==Enum.CreatorType.Group,label=(game.CreatorType==Enum.CreatorType.Group and 'Oyun grubu #'or'Oyun sahibi #')..game.CreatorId}end
 local n=Studio:GetUserId();assert(n>0,'Studio hesabında oturum aç');return{id=n,group=false,label='Yayımlanmamış oyun → hesabım #'..n}
end
function M.load(raw)
 local zip=Binary.zip(raw);local d=HS:JSONDecode(zip:read('manifest.json'));local nodes=Schema.validate(d,zip)
 -- Parse/verify PNG now; verify RGBA once in preview or upload preflight before ANY cloud mutation.
 for _,a in ipairs(d.assets)do zip:read(a.png)end -- RGBA verified once during native preview, or before upload below.
 for _,c in ipairs(d.scripts or{})do local code=zip:read(c.path);assert(not code:find('%z'),'Kod içinde NUL var')end
 return{raw=raw,data=d,zip=zip,nodes=nodes,fingerprint=tostring(Binary.crc(raw))..':'..#raw}
end
local function decode(key,v,class)
 local e=Schema.enums[key];if e then return Enum[key=='AutomaticCanvasSize'and'AutomaticSize'or key][v]end
 local t=Schema.props[key]
 if t=='color'then local c=Color3.fromRGB(v[1],v[2],v[3]);return class=='UIGradient'and ColorSequence.new(c,c)or c end
 if t=='u2'then return UDim2.new(v[1],v[2],v[3],v[4])end
 if t=='u1'then return UDim.new(v[1],v[2])end
 if t=='v2'then return Vector2.new(v[1],v[2])end
 if t=='rect'then return Rect.new(v[1],v[2],v[3],v[4])end
 if key=='Transparency'and class=='UIGradient'then return NumberSequence.new(v)end
 return v
end
local function object(class,parent,name,props)
 local x=Instance.new(class);x.Name=name;if x:IsA('GuiObject')then x.BorderSizePixel=0 end
 for k,v in pairs(props or{})do x[k]=v end
 x.Parent=parent;return x
end
function M.build(pack,ids,parent,preview)
 local d=pack.data;local gui=Instance.new(preview and'Frame'or'ScreenGui');gui.Name='UIP_'..d.id
 local ok,err=xpcall(function()
 if preview then gui.Size=UDim2.fromScale(1,1);gui.BackgroundTransparency=1;gui.BorderSizePixel=0
 else gui.ResetOnSpawn=false;gui.IgnoreGuiInset=false;gui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling;gui.DisplayOrder=20 end
 gui:SetAttribute('NativeAcceptance','NOT_RUN_BY_AUTHOR');gui:SetAttribute('UIPackage',d.id);gui:SetAttribute('DesignWidth',d.designSize[1]);gui:SetAttribute('DesignHeight',d.designSize[2]);gui:SetAttribute('UIInstaller','UI Studio 5.0')
 local viewport=object('Frame',gui,'Viewport',{Size=UDim2.fromScale(1,1),BackgroundTransparency=1})
 object('Frame',viewport,'Backdrop',{Size=UDim2.fromScale(1,1),BackgroundColor3=Color3.fromRGB(5,9,20),BackgroundTransparency=1,BorderSizePixel=0})
 local window=object('CanvasGroup',viewport,'Window',{Size=UDim2.fromOffset(d.designSize[1],d.designSize[2]),Position=UDim2.fromScale(.5,.5),AnchorPoint=Vector2.new(.5,.5),BackgroundTransparency=1,GroupTransparency=0,ZIndex=2})
 object('UIScale',window,'ResponsiveScale',{Scale=1})
 local function visit(n,p)
  local x=Instance.new(n.class);x.Name=n.name;x.Parent=p
  for key,v in pairs(n.props or{})do local applied,why=pcall(function()x[key]=decode(key,v,n.class)end);assert(applied,n.name..'.'..key..': '..tostring(why))end
  if x:IsA('GuiObject')then if not(n.props or{}).BorderSizePixel then x.BorderSizePixel=0 end end
  if n.asset then local ref=assert(ids[n.asset],'Eksik ID: '..n.asset);if typeof(ref)=='Content'then x.ImageContent=ref else x.Image=ref end end
  if n.action then x:SetAttribute('UIPAction',n.action)end;if n.motion then x:SetAttribute('UIPMotion',n.motion)end
  for _,c in ipairs(n.children or{})do visit(c,x)end;return x
 end
 local root=visit(d.tree,window);root.Size=UDim2.fromScale(1,1);root.Position=UDim2.fromOffset(0,0);root.AnchorPoint=Vector2.zero
 local reopen=object('TextButton',viewport,'Reopen',{Size=UDim2.fromOffset(180,44),Position=UDim2.new(.5,0,1,-18),AnchorPoint=Vector2.new(.5,1),BackgroundColor3=Color3.fromRGB(36,183,170),Text='MAĞAZAYI AÇ',Font=Enum.Font.GothamBold,TextSize=14,TextColor3=Color3.new(1,1,1),Visible=false,ZIndex=30,AutoButtonColor=false});object('UICorner',reopen,'Round',{CornerRadius=UDim.new(0,12)})
 local toast=object('TextLabel',viewport,'Toast',{Size=UDim2.new(.9,0,0,50),Position=UDim2.new(.5,0,1,60),AnchorPoint=Vector2.new(.5,1),BackgroundColor3=Color3.fromRGB(23,37,55),Text='',TextSize=13,TextWrapped=true,Font=Enum.Font.Gotham,TextColor3=Color3.new(1,1,1),Visible=false,ZIndex=40});object('UICorner',toast,'Round',{CornerRadius=UDim.new(0,12)})
 if not preview then local s=Instance.new('LocalScript');s.Name='UI_Motion';s.Source=RuntimeSource;s.Parent=gui end
 gui.Parent=parent
 end,debug.traceback)
 if not ok then gui:Destroy();error(err,0)end
 return gui
end
function M.upload(pack,owner,pluginObject,manual,log,cancel,onProgress)
 -- No upload until EVERY byte is verified, including when preview was skipped/failed.
 if pack.zip.verified then for _,a in ipairs(pack.data.assets)do
  for _,path in ipairs({a.png,a.rgba})do if not pack.zip.verified[path]then pack.zip:read(path)end end
 end end
 local ids={};local cache=pluginObject:GetSetting('UIPAssetCacheV1')or{};if type(cache)~='table'then cache={}end
 local queue={};local completed=0
 for _,a in ipairs(pack.data.assets)do
  assert(not cancel(),'İşlem iptal edildi; tamamlanan asset yüklemeleri Roblox üzerinde kalır')
  local entry=pack.zip.entries[a.rgba];local key=table.concat({owner.group and'g'or'u',owner.id,pack.data.id,a.key,a.width,a.height,entry.crc},':')
  local cached=manual[a.key]or cache[key]
  if cached then local n=tonumber(tostring(cached):match('(%d+)$'));assert(n and n>0 and n%1==0,'Geçersiz ID: '..a.key);ids[a.key]='rbxassetid://'..string.format('%.0f',n);completed+=1;log('Önbellekten: '..a.key)
  else table.insert(queue,{asset=a,key=key})end
 end
 local cursor=0;local running=0;local firstError
 local function worker()
  while not firstError and not cancel()do
   cursor+=1;local row=queue[cursor];if not row then break end
   local a=row.asset;log('Yükleniyor: '..a.key..' → '..owner.label)
   local ok,id=pcall(Bridge.upload,pack,a,owner,function()return cancel()or firstError~=nil end,log)
   if not ok then firstError=firstError or tostring(id);break end
   local n=tonumber(id);if not n or n<=0 then firstError='Geçersiz gerçek assetId';break end
   ids[a.key]='rbxassetid://'..string.format('%.0f',n);cache[row.key]=n;completed+=1
   local saved=pcall(function()pluginObject:SetSetting('UIPAssetCacheV1',cache)end)
   log('Yüklendi: '..a.key..' → '..tostring(id));if not saved then log('Cache yazılamadı; gerçek ID: '..tostring(id))end
   if onProgress then onProgress(completed,#pack.data.assets,a.key)end
  end
  running-=1
 end
 if task and task.spawn and #queue>1 then
  running=math.min(2,#queue);for _=1,running do task.spawn(worker)end
  while running>0 do task.wait()end
 elseif #queue>0 then running=1;worker()end
 if firstError then error(firstError,0)end
 assert(not cancel(),'İptal edildi; başlamış cloud işleri köprüde tamamlanabilir')
 return ids
end
-- Package scripts are installed only after explicit per-package approval in Main.
local function codeObject(pack,c,parent)
 local x=Instance.new(c.kind);x.Name=c.name;x.Parent=parent;x.Source=pack.zip:read(c.path);return x
end
function M.controllerSource(pack)
 return "local ctx={gui=script.Parent,preview=false,shared=game:GetService('ReplicatedStorage'):WaitForChild('UIP_Shared_"..pack.data.id.."')}\nlocal module=require(script.Parent:WaitForChild('"..pack.data.controller.."'))\nassert(type(module)=='table'and type(module.mount)=='function','Controller.mount gerekli')\nmodule.mount(ctx)"
end
function M.preview(pack,ids,parent,approved)
 local gui=M.build(pack,ids,parent,true)
 local ok,err=xpcall(function()
  Motion.mount(gui)
  if approved and pack.data.controller then
   for _,c in ipairs(pack.data.scripts or{})do if c.target=='UI'and c.kind=='ModuleScript'then codeObject(pack,c,gui)end end
   local mod=require(gui:FindFirstChild(pack.data.controller));assert(type(mod)=='table'and type(mod.mount)=='function','Controller.mount gerekli');mod.mount({gui=gui,preview=true,shared=nil})
  end
 end,debug.traceback)
 if not ok then gui:Destroy();error(err,0)end
 return gui
end
function M.stage(pack,ids,owner,approved)
 assert(#(pack.data.scripts or{})==0 or approved,'Paket kodu onaylanmadı')
 local out={};local function add(x,svc)out[#out+1]={object=x,parent=game:GetService(svc)};return x end
 local ok,err=xpcall(function()
  local gui=add(M.build(pack,ids,nil,false),'StarterGui')
  local shared=Instance.new('Folder');shared.Name='UIP_Shared_'..pack.data.id;shared:SetAttribute('UIPackage',pack.data.id);add(shared,'ReplicatedStorage')
  local server=Instance.new('Folder');server.Name='UIP_Server_'..pack.data.id;server:SetAttribute('UIPackage',pack.data.id);add(server,'ServerScriptService')
  local client=Instance.new('Folder');client.Name='UIP_Client_'..pack.data.id;client:SetAttribute('UIPackage',pack.data.id);out[#out+1]={object=client,parent=game:GetService('StarterPlayer'):WaitForChild('StarterPlayerScripts')}
  for _,row in ipairs(out)do row.object:SetAttribute('AssetOwnerId',owner.id);row.object:SetAttribute('AssetOwnerType',owner.group and'Group'or'User')end
  local map=Instance.new('StringValue');map.Name='AssetMap';map.Value=HS:JSONEncode(ids);map.Parent=shared
  local same=map:Clone();same.Parent=gui
  local templates=Instance.new('Folder');templates.Name='VFX';templates.Parent=shared
  for _,f in ipairs(pack.data.vfx or{})do
   local model=Instance.new('Model');model.Name=f.name;model.Parent=templates
   local p=Instance.new('Part');p.Name='Origin';p.Size=Vector3.one;p.Anchored=true;p.CanCollide=false;p.CanQuery=false;p.CanTouch=false;p.Transparency=1;p.Parent=model;model.PrimaryPart=p
   local a=Instance.new('Attachment');a.Name='FX';a.Parent=p
   local e=Instance.new('ParticleEmitter');e.Name=f.name;e.Enabled=false;e.Texture=ids[f.texture];e.Rate=f.rate;e.Lifetime=NumberRange.new(f.lifetime[1],f.lifetime[2]);e.Speed=NumberRange.new(f.speed[1],f.speed[2]);e.Size=NumberSequence.new(f.size[1],f.size[2]);e.Color=ColorSequence.new(Color3.fromRGB(f.color[1],f.color[2],f.color[3]));e.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,.1),NumberSequenceKeypoint.new(.7,.2),NumberSequenceKeypoint.new(1,1)});e.SpreadAngle=Vector2.new(45,45);e.LightEmission=.7;e.Drag=1;e.Parent=a
  end
  for _,c in ipairs(pack.data.scripts or{})do codeObject(pack,c,c.target=='UI'and gui or(c.target=='Shared'and shared or(c.target=='Server'and server or client)))end
  if pack.data.controller then local x=Instance.new('LocalScript');x.Name='Package_Start';x.Source=M.controllerSource(pack);x.Parent=gui end
 end,debug.traceback)
 if not ok then for _,row in ipairs(out)do row.object:Destroy()end;error(err,0)end
 return out
end
function M.canInstall(pack,replace)
 local id=pack.data.id
 local slots={{game:GetService('StarterGui'),'UIP_'..id},{game:GetService('ReplicatedStorage'),'UIP_Shared_'..id},{game:GetService('ServerScriptService'),'UIP_Server_'..id},{game:GetService('StarterPlayer'):WaitForChild('StarterPlayerScripts'),'UIP_Client_'..id}}
 for _,slot in ipairs(slots)do local old=slot[1]:FindFirstChild(slot[2]);if old then assert(replace,'Paket kurulu; Gelişmiş > güncelle seçeneğini aç');assert(old:GetAttribute('UIPackage')==id,'Farklı içerik korunuyor: '..old.Name)end end
end
function M.commit(rows,replace,packId)
 local existing={}
 for _,row in ipairs(rows)do
  local old=row.parent:FindFirstChild(row.object.Name)
  if old then assert(replace,'Aynı paket mevcut: Güncelle seçeneğini aç');assert(old:GetAttribute('UIPackage')==packId,'Aynı adlı farklı içerik korunuyor: '..old.Name);table.insert(existing,{object=old,parent=row.parent})end
 end
 local backup=Instance.new('Folder');backup.Name='UIP_Pro_Backup_'..os.time();backup.Parent=game:GetService('ServerStorage')
 local ok,err=xpcall(function()
  for _,row in ipairs(existing)do row.object.Parent=backup end
  for _,row in ipairs(rows)do row.object.Parent=row.parent end
 end,debug.traceback)
 if not ok then
  for _,row in ipairs(rows)do row.object:Destroy()end
  for _,row in ipairs(existing)do row.object.Parent=row.parent end
  backup:Destroy();error(err,0)
 end
 return{created=rows,previous=existing,backup=backup}
end
function M.undo(record)
 for _,r in ipairs(record.created)do assert(r.object.Parent==r.parent,'Kurulan içerik taşındı; otomatik geri alma durdu')end
 for _,r in ipairs(record.previous)do assert(r.object.Parent==record.backup,'Yedek taşındı; otomatik geri alma durdu')end
 for _,r in ipairs(record.created)do r.object:Destroy()end
 for _,r in ipairs(record.previous)do r.object.Parent=r.parent end
 if #record.backup:GetChildren()==0 then record.backup:Destroy()end
end
return M

end)()
assert(plugin,'Bu dosyayı yerel Plugins klasörüne kurmalısın.')
local Tween=game:GetService('TweenService');local Studio=game:GetService('StudioService');local Run=game:GetService('RunService');local History=game:GetService('ChangeHistoryService')
local toolbar=plugin:CreateToolbar('UI Studio 5');local toggle=toolbar:CreateButton('UIStudio5','UI Studio 5 — paket yöneticisi','rbxassetid://'..Icons.Shop,'UI Studio');toggle.ClickableWhenViewportHidden=true
local widget=plugin:CreateDockWidgetPluginGui('UIStudio5',DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Float,false,true,920,650,760,520));widget.Title='UI Studio 5.2 • Comic';widget.Enabled=false
local C={bg=Color3.fromRGB(0,112,235),card=Color3.fromRGB(0,130,238),accent=Color3.fromRGB(0,237,255),white=Color3.fromRGB(255,255,255),muted=Color3.fromRGB(192,217,238)}
local function make(cl,p,t)local o=Instance.new(cl);if o:IsA('GuiObject')then o.BorderSizePixel=0 end;for k,v in pairs(t)do o[k]=v end;o.Parent=p;if cl=='TextButton'then Theme.button(o)end;return o end
local function round(o,r)make('UICorner',o,{CornerRadius=UDim.new(0,r or 10)})end
local function icon(p,key,pos,size,z)return make('ImageLabel',p,{Image='rbxassetid://'..assert(Icons[key]),BackgroundTransparency=1,Position=pos,Size=UDim2.fromOffset(size,size),ScaleType=Enum.ScaleType.Fit,ZIndex=z or 9})end
local root=make('Frame',widget,{Position=UDim2.fromOffset(6,6),Size=UDim2.new(1,-12,1,-16),BackgroundColor3=C.bg});Theme.panel(root,Color3.fromRGB(0,238,255),Color3.fromRGB(0,102,255),true)
local function label(p,text,size,col,pos,sz)local x=make('TextLabel',p,{Text=text,TextSize=size or 13,Font=Enum.Font.Gotham,TextColor3=col or C.white,BackgroundTransparency=1,TextWrapped=true,TextXAlignment=Enum.TextXAlignment.Left,Position=pos or UDim2.new(),Size=sz or UDim2.new(1,0,0,26)});if(size or 13)>=16 then Theme.outline(x,1.5)end;return x end
local header=make('Frame',root,{Size=UDim2.new(1,0,0,64),BackgroundTransparency=1})
icon(header,'Shop',UDim2.fromOffset(18,15),34)
local title=label(header,'UI STUDIO',28,C.white,UDim2.fromOffset(64,10),UDim2.fromOffset(200,27));title.Font=Enum.Font.GothamBlack
label(header,'PAKET YÖNETİCİSİ / 5.2',9,C.muted,UDim2.fromOffset(65,37),UDim2.fromOffset(200,17))
local connection=make('TextButton',header,{Position=UDim2.new(1,-193,0,16),Size=UDim2.fromOffset(142,32),Text='API BAĞLANTISI',TextSize=10,Font=Enum.Font.GothamBold,TextColor3=C.accent,BackgroundColor3=C.card});round(connection,8)
local exit=make('ImageButton',header,{Position=UDim2.new(1,-38,0,21),Size=UDim2.fromOffset(22,22),Image='rbxassetid://'..Icons.Close,BackgroundTransparency=1});exit.Activated:Connect(function()widget.Enabled=false end)
local openAuth
local leftBack=make('Frame',root,{Position=UDim2.fromOffset(12,117),Size=UDim2.new(0,254,1,-129)});Theme.panel(leftBack,Color3.fromRGB(28,40,52),Color3.fromRGB(15,25,38),true)
local left=make('ScrollingFrame',root,{Position=UDim2.fromOffset(18,122),Size=UDim2.new(0,242,1,-140),BackgroundTransparency=1,ScrollBarThickness=3,ScrollBarImageColor3=C.accent,CanvasSize=UDim2.new(),AutomaticCanvasSize=Enum.AutomaticSize.Y})
make('UIListLayout',left,{Padding=UDim.new(0,8),SortOrder=Enum.SortOrder.LayoutOrder});make('UIPadding',left,{PaddingRight=UDim.new(0,6),PaddingBottom=UDim.new(0,16)})
local order=0;local function add(o)order+=1;o.LayoutOrder=order;return o end
local function text(t,size,col)local l=add(label(left,t,size,col));l.AutomaticSize=Enum.AutomaticSize.Y;return l end
local buttonIcons={['ZIP PAKETİ AÇ']='Plus',['OYUNA YÜKLE']='Shop',['İSİMLE KAYDET']='Save',['PAKET KODLARI / ONAY']='Codes',['GELİŞMİŞ / GÜNLÜK']='Settings'}
local function button(t,color)
 local b=add(make('TextButton',left,{Size=UDim2.new(1,0,0,40),Text=t,TextSize=13,Font=Enum.Font.GothamBold,TextColor3=C.white,BackgroundColor3=color or Color3.new(1,1,1),AutoButtonColor=false}));round(b)
 local id=buttonIcons[t];if id then icon(b,id,UDim2.fromOffset(12,9),22);b.Text='      '..t end
 return b
end
local pick=button('ZIP PAKETİ AÇ',Color3.fromRGB(0,165,255));pick.Size=UDim2.new(1,0,0,58)
local info=text('ZIP seç • Native önizle • Oyuna kur',11,C.muted)
local state=text('API BAĞLANTISI BEKLENİYOR',11,C.accent);state.Font=Enum.Font.GothamBold
local track=add(make('Frame',left,{Size=UDim2.new(1,0,0,3),BackgroundColor3=C.card}));round(track,3);local fill=make('Frame',track,{Size=UDim2.fromScale(0,1),BackgroundColor3=C.accent});round(fill,3)
local ownerLabel=text('Oyun sahibi otomatik seçilir',10,C.muted)
local uploadConsent=false;local uploadButton=button('[ ] Görselleri Roblox’a yüklemeye izin ver');uploadButton.TextSize=10;uploadButton.TextWrapped=true
local install=button('OYUNA YÜKLE',Color3.fromRGB(64,214,16))
local saveButton=button('İSİMLE KAYDET',Color3.fromRGB(174,65,246))
local codeButton=button('PAKET KODLARI / ONAY');codeButton.Visible=false
local advancedButton=button('GELİŞMİŞ / GÜNLÜK')
local advanced=add(make('Frame',left,{Size=UDim2.new(1,0,0,0),AutomaticSize=Enum.AutomaticSize.Y,BackgroundTransparency=1,Visible=false}));make('UIListLayout',advanced,{Padding=UDim.new(0,7)})
local function ab(t)local b=make('TextButton',advanced,{Size=UDim2.new(1,0,0,35),Text=t,TextWrapped=true,Font=Enum.Font.GothamBold,TextSize=10,TextColor3=C.white,BackgroundColor3=C.card});round(b);return b end
local mode='Otomatik';local modeButton=ab('Hedef: oyun sahibi / otomatik')
local group=make('TextBox',advanced,{Text='',Visible=false,Size=UDim2.new()})
local manual=make('TextBox',advanced,{Text='',Visible=false,Size=UDim2.new()})
local replace=false;local replaceButton=ab('[ ] Kurulu paketi yedekleyerek güncelle')
local undoButton=ab('SON KURULUMU GERİ AL');local cancelButton=ab('İŞLEMİ İPTAL ET')
local journal=label(advanced,'İşlem günlüğü\n',10,C.muted);journal.AutomaticSize=Enum.AutomaticSize.Y;journal.Font=Enum.Font.Code
local host=make('Frame',root,{Position=UDim2.fromOffset(278,82),Size=UDim2.new(1,-296,1,-100),BackgroundColor3=Color3.fromRGB(17,22,37),ClipsDescendants=true});round(host,14);Theme.panel(host,Color3.fromRGB(28,40,52),Color3.fromRGB(13,21,32),true)
local h=label(host,'NATIVE ÖNİZLEME',10,Color3.fromRGB(180,188,213),UDim2.fromOffset(16,12),UDim2.new(1,-130,0,24));h.Font=Enum.Font.GothamBold
local refresh=make('TextButton',host,{Position=UDim2.new(1,-99,0,10),Size=UDim2.fromOffset(85,28),Text='YENİLE',TextSize=10,Font=Enum.Font.GothamBold,TextColor3=Color3.fromRGB(223,227,245),BackgroundColor3=Color3.fromRGB(37,43,65)});round(refresh,7)
local previewHost=make('Frame',host,{Position=UDim2.fromOffset(0,46),Size=UDim2.new(1,0,1,-76),BackgroundTransparency=1,ClipsDescendants=true})
local placeholder=label(previewHost,'PAKETİN BURADA HAYAT BULUR\n\nAPI bağlantısını kur, ardından ZIP aç.\nBu alan HTML değil, native Roblox nesneleridir.',14,Color3.fromRGB(147,157,184),UDim2.new(.1,0,.3,0),UDim2.new(.8,0,.4,0));placeholder.TextXAlignment=Enum.TextXAlignment.Center
local foot=label(host,'Önizleme upload yapmaz • Kodlar ayrıca onay ister',9,Color3.fromRGB(145,155,180),UDim2.new(0,16,1,-28),UDim2.new(1,-32,0,23))
local imageRaw;local refsCache={};local pack,previewGui,lastInstall;local selectedLibraryId;local currentSavedName;local refreshLibrary;local openSave;local loadLibrary;local installPack;local images={};local busy=false;local canceled=false;local dead=false;local approved=false
local function log(t)print('[UI Studio 5] '..t);if not dead then journal.Text=(journal.Text..t..'\n'):sub(-22000)end end
local function progress(t,p)if dead then return end;state.Text=t;Tween:Create(fill,TweenInfo.new(.25),{Size=UDim2.fromScale(p,1)}):Play()end
local targetSerial=0
local function target()targetSerial+=1;local serial=targetSerial;local ok,o=pcall(Engine.owner,mode,'');ownerLabel.Text=ok and o.label or tostring(o);if ok then task.spawn(function()local named,name=pcall(function()if o.group then return game:GetService('GroupService'):GetGroupInfoAsync(o.id).Name else return game:GetService('Players'):GetNameFromUserIdAsync(o.id)end end);if named and serial==targetSerial and not dead then ownerLabel.Text=(o.group and 'Oyun grubu: 'or'Hesap: ')..name end end)end end;target()
local function clearPreview()if previewGui then previewGui:Destroy();previewGui=nil end;for _,im in ipairs(images)do im:Destroy()end;table.clear(images);refsCache={};imageRaw=nil end
local function operation(fn)
 if busy then return end;if not Bridge.ready then openAuth();return end;busy=true;canceled=false;group.TextEditable=false;manual.TextEditable=false
 local pulse=Tween:Create(fill,TweenInfo.new(.7,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),{BackgroundTransparency=.65});pulse:Play()
 task.spawn(function()local ok,err=xpcall(fn,debug.traceback);if not ok then log('DURDU: '..tostring(err));advanced.Visible=true;if not Bridge.ready then openAuth()end;progress(canceled and'İPTAL EDİLDİ'or('DURDU: '..tostring(err):match('[^\n]+')),0)end;pulse:Cancel();if not dead then fill.BackgroundTransparency=0;group.TextEditable=true;manual.TextEditable=true end;busy=false end)
end
local function showPreview()
 assert(pack,'Önce ZIP seç');if previewGui then previewGui:Destroy();previewGui=nil end;if imageRaw~=pack.raw then clearPreview()end;placeholder.Visible=false;progress('ÖNİZLEME HAZIRLANIYOR',.35)
 local ok,err=xpcall(function()
  local refs=refsCache;for i,a in ipairs(pack.data.assets)do
   if not refs[a.key]then
   assert(not canceled and not dead,'İptal');local im=game:GetService('AssetService'):CreateEditableImage({Size=Vector2.new(a.width,a.height)});assert(im,'EditableImage erişimi/belleği yok; günlükteki native hatayı paylaş')
   table.insert(images,im);im:WritePixelsBuffer(Vector2.zero,Vector2.new(a.width,a.height),buffer.fromstring(pack.zip:read(a.rgba)));refs[a.key]=Content.fromObject(im)
   end
   progress('ÖNİZLEME '..i..' / '..#pack.data.assets,.25+.15*i/math.max(1,#pack.data.assets))
  end
  refsCache=refs;imageRaw=pack.raw
  previewGui=Engine.preview(pack,refs,previewHost,approved)
 end,debug.traceback)
 if not ok then clearPreview();placeholder.Visible=true;error(err,0)end
 progress(approved and'ÖNİZLEME • paket controller kodu açık'or'ÖNİZLEME • görsel/UI/motion açık; paket kodu kapalı',.4)
end
local function acceptPack(value,filename)
 local placeholders={};for _,a in ipairs(value.data.assets)do placeholders[a.key]=''end;local preflight=Engine.build(value,placeholders,nil,true);preflight:Destroy()
 pack=value;approved=false;codeButton.Visible=#(pack.data.scripts or{})>0;uploadButton.Text=(uploadConsent and'[✓] 'or'[ ] ')..'Kalıcı görsel yüklemeyi onaylıyorum';codeButton.Text='PAKET KODLARI / ONAY';info.Text=pack.data.title..'\n'..#pack.data.assets..' görsel · '..#(pack.data.vfx or{})..' 3D şablon · '..#(pack.data.scripts or{})..' kod\n'..filename
 log('Doğrulandı: '..pack.data.id..' / '..pack.fingerprint);target();showPreview()
end
pick.Activated:Connect(function()operation(function()
 local f=Studio:PromptImportFileAsync({'zip'});if not f then return end
 local ok,value=xpcall(function()assert(f.Size<=134217728,'ZIP çok büyük');return Engine.load(f:GetBinaryContents())end,debug.traceback);local filename=f.Name;f:Destroy();assert(ok,value);assert(not canceled,'İptal')
 selectedLibraryId=nil;currentSavedName=nil;acceptPack(value,filename)
end)end)
refresh.Activated:Connect(function()operation(showPreview)end)
advancedButton.Activated:Connect(function()advanced.Visible=not advanced.Visible;advancedButton.Text=advanced.Visible and'      GÜNLÜĞÜ KAPAT'or'      GELİŞMİŞ / GÜNLÜK'end)
modeButton.Activated:Connect(function()if busy then return end;mode=mode=='Otomatik'and'Hesabım'or'Otomatik';modeButton.Text=mode=='Otomatik'and'Hedef: Oyun sahibi (otomatik)'or'Hedef: Oturum açılan hesabım';target()end);group:GetPropertyChangedSignal('Text'):Connect(target)
replaceButton.Activated:Connect(function()if busy then return end;replace=not replace;replaceButton.Text=(replace and'[✓] 'or'[ ] ')..'Kurulu paketi yedekleyerek güncelle'end)
uploadButton.Activated:Connect(function()if busy then return end;uploadConsent=not uploadConsent;uploadButton.Text=(uploadConsent and'[✓] 'or'[ ] ')..'Kalıcı görsel yüklemeyi onaylıyorum'end)
local review
codeButton.Activated:Connect(function()
 if busy or not pack then return end
 if review then review:Destroy()end
 local reviewPack=pack
 review=make('Frame',root,{Active=true,Position=UDim2.fromOffset(20,90),Size=UDim2.new(1,-40,1,-110),BackgroundColor3=C.bg,ZIndex=100});round(review)
 local note=label(review,'GÜVENİLİR PAKET KODU ONAYI\nController önizlemesi plugin bağlamında kod çalıştırır: oyun verilerini değiştirebilir. Sandbox değildir. Yalnız kendi/güvendiğin paketini onayla. Server/Client kodları kurulumdan sonra oyunda çalışır.',13,C.white,UDim2.fromOffset(18,12),UDim2.new(1,-36,0,96));note.ZIndex=101
 local all={};for _,c in ipairs(pack.data.scripts or{})do table.insert(all,'-- '..c.name..' / '..c.kind..' / '..c.target..' / '..c.path..'\n'..pack.zip:read(c.path)..'\n')end
 local sc=make('ScrollingFrame',review,{Position=UDim2.fromOffset(18,118),Size=UDim2.new(1,-36,1,-188),BackgroundColor3=C.card,BorderSizePixel=0,CanvasSize=UDim2.new(),AutomaticCanvasSize=Enum.AutomaticSize.Y,ScrollBarThickness=6,ZIndex=101})
 local source=make('TextLabel',sc,{Size=UDim2.new(1,-12,0,0),AutomaticSize=Enum.AutomaticSize.Y,Text=table.concat(all,'\n'),TextWrapped=true,TextSize=11,Font=Enum.Font.Code,TextColor3=C.white,BackgroundTransparency=1,TextXAlignment=Enum.TextXAlignment.Left,TextYAlignment=Enum.TextYAlignment.Top,ZIndex=102})
 local yes=make('TextButton',review,{Position=UDim2.new(0,18,1,-54),Size=UDim2.new(.65,-24,0,40),Text='BU PAKETİN KODUNU OKUDUM / ONAYLIYORUM',TextWrapped=true,TextSize=12,Font=Enum.Font.GothamBold,BackgroundColor3=Color3.fromRGB(64,214,16),TextColor3=C.white,ZIndex=101});round(yes)
 local no=make('TextButton',review,{Position=UDim2.new(.65,8,1,-54),Size=UDim2.new(.35,-26,0,40),Text='KAPAT',TextSize=12,BackgroundColor3=C.card,TextColor3=C.white,ZIndex=101});round(no)
 no.Activated:Connect(function()review:Destroy();review=nil end)
 yes.Activated:Connect(function()if pack~=reviewPack then log('Paket değişti; kodu yeniden incele');review:Destroy();review=nil;return end;approved=true;codeButton.Text='✓ PAKET KODU ONAYLANDI';review:Destroy();review=nil;operation(showPreview)end)
end)
local function readManual()return{}end
installPack=function()operation(function()
 assert(pack,'Önce ZIP seç');if Run:IsRunning()then progress('Play açık. Durdur düğmesine basıp tekrar yükle.',0);return end
 if not uploadConsent then progress('Önce aşağıdaki görsel yükleme onayını aç.',0);return end
 assert(#(pack.data.scripts or{})==0 or approved,'PAKET KODLARI / ONAY bölümünü incele ve onayla')
 Engine.canInstall(pack,replace)
 local owner=Engine.owner(mode,group.Text);log('HEDEF: '..owner.label);progress('GÖRSELLER YÜKLENİYOR',.55)
 local ids=Engine.upload(pack,owner,plugin,readManual(),log,function()return canceled or dead end,function(done,total,key)progress('YÜKLEME '..done..' / '..total,.55+.3*done/math.max(1,total))end)
 assert(not canceled and not dead and not Run:IsRunning(),'İptal/Play açık; assetler önbellekte kaldı')
 local rec=History:TryBeginRecording('UIPProInstall','UI Studio 5: '..pack.data.title);assert(rec,'Undo kaydı başlatılamadı')
 local staged;local ok,err=xpcall(function()staged=Engine.stage(pack,ids,owner,approved);assert(not Run:IsRunning()and not canceled and not dead,'Kurulum commit öncesi iptal edildi');lastInstall=Engine.commit(staged,replace,pack.data.id)end,debug.traceback)
 if not ok then if staged then for _,r in ipairs(staged)do if r.object.Parent==nil then r.object:Destroy()end end end;History:FinishRecording(rec,Enum.FinishRecordingOperation.Cancel);error(err,0)end
 History:FinishRecording(rec,Enum.FinishRecordingOperation.Commit);progress('KURULDU • Play ve asset erişimini kontrol et',1);log('UI + görsel ID’leri + VFX şablonları + paket kodları kuruldu. Cloud assetler undo ile silinmez.')
 local refs={};for _,id in pairs(ids)do table.insert(refs,id)end;task.spawn(function()local good,why=pcall(function()game:GetService('ContentProvider'):PreloadAsync(refs,function(id,status)log('ASSET_FETCH '..id..' '..tostring(status))end)end);if not good then log(tostring(why))end end)
end)end
install.Activated:Connect(installPack)
undoButton.Activated:Connect(function()operation(function()assert(not Run:IsRunning()and lastInstall,'Play kapalı ve son kurulum mevcut olmalı');local rec=History:TryBeginRecording('UIPProUndo','UI Studio 5 geri al');assert(rec,'Undo kaydı başlatılamadı');local ok,err=pcall(Engine.undo,lastInstall);History:FinishRecording(rec,ok and Enum.FinishRecordingOperation.Commit or Enum.FinishRecordingOperation.Cancel);assert(ok,err);lastInstall=nil;progress('OYUN İÇERİĞİ GERİ ALINDI',.4)end)end)
cancelButton.Activated:Connect(function()if busy then canceled=true;log('İptal istendi; sürmekte olan Roblox çağrısından sonra durur.')end end)
-- Local named library. This stores the full ZIP, not a stale File/temporary image ID.
local adapter={}
function adapter:get(k)return plugin:GetSetting(k)end
function adapter:set(k,v)plugin:SetSetting(k,v)end
function adapter:uuid()return game:GetService('HttpService'):GenerateGUID(false)end
local library=Library.new(adapter)
local function tab(text,x)
 local b=make('TextButton',root,{Position=UDim2.fromOffset(x,82),Size=UDim2.fromOffset(116,30),Text=text,Font=Enum.Font.GothamBold,TextSize=11,TextColor3=C.white,BackgroundColor3=C.card,AutoButtonColor=false,BorderSizePixel=0});round(b,9);return b
end
local packageTab=tab('PAKET',18);local libraryTab=tab('KAYDEDİLENLER',144)
local libPanel=make('Frame',root,{Position=UDim2.fromOffset(18,122),Size=UDim2.new(0,242,1,-140),BackgroundTransparency=1,Visible=false})
local search=make('TextBox',libPanel,{Size=UDim2.new(1,-8,0,39),Text='',PlaceholderText='Kaydedilen UI ara…',TextSize=12,Font=Enum.Font.Gotham,TextColor3=C.white,PlaceholderColor3=C.muted,BackgroundColor3=C.card,ClearTextOnFocus=false,BorderSizePixel=0});round(search)
local libraryStatus=label(libPanel,'Yerel kütüphane',11,C.muted,UDim2.fromOffset(0,44),UDim2.new(1,-8,0,28))
local list=make('ScrollingFrame',libPanel,{Position=UDim2.fromOffset(0,80),Size=UDim2.new(1,-8,1,-194),BackgroundTransparency=1,BorderSizePixel=0,ScrollBarThickness=3,CanvasSize=UDim2.new(),AutomaticCanvasSize=Enum.AutomaticSize.Y});make('UIListLayout',list,{Padding=UDim.new(0,8),SortOrder=Enum.SortOrder.LayoutOrder})
local function lb(t,x,w,color)
 local b=make('TextButton',libPanel,{Position=UDim2.new(0,x,1,-103),Size=UDim2.new(0,w,0,44),Text=t,TextSize=13,Font=Enum.Font.GothamBold,TextColor3=C.white,BackgroundColor3=color,BorderSizePixel=0});round(b);return b
end
local libInstall=lb('OYUNA YÜKLE',0,139,Color3.fromRGB(64,214,16));local libDelete=lb('SİL',146,70,Color3.fromRGB(242,45,75))
local libSave=make('TextButton',libPanel,{Position=UDim2.new(0,0,1,-51),Size=UDim2.new(1,-8,0,44),Text='AKTİF UI’YI İSİMLE KAYDET',TextSize=11,Font=Enum.Font.GothamBold,TextColor3=C.white,BackgroundColor3=Color3.fromRGB(174,65,246),BorderSizePixel=0});round(libSave)
local pendingDelete
refreshLibrary=function()
 for _,x in ipairs(list:GetChildren())do if x:IsA('GuiObject')then x:Destroy()end end
 local ok,rows=pcall(library.list,library,search.Text)
 if not ok then libraryStatus.Text='Kütüphane okunamadı';log(tostring(rows));return end
 libraryStatus.Text=#rows..' kayıt • seçince sağda önizlenir';libDelete.Text='SİL';pendingDelete=nil
 if #rows==0 then local empty=label(list,'Henüz kayıt yok. Bir ZIP açıp İSİMLE KAYDET kullan. Kayıtlar bu bilgisayarda tutulur.',13,C.muted,nil,UDim2.new(1,-10,0,100));empty.LayoutOrder=1 end
 for i,e in ipairs(rows)do
  local b=make('TextButton',list,{Size=UDim2.new(1,-6,0,83),LayoutOrder=i,Text='',BackgroundColor3=e.id==selectedLibraryId and Color3.fromRGB(0,195,255)or C.card,AutoButtonColor=false,BorderSizePixel=0});round(b,11)
  local badge=icon(b,'Folder',UDim2.fromOffset(10,20),34)
  local name=label(b,e.name,13,C.white,UDim2.fromOffset(60,10),UDim2.new(1,-70,0,34));name.Font=Enum.Font.GothamBold
  label(b,tostring(e.assetCount)..' görsel • '..string.format('%.0f KB',e.bytes/1024)..'\n'..os.date('%d.%m.%Y %H:%M',e.updated),10,C.muted,UDim2.fromOffset(60,45),UDim2.new(1,-70,0,31))
  b.Activated:Connect(function()if busy then return end;operation(function()local raw,entry=library:load(e.id);local value=Engine.load(raw);selectedLibraryId=e.id;currentSavedName=entry.name;refreshLibrary();acceptPack(value,'Kayıt: '..entry.name)end)end)
 end
end
local function setTab(saved)
 if busy then return end;left.Visible=not saved;libPanel.Visible=saved;packageTab.BackgroundColor3=saved and C.card or Color3.fromRGB(0,195,255);libraryTab.BackgroundColor3=saved and Color3.fromRGB(0,195,255)or C.card;if saved then refreshLibrary()end
end
packageTab.Activated:Connect(function()setTab(false)end);libraryTab.Activated:Connect(function()setTab(true)end)
search:GetPropertyChangedSignal('Text'):Connect(function()if not busy then refreshLibrary()end end)
local saveModal
openSave=function()
 if busy or not pack then log('Kaydetmek için önce bir UI paketi aç');return end
 if saveModal then saveModal:Destroy()end
 local captured=pack
 saveModal=make('Frame',root,{AnchorPoint=Vector2.new(.5,.5),Position=UDim2.fromScale(.5,.5),Size=UDim2.fromOffset(510,274),BackgroundColor3=C.bg,Active=true,ZIndex=150});round(saveModal,16);Theme.panel(saveModal,Color3.fromRGB(0,210,255),Color3.fromRGB(0,96,245),true)
 local h=label(saveModal,'UI KÜTÜPHANENE KAYDET',18,C.white,UDim2.fromOffset(24,18),UDim2.new(1,-48,0,32));h.Font=Enum.Font.GothamBold;h.ZIndex=151
 local n=make('TextBox',saveModal,{Position=UDim2.fromOffset(24,65),Size=UDim2.new(1,-48,0,44),Text=currentSavedName or pack.data.title,ClearTextOnFocus=false,PlaceholderText='UI adı gir',Font=Enum.Font.Gotham,TextSize=14,TextColor3=C.white,BackgroundColor3=C.card,BorderSizePixel=0,ZIndex=151});round(n,9)
 local overwrite=false;local ow=make('TextButton',saveModal,{Position=UDim2.fromOffset(24,119),Size=UDim2.new(1,-48,0,32),Text='[ ] Aynı isim varsa açıkça üzerine yaz',Font=Enum.Font.Gotham,TextSize=12,TextColor3=C.muted,BackgroundTransparency=1,ZIndex=151})
 ow.Activated:Connect(function()overwrite=not overwrite;ow.Text=(overwrite and'[✓] 'or'[ ] ')..'Aynı isim varsa açıkça üzerine yaz'end)
 local msg=label(saveModal,'Tam paket yerel olarak saklanır. Tekrar ZIP seçmeden açabilirsin. Bu işlem oyuna/cloud’a yükleme yapmaz.',11,C.muted,UDim2.fromOffset(24,156),UDim2.new(1,-48,0,44));msg.ZIndex=151
 local yes=make('TextButton',saveModal,{Position=UDim2.fromOffset(24,216),Size=UDim2.fromOffset(300,38),Text='KAYDET',Font=Enum.Font.GothamBold,TextSize=12,TextColor3=C.white,BackgroundColor3=Color3.fromRGB(64,214,16),BorderSizePixel=0,ZIndex=151});round(yes,9)
 local no=make('TextButton',saveModal,{Position=UDim2.fromOffset(334,216),Size=UDim2.fromOffset(152,38),Text='İPTAL',TextSize=12,TextColor3=C.white,BackgroundColor3=C.card,BorderSizePixel=0,ZIndex=151});round(no,9)
 no.Activated:Connect(function()if not busy then saveModal:Destroy();saveModal=nil end end)
 yes.Activated:Connect(function()if busy then return end;local name=n.Text;local replaceName=overwrite;operation(function()
  assert(pack==captured,'Paket değişti; kaydetmeyi yeniden aç');progress('YEREL KAYIT YAZILIYOR',.65)
  local entry=library:save(name,assert(captured.raw,'ZIP byte verisi eksik'),{title=captured.data.title,packageId=captured.data.id,assetCount=#captured.data.assets},replaceName)
  selectedLibraryId=entry.id;currentSavedName=entry.name;saveModal:Destroy();saveModal=nil;refreshLibrary();progress('KAYDEDİLDİ • '..entry.name,.4);log('Yerel kayıt byte readback doğrulandı: '..entry.name)
 end)end)
end
saveButton.Activated:Connect(openSave);libSave.Activated:Connect(openSave)
libInstall.Activated:Connect(function()if not selectedLibraryId then log('Önce kayıt seç');return end;installPack()end)
libDelete.Activated:Connect(function()
 if busy or not selectedLibraryId then return end
 if pendingDelete~=selectedLibraryId then pendingDelete=selectedLibraryId;libDelete.Text='EMİN MİSİN?';return end
 local id=selectedLibraryId;operation(function()local entry=library:delete(id);selectedLibraryId=nil;refreshLibrary();log('Yalnız kütüphane kaydı silindi: '..entry.name..' • oyun UI’sı/cloud assetler korunur');progress('KÜTÜPHANE KAYDI SİLİNDİ',.4)end)
end)
setTab(false)
toggle.Click:Connect(function()widget.Enabled=not widget.Enabled end);widget:GetPropertyChangedSignal('Enabled'):Connect(function()toggle:SetActive(widget.Enabled);if widget.Enabled and not Bridge.ready and openAuth then openAuth()end end);toggle:SetActive(false)
plugin.Unloading:Connect(function()dead=true;canceled=true;Bridge.forget();clearPreview();widget:Destroy()end)
log('UI Studio 5 / Open Cloud köprü. Native yürütme bu ortamda test edilmedi.')
-- First-open setup; keys are NEVER written to plugin settings or journal.
local authOverlay;local authWorking=false
openAuth=function()
 if authOverlay then return end
 authOverlay=make('Frame',root,{Size=UDim2.fromScale(1,1),BackgroundColor3=Color3.fromRGB(18,22,39),BackgroundTransparency=.12,Active=true,ZIndex=250})
 local panel=make('Frame',authOverlay,{Position=UDim2.fromScale(.5,.5),AnchorPoint=Vector2.new(.5,.5),Size=UDim2.fromOffset(490,376),BackgroundColor3=C.bg,ZIndex=251});round(panel,18);Theme.panel(panel,Color3.fromRGB(0,228,255),Color3.fromRGB(0,102,255),false)
 icon(panel,'Verify',UDim2.fromOffset(24,24),42,252)
 local heading=label(panel,'ROBLOX BAĞLANTISI',20,C.white,UDim2.fromOffset(81,24),UDim2.fromOffset(370,29));heading.Font=Enum.Font.GothamBold;heading.ZIndex=252
 local sub=label(panel,'OPEN CLOUD  /  YEREL VE ÖZEL',9,C.accent,UDim2.fromOffset(82,56),UDim2.fromOffset(330,18));sub.ZIndex=252
 local inner=make('Frame',panel,{Position=UDim2.fromOffset(18,84),Size=UDim2.fromOffset(454,180),ZIndex=252});Theme.panel(inner,Color3.fromRGB(28,40,52),Color3.fromRGB(15,25,38),false)
 local desc=label(panel,'Önce Kopru_Baslat.cmd açık olsun. API anahtarını buraya yapıştır. Anahtar dosyaya veya loglara kaydedilmez; yerel köprü RAM’inde kalır.',12,C.muted,UDim2.fromOffset(24,90),UDim2.fromOffset(442,60));desc.ZIndex=252
 local box=make('TextBox',panel,{Position=UDim2.fromOffset(24,163),Size=UDim2.fromOffset(442,46),Text='',PlaceholderText='',ClearTextOnFocus=false,TextTransparency=1,TextSize=14,BackgroundColor3=Color3.fromRGB(18,24,32),ZIndex=252});round(box,9)
 local mask=label(box,'API anahtarını yapıştır…',13,C.muted,UDim2.fromOffset(13,0),UDim2.new(1,-26,1,0));mask.ZIndex=253
 box:GetPropertyChangedSignal('Text'):Connect(function()mask.Text=#box.Text==0 and'API anahtarını yapıştır…'or string.rep('•',math.min(42,#box.Text))end)
 local msg=label(panel,'Bağlanmak asset yüklemez. Yetki ilk gerçek upload’da doğrulanır.',10,C.muted,UDim2.fromOffset(24,218),UDim2.fromOffset(442,45));msg.ZIndex=252
 local connect=make('TextButton',panel,{Position=UDim2.fromOffset(24,278),Size=UDim2.fromOffset(442,43),Text='GÜVENLİ YEREL BAĞLANTIYI AÇ',TextSize=12,Font=Enum.Font.GothamBold,TextColor3=Color3.new(1,1,1),BackgroundColor3=Color3.fromRGB(64,215,18),ZIndex=252});round(connect,10)
 local later=make('TextButton',panel,{Position=UDim2.fromOffset(123,331),Size=UDim2.fromOffset(244,23),Text='ŞİMDİLİK KAPAT',TextSize=10,Font=Enum.Font.GothamBold,TextColor3=C.muted,BackgroundColor3=Color3.fromRGB(236,60,91),ZIndex=252})
 later.Activated:Connect(function()if authWorking then return end;box.Text='';authOverlay:Destroy();authOverlay=nil;widget.Enabled=false end)
 connect.Activated:Connect(function()
  if authWorking then return end
  local key=box.Text:match('^%s*(.-)%s*$');box.Text=''
  if #key<20 then msg.Text='Anahtarı eksiksiz yapıştır. Anahtarın kendisi gösterilmez.';return end
  authWorking=true;connect.Text='YEREL KÖPRÜYE BAĞLANIYOR…'
  task.spawn(function()
   local ok,result=pcall(Bridge.connect,key);key=nil;authWorking=false
   if dead then return end
   if ok then authOverlay:Destroy();authOverlay=nil;connection.Text='BAĞLANTI HAZIR';progress('ZIP AÇMAYA HAZIR',0);log('Yerel köprü oturumu açık. Roblox upload yetkisi henüz sınanmadı.')
   else msg.Text=tostring(result);connect.Text='TEKRAR BAĞLAN' end
  end)
 end)
end
connection.Activated:Connect(function()if not busy then openAuth()end end)
