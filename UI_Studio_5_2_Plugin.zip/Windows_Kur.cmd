@echo off
setlocal
chcp 65001 >nul
set "UIPRO_SOURCE=%~dp0UI_Paket_Pro.lua"
echo UI STUDIO 5.2 - YEREL PLUGIN KURULUMU
echo Once eski kopru konsolunu ve Roblox Studioyu kapat.
powershell.exe -NoProfile -Command "& { $ErrorActionPreference='Stop'; try { if (Get-Process RobloxStudioBeta -ErrorAction SilentlyContinue) { throw 'Once Roblox Studioyu kapat.' }; $src=$env:UIPRO_SOURCE; if (!(Test-Path -LiteralPath $src)) { throw 'ZIP dosyasinin tamamini once cikart.' }; $folder=Join-Path $env:LOCALAPPDATA 'Roblox\Plugins'; $answer=Read-Host ('Hedef: '+$folder+' | E=Kur, K=Klasor sec, diger=iptal'); if ($answer -match '^[Kk]$') { Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; if ($d.ShowDialog() -ne 'OK') { exit 2 }; $folder=$d.SelectedPath } elseif ($answer -notmatch '^[Ee]$') { exit 2 }; New-Item -ItemType Directory -Path $folder -Force | Out-Null; $dst=Join-Path $folder 'UI_Paket_Pro.lua'; if (Test-Path -LiteralPath $dst) { Copy-Item -LiteralPath $dst -Destination ($dst+'.backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss')) }; Copy-Item -LiteralPath $src -Destination $dst -Force; if ((Get-FileHash -LiteralPath $src).Hash -ne (Get-FileHash -LiteralPath $dst).Hash) { throw 'Kopya hash dogrulanamadi' }; Write-Host 'PLUGIN KURULDU. Eski farkli isimli plugin kopyalarini devre disi birak.'; } catch { Write-Host $_.Exception.Message; exit 1 } }"
if errorlevel 1 goto done
start "UI Studio 5 Yerel Kopru" cmd /c ""%~dp0Kopru_Baslat.cmd""
echo Kopru acilacak. Ardindan Studioyu ac, UI Studio dugmesine bas.
:done
pause
endlocal
