from pathlib import Path
import json,zipfile,io,subprocess,zlib,random,hashlib
from PIL import Image
R=Path(__file__).resolve().parents[1];CLI=R.parent/'.cache/luau/luau';COMP=CLI.with_name('luau-compile')
def literal(v):
 if isinstance(v,bytes):return '"'+''.join(chr(b)if 32<=b<127 and b not in [34,92]else '\\'+f'{b:03d}'for b in v)+'"'
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 if v is None:return 'nil'
 if v is True:return 'true'
 if v is False:return 'false'
 if isinstance(v,(int,float)):return str(v)
 if isinstance(v,list):return '{'+','.join(map(literal,v))+'}'
 return '{'+','.join('['+literal(k)+']='+literal(x)for k,x in v.items())+'}'
lines=["local B=require('../src/Binary');local S=require('../src/Schema')","local tests=0;local function good(f)f();tests+=1 end;local function bad(f)local ok=pcall(f);assert(not ok,'Expected rejection');tests+=1 end"]
rng=random.Random(8)
for raw in [b'',b'hello'*1000,bytes(rng.randrange(256)for _ in range(24000)),bytes(range(256))*32]:
 for strategy in [zlib.Z_DEFAULT_STRATEGY,zlib.Z_FIXED]:
  c=zlib.compressobj(6,zlib.DEFLATED,-15,8,strategy);packed=c.compress(raw)+c.flush()
  lines.append(f'good(function()assert(B.inflate({literal(packed)},{len(raw)})=={literal(raw)})end)')
 lines.append(f'good(function()assert(B.crc({literal(raw)})=={zlib.crc32(raw)})end)')
for method in [zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED]:
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',method)as z:z.writestr('manifest.json','{}');z.writestr('images/test.rgba',b'rgba'*200)
 raw=buf.getvalue();lines.append(f'good(function()local z=B.zip({literal(raw)});assert(z:read("images/test.rgba")==string.rep("rgba",200))end)')
with zipfile.ZipFile(R/'tests/fixture.zip')as z:
 d=json.loads(z.read('manifest.json'));entries={name:{'size':len(z.read(name))}for name in z.namelist()};rgba_ok=[]
 for a in d['assets']:
  im=Image.open(io.BytesIO(z.read(a['png']))).convert('RGBA');assert im.size==(a['width'],a['height'])and im.tobytes()==z.read(a['rgba']);rgba_ok.append(a['key'])
 lines.append('local d='+literal(d)+';local z={entries='+literal(entries)+'}')
 def count(n):return 1+sum(count(c)for c in n.get('children',[]))
 lines.append('good(function()assert(S.validate(d,z)=='+str(count(d['tree']))+')end)')
 lines.append("bad(function()local x=table.clone(d);x.tree={class='LocalScript',name='Bad'};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.tree={class='Frame',name='Root',props={Source='arbitrary'}};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.tree={class='Frame',name='Root',props={Size={math.huge,0,0,1}}};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.tree={class='ImageLabel',name='Root',asset='missing'};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.tree={class='Frame',name='Root',action='http'};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.tree={class='Frame',name='Root',children={{class='Frame',name='Root'}}};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.controller='missing';S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.scripts={{name='Bad',kind='Script',target='Shared',path='code/ShopController.luau'}};S.validate(x,z)end)")
 lines.append("bad(function()local x=table.clone(d);x.vfx={{name='FX',texture='absent'}};S.validate(x,z)end)")
 for a in d['assets']:lines.append(f'good(function()local z=B.zip({literal((R/"tests/fixture.zip").read_bytes())});assert(#z:read({literal(a["rgba"])})=={a["width"]*a["height"]*4})end)')
for name in ['../escape','/absolute','a\\b','C:evil']:
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w')as z:z.writestr(name,b'bad')
 lines.append(f'bad(function()B.zip({literal(buf.getvalue())})end)')
lines.append('bad(function()B.zip("not a zip")end)')
# CRC must reject altered STORED data even when structure is intact.
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_STORED)as z:z.writestr('x',b'ABCDE')
corrupt=buf.getvalue().replace(b'ABCDE',b'ABCDF');lines.append(f'bad(function()B.zip({literal(corrupt)}):read("x")end)')
lines.append("print('OFFLINE_BINARY_SCHEMA_PASS',tests)")
(R/'tests/GeneratedSpec.luau').write_text('\n'.join(lines))
compiled=[]
for p in sorted(list((R/'src').glob('*.luau'))+[R/'UI_Paket_Pro.lua',R/'tests/Runtime_Generated.luau']+list((R/'demo/code').glob('*.luau'))):
 subprocess.run([str(COMP),str(p)],stdout=subprocess.DEVNULL,check=True);compiled.append(str(p.relative_to(R)))
r=subprocess.run([str(CLI),str(R/'tests/GeneratedSpec.luau')],capture_output=True,text=True,check=True);print(r.stdout)
mock=(R/'tests/engine_mock_prefix.luau').read_text()+'\nlocal E=(function()\n'+(R/'src/Engine.luau').read_text()+'\nend)()\n'+(R/'tests/engine_mock_suffix.luau').read_text()
(R/'tests/EngineGeneratedSpec.luau').write_text(mock)
mr=subprocess.run([str(CLI),str(R/'tests/EngineGeneratedSpec.luau')],capture_output=True,text=True,check=True);print(mr.stdout)
tx=(R/'tests/transaction_mock.luau').read_text()+'\nlocal E=(function()\n'+(R/'src/Engine.luau').read_text()+'\nend)()\n'+(R/'tests/transaction_suffix.luau').read_text()
(R/'tests/TransactionsGenerated.luau').write_text(tx)
tr=subprocess.run([str(CLI),str(R/'tests/TransactionsGenerated.luau')],capture_output=True,text=True,check=True);print(tr.stdout)
lib='local Binary=(function()\n'+(R/'src/Binary.luau').read_text()+'\nend)()\nlocal Library=(function()\n'+(R/'src/Library.luau').read_text()+'\nend)()\n'+(R/'tests/library_spec_body.luau').read_text()
(R/'tests/LibraryGenerated.luau').write_text(lib)
lr=subprocess.run([str(CLI),str(R/'tests/LibraryGenerated.luau')],capture_output=True,text=True,check=True);print(lr.stdout)
report={'native_library_restart_persistence':'NOT_RUN','offline_library_MOCK_NOT_NATIVE':lr.stdout.strip(),'offline_transaction_NOT_NATIVE':tr.stdout.strip(),'windows_installer_execution':'NOT_RUN','native_controller_preview_execution':'NOT_RUN','native_particle_rendering':'NOT_RUN','offline_binary_schema':r.stdout.strip(),'offline_mock_contract_NOT_NATIVE':mr.stdout.strip(),'compiled':compiled,'png_rgba_pixel_parity':rgba_ok,'native_plugin_execution':'NOT_RUN','native_image_upload_permissions':'NOT_RUN','native_group_upload':'NOT_RUN','native_motion_playback':'NOT_RUN','native_undo':'NOT_RUN','native_save_reopen':'NOT_RUN','native_fps':'NOT_MEASURED'}
(R/'tests/results.json').write_text(json.dumps(report,indent=2));print('OFFLINE_PASS; NATIVE_NOT_RUN')

for name in ["GeneratedSpec.luau","EngineGeneratedSpec.luau","TransactionsGenerated.luau","LibraryGenerated.luau"]:(R/"tests"/name).unlink(missing_ok=True)
