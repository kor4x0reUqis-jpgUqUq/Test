from pathlib import Path
import json,zlib,subprocess
R=Path(__file__).resolve().parents[1];CLI=R.parent/'.cache/luau/luau'
raw=bytes(range(256))*8192
c=zlib.compressobj(6,zlib.DEFLATED,-15);packed=c.compress(raw)+c.flush()
def lit(v):return '"'+''.join('\\'+f'{b:03d}'for b in v)+'"'
script='local yields=0;local task={wait=function()yields+=1 end}\n'
for var,p in [('Old',R/'tests/Binary_before_perf.luau'),('New',R/'src/Binary.luau')]:script+='local '+var+'=(function()\n'+p.read_text()+'\nend)()\n'
script+='local raw=string.rep('+lit(bytes(range(256)))+',8192);local packed='+lit(packed)+'\n'
script+='''yields=0;local start=os.clock();assert(Old.inflate(packed,#raw)==raw);local oc=Old.crc(raw);local ot=os.clock()-start;local oy=yields
yields=0;start=os.clock();assert(New.inflate(packed,#raw)==raw);assert(New.crc(raw)==oc);local nt=os.clock()-start;local ny=yields
assert(ny<oy,'Forced-yield regression')
print('PERF_BUDGET_PASS',oy,ny,ot,nt,'NOT_STUDIO_SECONDS')
'''
p=R/'tests/Perf_Generated.luau';p.write_text(script)
try:
 result=subprocess.run([str(CLI),str(p)],capture_output=True,text=True,check=True);print(result.stdout)
 fields=result.stdout.strip().split();report={'fixture_bytes':len(raw),'old_forced_yields':int(fields[1]),'new_budget_yields':int(fields[2]),'old_CPU_seconds':float(fields[3]),'new_CPU_seconds':float(fields[4]),'scope':'Luau CLI, fake wait counts; NOT Studio elapsed speed/FPS benchmark'}
 (R/'tests/performance_results.json').write_text(json.dumps(report,indent=2))
finally:p.unlink(missing_ok=True)
