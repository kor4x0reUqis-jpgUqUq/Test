from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1];CLI=R.parent/'.cache/luau/luau'
prefix='''local main=coroutine.running();local threads={};local ticks=0
local task={}
function task.spawn(fn)local co=coroutine.create(fn);threads[#threads+1]=co;assert(coroutine.resume(co))end
function task.wait()
 if coroutine.running()~=main then return coroutine.yield()end
 ticks+=1;assert(ticks<100,'deadlock')
 for _,co in ipairs(threads)do if coroutine.status(co)~='dead'then local ok,err=coroutine.resume(co);assert(ok,err)end end
end
local Enum={CreatorType={Group='group'}};local game={GetService=function()return{}end}
local active=0;local maxActive=0;local uploads=0;local deny=false
local Bridge={}
function Bridge.upload(pack,a,owner,cancel,log)
 for _,v in ipairs(pack.data.assets)do assert(pack.zip.verified[v.png]and pack.zip.verified[v.rgba],'Uploaded before all CRC checks')end
 active+=1;maxActive=math.max(maxActive,active);uploads+=1
 task.wait();task.wait()
 active-=1
 if deny and a.key=='a1'then error('first cloud error')end
 assert(not cancel(),'Canceled other worker')
 return tostring(1000+tonumber(a.key:sub(2)))
end
local E=(function()
'''
suffix='''
end)()
local pack={data={id='Parallel',title='Mock',assets={}},zip={entries={},verified={},reads=0}}
for i=1,4 do local k='a'..i;pack.data.assets[i]={key=k,png=k..'.png',rgba=k..'.rgba',width=1,height=1};pack.zip.entries[k..'.rgba']={crc=i}end
function pack.zip:read(n)self.reads+=1;self.verified[n]=true;return'x'end
local cache={};local plugin={GetSetting=function()return cache end,SetSetting=function(_,k,v)cache=v end}
local tests=0;local function good(fn)fn();tests+=1 end
local owner={id=12,group=true,label='group'}
good(function()local ids=E.upload(pack,owner,plugin,{},function()end,function()return false end);assert(ids.a4=='rbxassetid://1004');assert(maxActive==2 and active==0 and uploads==4);assert(pack.zip.reads==8)end)
good(function()local n=uploads;E.upload(pack,owner,plugin,{},function()end,function()return false end);assert(uploads==n and pack.zip.reads==8)end)
good(function()cache={};deny=true;local ok,err=pcall(E.upload,pack,owner,plugin,{},function()end,function()return false end);assert(not ok and tostring(err):find('first cloud error'));assert(active==0)end)
good(function()assert(maxActive<=2);for _,co in ipairs(threads)do assert(coroutine.status(co)=='dead')end end)
print('PARALLEL_ENGINE_PASS',tests,'MOCK_NOT_NATIVE')
'''
p=R/'tests/Parallel_Generated.luau';p.write_text(prefix+(R/'src/Engine.luau').read_text()+suffix)
try:print(subprocess.run([str(CLI),str(p)],capture_output=True,text=True,check=True).stdout)
finally:p.unlink(missing_ok=True)
