import base64, hashlib, importlib.util, io, json, struct, sys, tempfile, threading, time, unittest, urllib.request, urllib.error, zlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('bridge',R/'bridge/bridge.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
KEY='TEST_ONLY_NOT_A_REAL_ROBLOX_KEY'
def png():
 def chunk(t,b):return struct.pack('>I',len(b))+t+b+struct.pack('>I',zlib.crc32(t+b))
 return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',1,1,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(bytes([0,10,20,30,255])))+chunk(b'IEND',b'')
def payload(kind='group',ident='456'):
 return {'creator':{'kind':kind,'id':ident},'name':'Test','png':base64.b64encode(png()).decode()}
class Remote:
 def __init__(self):self.posts=0;self.gets=0;self.mode='ok';self.body=None
 def __call__(self,method,path,key,data=None,content_type=None):
  assert key==KEY
  if method=='POST':
   self.posts+=1;self.body=data
   if self.mode=='denied':raise m.Problem('Forbidden',403)
   if self.mode=='unknown':raise m.Problem('Unknown',502)
   return {'path':'operations/mock_1'}
  self.gets+=1
  if self.mode=='pending_once' and self.gets<=4:raise m.Problem('Transient',502)
  if self.mode=='poll429' and self.gets==1:raise m.Problem('Rate limit',429)
  if self.mode=='failed_operation':return {'done':True,'error':{'code':3}}
  return {'done':True,'response':{'assetId':'987654321'}}
class TestBridge(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.remote=Remote();self.state=m.State(Path(self.tmp.name)/'cache.json',self.remote,lambda x:None);self.config=self.state.configure(KEY)
 def tearDown(self):self.state.pool.shutdown(wait=True);self.tmp.cleanup()
 def job(self,p=None):
  result=self.state.submit(p or payload());j=result['job']
  for i in range(300):
   with self.state.lock:d=dict(self.state.jobs[j])
   if d['status']!='running':return d
   time.sleep(.002)
  self.fail('worker did not finish')
 def test_01_key_memory_only(self):
  self.assertFalse(self.state.path.exists());self.assertTrue(self.state.authorized(self.config['token']));self.assertFalse(self.state.authorized('wrong'))
 def test_02_format(self):
  for key in ['',None,'short','bad\n'+KEY]:
   with self.assertRaises(m.Problem):self.state.configure(key)
 def test_03_real_shape_and_creator(self):
  d=self.job();self.assertEqual(d['assetId'],'987654321');self.assertIn(b'"assetType": "Image"',self.remote.body);self.assertIn(b'"groupId": "456"',self.remote.body)
 def test_04_cache_dedup(self):
  self.job();self.job();self.assertEqual(self.remote.posts,1)
 def test_05_owner_isolation(self):
  self.job();self.job(payload('user','456'));self.assertEqual(self.remote.posts,2)
 def test_06_no_secrets_on_disk(self):
  self.job();raw=self.state.path.read_text();self.assertNotIn(KEY,raw);self.assertNotIn(self.config['token'],raw)
 def test_07_denied_retry_no_owner_fallback(self):
  self.remote.mode='denied';self.assertEqual(self.job()['status'],'error');self.assertEqual(self.state.cache,{})
  self.remote.mode='ok';self.assertEqual(self.job()['status'],'done');self.assertEqual(self.remote.posts,2)
 def test_08_uncertain_never_repost(self):
  self.remote.mode='unknown';self.assertEqual(self.job()['status'],'error')
  with self.assertRaises(m.Problem):self.job()
  self.assertEqual(self.remote.posts,1)
 def test_09_pending_resume(self):
  self.remote.mode='pending_once';self.assertEqual(self.job()['status'],'error');self.assertEqual(self.job()['status'],'done');self.assertEqual(self.remote.posts,1)
 def test_10_cache_restart(self):
  self.job();other=m.State(self.state.path,self.remote,lambda x:None);other.configure(KEY)
  try:
   j=other.submit(payload())['job']
   for i in range(100):
    if other.jobs[j]['status']=='done':break
    time.sleep(.002)
   self.assertEqual(other.jobs[j]['assetId'],'987654321');self.assertEqual(self.remote.posts,1)
  finally:other.pool.shutdown(wait=True)
 def test_11_invalid_png_creator(self):
  for d in [payload('bad'),payload(ident='0'),{**payload(),'png':'bad'}, {**payload(),'name':''}]:
   with self.assertRaises(m.Problem):self.state.submit(d)
 def test_12_multipart(self):
  body,ctype=m.multipart(png(),{'assetType':'Image'});self.assertIn(b'name="request"',body);self.assertIn(b'name="fileContent"',body);self.assertIn(png(),body);self.assertTrue(ctype.startswith('multipart/form-data; boundary='))
 def test_13_poll_rate_limit(self):
  self.remote.mode='poll429';self.assertEqual(self.job()['status'],'done');self.assertEqual(self.remote.posts,1)
 def test_14_operation_failed(self):
  self.remote.mode='failed_operation';self.assertEqual(self.job()['status'],'error');self.assertFalse(self.state.cache)
 def test_15_session_expiry(self):
  self.state.expires=0;self.assertFalse(self.state.authorized(self.config['token']))
 def test_16_http_boundaries(self):
  server=m.make_server(0,self.state);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();base='http://127.0.0.1:'+str(server.server_port)
  def call(path,method='GET',data=None,headers=None):
   req=urllib.request.Request(base+path,data=json.dumps(data).encode()if data is not None else None,method=method,headers=headers or {})
   try:
    with urllib.request.urlopen(req,timeout=5)as res:return res.status,json.load(res)
   except urllib.error.HTTPError as e:return e.code,json.load(e)
  try:
   self.assertEqual(call('/health')[1]['app'],'UIStudio5')
   self.assertEqual(call('/health',headers={'Origin':'https://evil.example'})[0],403)
   self.assertEqual(call('/health',headers={'Host':'evil.example'})[0],403)
   self.assertEqual(call('/upload','POST',payload(),{'Content-Type':'application/json'})[0],401)
   self.assertEqual(call('/configure','POST',{'key':KEY},{'Content-Type':'text/plain'})[0],415)
   code,d=call('/configure','POST',{'key':KEY},{'Content-Type':'application/json'});self.assertEqual(code,200)
   h={'Content-Type':'application/json','Authorization':'Bearer '+d['token']}
   code,j=call('/upload','POST',payload(),h);self.assertEqual(code,202)
   for _ in range(100):
    code,out=call('/jobs/'+j['job'],headers=h)
    if out['status']!='running':break
    time.sleep(.002)
   self.assertEqual(out['status'],'done');self.assertNotIn('hash',out);self.assertNotIn(KEY,json.dumps(out))
   raw=png();_,t=call('/transfer','POST',{'name':'HTTP chunk','creator':{'kind':'group','id':'456'},'length':len(raw),'crc':zlib.crc32(raw)},h)
   self.assertEqual(call('/chunk','POST',{'transfer':t['transfer'],'seq':0,'chunk':base64.b64encode(raw).decode()},h)[0],200)
   self.assertEqual(call('/complete','POST',{'transfer':t['transfer']},h)[0],202)
   self.assertEqual(call('/configure','OPTIONS')[0],403)
  finally:server.shutdown();server.server_close();thread.join()
 def test_17_ssrf_path(self):
  with self.assertRaises(m.Problem):m.cloud('GET','https://evil.example',KEY)
 def test_18_corrupt_cache(self):
  self.state.path.write_text('broken')
  with self.assertRaises(RuntimeError):m.State(self.state.path)
 def test_19_chunk_roundtrip(self):
  raw=png();t=self.state.transfer({'name':'Chunk','creator':{'kind':'group','id':'456'},'length':len(raw),'crc':zlib.crc32(raw)})['transfer']
  self.assertEqual(self.state.append({'transfer':t,'seq':0,'chunk':base64.b64encode(raw[:30]).decode()})['next'],1)
  with self.assertRaises(m.Problem):self.state.append({'transfer':t,'seq':0,'chunk':'AA=='})
  self.state.append({'transfer':t,'seq':1,'chunk':base64.b64encode(raw[30:]).decode()})
  j=self.state.complete({'transfer':t})['job']
  for _ in range(100):
   if self.state.jobs[j]['status']!='running':break
   time.sleep(.002)
  self.assertEqual(self.state.jobs[j]['assetId'],'987654321')
 def test_20_chunk_crc(self):
  raw=png();t=self.state.transfer({'name':'CRC','creator':{'kind':'user','id':'1'},'length':len(raw),'crc':0})['transfer'];self.state.append({'transfer':t,'seq':0,'chunk':base64.b64encode(raw).decode()})
  with self.assertRaises(m.Problem):self.state.complete({'transfer':t})
  self.assertEqual(self.remote.posts,0)
 def test_21_key_rotation_clears_partial(self):
  raw=png();self.state.transfer({'name':'Partial','creator':{'kind':'user','id':'1'},'length':len(raw),'crc':zlib.crc32(raw)})
  old=self.config['token'];self.state.configure(KEY);self.assertFalse(self.state.authorized(old));self.assertFalse(self.state.transfers)
 def test_22_two_workers(self):
  barrier=threading.Barrier(2);counts={'active':0,'peak':0};lock=threading.Lock()
  def remote(method,path,key,data=None,content_type=None):
   if method=='POST':
    with lock:counts['active']+=1;counts['peak']=max(counts['peak'],counts['active'])
    try:barrier.wait(timeout=2)
    finally:
     with lock:counts['active']-=1
    return {'path':'operations/parallel'}
   return {'done':True,'response':{'assetId':'123'}}
  self.state.remote=remote;j1=self.state.submit(payload('user','1'))['job'];j2=self.state.submit(payload('group','2'))['job']
  for _ in range(1000):
   if all(self.state.jobs[j]['status']!='running'for j in [j1,j2]):break
   time.sleep(.003)
  self.assertEqual(counts['peak'],2);self.assertTrue(all(self.state.jobs[j]['status']=='done'for j in [j1,j2]))
 def test_23_post429_backoff(self):
  calls=[];sleeps=[]
  def remote(method,path,key,data=None,content_type=None):
   if method=='POST':
    calls.append(1)
    if len(calls)==1:raise m.Problem('Rate',429)
    return {'path':'operations/retry'}
   return {'done':True,'response':{'assetId':'123'}}
  self.state.remote=remote;self.state.sleep=sleeps.append
  self.assertEqual(self.job()['status'],'done');self.assertEqual(len(calls),2);self.assertEqual(sleeps,[2])
 def test_24_no_initial_poll_sleep(self):
  sleeps=[];self.state.sleep=sleeps.append
  self.assertEqual(self.job()['status'],'done');self.assertEqual(sleeps,[])
 def test_25_safe_get_retry(self):
  calls=[];sleeps=[]
  def remote(method,path,key,data=None,content_type=None):
   if method=='POST':return {'path':'operations/get_retry'}
   calls.append(1)
   if len(calls)==1:raise m.Problem('Temporary GET',502)
   return {'done':True,'response':{'assetId':'123'}}
  self.state.remote=remote;self.state.sleep=sleeps.append
  self.assertEqual(self.job()['status'],'done');self.assertEqual(len(calls),2);self.assertEqual(sleeps,[.5])
if __name__=='__main__':unittest.main(verbosity=2)
